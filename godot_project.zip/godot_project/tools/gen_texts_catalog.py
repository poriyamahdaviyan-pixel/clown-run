#!/usr/bin/env python3
"""فهرست کامل متن‌های فارسیِ داخل کد را می‌سازد (scripts/texts_catalog.gd) تا در «ویرایش محتوا ← متن‌ها»
دسته‌بندی‌شده و جستجوپذیر باشند. بعد از افزودن متن جدید به بازی، یک‌بار اجرا کن:  python3 tools/gen_texts_catalog.py"""
import re, glob, os
ADMIN = 'پنل مدیر'
CAT = {
 'modes.gd': 'جهان‌ها و پرتال', 'modes_ext.gd': 'جهان‌ها و پرتال', 'ui.gd': 'منو و صفحه‌های اصلی', 'settings_screen.gd': 'تنظیمات',
 'game.gd': 'پیام‌ها، پاداش و قدرت‌ها', 'track.gd': 'پیام‌های مسیر', 'online_screens.gd': 'حساب، فروشگاه و جدول', 'char_shop.gd': 'کاراکتر و فروشگاه',
 'online.gd': 'حساب و آنلاین', 'updater.gd': 'حساب و آنلاین', 'competitive.gd': 'رقابت و لیگ', 'power_shop.gd': 'فروشگاه قدرت‌ها',
 'rules.gd': 'قوانین و اسکین‌ها', 'skins.gd': 'قوانین و اسکین‌ها', 'skin_lib.gd': 'قوانین و اسکین‌ها', 'coin_skin.gd': 'قوانین و اسکین‌ها',
 'music.gd': 'صدا و موسیقی', 'sound_panel.gd': 'صدا و موسیقی', 'sfx.gd': 'صدا و موسیقی',
 'look_fx.gd': 'ظاهر و محیط', 'hud_fx.gd': 'ظاهر و محیط', 'world.gd': 'ظاهر و محیط', 'player.gd': 'ظاهر و محیط', 'police_cfg.gd': 'ظاهر و محیط', 'ui_art.gd': 'ظاهر و محیط',
}
for f in ['content.gd', 'content_editor.gd', 'store_admin.gd', 'release_admin.gd', 'store_studio.gd', 'studio.gd', 'item_studio.gd', 'item_preview.gd',
          'model_import.gd', 'file_picker.gd', 'skin_canvas.gd', 'glb_model.gd', 'local_preview.gd', 'edition.gd']:
    CAT[f] = ADMIN
ORDER = ['جهان‌ها و پرتال', 'بازی‌های مستقل', 'منو و صفحه‌های اصلی', 'تنظیمات', 'پیام‌ها، پاداش و قدرت‌ها', 'پیام‌های مسیر', 'کاراکتر و فروشگاه',
         'فروشگاه قدرت‌ها', 'حساب، فروشگاه و جدول', 'رقابت و لیگ', 'حساب و آنلاین', 'قوانین و اسکین‌ها', 'صدا و موسیقی', 'ظاهر و محیط', ADMIN, 'سایر']
lit = re.compile(r'"((?:[^"\\\n]|\\.)*)"')
fa = re.compile(r'[\u0600-\u06FF]')
root = os.path.join(os.path.dirname(__file__), '..')
seen = {}
for f in sorted(glob.glob(os.path.join(root, 'scripts', '*.gd'))):
    b = os.path.basename(f)
    if b in ('texts_catalog.gd', 'content_data.gd'):
        continue
    cat = 'بازی‌های مستقل' if b.startswith('mini_') else CAT.get(b, 'سایر')
    for line in open(f, encoding='utf-8'):
        if line.strip().startswith('#'):
            continue
        line = re.sub(r'\s#\s.*$', '', line) if '"' not in line.split('#')[-1] else line
        lcat = 'بازی‌های مستقل' if (b == 'modes.gd' and '"kind": "mini"' in line) else cat
        for m in lit.finditer(line):
            t = m.group(1)
            if not fa.search(t):
                continue
            t = t.replace('\\n', '\n').replace('\\"', '"').replace('\\\\', '\\')
            if len(t.strip()) < 3 or len(t) > 160 or t.startswith('res://') or t.startswith('http'):
                continue
            if t not in seen or ORDER.index(lcat) < ORDER.index(seen[t]):
                seen[t] = lcat
def esc(s):
    return s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
rows = sorted(seen.items(), key=lambda kv: (ORDER.index(kv[1]), kv[0]))
out = ['# تولیدشده با tools/gen_texts_catalog.py — دستی ویرایش نکن', 'class_name TextsCatalog', 'extends RefCounted', '',
       'const CATS: Array[String] = [' + ', '.join('"%s"' % c for c in ORDER) + ']', '', 'const ROWS: Array = [']
for t, c in rows:
    out.append('\t["%s", %d],' % (esc(t), ORDER.index(c)))
out.append(']')
open(os.path.join(root, 'scripts', 'texts_catalog.gd'), 'w', encoding='utf-8').write('\n'.join(out) + '\n')
print(len(rows), 'texts')
