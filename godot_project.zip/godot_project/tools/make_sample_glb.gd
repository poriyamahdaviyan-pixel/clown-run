extends SceneTree
## ساخت دو مدل نمونه‌ی GLB (رو به +Z مثل استاندارد glTF):
##  samples/sample_robot.glb  : ربات با کلیپ انیمیشن «run»
##  samples/sample_rigged.glb : انسان‌نمای اسکلت‌دار (نام استخوان‌ها مثل Mixamo) بدون کلیپ → حرکت‌ها با کد ساخته می‌شود
## اجرا: godot --headless --path . -s res://tools/make_sample_glb.gd

func _mat(c: Color, metal := 0.2) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metal
	m.roughness = 0.5
	return m

func _box(parent: Node3D, nm: String, size: Vector3, pos: Vector3, col: Color, metal := 0.2) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = nm
	var m := BoxMesh.new()
	m.size = size
	mi.mesh = m
	mi.material_override = _mat(col, metal)
	mi.position = pos
	parent.add_child(mi)
	return mi

func _own(root: Node) -> void:
	for n in root.find_children("*", "", true, false):
		n.owner = root

func _write(root: Node3D, path: String) -> void:
	var doc := GLTFDocument.new()
	var st := GLTFState.new()
	print(path, " append=", doc.append_from_scene(root, st), " write=", doc.write_to_filesystem(st, path))

func _robot() -> void:
	var root := Node3D.new()
	root.name = "SampleRobot"
	_box(root, "Body", Vector3(0.5, 0.6, 0.3), Vector3(0, 1.05, 0), Color("2f7bff"))
	_box(root, "Head", Vector3(0.38, 0.34, 0.34), Vector3(0, 1.55, 0), Color("c8ccd6"), 0.6)
	_box(root, "EyeL", Vector3(0.08, 0.06, 0.02), Vector3(-0.09, 1.58, 0.18), Color("27f3ff"))
	_box(root, "EyeR", Vector3(0.08, 0.06, 0.02), Vector3(0.09, 1.58, 0.18), Color("27f3ff"))
	_box(root, "Antenna", Vector3(0.03, 0.2, 0.03), Vector3(0, 1.82, 0), Color("ffb02e"))
	var limbs := {"ArmL": Vector3(-0.35, 1.3, 0), "ArmR": Vector3(0.35, 1.3, 0), "LegL": Vector3(-0.13, 0.75, 0), "LegR": Vector3(0.13, 0.75, 0)}
	for nm in limbs:
		var n := Node3D.new()
		n.name = nm
		n.position = limbs[nm]
		root.add_child(n)
		var leg := String(nm).begins_with("Leg")
		_box(n, nm + "Mesh", Vector3(0.17, 0.75, 0.17) if leg else Vector3(0.14, 0.55, 0.14), Vector3(0, -0.375 if leg else -0.25, 0), Color("3a3a44") if leg else Color("c8ccd6"), 0.2 if leg else 0.6)
	var ap := AnimationPlayer.new()
	ap.name = "AnimationPlayer"
	root.add_child(ap)
	var anim := Animation.new()
	anim.length = 0.8
	anim.loop_mode = Animation.LOOP_LINEAR
	for pair in [["ArmL", 1.0], ["ArmR", -1.0], ["LegL", -1.0], ["LegR", 1.0]]:
		var tr := anim.add_track(Animation.TYPE_ROTATION_3D)
		anim.track_set_path(tr, NodePath(str(pair[0])))
		for i in 5:
			anim.rotation_track_insert_key(tr, float(i) * 0.2, Quaternion(Vector3.RIGHT, sin(float(i) / 4.0 * TAU) * 0.8 * float(pair[1])))
	var lib := AnimationLibrary.new()
	lib.add_animation("run", anim)
	ap.add_animation_library("", lib)
	_own(root)
	_write(root, "res://samples/sample_robot.glb")

func _rigged() -> void:
	var root := Node3D.new()
	root.name = "SampleHuman"
	var sk := Skeleton3D.new()
	sk.name = "Skeleton3D"
	root.add_child(sk)
	# [نام، والد، موقعیت نسبی]
	var defs := [
		["mixamorig:Hips", -1, Vector3(0, 0.95, 0)],
		["mixamorig:Spine", 0, Vector3(0, 0.2, 0)],
		["mixamorig:Head", 1, Vector3(0, 0.5, 0)],
		["mixamorig:LeftUpLeg", 0, Vector3(-0.12, 0, 0)],
		["mixamorig:LeftLeg", 3, Vector3(0, -0.45, 0)],
		["mixamorig:LeftFoot", 4, Vector3(0, -0.42, 0)],
		["mixamorig:RightUpLeg", 0, Vector3(0.12, 0, 0)],
		["mixamorig:RightLeg", 6, Vector3(0, -0.45, 0)],
		["mixamorig:RightFoot", 7, Vector3(0, -0.42, 0)],
		["mixamorig:LeftArm", 1, Vector3(-0.3, 0.38, 0)],
		["mixamorig:LeftForeArm", 9, Vector3(0, -0.3, 0)],
		["mixamorig:LeftHand", 10, Vector3(0, -0.28, 0)],
		["mixamorig:RightArm", 1, Vector3(0.3, 0.38, 0)],
		["mixamorig:RightForeArm", 12, Vector3(0, -0.3, 0)],
		["mixamorig:RightHand", 13, Vector3(0, -0.28, 0)],
	]
	for d in defs:
		var i := sk.add_bone(d[0])
		sk.set_bone_parent(i, d[1])
		sk.set_bone_rest(i, Transform3D(Basis.IDENTITY, d[2]))
	sk.reset_bone_poses()
	# قطعه‌ها: [نام، استخوان، مرکز (فضای اسکلت)، اندازه، رنگ]
	var parts := [
		["Pelvis", 0, Vector3(0, 0.98, 0), Vector3(0.36, 0.2, 0.22), Color("2a3a7a")],
		["Torso", 1, Vector3(0, 1.3, 0), Vector3(0.44, 0.5, 0.26), Color("e0243c")],
		["Head", 2, Vector3(0, 1.82, 0), Vector3(0.3, 0.32, 0.3), Color("f0c49c")],
		["Nose", 2, Vector3(0, 1.8, 0.17), Vector3(0.06, 0.06, 0.08), Color("d9a47c")],
		["ThighL", 3, Vector3(-0.12, 0.72, 0), Vector3(0.16, 0.46, 0.16), Color("2a3a7a")],
		["ShinL", 4, Vector3(-0.12, 0.28, 0), Vector3(0.14, 0.44, 0.14), Color("2a3a7a")],
		["FootL", 5, Vector3(-0.12, 0.05, 0.05), Vector3(0.14, 0.1, 0.26), Color("333333")],
		["ThighR", 6, Vector3(0.12, 0.72, 0), Vector3(0.16, 0.46, 0.16), Color("2a3a7a")],
		["ShinR", 7, Vector3(0.12, 0.28, 0), Vector3(0.14, 0.44, 0.14), Color("2a3a7a")],
		["FootR", 8, Vector3(0.12, 0.05, 0.05), Vector3(0.14, 0.1, 0.26), Color("333333")],
		["UpperArmL", 9, Vector3(-0.3, 1.5, 0), Vector3(0.12, 0.34, 0.12), Color("e0243c")],
		["ForeArmL", 10, Vector3(-0.3, 1.2, 0), Vector3(0.1, 0.3, 0.1), Color("f0c49c")],
		["UpperArmR", 12, Vector3(0.3, 1.5, 0), Vector3(0.12, 0.34, 0.12), Color("e0243c")],
		["ForeArmR", 13, Vector3(0.3, 1.2, 0), Vector3(0.1, 0.3, 0.1), Color("f0c49c")],
	]
	var skin := Skin.new()
	for i in sk.get_bone_count():
		skin.add_bind(i, sk.get_bone_global_rest(i).affine_inverse())
	for p in parts:
		var bm := BoxMesh.new()
		bm.size = p[3]
		var arrays := bm.get_mesh_arrays()
		var verts: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var bones := PackedInt32Array()
		var weights := PackedFloat32Array()
		for v in verts.size():
			verts[v] += p[2]
			bones.append_array(PackedInt32Array([p[1], 0, 0, 0]))
			weights.append_array(PackedFloat32Array([1.0, 0.0, 0.0, 0.0]))
		arrays[Mesh.ARRAY_VERTEX] = verts
		arrays[Mesh.ARRAY_BONES] = bones
		arrays[Mesh.ARRAY_WEIGHTS] = weights
		var am := ArrayMesh.new()
		am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		am.surface_set_material(0, _mat(p[4], 0.0))
		var mi := MeshInstance3D.new()
		mi.name = p[0]
		mi.mesh = am
		sk.add_child(mi)
		mi.skeleton = NodePath("..")
		mi.skin = skin
	_own(root)
	_write(root, "res://samples/sample_rigged.glb")

func _initialize() -> void:
	_robot()
	_rigged()
	quit()
