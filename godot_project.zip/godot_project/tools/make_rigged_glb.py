"""ساخت samples/sample_rigged.glb: انسان‌نمای اسکلت‌دار (نام استخوان‌ها مثل Mixamo، رو به +Z) بدون کلیپ انیمیشن.
اجرا: python3 tools/make_rigged_glb.py"""
import json, struct

BONES = [  # name, parent, local translation
    ("mixamorig:Hips", -1, (0, .95, 0)), ("mixamorig:Spine", 0, (0, .2, 0)), ("mixamorig:Head", 1, (0, .5, 0)),
    ("mixamorig:LeftUpLeg", 0, (-.12, 0, 0)), ("mixamorig:LeftLeg", 3, (0, -.45, 0)), ("mixamorig:LeftFoot", 4, (0, -.42, 0)),
    ("mixamorig:RightUpLeg", 0, (.12, 0, 0)), ("mixamorig:RightLeg", 6, (0, -.45, 0)), ("mixamorig:RightFoot", 7, (0, -.42, 0)),
    ("mixamorig:LeftArm", 1, (-.3, .38, 0)), ("mixamorig:LeftForeArm", 9, (0, -.3, 0)), ("mixamorig:LeftHand", 10, (0, -.28, 0)),
    ("mixamorig:RightArm", 1, (.3, .38, 0)), ("mixamorig:RightForeArm", 12, (0, -.3, 0)), ("mixamorig:RightHand", 13, (0, -.28, 0)),
]
PARTS = [  # name, bone, center, size, color
    ("Pelvis", 0, (0, .98, 0), (.36, .2, .22), (.16, .23, .48)), ("Torso", 1, (0, 1.3, 0), (.44, .5, .26), (.88, .14, .24)),
    ("Head", 2, (0, 1.82, 0), (.3, .32, .3), (.94, .77, .61)), ("Nose", 2, (0, 1.8, .17), (.06, .06, .08), (.85, .64, .49)),
    ("ThighL", 3, (-.12, .72, 0), (.16, .46, .16), (.16, .23, .48)), ("ShinL", 4, (-.12, .28, 0), (.14, .44, .14), (.16, .23, .48)),
    ("FootL", 5, (-.12, .05, .05), (.14, .1, .26), (.2, .2, .2)),
    ("ThighR", 6, (.12, .72, 0), (.16, .46, .16), (.16, .23, .48)), ("ShinR", 7, (.12, .28, 0), (.14, .44, .14), (.16, .23, .48)),
    ("FootR", 8, (.12, .05, .05), (.14, .1, .26), (.2, .2, .2)),
    ("UpperArmL", 9, (-.3, 1.5, 0), (.12, .34, .12), (.88, .14, .24)), ("ForeArmL", 10, (-.3, 1.2, 0), (.1, .3, .1), (.94, .77, .61)),
    ("UpperArmR", 12, (.3, 1.5, 0), (.12, .34, .12), (.88, .14, .24)), ("ForeArmR", 13, (.3, 1.2, 0), (.1, .3, .1), (.94, .77, .61)),
]

def glob(i):
    p, t = BONES[i][1], BONES[i][2]
    if p < 0: return t
    g = glob(p); return (g[0]+t[0], g[1]+t[1], g[2]+t[2])

def box(c, s):
    hx, hy, hz = s[0]/2, s[1]/2, s[2]/2
    faces = [((1,0,0),[(hx,-hy,-hz),(hx,hy,-hz),(hx,hy,hz),(hx,-hy,hz)]), ((-1,0,0),[(-hx,-hy,hz),(-hx,hy,hz),(-hx,hy,-hz),(-hx,-hy,-hz)]),
             ((0,1,0),[(-hx,hy,-hz),(-hx,hy,hz),(hx,hy,hz),(hx,hy,-hz)]), ((0,-1,0),[(-hx,-hy,hz),(-hx,-hy,-hz),(hx,-hy,-hz),(hx,-hy,hz)]),
             ((0,0,1),[(-hx,-hy,hz),(hx,-hy,hz),(hx,hy,hz),(-hx,hy,hz)]), ((0,0,-1),[(hx,-hy,-hz),(-hx,-hy,-hz),(-hx,hy,-hz),(hx,hy,-hz)])]
    pos, nor, idx = [], [], []
    for n, vs in faces:
        b = len(pos)
        for v in vs:
            pos.append((v[0]+c[0], v[1]+c[1], v[2]+c[2])); nor.append(n)
        idx += [b, b+1, b+2, b, b+2, b+3]
    return pos, nor, idx

buf = bytearray(); views = []; accs = []
def add(data, target=None):
    while len(buf) % 4: buf.append(0)
    views.append({"buffer": 0, "byteOffset": len(buf), "byteLength": len(data), **({"target": target} if target else {})})
    buf.extend(data); return len(views)-1
def acc(view, ctype, count, typ, mn=None, mx=None):
    a = {"bufferView": view, "componentType": ctype, "count": count, "type": typ}
    if mn: a["min"], a["max"] = mn, mx
    accs.append(a); return len(accs)-1

nodes = []; meshes = []; mats = []
for i, (nm, p, t) in enumerate(BONES):
    nodes.append({"name": nm, "translation": list(t)})
for i, (nm, p, t) in enumerate(BONES):
    if p >= 0: nodes[p].setdefault("children", []).append(i)
ibm = bytearray()
for i in range(len(BONES)):
    g = glob(i)
    ibm += struct.pack('<16f', 1,0,0,0, 0,1,0,0, 0,0,1,0, -g[0],-g[1],-g[2],1)
ibm_acc = acc(add(bytes(ibm)), 5126, len(BONES), "MAT4")
mesh_nodes = []
for pi, (nm, bone, c, s, col) in enumerate(PARTS):
    pos, nor, idx = box(c, s)
    pb = b''.join(struct.pack('<3f', *v) for v in pos); nb = b''.join(struct.pack('<3f', *v) for v in nor)
    jb = b''.join(struct.pack('<4B', bone, 0, 0, 0) for _ in pos); wb = b''.join(struct.pack('<4f', 1, 0, 0, 0) for _ in pos)
    ib = b''.join(struct.pack('<H', i) for i in idx)
    mn = [min(v[k] for v in pos) for k in range(3)]; mx = [max(v[k] for v in pos) for k in range(3)]
    a_pos = acc(add(pb, 34962), 5126, len(pos), "VEC3", mn, mx); a_nor = acc(add(nb, 34962), 5126, len(pos), "VEC3")
    a_j = acc(add(jb, 34962), 5121, len(pos), "VEC4"); a_w = acc(add(wb, 34962), 5126, len(pos), "VEC4")
    a_i = acc(add(ib, 34963), 5123, len(idx), "SCALAR")
    mats.append({"name": nm, "pbrMetallicRoughness": {"baseColorFactor": [*col, 1], "metallicFactor": 0, "roughnessFactor": .6}})
    meshes.append({"name": nm, "primitives": [{"attributes": {"POSITION": a_pos, "NORMAL": a_nor, "JOINTS_0": a_j, "WEIGHTS_0": a_w}, "indices": a_i, "material": pi}]})
    nodes.append({"name": nm, "mesh": pi, "skin": 0}); mesh_nodes.append(len(nodes)-1)
root = len(nodes); nodes.append({"name": "SampleHuman", "children": [0] + mesh_nodes})
gltf = {"asset": {"version": "2.0", "generator": "make_rigged_glb.py"}, "scene": 0, "scenes": [{"nodes": [root]}], "nodes": nodes,
        "meshes": meshes, "materials": mats, "skins": [{"inverseBindMatrices": ibm_acc, "joints": list(range(len(BONES))), "skeleton": 0}],
        "accessors": accs, "bufferViews": views, "buffers": [{"byteLength": len(buf)}]}
import sys, math
ANIM = len(sys.argv) > 1 and sys.argv[1] == "anim"      # python3 tools/make_rigged_glb.py anim → samples/sample_anim.glb (دو کلیپ: Jump و Wave)
if ANIM:
    def q_x(a): return (math.sin(a / 2), 0, 0, math.cos(a / 2))
    def q_z(a): return (0, 0, math.sin(a / 2), math.cos(a / 2))
    chans, samplers = [], []
    def track(node, path, times, vals, comps):
        t_acc = acc(add(b''.join(struct.pack('<f', t) for t in times)), 5126, len(times), "SCALAR", [min(times)], [max(times)])
        v_acc = acc(add(b''.join(struct.pack('<%df' % comps, *v) for v in vals)), 5126, len(vals), "VEC4" if comps == 4 else "VEC3")
        return t_acc, v_acc, node, path
    def clip(name, tracks):
        ch, sa = [], []
        for t_acc, v_acc, node, path in tracks:
            sa.append({"input": t_acc, "output": v_acc, "interpolation": "LINEAR"})
            ch.append({"sampler": len(sa) - 1, "target": {"node": node, "path": path}})
        return {"name": name, "channels": ch, "samplers": sa}
    T = [0, .3, .6]
    jump = clip("Jump", [track(0, "translation", T, [(0, .95, 0), (0, 1.5, 0), (0, .95, 0)], 3),
                         track(4, "rotation", T, [q_x(0), q_x(-1.0), q_x(0)], 4), track(7, "rotation", T, [q_x(0), q_x(-1.0), q_x(0)], 4)])
    wave = clip("Wave", [track(13, "rotation", [0, .25, .5, .75, 1.0], [q_z(0), q_z(1.2), q_z(2.0), q_z(1.2), q_z(0)], 4)])
    gltf["animations"] = [jump, wave]
    gltf["accessors"] = accs; gltf["bufferViews"] = views; gltf["buffers"] = [{"byteLength": len(buf)}]
js = json.dumps(gltf).encode()
while len(js) % 4: js += b' '
while len(buf) % 4: buf.append(0)
out = struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(buf)) + struct.pack('<I4s', len(js), b'JSON') + js + struct.pack('<I4s', len(buf), b'BIN\0') + bytes(buf)
open('samples/sample_anim.glb' if ANIM else 'samples/sample_rigged.glb', 'wb').write(out)
print("ok", len(out))
