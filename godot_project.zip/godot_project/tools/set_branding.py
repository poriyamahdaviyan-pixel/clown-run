#!/usr/bin/env python3
"""تغییر نام بازی، آیکن، نام بسته و نسخه — روی هر سه پریست (مالک، عمومی، پلی/AAB).

نیازمندی: python3 و کتابخانه‌ی Pillow  (pip install pillow)

مثال‌ها (از پوشه‌ی اصلی پروژه اجرا کن):
  python3 tools/set_branding.py --name "دلقک فراری" --icon ~/Pictures/my_icon.png
  python3 tools/set_branding.py --package com.pooria.clownrun --version-name 1.1 --version-code 2
  python3 tools/set_branding.py --name "دلقک فراری" --package com.pooria.clownrun --icon icon.png
"""
import argparse, re, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PRESETS = os.path.join(ROOT, "export_presets.cfg")
PROJECT = os.path.join(ROOT, "project.godot")
ICON_DIR = os.path.join(ROOT, "assets", "icon")


def make_icons(path):
    from PIL import Image, ImageFilter
    src = Image.open(path).convert("RGBA")
    w, h = src.size
    s = min(w, h)
    sq = src.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))
    os.makedirs(ICON_DIR, exist_ok=True)
    sq.resize((512, 512), Image.LANCZOS).save(os.path.join(ICON_DIR, "icon.png"))
    sq.resize((192, 192), Image.LANCZOS).save(os.path.join(ICON_DIR, "main_192.png"))
    sq.resize((432, 432), Image.LANCZOS).filter(ImageFilter.GaussianBlur(18)).save(os.path.join(ICON_DIR, "adaptive_bg_432.png"))
    fg = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
    fg.paste(sq.resize((300, 300), Image.LANCZOS), (66, 66))   # فاصله‌ی ایمن آیکن تطبیقی اندروید
    fg.save(os.path.join(ICON_DIR, "adaptive_fg_432.png"))
    # آیکن ۵۱۲ برای فروشگاه‌ها (Google Play / مایکت): همان assets/icon/icon.png
    print("آیکن‌ها ساخته شد: assets/icon/ (icon.png = آیکن ۵۱۲ برای فروشگاه‌ها)")


def edit_presets(fn):
    s = open(PRESETS, encoding="utf-8").read()
    parts = re.split(r"(?m)^(?=\[preset\.\d+\]$)", s)
    out = []
    for blk in parts:
        m = re.match(r"\[preset\.(\d+)\]", blk)
        if m:
            nm = re.search(r'(?m)^name="(.*)"$', blk).group(1)
            blk = fn(blk, nm)
        out.append(blk)
    open(PRESETS, "w", encoding="utf-8").write("".join(out))


def setkey(blk, key, val):
    pat = r'(?m)^%s=.*$' % re.escape(key)
    line = '%s=%s' % (key, val)
    if re.search(pat, blk):
        return re.sub(pat, lambda _m: line, blk)
    return blk.rstrip("\n") + "\n" + line + "\n"


def main():
    ap = argparse.ArgumentParser(description="تغییر نام/آیکن/بسته/نسخه‌ی بازی")
    ap.add_argument("--name", help="نام بازی (زیر آیکن روی گوشی)")
    ap.add_argument("--icon", help="مسیر عکس آیکن (PNG/JPG، ترجیحاً مربع ۱۰۲۴×۱۰۲۴)")
    ap.add_argument("--package", help="نام بسته، مثلاً com.pooria.clownrun (فقط حروف انگلیسی، عدد و نقطه)")
    ap.add_argument("--version-name", help="نام نسخه، مثلاً 1.1")
    ap.add_argument("--version-code", type=int, help="شماره‌ی نسخه (عدد صحیح؛ با هر انتشار جدید باید بیشتر شود)")
    a = ap.parse_args()
    if not any([a.name, a.icon, a.package, a.version_name, a.version_code]):
        ap.print_help()
        sys.exit(1)
    if a.package and not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", a.package):
        sys.exit("نام بسته نامعتبر است. مثال درست: com.pooria.clownrun")
    if a.icon:
        make_icons(os.path.expanduser(a.icon))
    if a.name:
        p = open(PROJECT, encoding="utf-8").read()
        p = re.sub(r'(?m)^config/name=".*"$', lambda _m: 'config/name="%s"' % a.name, p)
        open(PROJECT, "w", encoding="utf-8").write(p)

    def fn(blk, nm):
        owner = "Owner" in nm
        if a.name:
            blk = setkey(blk, "package/name", '"%s%s"' % (a.name, " (مالک)" if owner else ""))
        if a.package:
            blk = setkey(blk, "package/unique_name", '"%s%s"' % (a.package, ".owner" if owner else ""))
        if a.version_name:
            blk = setkey(blk, "version/name", '"%s"' % a.version_name)
        if a.version_code is not None:
            blk = setkey(blk, "version/code", str(a.version_code))
        if a.icon:
            blk = setkey(blk, "launcher_icons/main_192x192", '"res://assets/icon/main_192.png"')
            blk = setkey(blk, "launcher_icons/adaptive_foreground_432x432", '"res://assets/icon/adaptive_fg_432.png"')
            blk = setkey(blk, "launcher_icons/adaptive_background_432x432", '"res://assets/icon/adaptive_bg_432.png"')
        return blk
    edit_presets(fn)
    print("انجام شد. حالا دوباره Export بگیر.")


if __name__ == "__main__":
    main()
