#!/usr/bin/env bash
# یک‌بار: ساخت جفت‌کلید امضای بروزرسانی (برای کسی که روی کامپیوتر کار می‌کند).
# کلید عمومی در پروژه می‌ماند (update_key.pub)، کلید خصوصی را پیش خودت نگه‌دار و هرگز در مخزن نگذار.
set -euo pipefail
cd "$(dirname "$0")/.."
KEY="${1:-$HOME/.clownrun_update_priv.pem}"
[ -f "$KEY" ] && { echo "کلید از قبل هست: $KEY"; exit 0; }
openssl genrsa -out "$KEY" 2048
openssl rsa -in "$KEY" -pubout -out update_key.pub
chmod 600 "$KEY"
echo "کلید خصوصی: $KEY   (پشتیبان بگیر)"
echo "کلید عمومی: update_key.pub  ← حالا APK را یک‌بار دوباره بساز"
