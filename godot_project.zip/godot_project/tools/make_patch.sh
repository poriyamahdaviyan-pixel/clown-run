#!/usr/bin/env bash
# ساخت فایل وصله (build/patch.pck) برای بروزرسانی بدون نصب دوباره‌ی APK.
# استفاده:  GODOT=/path/godot ./tools/make_patch.sh
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT="${GODOT:-godot}"
mkdir -p build
"$GODOT" --headless --import
"$GODOT" --headless --export-pack "Patch" build/patch.pck
SHA=$(sha256sum build/patch.pck | cut -d' ' -f1)
echo "ساخته شد: build/patch.pck  ($(du -h build/patch.pck | cut -f1))  sha256=$SHA"
echo "حالا در نسخه‌ی مالک: حساب ← نسخه‌ها و بروزرسانی ← وصله ← انتخاب فایل ← انتشار (امضا و آپلود خودکار)"
