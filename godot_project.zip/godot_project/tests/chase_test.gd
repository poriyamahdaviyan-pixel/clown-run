extends Node
## اینترو، پلیس پشت سر (عقب‌ماندن / نزدیک‌شدن هنگام خراش)، دوربین و صداها
var fails := 0
func ok(c: bool, w: String) -> void:
	if not c:
		fails += 1
		print("[FAIL] ", w)
func frames(n: int) -> void:
	var t0 := Time.get_ticks_msec()
	for i in n:
		await get_tree().process_frame
	while Time.get_ticks_msec() - t0 < int(n * 16.7):
		await get_tree().process_frame
func _ready() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await frames(3)
	var pol = main.get_node("Police")
	Game.quit_to_menu()
	await frames(2)
	ok(not pol.visible, "police hidden in menu")
	Game.play()
	await frames(30)
	ok(Game.intro_active and not Game.is_active, "intro running")
	var seen := false
	for i in 200:
		await frames(1)
		seen = seen or pol.visible
	ok(seen, "police visible in intro")
	await frames(60)
	ok(Game.is_active and not Game.intro_active, "run started after intro")
	main.track.reset()
	main.track._cursor = -99999.0
	await frames(10)
	ok(pol.visible and pol.get_gap() < 5.0, "police right behind at start (gap=%.1f)" % pol.get_gap())
	var k0: float = pol.near_k()
	var back_chase: float = main.cam.position.z
	await frames(60 * 12)
	ok(not pol.visible and pol.get_gap() > 15.0, "police fell behind (gap=%.1f)" % pol.get_gap())
	var back_free: float = main.cam.position.z
	ok(back_free < back_chase - 1.5, "camera comes closer after escape (%.1f -> %.1f)" % [back_chase, back_free])
	ok(k0 > 0.5, "police near at start")
	# صدای هر کاراکتر
	ok(Game.voice_of("a") >= 0 and Sfx.VOICES.size() == 6, "voice profiles")
	Game.set_voice("zz", 4)
	ok(Game.voice_of("zz") == 4, "owner voice override")
	# خراش: پلیس می‌آید، بعد برمی‌گردد
	main.player.invuln = 0.0
	var r: String = Game.register_obstacle_hit(true)
	ok(r == "stumble", "graze = stumble")
	await frames(60 * 2)
	ok(pol.visible and pol.get_gap() < 4.0, "police closes in after graze (gap=%.1f)" % pol.get_gap())
	await frames(60 * 20)
	ok(not pol.visible and Game.is_active, "police fell back again (gap=%.1f)" % pol.get_gap())
	# برخورد کامل = مرگ
	main.player.invuln = 0.0
	ok(Game.register_obstacle_hit(false) == "caught" and Game.over, "full crash ends run")
	await frames(150)
	ok(pol.get_gap() < 2.0, "police catches the player")
	# صدا
	ok(Sfx.CAT["siren"] == "police" and Game.vol.has("police") and Game.vol.has("master"), "sound categories")
	print("[CHASETEST] ", "FAILED" if fails > 0 else "PASSED")
	get_tree().quit(1 if fails > 0 else 0)
