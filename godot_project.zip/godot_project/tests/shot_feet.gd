extends Node
## نمای نزدیک از پای کاراکتر (فقط برای تست). SHOT_GLB=مسیر فایل (اختیاری)
var main
var f := 0
var cam: Camera3D
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var g := OS.get_environment("SHOT_GLB")
	if g != "":
		Skins.add_glb(g, "تست")
	Game.start_run()
	Game.jet_grace = 99999.0
	cam = Camera3D.new()
	add_child(cam)
func _process(_d: float) -> void:
	f += 1
	var p = main.player
	cam.current = true
	cam.global_position = Vector3(p.position.x + 1.6, 0.7, 2.4)
	cam.look_at(Vector3(p.position.x, 0.5, 0.0), Vector3.UP)
	cam.fov = 45
	if f == 60 or f == 61:
		pass
	if f == 80:
		get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT_DIR") + "/feet_run.png")
	if f == 100:
		p.slide()
	if f == 112:
		get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT_DIR") + "/feet_slide.png")
	if f == 150:
		p.jump()
	if f == 168:
		get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT_DIR") + "/feet_jump.png")
		get_tree().quit()
