extends Node
## انتشار APK/وصله، لینک دانلود، بررسی بروزرسانی و دانلود وصله‌ی امضادار (سرور ساختگی)
const RA := preload("res://scripts/release_admin.gd")
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var nm := "rl%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	var ra = RA.new()
	add_child(ra)
	ra.ui = null
	if FileAccess.file_exists(RA.PRIV_PATH): DirAccess.remove_absolute(RA.PRIV_PATH)
	ok(ra.make_keys() and ra.has_private_key(), "signing keys made")
	# امضا و راستی‌آزمایی
	var sha := "ab" .repeat(32)
	var sig := Updater.sign(1, 5, sha, ra.private_pem())
	ok(sig != "" and Updater.verify(1, 5, sha, sig, ra.public_pem()), "signature verifies with own public key")
	ok(not Updater.verify(1, 6, sha, sig, ra.public_pem()), "signature rejects other version")
	ok(not Updater.verify(1, 5, "cd".repeat(32), sig, ra.public_pem()), "signature rejects other hash")
	# فایل pck ساختگی (GDPC)
	var fake := PackedByteArray([0x47, 0x44, 0x50, 0x43]); for i in 3000: fake.append(i % 251)
	var pp := ProjectSettings.globalize_path("user://fake_patch.pck")
	var f := FileAccess.open(pp, FileAccess.WRITE); f.store_buffer(fake); f.close()
	var bad := ProjectSettings.globalize_path("user://not_pack.pck")
	f = FileAccess.open(bad, FileAccess.WRITE); f.store_string("hello world this is not a pack"); f.close()
	var rb: Dictionary = await ra.publish_patch(bad, 3, "x", "", false)
	ok(not rb.ok, "non-pck rejected: " + String(rb.error))
	Online.SINGLE_MAX = 1000; Online.CHUNK = 900     # آزمایش تکه‌تکه
	var rp: Dictionary = await ra.publish_patch(pp, 3, "1.3", "رفع باگ", false)
	ok(rp.ok, "patch published: " + str(rp.get("error", "")))
	Online.SINGLE_MAX = 45 * 1024 * 1024; Online.CHUNK = 40 * 1024 * 1024
	# APK با لینک بیرونی
	var ra2: Dictionary = await ra.publish_apk("", "https://example.com/game.apk", 9, "2.0", "نسخه‌ی بزرگ", false)
	ok(ra2.ok, "external apk published")
	var rbad: Dictionary = await ra.publish_apk("", "http://insecure/x.apk", 10, "2.1", "", false)
	ok(not rbad.ok, "http link rejected")
	# APK کوچک مستقیم
	var apkp := ProjectSettings.globalize_path("user://t.apk")
	f = FileAccess.open(apkp, FileAccess.WRITE); f.store_buffer(fake); f.close()
	var rd: Dictionary = await ra.publish_apk(apkp, "", 11, "2.2", "", false)
	ok(rd.ok and Updater.link_of(rd.row).contains("/storage/v1/object/public/releases/apk/"), "small apk gets direct public link")
	Online.SINGLE_MAX = 1000
	var rbig: Dictionary = await ra.publish_apk(apkp, "", 12, "2.3", "", false)
	ok(not rbig.ok and String(rbig.error).contains("GitHub"), "big apk asks for external link")
	Online.SINGLE_MAX = 45 * 1024 * 1024
	var all: Array = await ra.list_all()
	ok(all.size() == 3, "list has 3 releases: %d" % all.size())
	# بررسی بروزرسانی: وصله برای ساخت دیگر نادیده گرفته می‌شود
	ok(Updater.key_ok == FileAccess.file_exists(Updater.PUB_KEY), "key_ok reflects res://update_key.pub")
	Updater.key_ok = true
	await Updater.check()
	ok(Updater.apk_info.get("version_code", 0) == 11, "newest apk detected (11): " + str(Updater.apk_info.get("version_code", 0)))
	ok(Updater.patch_info.get("version_code", 0) == 3, "patch for this build detected")
	# دانلود: امضا با کلید داخل بازی نمی‌خواند (کلید تست من داخل res:// نیست) → باید رد شود
	var dl: Dictionary = await Updater.download_patch()
	ok(not dl.ok, "patch not installed when signature key differs: " + String(dl.get("error", "")))
	ok(Updater.active.is_empty(), "no active patch after rejection")
	# پنهان‌سازی و حذف
	await ra.set_published(rd.row, false)
	await Updater.check()
	ok(Updater.apk_info.get("version_code", 0) == 9, "unpublished apk disappears for players")
	var del: Dictionary = await ra.delete_release(rp.row)
	ok(del.ok, "patch deleted")
	all = await ra.list_all()
	ok(all.size() == 2, "list after delete: %d" % all.size())
	print("[RELEASE] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
