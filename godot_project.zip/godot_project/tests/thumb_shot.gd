extends Node
const ThumbMaker := preload("res://scripts/thumb_maker.gd")
func _ready() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var ui = main.ui
	var im := Image.create(256, 256, false, Image.FORMAT_RGBA8)
	im.fill(Color(0, 0, 0, 0))
	for y in 256:
		for x in 256:
			var d := Vector2(x - 128, y - 128).length()
			if d < 120:
				var c := Color("ffc21a") if d > 95 or (absf(x - 128) < 14 and y > 60 and y < 200) or (absf(y - 128) < 14 and x > 60 and x < 200) else Color("c0392b")
				im.set_pixel(x, y, c)
	im.save_png("user://coin_t.png")
	var cases := [["glb", ProjectSettings.globalize_path("res://samples/sample_anim.glb"), {}, 2], ["coin", ProjectSettings.globalize_path("user://coin_t.png"), {}], ["glb", ProjectSettings.globalize_path("res://samples/sample_anim.glb"), {}], ["voice", "", {"event": "jump"}], ["anim_clip", "", {"clip": "Wave"}]]
	for c in cases:
		var png: PackedByteArray = await ThumbMaker.make(ui, self, c[0], c[1], c[2], int(c[3]) if c.size() > 3 else 0)
		print("THUMB ", c[0], " bytes=", png.size())
		if not png.is_empty():
			var f := FileAccess.open("/tmp/th_%s%s.png" % [c[0], "_r" if c.size() > 3 else ""], FileAccess.WRITE)
			f.store_buffer(png)
			f.close()
	get_tree().quit()
