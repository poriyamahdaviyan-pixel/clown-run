extends Node
## استودیوی فروشگاه: انیمیشن از روی فایل مدل، خرید، نصب روی رویداد، مالک
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _wav() -> PackedByteArray:
	var n := 2400
	var pcm := PackedByteArray()
	for i in n:
		var v := int(sin(float(i) * 0.2) * 9000.0)
		pcm.append(v & 0xff); pcm.append((v >> 8) & 0xff)
	var h := PackedByteArray()
	h.append_array("RIFF".to_ascii_buffer()); h.append_array(PackedByteArray([0, 0, 0, 0]))
	h.append_array("WAVEfmt ".to_ascii_buffer())
	h.append_array(PackedByteArray([16, 0, 0, 0, 1, 0, 1, 0, 0x40, 0x1f, 0, 0, 0x80, 0x3e, 0, 0, 2, 0, 16, 0]))
	h.append_array("data".to_ascii_buffer())
	h.append_array(PackedByteArray([n * 2 & 0xff, (n * 2 >> 8) & 0xff, 0, 0]))
	h.append_array(pcm)
	var sz := h.size() - 8
	h[4] = sz & 0xff; h[5] = (sz >> 8) & 0xff
	return h
func _count(n: Node, cls: String) -> int:
	var c := 1 if n.is_class(cls) else 0
	for ch in n.get_children(): c += _count(ch, cls)
	return c
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var nm := "st%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await _post("/__test/coins/%s/500" % nm)
	await Online.refresh_profile()
	var ui = main.ui
	var scr = ui._online
	var st = scr.studio
	ok(st != null, "studio exists")
	Skins.add_glb(ProjectSettings.globalize_path("res://samples/sample_anim.glb"), "الف")
	var e: Dictionary = Skins.current_entry()
	var key := Skins.char_key(e)
	Content.set_char_default(key, "Wave", true)
	var j := await Online.admin_save_item({"kind": "anim_clip", "name": "Jump", "price": 30, "status": "approved", "payload": {"char": key, "clip": "Jump"}})
	ok(j.ok, "admin sells Jump clip")
	await Online.admin_upload("voice/s.wav", _wav(), "audio/wav")
	var v := await Online.admin_save_item({"kind": "voice", "name": "پرش ویژه", "price": 20, "status": "approved", "file_path": "voice/s.wav", "payload": {"char": key, "event": "jump", "pv": ""}})
	ok(v.ok, "admin sells jump voice")
	await Online.load_items()
	# ---- مالک: صفحه‌ی استودیو
	Edition.simulate_public = false
	scr.store_filter = "@chars"
	st.sel_key = key
	st.tab = "anim"
	scr.refresh_store()
	await get_tree().process_frame
	await get_tree().process_frame
	ok(ui._pv.has("studio"), "live stage created")
	ok(st._list != null and st._list.get_child_count() >= 2, "anim list: free Wave + sale Jump (%d rows)" % st._list.get_child_count())
	ok(_count(st._col, "OptionButton") >= 1, "slot picker for free clip")
	var clips: Array = st._clips_of(e)
	ok("Wave" in clips and "Jump" in clips, "clips read from the model file itself: %s" % str(clips))
	# ---- اختصاص کلیپ رایگان به رویداد
	var eid := String(e.id)
	Rules.set_slot(eid, "jump", "anim", "clip:Wave")
	st.tab = "slots"; st._fill()
	await get_tree().process_frame
	ok(Rules.slot_event_of(eid, "clip:Wave", "anim") == "jump", "free clip equipped on jump")
	ok(st._list.get_child_count() >= 2, "slots tab shows equipped event")
	# ---- بازیکن: خرید و نصب
	Online.sign_out()
	var pn := "pl%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(pn, "secret1")
	await _post("/__test/coins/%s/200" % pn)
	await Online.refresh_profile()
	await Online.load_items()
	Edition.simulate_public = true
	Content.apply_remote({"abilities": {"store_anim": true, "store_voice": true, "chooser": true, "store_chars": true}, "store": {}})
	st.tab = "anim"; st._fill()
	await get_tree().process_frame
	var rows_pub: int = st._list.get_child_count()
	ok(rows_pub >= 2, "public sees free + sale clips (%d)" % rows_pub)
	var jump_it: Dictionary = Online.items_of_char(key, "anim_clip")[0]
	await st._buy(jump_it)
	ok(Online.is_owned(jump_it), "bought clip in studio")
	var lib := false
	for le in Rules.library:
		if String(le.get("clip", "")) == "Jump": lib = true
	ok(lib, "installed clip in library")
	var voice_it: Dictionary = Online.items_of_char(key, "voice")[0]
	Content.apply_remote({"abilities": {"store_anim": true, "store_voice": true, "chooser": true}})
	await st._buy(voice_it)
	await get_tree().process_frame
	ok(Rules.slot_of(eid, "jump", "sound") == String(voice_it.id), "bought voice auto-equipped on jump")
	# ---- پیش‌نمایش: کاراکتر می‌پرد
	st._stage_act("clip:Jump", 1.0)
	st._stage_act("jump", 1.0)
	ok(true, "stage actions run")
	# ---- مالک‌مود
	for i in 3:
		scr.refresh_store()
		await get_tree().process_frame
		await get_tree().process_frame
		print("STEP rebuild ", i)
	print("STEP owner")
	Edition.simulate_public = false
	Online.sign_out()
	print("STEP so")
	await Online.sign_in(nm, "secret1")
	print("STEP si")
	await Online.refresh_profile()
	await st._toggle_owner()
	print("STEP toggled")
	await get_tree().process_frame
	ok(st.owner_mode and st._list.get_child_count() >= 1, "owner mode shows manager rows")
	st.show_perms = true; st._fill()
	await get_tree().process_frame
	ok(_count(st._list, "Button") > 20, "owner perms panel inside store")
	ok(ui._pv["studio"]["cam"] != null, "camera orbit registered")
	ui.preview_zoom("studio", 1.5)
	ok(float(ui._pv["studio"]["zoom"]) > 1.4, "zoom works")
	print("PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()

