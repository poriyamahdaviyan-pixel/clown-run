extends Node
## تست منطق استودیو: تقارن، واگرد، پرکردن، تبدیل بازو، خروجی، پریست‌ها، عکس→اسکین
const SkinLib := preload("res://scripts/skin_lib.gd")
const SkinCanvas := preload("res://scripts/skin_canvas.gd")
var fails := 0

func ok(c: bool, w: String) -> void:
	if not c:
		fails += 1
		print("[FAIL] ", w)

func _ready() -> void:
	# --- تقارن ---
	for slim in [false, true]:
		var bad := 0
		for y in 64:
			for x in 64:
				var p := Vector2i(x, y)
				var loc := SkinLib.locate(p, slim)
				if loc.is_empty():
					continue
				var m := SkinLib.mirror_of(p, slim, 2)
				if m.x < 0:
					bad += 1
					continue
				# آینه‌ی آینه باید خودش باشد
				var mm := SkinLib.mirror_of(m, slim, 2)
				if mm != p:
					bad += 1
		ok(bad == 0, "mirror involution slim=%s bad=%d" % [slim, bad])
	# دست راست جلو (۴۴،۲۰) ↔ دست چپ جلو (۳۶،۵۲)  در کلاسیک
	var m1 := SkinLib.mirror_of(Vector2i(44, 20), false, 1)
	ok(m1 == Vector2i(39, 52) or m1.x >= 0, "arm mirror exists")
	ok(SkinLib.mirror_of(Vector2i(20, 20), false, 1).x < 0, "smart sym ignores body")
	ok(SkinLib.mirror_of(Vector2i(20, 20), false, 2).x >= 0, "full sym mirrors body")
	# --- بوم ---
	var cv := SkinCanvas.new()
	cv.size = Vector2(640, 640)
	add_child(cv)
	cv.load_image(SkinLib.preset(4), false, false)
	cv.clear_history()
	cv.set_sym(1)
	cv.set_color(Color(1, 0, 0))
	cv.set_brush(1)
	var p0 := Vector2i(44, 20)  # جلوی دست راست
	cv._begin(Vector2(44.5 * 10.0, 20.5 * 10.0))
	cv._end()
	var m := SkinLib.mirror_of(p0, false, 1)
	ok(cv.image.get_pixelv(p0).is_equal_approx(Color(1, 0, 0)), "pen paints")
	ok(m.x >= 0 and cv.image.get_pixelv(m).is_equal_approx(Color(1, 0, 0)), "mirror painted")
	ok(cv.undo_count() == 1, "one undo step")
	cv.undo()
	ok(not cv.image.get_pixelv(p0).is_equal_approx(Color(1, 0, 0)), "undo restores")
	cv.redo()
	ok(cv.image.get_pixelv(p0).is_equal_approx(Color(1, 0, 0)), "redo")
	# سقف ۲۵
	cv.clear_history()
	cv.set_sym(0)
	for i in 40:
		cv.set_color(Color(i / 40.0, 0.5, 0.2))
		cv._begin(Vector2((8 + i % 8) * 10.0 + 5.0, (8 + i / 8) * 10.0 + 5.0))
		cv._end()
	ok(cv.undo_count() == 25, "undo capped at 25 (got %d)" % cv.undo_count())
	# پاک‌کن روی لایه‌ی اول ممنوع، روی روکش مجاز
	cv.set_tool(SkinCanvas.Tool.ERASER)
	var base_px := Vector2i(12, 12)
	var before := cv.image.get_pixelv(base_px)
	cv._begin(Vector2(12 * 10.0 + 5.0, 12 * 10.0 + 5.0))
	cv._end()
	ok(cv.image.get_pixelv(base_px) == before, "eraser blocked on base layer")
	cv.set_tool(SkinCanvas.Tool.PEN)
	cv.set_color(Color(0, 1, 0))
	var hat_px := Vector2i(40, 12)  # روکش سر
	ok(cv.face_id(hat_px) >= 0 and not cv.is_base_layer(hat_px), "hat pixel is overlay")
	cv._begin(Vector2(40 * 10.0 + 5.0, 12 * 10.0 + 5.0))
	cv._end()
	ok(cv.image.get_pixelv(hat_px).a > 0.99, "painted overlay")
	cv.set_tool(SkinCanvas.Tool.ERASER)
	cv._begin(Vector2(40 * 10.0 + 5.0, 12 * 10.0 + 5.0))
	cv._end()
	ok(cv.image.get_pixelv(hat_px).a < 0.01, "eraser works on overlay")
	# پرکردن
	cv.set_tool(SkinCanvas.Tool.FILL)
	cv.set_color(Color(0, 0, 1))
	cv.set_sym(0)
	var face_r := SkinLib.face_rect(SkinLib.BODY, SkinLib.Face.FRONT)
	cv._begin(Vector2((face_r.position.x + 1) * 10.0 + 5.0, (face_r.position.y + 6) * 10.0 + 5.0))
	cv._end()
	var all_blue := true
	var other_untouched := cv.image.get_pixelv(Vector2i(face_r.position.x - 1, face_r.position.y + 6)) != Color(0, 0, 1)
	for y in range(face_r.position.y, face_r.end.y):
		for x in range(face_r.position.x, face_r.end.x):
			if cv.image.get_pixel(x, y).is_equal_approx(Color(1, 1, 1)):
				pass
	ok(cv.image.get_pixel(face_r.position.x + 1, face_r.position.y + 6).is_equal_approx(Color(0, 0, 1)), "fill paints")
	ok(other_untouched, "fill stays in face")
	# قطره
	cv.set_tool(SkinCanvas.Tool.PICKER)
	cv.set_color(Color(0.3, 0.3, 0.3))
	cv._begin(Vector2((face_r.position.x + 1) * 10.0 + 5.0, (face_r.position.y + 6) * 10.0 + 5.0))
	cv._end()
	ok(cv.color.is_equal_approx(Color(0, 0, 1)) and cv.tool == SkinCanvas.Tool.FILL, "picker picks and returns to previous tool")
	# قلم ۴ پیکسلی فقط در یک وجه
	cv.set_tool(SkinCanvas.Tool.PEN)
	cv.set_brush(4)
	cv.set_color(Color(1, 1, 0))
	var fp := cv._footprint(Vector2i(face_r.position.x, face_r.position.y))
	for q in fp:
		if cv.face_id(q) != cv.face_id(Vector2i(face_r.position.x, face_r.position.y)):
			ok(false, "brush leaks")
	ok(fp.size() >= 4 and fp.size() <= 16, "brush footprint size %d" % fp.size())
	# تبدیل بازو
	var img := SkinLib.preset(5)
	var orig := img.duplicate() as Image
	SkinLib.convert_arms(img, false, true)
	var fin := SkinLib.finalize_for_export(img, true)
	ok(SkinLib.detect_slim(fin), "slim export detected as slim")
	SkinLib.convert_arms(img, true, false)
	ok(not SkinLib.detect_slim(SkinLib.finalize_for_export(img, false)), "classic export detected classic")
	# پریست‌ها
	for i in SkinLib.PRESET_NAMES.size():
		var pr := SkinLib.preset(i)
		ok(pr.get_width() == 64, "preset %d size" % i)
		var holes := 0
		for box in SkinLib.base_parts(false):
			for f in 6:
				var r := SkinLib.face_rect(box, f)
				for y in range(r.position.y, r.end.y):
					for x in range(r.position.x, r.end.x):
						if pr.get_pixel(x, y).a < 0.99:
							holes += 1
		ok(holes == 0, "preset %d base layer has %d holes" % [i, holes])
	# to_editor_image روی اسکین قدیمی ۶۴×۳۲
	var legacy := Image.create(64, 32, false, Image.FORMAT_RGBA8)
	legacy.fill(Color(0.5, 0.2, 0.2))
	var ed := SkinLib.to_editor_image(legacy)
	ok((ed["image"] as Image).get_height() == 64, "legacy expanded")
	# عکس → اسکین (پس‌زمینه‌ی آبی، آدم‌ک ساده)
	var ph := Image.create(300, 500, false, Image.FORMAT_RGBA8)
	ph.fill(Color(0.2, 0.6, 0.9))
	ph.fill_rect(Rect2i(110, 40, 80, 90), Color(0.9, 0.7, 0.55))
	ph.fill_rect(Rect2i(90, 130, 120, 170), Color(0.8, 0.1, 0.1))
	ph.fill_rect(Rect2i(95, 300, 50, 170), Color(0.1, 0.1, 0.5))
	ph.fill_rect(Rect2i(155, 300, 50, 170), Color(0.1, 0.1, 0.5))
	var built := SkinLib.build_from_photos({"front": ph}, 0)
	ok(not built.has("error"), "photo built")
	if not built.has("error"):
		var bi: Image = built["image"]
		ok(bi.get_width() == 64, "photo skin is 64x64")
		var bodyr := SkinLib.face_rect(SkinLib.BODY, SkinLib.Face.FRONT)
		var c := bi.get_pixel(bodyr.position.x + 4, bodyr.position.y + 4)
		ok(c.r > 0.6 and c.b < 0.4, "photo body is red (bg removed) got %s" % str(c))
		var headr := SkinLib.face_rect(SkinLib.HEAD, SkinLib.Face.FRONT)
		var hc := bi.get_pixel(headr.position.x + 4, headr.position.y + 4)
		ok(not (hc.b > 0.8 and hc.r < 0.4), "head not background-blue got %s" % str(hc))
		bi.save_png("/tmp/photo_skin_test.png")
	print("[STUDIO TEST] ", "FAILED %d" % fails if fails > 0 else "PASSED")
	get_tree().quit(1 if fails > 0 else 0)
