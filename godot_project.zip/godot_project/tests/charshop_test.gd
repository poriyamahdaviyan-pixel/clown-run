extends Node
## فروشگاه انیمیشن/صدای هر کاراکتر با سرور ساختگی (نه Supabase واقعی)
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok  " if c else "  FAIL ") + m)
	if not c: fails += 1

func _post(path: String) -> void:
	var h := HTTPRequest.new()
	add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()

func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"
	Online.anon_key = "ANON"
	var name := "own%d" % (Time.get_ticks_msec() % 100000)
	var r := await Online.sign_up(name, "secret1")
	ok(r.ok, "owner signed up")
	await _post("/__test/admin/%s/0" % name)
	await Online.refresh_profile()
	ok(Online.is_admin, "became admin")
	var key := "11111111-aaaa-bbbb-cccc-000000000001"
	# مدیر: دو کلیپ فروشی، یکی پیش‌فرض
	var a1 := await Online.admin_save_item({"kind": "anim_clip", "name": "Wave", "price": 40, "status": "approved", "payload": {"char": key, "clip": "Wave"}})
	ok(a1.ok, "admin adds animation item")
	var a2 := await Online.admin_save_item({"kind": "anim_clip", "name": "Dance", "price": 90, "status": "approved", "payload": {"char": key, "clip": "Dance"}})
	ok(a2.ok, "admin adds second animation")
	var other := await Online.admin_save_item({"kind": "anim_clip", "name": "Wave", "price": 10, "status": "approved", "payload": {"char": "other-char", "clip": "Wave"}})
	var up := await Online.admin_upload("voice/t.wav", PackedByteArray([1, 2, 3]), "audio/wav")
	ok(up.ok, "admin uploads voice file")
	var v1 := await Online.admin_save_item({"kind": "voice", "name": "hello", "price": 0, "status": "approved", "file_path": "voice/t.wav", "payload": {"char": key}})
	ok(v1.ok, "admin adds voice item")
	# تغییر قیمت و پنهان‌کردن
	var pr := await Online.admin_patch_item(String(a2.item.id), {"price": 120})
	ok(pr.ok, "admin changes price")
	pr = await Online.admin_patch_item(String(other.item.id), {"status": "hidden"})
	var mine := await Online.admin_load_char_items(key)
	ok(mine.size() == 3, "admin sees char items (%d)" % mine.size())
	# بازیکن عادی
	Online.sign_out()
	var pn := "ply%d" % (Time.get_ticks_msec() % 100000)
	r = await Online.sign_up(pn, "secret1")
	await Online.load_items()
	ok(Online.items_of_char(key, "anim_clip").size() == 2, "player sees 2 animations of char")
	ok(Online.items_of_char("other-char", "anim_clip").is_empty(), "hidden item not visible to player")
	var items := Online.items_of_char(key, "anim_clip")
	var wave: Dictionary = items.filter(func(i): return i.name == "Wave")[0]
	var dance: Dictionary = items.filter(func(i): return i.name == "Dance")[0]
	ok(int(dance.price) == 120, "player sees updated price 120")
	var b := await Online.buy(wave)
	ok(not b.ok and b.error == "no_coins", "cannot buy without coins")
	await _post("/__test/coins/%s/100" % pn)
	await Online.refresh_profile()
	b = await Online.buy(wave)
	ok(b.ok and Online.coins == 60 and Online.is_owned(wave), "bought wave (coins 60)")
	b = await Online.buy(dance)
	ok(not b.ok and b.error == "no_coins", "dance 120 too expensive")
	var inst := await Online.install(wave)
	ok(inst.ok and Rules.library_of("anim", false, key).size() == 1, "install -> library (for this char)")
	ok(Rules.library_of("anim", false, "another").is_empty(), "not offered to other characters")
	ok(Rules.set_slot("t", "jump", "anim", String(wave.id)) and Rules.rules_of("t")[0].arg == "clip:Wave", "chosen for jump -> clip:Wave")
	Rules.set_slot("t", "jump", "anim", "")
	Rules.library_remove(String(wave.id))
	var voice: Dictionary = Online.items_of_char(key, "voice")[0]
	b = await Online.buy(voice)
	ok(b.ok, "free voice bought")
	# هیچ ضایعاتی برای public: مالک نبودن
	print("[CHARSHOP TEST] ", "PASSED" if fails == 0 else "FAILED (%d)" % fails)
	get_tree().quit()
