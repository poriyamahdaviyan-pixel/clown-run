extends Node
## ربات تست خودکار (اختیاری — فقط برای کنترل کیفیت).
## اجرا: godot --headless --fixed-fps 60 --path . res://tests/autotest.tscn
## چند سناریو را بدون نیاز به انسان بازی می‌کند و خطاهای اسکریپت/منطق را در خروجی نشان می‌دهد.

const SCENARIOS := [
	{"name": "idle (بازیکن بی‌حرکت باید گرفته شود)", "bot": false, "frames": 60 * 90},
	{"name": "bot (ربات هوشمند از هر سه محیط رد می‌شود)", "bot": true, "frames": 60 * 120},
]

var main: Node
var idx := -1
var bot_on := false
var _frames := 0
var _max_frames := 0
var _hits := 0
var _coins := 0
var _powers := 0
var _lane_cd := 0.0
var _failed := false
var _pause_state := 0
var _pause_elapsed := 0.0
var _pause_frames := 0
var _zones_seen := {}
var _over := false
var _power_test_done := false


func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	Game.game_over.connect(_on_over)
	Game.player_hit.connect(func(): _hits += 1)
	Game.coin_collected.connect(func(_v: int): _coins += 1)
	Game.power_collected.connect(func(_id: int): _powers += 1)
	Game.zone_changed.connect(func(z: int): _zones_seen[z] = true)
	_test_shop()
	call_deferred("_next")


func _check(cond: bool, what: String) -> void:
	if not cond:
		_failed = true
		print("[FAIL] ", what)


func _test_shop() -> void:
	Game.coins = 1000
	for i in Game.levels.size():
		Game.levels[i] = 0
	# خرید ارتقا و زنده‌شدن حالا روی سرور است؛ در online_full_test آزموده می‌شود
	var d0 := Game.power_duration(0)
	Game.levels[0] = 1
	_check(Game.power_duration(0) > d0, "duration grows with level")
	Game.coins = 0
	for i in Game.levels.size():
		Game.levels[i] = 0
	print("[TEST] shop logic checked")


func _next() -> void:
	idx += 1
	if idx >= SCENARIOS.size():
		_final_checks()
		return
	var sc: Dictionary = SCENARIOS[idx]
	Game.quit_to_menu()
	_frames = 0
	_max_frames = sc["frames"]
	_hits = 0
	_coins = 0
	_powers = 0
	_lane_cd = 0.0
	_over = false
	_pause_state = 0
	_power_test_done = false
	_zones_seen.clear()
	bot_on = sc["bot"]
	Game.coins = 0
	Game.start_run()
	print("[TEST] start: ", sc["name"])


func _final_checks() -> void:
	# زنده‌شدن دوباره
	Game.quit_to_menu()
	Game.coins = 100
	Game.start_run()
	Game.register_obstacle_hit(true)
	_check(Game.stumble > 0.0, "graze = stumble")
	Game.register_obstacle_hit(true)
	_check(not Game.is_active and Game.over, "second hit while police near = caught")
	Game.quit_to_menu()
	Game.start_run()
	Game.register_obstacle_hit(false)
	_check(not Game.is_active and Game.over, "full crash = caught at once")
	Game.quit_to_menu()
	Game.coins = 100
	Game.start_run()
	Game.register_obstacle_hit(false)
	_check(Game.can_revive(), "can revive with coins")
	Game.used_revive = true
	_check(not Game.can_revive(), "revive only once")
	# سپر و جت
	Game.quit_to_menu()
	Game.start_run()
	Game.register_power(Game.Power.SHIELD)
	_check(Game.register_obstacle_hit() == "shield" and Game.stumble == 0.0, "shield blocks one hit")
	Game.register_power(Game.Power.JET)
	_check(Game.register_obstacle_hit() == "ignored", "jet is invincible")
	Game.quit_to_menu()
	# ×۲
	Game.start_run()
	Game.register_power(Game.Power.DOUBLE)
	var c0 := Game.run_coins
	Game.register_coin()
	_check(Game.run_coins == c0 + 2, "double coins")
	Game.quit_to_menu()
	print("[TEST] ALL SCENARIOS DONE — ", "FAILED" if _failed else "PASSED")
	get_tree().quit(1 if _failed else 0)


func _on_over(summary: Dictionary) -> void:
	if _over:
		return
	_over = true
	var sc: Dictionary = SCENARIOS[idx]
	print("[TEST] over: %s | score=%d dist=%d coins=%d hits=%d powers=%d zones=%s frames=%d" % [
		sc["name"], summary["score"], summary["distance"], _coins, _hits, _powers, str(_zones_seen.keys()), _frames])
	if not bot_on:
		_check(_hits >= 1, "idle player must be caught by a crash")
	call_deferred("_next")


func _process(delta: float) -> void:
	_frames += 1
	if _frames > _max_frames:
		if bot_on and Game.is_active:
			# ربات تا آخر زنده ماند: باید سکه جمع کرده و از چند محیط گذشته باشد
			print("[TEST] bot survived: dist=%d coins=%d powers=%d zones=%s hits=%d" % [int(Game.distance), _coins, _powers, str(_zones_seen.keys()), _hits])
			_check(_coins > 20, "bot collected coins")
			_check(Game.distance > 300.0, "bot ran far")
			_over = true
			call_deferred("_next")
			return
		print("[FAIL] scenario timeout: ", SCENARIOS[idx]["name"])
		_failed = true
		get_tree().quit(1)
		return
	if not Game.is_active:
		return

	# تست توقف/ادامه (ثانیه‌ی ۴ بازی در سناریوی ربات)
	if bot_on and _pause_state == 0 and Game.elapsed > 4.0:
		_pause_elapsed = Game.elapsed
		Game.pause_game()
		_pause_state = 1
		_pause_frames = 0
	elif _pause_state == 1:
		_pause_frames += 1
		if _pause_frames > 90:
			_check(Game.elapsed == _pause_elapsed, "game frozen while paused")
			Game.resume_game()
			_pause_state = 2
			print("[TEST] pause/resume checked")
	if Game.is_paused:
		return

	# تله‌پورت برای عبور سریع از محیط‌ها (تا سازنده‌ی همه‌ی موانع و دنیاها اجرا شود)
	if bot_on and _frames % (60 * 20) == 0:
		Game.distance += Game.ZONE_LENGTH * 0.6
	# قدرت‌ها در ثانیه‌ی ۸ و ۲۰
	if bot_on and not _power_test_done and Game.elapsed > 8.0:
		_power_test_done = true
		Game.register_power(Game.Power.MAGNET)
		Game.register_power(Game.Power.SPRING)
	if bot_on and Game.elapsed > 30.0 and Game.elapsed < 30.1:
		Game.register_power(Game.Power.JET)
	if bot_on and Game.elapsed > 45.0 and Game.elapsed < 45.1:
		Game.register_power(Game.Power.SHIELD)
		Game.register_power(Game.Power.DOUBLE)

	if bot_on:
		_run_bot(delta)


# ------------------------- ربات ساده -------------------------
func _lane_of(x: float) -> int:
	return clampi(roundi(x / Game.LANE_WIDTH), -1, 1)


func _run_bot(delta: float) -> void:
	var track = main.track
	var player = main.player
	var spd := Game.run_speed

	var scores := {-1: 0.0, 0: 0.0, 1: 0.0}
	var jump_dist := 999.0
	var slide_dist := 999.0
	for e in track.ents:
		if e.done or not is_instance_valid(e.node):
			continue
		var dist: float = -e.node.position.z
		if dist < -1.0 or dist > 34.0:
			continue
		var l := _lane_of(e.x)
		match e.kind:
			track.Kind.COIN:
				scores[l] += 1.0
			track.Kind.POWER:
				scores[l] += 3.0
			track.Kind.FULL:
				if dist < 20.0:
					scores[l] -= 100.0
			track.Kind.LOW:
				scores[l] -= 4.0
				if l == player.lane and dist < jump_dist:
					jump_dist = dist
			track.Kind.OVERHEAD:
				scores[l] -= 4.0
				if l == player.lane and dist < slide_dist:
					slide_dist = dist

	_lane_cd -= delta
	var best: int = player.lane
	for l in [-1, 0, 1]:
		if absi(l - player.lane) > 1:
			continue
		if scores[l] > scores[best] + 0.5:
			best = l
	if best != player.lane and _lane_cd <= 0.0:
		player.move_lane(1 if best > player.lane else -1)
		_lane_cd = 0.22

	if jump_dist < spd * 0.28 + 0.8 and jump_dist > 0.0:
		player.jump()
	if slide_dist < spd * 0.2 + 1.4 and slide_dist > 0.0:
		player.slide()
