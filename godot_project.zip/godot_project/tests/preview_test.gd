extends Node
## پیش‌نمایش قفل‌شده + انیمیشن قرضی + فروشگاه کاراکتر + آهنگ مخصوص کاراکتر (سرور ساختگی)
const GlbModel = preload("res://scripts/glb_model.gd")
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _wav() -> PackedByteArray:
	var n := 2400
	var pcm := PackedByteArray()
	for i in n:
		var v := int(sin(float(i) * 0.2) * 9000.0)
		pcm.append(v & 0xff); pcm.append((v >> 8) & 0xff)
	var h := PackedByteArray()
	h.append_array("RIFF".to_ascii_buffer()); h.append_array(PackedByteArray([0, 0, 0, 0]))
	h.append_array("WAVEfmt ".to_ascii_buffer())
	h.append_array(PackedByteArray([16, 0, 0, 0, 1, 0, 1, 0, 0x40, 0x1f, 0, 0, 0x80, 0x3e, 0, 0, 2, 0, 16, 0]))
	h.append_array("data".to_ascii_buffer())
	h.append_array(PackedByteArray([n * 2 & 0xff, (n * 2 >> 8) & 0xff, 0, 0]))
	h.append_array(pcm)
	var sz := h.size() - 8
	h[4] = sz & 0xff; h[5] = (sz >> 8) & 0xff
	return h
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var nm := "pv%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await _post("/__test/coins/%s/500" % nm)
	await Online.refresh_profile()
	var ui = main.ui
	var scr = ui._online
	# --- AnimPack: کلیپ از فایل الف روی کاراکتر ب
	var src_path := ProjectSettings.globalize_path("res://samples/sample_anim.glb")
	var clips := AnimPack.clips_of_model(src_path)
	ok("Jump" in clips and "Wave" in clips, "clips listed: %s" % str(clips))
	var d := AnimPack.extract(src_path, ["Jump"])
	ok(d.has("Jump") and d.Jump.tracks.size() == 3, "jump extracted with 3 tracks")
	AnimPack.save("t1", d.Jump)
	var gm := GlbModel.new()
	add_child(gm)
	ok(gm.load_from_file(ProjectSettings.globalize_path("res://samples/sample_rigged.glb")), "target model loads")
	ok(gm.clip_list().is_empty(), "target has no clips of its own")
	gm.play_clip_once("pack:t1", 1.0)
	ok(gm._anim != null and gm._anim.has_animation("pack_t1"), "borrowed clip registered on target")
	await get_tree().create_timer(0.4).timeout
	ok(gm._anim != null and gm._anim.is_playing() and gm._anim.current_animation == "pack_t1", "borrowed clip playing")
	gm.queue_free()
	# --- ساخت و فروش از ابزار مالک
	Skins.add_glb(src_path, "الف")
	var ea: Dictionary = Skins.current_entry()
	Skins.add_glb(ProjectSettings.globalize_path("res://samples/sample_rigged.glb"), "ب")
	var eb: Dictionary = Skins.current_entry()
	var key_b := Skins.char_key(eb)
	var cs = scr.char_shop
	cs._entry = eb
	cs._mgr = true
	await cs._sell_borrowed(ea, "Jump", 30)
	await Online.load_items()
	var packs := Online.items_of_char(key_b, "anim_clip")
	ok(packs.size() == 1, "borrowed anim item created for B")
	var it: Dictionary = packs[0]
	var pl: Dictionary = it.payload
	ok(bool(pl.get("pack", false)) and String(pl.get("pv", "")).begins_with("pv/") and String(it.file_path).begins_with("anim/"), "payload pack+pv, file uploaded")
	# --- پیش‌نمایش قفل
	scr._open_detail(it)
	await get_tree().create_timer(1.5).timeout
	var ipv: Node = null
	for c in scr._detail.find_children("*", "VBoxContainer", true, false):
		if c.get_script() != null and String(c.get_script().resource_path).ends_with("item_preview.gd"):
			ipv = c
	ok(ipv != null and ipv._model != null, "detail has item preview with a model")
	ok(ipv != null and ipv._tricks.size() == 1, "preview prepared the borrowed trick")
	await get_tree().create_timer(0.6).timeout
	ok(ipv._model.get("is_glb") == true or ipv._stand_in == false, "preview model ok")
	scr._detail.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	ok(not ui._pv.keys().any(func(k): return String(k).begins_with("ipv")), "preview registry cleaned on close")
	# --- خرید و نصب انیمیشن قرضی
	var br: Dictionary = await Online.buy(it)
	ok(br.get("ok", false), "bought: " + str(br.get("error", "")))
	var ir: Dictionary = await Online.install(it)
	ok(ir.get("ok", false), "installed: " + str(ir))
	ok(not AnimPack.load_pack(String(it.id)).is_empty(), "pack saved locally")
	var lib_ok := false
	for e in Rules.library:
		if String(e.get("clip", "")) == "pack:" + String(it.id): lib_ok = true
	ok(lib_ok, "rules library has pack clip")
	# --- صدا و آهنگ مخصوص کاراکتر با پیش‌نمایش
	var wav := _wav()
	var tmp := ProjectSettings.globalize_path("user://t.wav")
	var f := FileAccess.open(tmp, FileAccess.WRITE); f.store_buffer(wav); f.close()
	for kind in ["voice", "music"]:
		var id := "11111111-2222-4333-8444-%012d" % (1 if kind == "voice" else 2)
		await Online.admin_upload("%s/%s.wav" % [kind, id], wav, "audio/wav")
		await Online.admin_upload("pv/%s.wav" % id, wav, "audio/wav", "previews")
		await Online.admin_save_item({"id": id, "kind": kind, "name": "نمونه " + kind, "price": 0, "status": "approved", "file_path": "%s/%s.wav" % [kind, id],
			"payload": {"char": key_b, "char_name": "ب", "pv": "pv/%s.wav" % id, "event": "jump"}})
	await Online.load_items()
	for kind in ["voice", "music"]:
		var li := Online.items_of_char(key_b, kind)
		ok(li.size() == 1, kind + " item exists")
		scr._open_detail(li[0])
		await get_tree().create_timer(1.5).timeout
		var ip: Node = null
		for c in scr._detail.find_children("*", "VBoxContainer", true, false):
			if c.get_script() != null and String(c.get_script().resource_path).ends_with("item_preview.gd"):
				ip = c
		ok(ip != null and ip._model != null and ip._local != "", kind + " preview built, preview file downloaded")
		if kind == "voice":
			ip._play_voice("jump")
			await get_tree().create_timer(0.2).timeout
			ok(ip._audio != null and ip._audio.playing, "voice plays during the jump")
		else:
			ip._play_audio(true)
			await get_tree().create_timer(0.2).timeout
			ok(ip._audio != null and ip._audio.playing and Music.hold, "music plays, menu music held")
		scr._detail.queue_free()
		await get_tree().process_frame
		await get_tree().process_frame
		ok(not Music.hold, "menu music released after closing")
	# --- خرید آهنگ مخصوص کاراکتر → خودکار برای او انتخاب می‌شود
	var mi: Dictionary = Online.items_of_char(key_b, "music")[0]
	await Online.buy(mi)
	var mr: Dictionary = await Online.install(mi)
	ok(mr.get("ok", false) and Music.char_choice(key_b).begins_with("own:"), "char music selected for B: " + Music.char_choice(key_b))
	# --- فروشگاه کاراکتر (انتخاب کاراکتر ← بخش)
	cs.sel_key = key_b
	cs.sel_tab = "anim"
	ui._set_screen(ui.Screen.ONLINE_STORE)
	scr.store_filter = "@chars"
	scr.refresh_store()
	await get_tree().create_timer(0.4).timeout
	ok(scr._store_grid.columns == 1 and scr._store_grid.get_child_count() == 1, "character store inline layout")
	scr.store_filter = ""
	scr.refresh_store()
	ok(scr._store_grid.columns == 2, "other sections back to 2 columns")
	# --- همه‌ی نوع‌های دیگر: اسکین، سکه، بخش دلخواه (عکس/متن/مدل/صدا/نامشخص/بدون پیش‌نمایش)
	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.8, 0.3, 0.2, 1))
	var png := img.save_png_to_buffer()
	var glb_bytes := FileAccess.get_file_as_bytes(ProjectSettings.globalize_path("res://samples/sample_rigged.glb"))
	var cases := [
		["skin", "png", png, "image"], ["coin", "png", png, "image"], ["poster", "png", png, "image"],
		["notes", "txt", "hello preview".to_utf8_buffer(), "text"], ["gizmo", "bin", PackedByteArray([1, 2, 3, 4]), "info"],
		["decor", "glb", glb_bytes, "model"], ["jingle", "wav", wav, "audio"], ["nopv", "", PackedByteArray(), "card"]]
	var n := 0
	for c in cases:
		n += 1
		var cid := "33333333-4444-4555-8666-%012d" % n
		var kind: String = c[0]
		var ext: String = c[1]
		var data := {"id": cid, "kind": kind, "name": "آیتم " + kind, "price": 5, "status": "approved", "payload": {}}
		if ext != "":
			await Online.admin_upload("pv/%s.%s" % [cid, ext], c[2], "application/octet-stream", "previews")
			data["payload"] = {"pv": "pv/%s.%s" % [cid, ext]}
			data["file_path"] = "x/%s.%s" % [cid, ext]
		await Online.admin_save_item(data)
	await Online.load_items()
	for c in cases:
		var found: Dictionary = {}
		for x in Online.items:
			if String(x.kind) == String(c[0]): found = x
		ok(not found.is_empty(), "item of kind " + String(c[0]))
		scr._open_detail(found)
		await get_tree().create_timer(1.2).timeout
		var ip2: Node = null
		for cc in scr._detail.find_children("*", "VBoxContainer", true, false):
			if cc.get_script() != null and String(cc.get_script().resource_path).ends_with("item_preview.gd"):
				ip2 = cc
		var has_view := false
		if ip2 != null:
			match String(c[3]):
				"image": has_view = ip2.find_children("*", "TextureRect", true, false).size() > 0 or ip2._model != null or ip2.find_children("*", "SubViewport", true, false).size() > 0
				"model", "audio": has_view = ip2._model != null
				"text", "info": has_view = ip2.get_child_count() > 0 and ip2.find_children("*", "Label", true, false).size() > 0
				"card": has_view = ip2.find_children("*", "Label", true, false).size() > 0
		ok(has_view, "preview for kind %s shows %s" % [c[0], c[3]])
		if String(c[0]) == "skin":
			ok(ip2._model != null, "skin: rotatable character model")
		if String(c[0]) == "coin":
			ok(ip2.find_children("*", "SubViewport", true, false).size() == 1, "coin: 3D viewport")
		scr._detail.queue_free()
		await get_tree().process_frame
		await get_tree().process_frame
	print("[PREVIEW] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
