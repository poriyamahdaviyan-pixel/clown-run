extends Node
var fails := 0
func ok(c: bool, w: String) -> void:
	if not c:
		fails += 1
		print("[FAIL] ", w)
func _texts(n: Node, out: Array) -> void:
	if n is Control and not (n as Control).is_visible_in_tree():
		return
	if n is Label:
		out.append((n as Label).text)
	if n is Button:
		out.append((n as Button).text)
	for c in n.get_children():
		_texts(c, out)

func _ready() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var pol = main.get_node("Police")
	PoliceCfg.clear_model()
	PoliceCfg.reset_cfg()
	ok(not PoliceCfg.has_model(), "no model initially")
	ok(pol._gm == null and pol._officer.visible, "placeholder when no model")
	# مالک: انتخاب مدل
	ok(Edition.is_owner(), "headless editor run = owner")
	ok(PoliceCfg.choose_model("res://samples/sample_robot.glb") == "", "choose model")
	await get_tree().process_frame
	ok(pol._gm != null and not pol._officer.visible, "glb replaces placeholder")
	ok(PoliceCfg.choose_model("res://project.godot") != "", "reject non-glb")
	PoliceCfg.set_cfg("scale", 1.3)
	ok(is_equal_approx(float(PoliceCfg.cfg()["scale"]), 1.3), "owner cfg applies")
	# حرکت: چند فریم در حالت تعقیب
	Game.start_run()
	Game.register_obstacle_hit()
	for i in 90:
		await get_tree().process_frame
	ok(pol.visible and pol._gm != null, "chaser visible after stumble")
	# رابط مالک
	var st = main.ui._settings
	main.ui._set_screen(main.ui.Screen.SETTINGS)
	await get_tree().process_frame
	var t: Array = []
	_texts(st, t)
	ok(t.any(func(x): return "پلیس" in str(x)), "owner sees police controls")
	st._set_target("police")
	await get_tree().process_frame
	ok(st._body_box.visible and st._police_box.visible, "police body panel visible")
	st._set_cfg("swing", 1.2)
	ok(is_equal_approx(float(PoliceCfg.cfg()["swing"]), 1.2), "ui sets police cfg")
	# نسخه‌ی عمومی: هیچ چیز دیده نمی‌شود و تنظیم محلی اعمال نمی‌شود
	Edition.set_simulate_public(true)
	await get_tree().process_frame
	ok(not PoliceCfg.has_model() and pol._gm == null, "public: local model ignored")
	ok(is_equal_approx(float(PoliceCfg.cfg()["scale"]), 1.0), "public: local cfg ignored")
	PoliceCfg.apply_remote({"scale": 0.9})
	ok(is_equal_approx(float(PoliceCfg.cfg()["scale"]), 0.9), "public: remote cfg applies")
	PoliceCfg.apply_remote({})
	main.ui._set_screen(main.ui.Screen.SETTINGS)
	await get_tree().process_frame
	t = []
	_texts(st, t)
	ok(not t.any(func(x): return "پلیس" in str(x) or "تعقیب" in str(x)), "public UI has no police text: " + str(t.filter(func(x): return "پلیس" in str(x))))
	ok(st._target == "char" and not st._target_box.visible and not st._police_box.visible, "public: selector hidden")
	for scr in [main.ui.Screen.START, main.ui.Screen.CHARACTER, main.ui.Screen.SHOP, main.ui.Screen.MISSIONS]:
		main.ui._set_screen(scr)
		await get_tree().process_frame
		t = []
		_texts(main.ui, t)
		ok(not t.any(func(x): return "پلیس" in str(x)), "public screen %d has no police text" % scr)
	Edition.set_simulate_public(false)
	PoliceCfg.clear_model()
	PoliceCfg.reset_cfg()
	print("[POLICETEST] ", "PASSED" if fails == 0 else "FAILED")
	Game.is_active = false
	get_tree().quit(0 if fails == 0 else 1)
