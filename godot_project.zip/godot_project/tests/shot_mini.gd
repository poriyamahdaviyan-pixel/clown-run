extends Node
func _shot(n: String, w: float) -> void:
	await get_tree().create_timer(w).timeout
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [OS.get_environment("SHOT_DIR"), n])
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	await Online.sign_up("mi%d" % (Time.get_ticks_msec() % 100000), "secret1")
	Game.intro_on = false
	Game.start_run()
	Game.jet_grace = 99999.0
	await get_tree().create_timer(1.0).timeout
	Game.start_mini("drive")
	await get_tree().create_timer(1.0).timeout
	var d = main._mini
	d.stick._touch = 99; d.stick.value = Vector2(0.4, -1.0)
	await _shot("drive1", 2.6)
	d.stick.value = Vector2(0.9, -0.7)
	await _shot("drive2", 1.2)
	d.time_left = 0.05
	await get_tree().create_timer(2.2).timeout
	Game.start_mini("craft")
	await get_tree().create_timer(1.0).timeout
	var c = main._mini
	await _shot("craft1", 1.4)
	c.stick._touch = 99; c.stick.value = Vector2(0.7, 0.7)
	await _shot("craft2", 2.5)
	get_tree().quit()
