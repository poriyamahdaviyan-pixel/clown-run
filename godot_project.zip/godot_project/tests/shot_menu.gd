extends Node
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	await Online.sign_up("mn%d" % (Time.get_ticks_msec() % 100000), "secret1")
	await get_tree().create_timer(2.5).timeout
	for t in 4:
		Game.menu_theme = t
		Game.menu_theme_changed.emit()
		await get_tree().create_timer(0.8).timeout
		get_viewport().get_texture().get_image().save_png("%s/menu%d.png" % [OS.get_environment("SHOT_DIR"), t])
	get_tree().quit()
