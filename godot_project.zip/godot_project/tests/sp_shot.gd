extends Node
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var ui = main.ui
	await Online.sign_up("sp%d" % (Time.get_ticks_msec() % 100000), "secret1")
	Edition.simulate_public = (OS.get_environment("PUB") == "1")
	Content.apply_remote({"perms": {"snd_per_char": true, "snd_per_chaser": true, "snd_mix_police": true}})
	ui._set_screen(ui.Screen.SETTINGS)
	for i in 6: await get_tree().process_frame
	await get_tree().create_timer(0.5).timeout
	var st := [ui._settings] if "_settings" in ui else []
	for n in get_tree().root.find_children("*", "Button", true, false):
		if n.is_visible_in_tree() and n.get_parent() is HFlowContainer:
			print("BTN [", n.text, "] size=", n.size, " fs=", n.get_theme_font_size("font_size"), " clip=", n.clip_text)
			break
	get_viewport().get_texture().get_image().save_png("/tmp/sp_%s.png" % OS.get_environment("PUB"))
	get_tree().quit()
