extends Node
var main
var f := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var g := OS.get_environment("SHOT_GLB")
	if g != "":
		Skins.add_glb(g, "تست")
	elif OS.get_environment("SHOT_SKIN") != "":
		Skins.select(OS.get_environment("SHOT_SKIN"))
	Game.start_run()
	Game.jet_grace = 99999.0
func _process(_d: float) -> void:
	f += 1
	if f >= 120 and (f - 120) % 5 == 0 and (f - 120) / 5 < 6:
		get_viewport().get_texture().get_image().save_png("%s/r%d.png" % [OS.get_environment("SHOT_DIR"), (f - 120) / 5])
	if f > 160:
		get_tree().quit()
