extends Node
const Ext := preload("res://scripts/obstacles_ext.gd")
const SP := preload("res://scripts/setpieces.gd")
const Props := preload("res://scripts/props.gd")
func _b(tag: String, f: Callable) -> void:
	print("B:", tag)
	var n := Node3D.new()
	add_child(n)
	f.call(n)
	n.queue_free()
func _ready() -> void:
	for z in 6:
		for v in 6:
			_b("low %d %d" % [z, v], func(n): Ext.low(z, v, n))
			_b("full %d %d" % [z, v], func(n): Ext.full(z, v, n))
		for v in 5:
			_b("over %d %d" % [z, v], func(n): Ext.over(z, v, n))
		_b("platform %d" % z, func(n): SP.platform(n, z, 20.0, 1.8, 7.0, 5.0))
		_b("closure %d" % z, func(n): SP.closure(n, z, 12.0, 3))
		_b("sign %d" % z, func(n): SP.detour_sign(n, z, 2.4, 6.0))
		_b("pit %d" % z, func(n): SP.pit(n, z, 3.4))
		_b("tunnel %d" % z, func(n): SP.tunnel(n, z, 7.0))
		_b("switcher %d" % z, func(n): SP.switcher(n, z, 2))
		_b("roller %d" % z, func(n): SP.roller(n, z))
	for i in 6:
		_b("power %d" % i, func(n): Props.power_model(n, i))
	print("[BUILDTEST] DONE")
	get_tree().quit(0)
