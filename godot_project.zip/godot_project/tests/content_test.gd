extends Node
## تست منطق Content / Rules و صفحه‌های ویرایشگر
var main
var f := 0
var bad := 0
func _chk(c: bool, m: String) -> void:
	print(("  ok  " if c else "  FAIL ") + m)
	if not c: bad += 1
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
func _store_checks() -> void:
	var n0 := Content.store_all().size()
	Content.add_store("ویژه", "voice")
	_chk(Content.store_all().size() == n0 + 1, "store: custom section added")
	var cid: String = Content.store_all()[-1].id
	Content.move_store(cid, -2)
	_chk(Content.store_all().find(Content.store_all().filter(func(x): return x.id == cid)[0]) == n0 - 2, "store: moved")
	Content.remove_store(cid)
	_chk(Content.store_all().size() == n0, "store: custom removed")
	_chk(not Content.store_shows_kind("police"), "store: police hidden for public by default")
	_chk(not Content.store_shows_kind("@chars"), "store: per-character shop hidden for public by default")
	_chk(not Content.store_shows_kind("chaser_anim") and not Content.store_shows_kind("anim"), "store: anim/chaser sections hidden for public")
	_chk(Content.char_defaults("zz").is_empty(), "no char defaults by default")
	Content.set_char_default("zz", "Wave", true)
	_chk(Content.char_defaults("zz") == ["Wave"], "char default set")
	Content.set_char_default("zz", "Wave", false)
	_chk(Content.char_defaults("zz").is_empty(), "char default cleared")
	Edition.simulate_public = false
	Content.set_ability("store_voice", false)
	Edition.simulate_public = true
	_chk(not Content.store_shows_kind("voice"), "store: unticked section hides its kind")
	_chk(Content.store_shows_kind("skin"), "store: skin still shown")
	Content.set_ability("store_voice", true)
	# نصب انواع تازه (بدون شبکه)
	var dir := "user://t_items"
	DirAccess.make_dir_recursive_absolute(dir)
	var wav := dir + "/v.wav"
	var f := FileAccess.open(wav, FileAccess.WRITE)
	var hdr := PackedByteArray([82,73,70,70,40,0,0,0,87,65,86,69,102,109,116,32,16,0,0,0,1,0,1,0,64,31,0,0,64,31,0,0,1,0,8,0,100,97,116,97,4,0,0,0,128,130,128,126])
	f.store_buffer(hdr); f.close()
	var ch: String = Skins.current_id
	var nr0 := Rules.rules_of(ch).size()
	var r: Dictionary = Online.apply_item_file({"id": "abc", "kind": "voice", "name": "ص"}, wav)
	_chk(r.ok and Rules.library_of("voice").size() == 1, "voice installs into library")
	_chk(Rules.rules_of(ch).size() == nr0, "install does NOT force a rule (default stays)")
	_chk(Rules.slot_of(ch, "jump", "sound") == "", "slot default = none")
	_chk(Rules.set_slot(ch, "jump", "sound", "abc") and Rules.slot_of(ch, "jump", "sound") == "abc", "choose library voice for jump")
	_chk(Rules.fire("jump"), "chosen voice replaces default")
	_chk(Rules.set_slot(ch, "jump", "sound", "") and Rules.slot_of(ch, "jump", "sound") == "", "back to default clears slot")
	_chk(Rules.rules_of(ch).size() == nr0, "slot reset leaves no rule")
	_chk(Rules.set_slot(Rules.CHASER, "chaser_caught", "sound", "abc") and Rules.fire("chaser_caught", 0.0, Rules.CHASER), "chaser sound slot")
	_chk(not Rules.fire("jump", 0.0, Rules.CHASER), "chaser rules separate from character")
	Rules.set_slot(Rules.CHASER, "chaser_caught", "sound", "")
	Rules.library_remove("abc")
	Edition.simulate_public = true
	_chk(not Content.can("chooser"), "public: chooser closed with empty library")
	Online.apply_item_file({"id": "cv", "kind": "chaser_voice", "name": "ک"}, wav)
	_chk(Content.can("chooser") and Content.can("chooser_chaser"), "public: buying chaser voice opens chooser + chaser tab")
	_chk(Rules.library_of("voice", true).size() == 1 and Rules.library_of("voice", false).is_empty(), "chaser item only in chaser list")
	_chk(Rules.set_slot(Rules.CHASER, "chaser_approach", "sound", "cv") and Rules.fire("chaser_approach", 0.0, Rules.CHASER), "approach sound slot works")
	Rules.set_slot(Rules.CHASER, "chaser_approach", "sound", "")
	Rules.library_remove("cv")
	_chk(not Content.can("chooser"), "public: chooser closes again when library empty")
	Edition.simulate_public = false
	var pk := dir + "/a.json"
	f = FileAccess.open(pk, FileAccess.WRITE)
	f.store_string('{"rules":[{"event":"jump","action":"anim","arg":"flip"},{"event":"bogus"}]}')
	f.close()
	r = Online.apply_item_file({"id": "x", "kind": "anim", "name": "پک"}, pk)
	_chk(r.ok and Rules.library_of("anim").size() == 1 and Rules.library_of("anim")[0].rules.size() == 1, "anim pack to library (invalid skipped)")
	_chk(Rules.set_slot(ch, "jump", "anim", "x"), "choose pack anim for jump")
	_chk(not Rules.set_slot(ch, "slide", "anim", "x"), "pack without that event refused")
	_chk(Rules.set_slot(ch, "slide", "anim", "trick:spin"), "builtin trick for slide")
	_chk(Rules.set_slot(Rules.CHASER, "chaser_caught", "anim", "trick:shake"), "chaser animation slot")
	var pol = main.find_child("Police", true, false)
	_chk(pol != null and pol.has_method("play_trick"), "police can play tricks")
	pol.play_trick("spin", 0.5)
	Rules.set_slot(Rules.CHASER, "chaser_caught", "anim", "")
	Rules.set_slot(ch, "jump", "anim", "")
	Rules.set_slot(ch, "slide", "anim", "")
	Rules.library_remove("x")
	r = Online.apply_item_file({"id": "y", "kind": "brandnew", "name": "تازه"}, pk)
	_chk(r.ok, "unknown kind saved gracefully")
	Edition.simulate_public = true
	r = Online.apply_item_file({"id": "p", "kind": "police", "name": "پ", "glb_yaw": 1}, ProjectSettings.globalize_path("res://samples/sample_rigged.glb"))
	_chk(r.ok and PoliceCfg.model_path() == PoliceCfg.BOUGHT_MODEL and PoliceCfg.yaw() == 1, "install police skin works for public edition")
	PoliceCfg.clear_bought()
	_chk(PoliceCfg.model_path() != PoliceCfg.BOUGHT_MODEL, "police skin cleared")
	r = Online.apply_item_file({"id": "z", "kind": "anim", "name": "bad"}, wav)
	_chk(not r.ok, "bad anim pack rejected")
	Rules.library_remove("abc")
	Edition.simulate_public = false


func _process(_d: float) -> void:
	f += 1
	var ui = main.ui
	var d := OS.get_environment("SHOT_DIR")
	match f:
		3:
			Content.reset_local()
			Rules.add_rule(Skins.current_id, {"event": "jump", "action": "popup", "arg": "hi", "replace": true, "max": 0, "chance": 1.0, "every": 0.0, "at": 0.0, "cooldown": 0.0})
			_chk(Rules.fire("jump"), "rule replace returns true")
			_chk(not Rules.fire("coin"), "no rule -> false")
			Content.set_text("بازگشت", "برگرد")
			_chk(Content.text_for("بازگشت") == "برگرد", "text override")
			var n0 := Content.menu_all().size()
			Content.add_custom("تست", "text:سلام", false)
			_chk(Content.menu_all().size() == n0 + 1, "custom menu add")
			var first = Content.menu_all()[0].id
			Content.move_item(first, 1)
			_chk(Content.menu_all()[1].id == first, "move item")
			Content.set_ability("coins_ui", false)
			Edition.simulate_public = true
			Edition.changed.emit()
			_chk(not Content.can("coins_ui"), "public cannot coins_ui")
			_chk(not Edition.is_owner(), "simulated public")
			_store_checks()
		6: ui._set_screen(ui.Screen.START)
		12: get_viewport().get_texture().get_image().save_png(d + "/c_pub_start.png")
		14:
			Edition.simulate_public = false
			Edition.changed.emit()
			ui._set_screen(ui.Screen.START)
		20: get_viewport().get_texture().get_image().save_png(d + "/c_own_start.png")
		22: ui._set_screen(ui.Screen.CONTENT)
		30: get_viewport().get_texture().get_image().save_png(d + "/c_content_texts.png")
		32:
			ui._editors._tab = 1
			ui._editors.refresh_content()
		40: get_viewport().get_texture().get_image().save_png(d + "/c_content_menu.png")
		41:
			ui._editors._tab = 2
			ui._editors.refresh_content()
		44: get_viewport().get_texture().get_image().save_png(d + "/c_content_store.png")
		45:
			ui._set_screen(ui.Screen.CHOOSER)
		48: get_viewport().get_texture().get_image().save_png(d + "/c_chooser.png")
		49: ui._set_screen(ui.Screen.RULES)
		52: get_viewport().get_texture().get_image().save_png(d + "/c_rules.png")
		54:
			Content.reset_local()
			Rules.remove_rule(Skins.current_id, 0)
			print("[CONTENTTEST] ", "PASSED" if bad == 0 else "FAILED")
			get_tree().quit()
