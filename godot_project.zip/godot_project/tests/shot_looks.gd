extends Node
## اسکرین‌شات سبک‌های تصویر و دوربین‌ها حین بازی
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _shot(n: String) -> void:
	await get_tree().create_timer(0.7).timeout
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [OS.get_environment("SHOT_DIR"), n])
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	await Online.sign_up("lk%d" % (Time.get_ticks_msec() % 100000), "secret1")
	Game.start_run()
	Game.jet_grace = 99999.0
	await get_tree().create_timer(2.0).timeout
	for s in 5:
		Game.look_style = s; Game.look_changed.emit()
		await _shot("look%d" % s)
	Game.look_style = 0; Game.look_changed.emit()
	for v in [1, 2, 3]:
		Game.cam_view = v
		await _shot("cam%d" % v)
	get_tree().quit()
