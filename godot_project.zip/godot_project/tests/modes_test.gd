extends Node
## پرتال‌ها و جهان‌ها: ورود/خروج، موانع و سکه‌ی هر جهان، تم دنیا، فرمان آزاد، حلقه‌ها، جعبه‌شکنی
var fails := 0
var main
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func frames(n: int) -> void:
	# حداقل n فریم و n/60 ثانیه (تا نتیجه به سرعت ماشین بستگی نداشته باشد)
	var t0 := Time.get_ticks_msec()
	for i in n: await get_tree().process_frame
	while Time.get_ticks_msec() - t0 < int(n * 16.7):
		await get_tree().process_frame
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await frames(2)
	var t = main.track
	var p = main.player
	Game.quit_to_menu(); await frames(2)
	Game.start_run(); Game.jet_grace = 0.0
	ok(Game.mode == "", "start: normal world")
	ok(Modes.RUN_IDS.size() == 12 and Modes.IDS.size() == 17 and Modes.enabled_ids().size() == 17, "17 portal worlds enabled by default")
	for id in Modes.RUN_IDS:
		Game.enter_mode(id)
		await frames(3)
		ok(Game.mode == id, "%s: entered" % id)
		ok(Game.mode_end > Game.distance + 300.0, "%s: has a length" % id)
		# موانع هر نوع
		t.reset(); t._cursor = -99999.0
		for k in [2, 3, 4]:
			t._spawn_obstacle(k, 0, -30.0 - k, 1)
		var kinds := {}
		for e in t.ents:
			kinds[e.kind] = true
			ok(e.node != null and e.node.get_child_count() > 0, "%s: obstacle kind %d has a model" % [id, e.kind])
		ok(kinds.size() == 3, "%s: all obstacle kinds built" % id)
		t._spawn_coin(0.0, 1.0, -20.0)
		ok(t.ents.size() >= 4, "%s: themed coin spawned" % id)
		Game.exit_mode(true)
		await frames(3)
		ok(Game.mode == "", "%s: exited" % id)
	# پرتال در جاده
	t.reset(); t._cursor = -99999.0
	t._spawn_portal(-5.0, "moto")
	var pe = null
	for e in t.ents:
		if e.portal == "moto": pe = e
	ok(pe != null, "portal entity spawned")
	for i in 600:
		if Game.mode == "moto": break
		await frames(1)
	ok(Game.mode == "moto", "driving through the portal enters moto world (mode=%s)" % Game.mode)
	ok(Game.free_steer(), "moto: free steering on")
	ok(p._vehicle != null and not p._model.visible, "moto: vehicle replaces the character model")
	var x0 = p.position.x
	p._free_x = 2.8
	for i in 40: await frames(1)
	ok(p.position.x > 2.5, "free steering moves the player continuously (x=%.2f)" % p.position.x)
	# خروج
	t._spawn_portal(-5.0, "", p.position.x)
	for i in 40: await frames(1)
	ok(Game.mode == "", "exit portal returns to normal")
	ok(p._vehicle == null and p._model.visible, "character model restored")
	ok(Game.free_steer() == false, "lane steering restored")
	# حلقه‌ها (سونیک)
	Game.enter_mode("ring"); await frames(2)
	Game.register_coin(); Game.register_coin(); Game.register_coin()
	ok(Game.rings == 3, "rings collected")
	var res := Game.register_obstacle_hit(false)
	ok(res == "ring" and Game.rings == 0 and Game.is_active, "hit with rings scatters them instead of ending the run")
	res = Game.register_obstacle_hit(false)
	ok(res != "ring", "hit without rings is a normal hit")
	Game.quit_to_menu(); await frames(2)
	Game.start_run(); Game.jet_grace = 0.0; main.player.invuln = 0.0
	# جعبه‌شکنی
	Game.enter_mode("crate"); await frames(2)
	t.reset(); t._cursor = -99999.0
	t._spawn_obstacle(2, 0, -2.0, 0)
	var crate = null
	for e in t.ents:
		if e.kind == 2: crate = e
	ok(crate != null and crate.crate, "crate obstacle flagged breakable")
	p.position.x = 0.0; p.lane = 0
	p.slide()
	var bonus0 = Game.run_bonus
	for i in 30: await frames(1)
	ok(crate.done and Game.run_bonus >= bonus0 + 60 and Game.stumble <= 0.0, "sliding smashes the crate (+60, no hit)")
	# تنظیمات
	Game.toggle_mode_enabled("brick")
	ok(not Modes.enabled_ids().has("brick") and Modes.enabled_ids().size() == 16, "mode can be disabled")
	Game.toggle_mode_enabled("brick")
	Game.toggle_portals(); ok(not Game.portals_on, "portals toggle off")
	Game.toggle_portals()
	# --- بازی‌های مستقل
	Game.quit_to_menu(); await frames(2)
	Game.start_run(); Game.jet_grace = 0.0
	var coins0 := Game.run_coins
	Game.start_mini("drive")
	await get_tree().create_timer(0.6).timeout
	var d = main._mini
	ok(d is MiniDrive and Game.mini == "drive", "drive world started as a separate game")
	ok(not main.track.visible and not main.world.visible, "main run hidden during mini-game")
	await frames(10)
	var c0 = d.coins
	for cd in d._coins:
		d.pos = cd.pos
		break
	await frames(3)
	ok(d.coins > c0, "driving over a coin collects it (coins=%d)" % d.coins)
	var dp0 = d.pos
	d.stick.value = Vector2(0, -1.0)
	d.stick._touch = 99
	await frames(60)
	ok(d.pos.distance_to(dp0) > 3.0 or d.vel.length() > 3.0, "analog stick drives the car")
	d.stick._touch = -1
	d.time_left = 0.05
	await get_tree().create_timer(1.8).timeout
	ok(Game.mini == "" and main._mini == null, "drive world finished and removed")
	ok(Game.run_coins > coins0 and main.track.visible and main.world.visible, "coins credited and main run restored")
	Game.start_mini("craft")
	await get_tree().create_timer(0.6).timeout
	var cr = main._mini
	ok(cr is MiniCraft and Game.mini == "craft", "cube world started")
	await frames(10)
	var cc0 = cr.coins
	for o in cr._ores:
		cr.pp = o.pos
		cr.py = cr._ground(o.pos.x, o.pos.y)
		break
	await frames(3)
	ok(cr.coins > cc0, "collecting an ore gives coins (coins=%d)" % cr.coins)
	var p0 = cr.pp
	cr.stick.value = Vector2(1.0, 0.0)
	cr.stick._touch = 99
	await frames(60)
	ok(cr.pp.distance_to(p0) > 1.0, "analog stick walks the blocky player")
	cr.stick._touch = -1
	var tl = cr.time_left
	for c in cr._creepers:
		c.pos = cr.pp + Vector2(1.0, 0.0)
		break
	await frames(100)
	ok(cr.time_left < tl - 3.0, "a creeper explosion costs time (%.1f -> %.1f)" % [tl, cr.time_left])
	cr.time_left = 0.05
	await get_tree().create_timer(1.8).timeout
	ok(Game.mini == "" and main._mini == null, "cube world finished and removed")
	# --- نبرد فضایی
	Game.start_mini("shooter")
	await get_tree().create_timer(0.6).timeout
	var sp = main._mini
	ok(sp is MiniSpace and Game.mini == "shooter", "space shooter started")
	var k0 = sp.coins
	sp.stick.value = Vector2(1.0, 0.0)
	sp.stick._touch = 99
	var sx0 = sp.ship.position.x
	await frames(30)
	ok(sp.ship.position.x > sx0 + 1.0, "analog moves the ship")
	sp.stick._touch = -1
	sp.ship.position = Vector3(0, 0, 0)
	sp._spawn_t = 99.0
	var tgt := Node3D.new(); sp.add_child(tgt); tgt.position = Vector3(0, 0, -30)
	sp._ents.append({"node": tgt, "kind": 1, "hp": 1, "vz": 0.0, "spin": Vector3.ZERO})
	await frames(90)
	ok(sp.coins > k0, "auto-fire destroys an enemy (coins=%d)" % sp.coins)
	var tl2 = sp.time_left
	var hitn := Node3D.new(); sp.add_child(hitn); hitn.position = Vector3(sp.ship.position.x, sp.ship.position.y, sp.ship.position.z)
	sp._ents.append({"node": hitn, "kind": 0, "hp": 99, "vz": 0.0, "spin": Vector3.ZERO, "r": 0.5})
	await frames(3)
	ok(sp.time_left < tl2 - 3.0, "collision costs time")
	sp.time_left = 0.05
	await get_tree().create_timer(1.8).timeout
	ok(Game.mini == "" and main._mini == null, "space shooter finished")
	# --- برش میوه
	Game.start_mini("fruit")
	await get_tree().create_timer(0.6).timeout
	var fr = main._mini
	ok(fr is MiniFruit and Game.mini == "fruit", "fruit slicer started")
	fr._spawn_t = 99.0
	fr._items.clear()
	fr._items.append({"p": Vector2(200, 300), "v": Vector2.ZERO, "kind": 0, "f": MiniFruit.FRUITS[0], "rot": 0.0, "w": 0.0, "r": 54.0})
	fr._items.append({"p": Vector2(300, 300), "v": Vector2.ZERO, "kind": 0, "f": MiniFruit.FRUITS[1], "rot": 0.0, "w": 0.0, "r": 54.0})
	fr._items.append({"p": Vector2(400, 300), "v": Vector2.ZERO, "kind": 0, "f": MiniFruit.FRUITS[2], "rot": 0.0, "w": 0.0, "r": 54.0})
	var fc0 = fr.coins
	fr._down = true
	fr._last = Vector2(100, 300)
	fr._move_to(Vector2(520, 300))
	fr._down = false
	fr._end_swipe()
	ok(fr.coins >= fc0 + 3 + 6 and fr._halves.size() == 6, "swipe slices 3 fruits with combo (coins=%d)" % fr.coins)
	var ftl = fr.time_left
	fr._items.append({"p": Vector2(200, 500), "v": Vector2.ZERO, "kind": 1, "f": MiniFruit.FRUITS[0], "rot": 0.0, "w": 0.0, "r": 56.0})
	fr._last = Vector2(100, 500)
	fr._move_to(Vector2(300, 500))
	ok(fr.time_left < ftl - 4.0, "bomb costs time")
	fr.time_left = 0.05
	await get_tree().create_timer(1.8).timeout
	ok(Game.mini == "" and main._mini == null, "fruit slicer finished")
	# --- برج‌چینی
	Game.start_mini("stack")
	await get_tree().create_timer(0.6).timeout
	var st = main._mini
	ok(st is MiniStack and Game.mini == "stack", "stack tower started")
	st._pos = 0.05
	st._drop()
	ok(st._floors == 1 and st._perfects == 1, "near-perfect drop counts as perfect")
	st._pos = 0.8
	st._drop()
	ok(st._floors == 2 and float(st._tower[st._tower.size() - 1]["w"]) < 3.0 or float(st._tower[st._tower.size() - 1]["d"]) < 3.0, "offset drop trims the block")
	st._pos = 4.0
	st._drop()
	await get_tree().create_timer(1.8).timeout
	ok(Game.mini == "" and main._mini == null, "tower collapse ends the game")
	# --- ظاهر و تنظیم پرتال
	for i in PortalSkins.NAMES.size():
		var pn := Modes.portal_model(Color("27e8ff"), "تست", i)
		main.add_child(pn)
		PortalSkins.animate(pn)
		ok(pn.get_child_count() > 6, "portal skin %d builds (%d nodes)" % [i, pn.get_child_count()])
		pn.queue_free()
	Game.portal_skin = 3
	ok(Game.pick_portal_skin(RandomNumberGenerator.new()) == 3, "fixed portal skin respected")
	Content.set_feature("portal_skin_3", false)
	ok(Game.pick_portal_skin(RandomNumberGenerator.new()) != 3, "disabled skin never picked")
	Content.reset_local()
	Game.portal_skin = -1
	var seen_s := {}
	var rr := RandomNumberGenerator.new()
	for k in 80: seen_s[Game.pick_portal_skin(rr)] = true
	ok(seen_s.size() >= 6, "random skin varies (%d kinds)" % seen_s.size())
	Game.portal_trig = 1
	Game.portal_level = 0
	Game.score = 0
	Game.schedule_portal()
	ok(not Game.portal_due(), "score trigger not due at start")
	Game.score = 2500
	ok(Game.portal_due(), "score trigger due after enough points")
	Game.portal_trig = 2
	Game.run_coins = 0
	Game.schedule_portal()
	ok(not Game.portal_due(), "coin trigger not due")
	Game.run_coins = 40
	ok(Game.portal_due(), "coin trigger due after coins")
	Game.portal_trig = 3
	Game.portal_level = 4
	var hits := 0
	for k in 400:
		if Game.portal_due(): hits += 1
	ok(hits > 20 and hits < 120, "chance trigger ~15%% (%d/400)" % hits)
	Game.portal_trig = 0
	Game.portal_level = 2
	Game.portal_len = 2.0
	Game.mode = ""
	Game.distance = 100.0
	Game.enter_mode("brick")
	ok(absf(Game.mode_end - (100.0 + float(Modes.def("brick").len) * 2.0)) < 1.0, "world length multiplier")
	Game.exit_mode(false)
	Game.portal_len = 1.0
	Game.portal_dest = ""
	Game.cycle_portal_dest()
	ok(Game.portal_dest == Modes.IDS[0], "dest cycle -> first id")
	# --- پرتال تک‌لِین: رد کردن = انتخاب بازیکن
	Game.start_run(); Game.jet_grace = 99999.0
	await frames(3)
	t.reset(); t._cursor = -99999.0
	p.position.x = 0.0
	t._spawn_portal(-5.0, "moto", Game.LANE_WIDTH)
	for i in 400:
		await frames(1)
		var gone := true
		for e in t.ents:
			if e.portal != "" and not e.done: gone = false
		if gone: break
	ok(Game.mode == "", "portal on another lane is skipped (player choice)")
	ok(Game.next_portal_at < 90000.0, "missed portal re-schedules the next one")
	# --- شرط‌های بازگشت
	Game.enter_mode("brick")
	await frames(2)
	Game.ret_mode = 1; Game.ret_level = 0
	ok(not Game.ret_due(95.0), "time return: not due at start")
	Game.mode_t = float(Game.ret_amount())
	ok(Game.ret_due(95.0), "time return: due after the time")
	Game.ret_mode = 2; Game.ret_level = 0
	ok(not Game.ret_due(95.0), "coin return: not due without coins")
	Game.run_coins = Game.mode_coins0 + Game.ret_amount()
	ok(Game.ret_due(95.0), "coin return: due after coins")
	Game.ret_mode = 3; Game.ret_level = 0
	ok(not Game.ret_due(95.0), "score return: not due")
	Game.score = Game.mode_score0 + Game.ret_amount()
	ok(Game.ret_due(95.0), "score return: due after score")
	ok(Game.ret_progress() >= 1.0 and Game.ret_left_text() != "", "progress + text")
	Game.exit_spawned = true
	Game.exit_missed()
	ok(not Game.exit_spawned and Game.mode == "brick" and not Game.ret_due(95.0), "missed exit keeps the world, waits")
	Game.ret_mode = 0; Game.ret_level = 2
	Game.exit_mode(false)
	for id in Modes.IDS:
		if Modes.is_run(id):
			var rst: Array = PortalSkins.return_style(id)
			ok(int(rst[0]) >= 0 and int(rst[0]) < PortalSkins.NAMES.size() and String(rst[1]) != "", "return gate style: " + id)
	Game.cycle_ret_mode()
	ok(Game.ret_mode == 1, "cycle return mode")
	Game.ret_mode = 0
	Game.portal_dest = ""
	print("[MODES] " + ("PASSED" if fails == 0 else "FAILED %d" % fails))
	get_tree().quit()
