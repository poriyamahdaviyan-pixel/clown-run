extends Node
## اسکرین‌شات از هر سه محیط بازی (فقط برای تست)
var main: Node
var f := 0
var shots := [[0.0, "city"], [470.0, "desert"], [920.0, "jungle"]]
var si := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	Game.start_run()
	Game.jet_grace = 9999.0
func _process(_d: float) -> void:
	f += 1
	var step := 360
	if si < shots.size():
		if f == si * step + 5:
			Game.distance = shots[si][0]
			Game.elapsed = 60.0 + si * 40.0
			main.world.rebuild_all()
			main.track.reset()
		if f == si * step + step - 2:
			get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT_DIR") + "/zone_%s.png" % shots[si][1])
			si += 1
	else:
		get_tree().quit()
