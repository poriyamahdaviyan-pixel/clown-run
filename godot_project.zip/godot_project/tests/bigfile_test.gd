extends Node
## آپلود/دانلود فایل بزرگ (تکه‌تکه) با سرور ساختگی؛ سقف تکه برای تست کوچک می‌شود
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var nm := "bf%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	Online.SINGLE_MAX = 1000
	Online.CHUNK = 700
	var data := PackedByteArray()
	for i in 3050:
		data.append((i * 7 + i / 13) % 256)
	var texts: Array = []
	Online.transfer.connect(func(t): texts.append(t))
	var r: Dictionary = await Online.admin_upload("big/test file.bin", data, "application/octet-stream")
	ok(r.ok and int(r.get("parts", 0)) == 5, "uploaded in 5 parts: " + str(r))
	ok(texts.has("آپلود بخش 5 از 5…"), "progress emitted")
	var local := "user://big_dl.bin"
	var d: Dictionary = await Online.fetch_object_to_file("item-files", "big/test file.bin", local, false)
	ok(d.ok, "downloaded: " + str(d))
	ok(FileAccess.get_file_as_bytes(local) == data, "reassembled bytes identical")
	# فایل کوچک: تکه‌ای نمی‌شود
	var small := PackedByteArray([1, 2, 3])
	var r2: Dictionary = await Online.admin_upload("big/small.bin", small, "application/octet-stream")
	ok(r2.ok and not r2.has("parts"), "small file single object")
	var d2: Dictionary = await Online.fetch_object_to_file("item-files", "big/small.bin", "user://small_dl.bin")
	ok(d2.ok and FileAccess.get_file_as_bytes("user://small_dl.bin") == small, "small downloaded")
	print("[BIGFILE] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
