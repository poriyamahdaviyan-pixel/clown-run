extends Node
const GlbModel := preload("res://scripts/glb_model.gd")
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _ready() -> void:
	await get_tree().process_frame
	var base := ProjectSettings.globalize_path("user://imp")
	DirAccess.make_dir_recursive_absolute(base)
	# OBJ
	var obj := "v -1 0 -1\nv 1 0 -1\nv 1 2 -1\nv -1 2 -1\nv -1 0 1\nv 1 0 1\nv 1 2 1\nv -1 2 1\nf 1 2 3 4\nf 5 8 7 6\nf 1 5 6 2\nf 2 6 7 3\nf 3 7 8 4\nf 4 8 5 1\n"
	var f := FileAccess.open(base + "/cube.obj", FileAccess.WRITE); f.store_string(obj); f.close()
	var n0 := Skins.custom_count()
	var e1 := Skins.add_glb(base + "/cube.obj", "cube")
	ok(e1 == "" and Skins.custom_count() == n0 + 1, "OBJ imported: " + e1)
	# glTF (separate files) from sample glb
	var doc := GLTFDocument.new(); var st := GLTFState.new()
	ok(doc.append_from_file("res://samples/sample_robot.glb", st) == OK, "sample loads")
	var scene := doc.generate_scene(st)
	var d2 := GLTFDocument.new(); var s2 := GLTFState.new()
	d2.append_from_scene(scene, s2)
	ok(d2.write_to_filesystem(s2, base + "/robot.gltf") == OK, "write gltf"); scene.free()
	var e2 := Skins.add_glb(base + "/robot.gltf", "robot")
	ok(e2 == "" and Skins.custom_count() == n0 + 2, "glTF imported: " + e2)
	# the stored model has animation clip
	var gm := GlbModel.new(); add_child(gm)
	var entry = Skins.current_entry()
	ok(gm.load_from_file(String(entry.get("glb", "")), 0) and gm.clip_list().size() > 0, "converted model keeps animations %s" % str(gm.clip_list()))
	ok(Skins.add_glb(base + "/x.xyz", "x") != "", "unknown format rejected")
	# zip (gltf + bin) ، bin تنها ، glb با پسوند عوضی
	var zp := ZIPPacker.new()
	ok(zp.open(base + "/pack.zip") == OK, "zip open")
	for fn in ["robot.gltf", "robot0.bin"]:
		zp.start_file("model/" + fn); zp.write_file(FileAccess.get_file_as_bytes(base + "/" + fn)); zp.close_file()
	zp.start_file("readme.txt"); zp.write_file("hi".to_utf8_buffer()); zp.close_file()
	zp.close()
	var n1 := Skins.custom_count()
	var e3 := Skins.add_glb(base + "/pack.zip", "zipped")
	ok(e3 == "" and Skins.custom_count() == n1 + 1, "zip imported: " + e3)
	var e4 := Skins.add_glb(base + "/robot0.bin", "binonly")
	ok(e4 == "" and Skins.custom_count() == n1 + 2, "bin next to gltf imported: " + e4)
	var gb := FileAccess.get_file_as_bytes("res://samples/sample_robot.glb")
	var fg := FileAccess.open(base + "/weird.dat", FileAccess.WRITE); fg.store_buffer(gb); fg.close()
	var e5 := Skins.add_glb(base + "/weird.dat", "weird")
	ok(e5 == "" and Skins.custom_count() == n1 + 3, "glb with unknown extension sniffed: " + e5)
	var lone := FileAccess.open(base + "/lone/a.bin", FileAccess.WRITE) if DirAccess.make_dir_recursive_absolute(base + "/lone") == OK else null
	lone.store_string("garbage"); lone.close()
	var e6 := Skins.add_glb(base + "/lone/a.bin", "lone")
	ok(e6 != "", "lone bin gives clear error: " + e6)
	var zp2 := ZIPPacker.new(); zp2.open(base + "/empty.zip"); zp2.start_file("a.txt"); zp2.write_file("x".to_utf8_buffer()); zp2.close_file(); zp2.close()
	ok(Skins.add_glb(base + "/empty.zip", "e") != "", "zip without model rejected")
	ok(ClassDB.class_exists("FBXDocument"), "FBX runtime support present")
	print("[IMPORT] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
