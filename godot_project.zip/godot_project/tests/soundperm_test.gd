extends Node
## دسترسی صدا، میکسر، صدای فروشیِ هر رویداد، محدودیت‌ها
const SoundPanel := preload("res://scripts/sound_panel.gd")
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _count_sliders(n: Node) -> int:
	var c := 1 if n is HSlider else 0
	for ch in n.get_children():
		c += _count_sliders(ch)
	return c
func _ready() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var ui = main.ui
	# ---------- پیش‌فرض‌ها: مالک همه را دارد، عمومی محتاط
	Edition.simulate_public = false
	ok(Content.perm_b("snd_per_sound") and Content.perm_n("snd_vol_max") == 100, "owner has everything")
	Edition.simulate_public = true
	ok(not Content.perm_b("snd_per_sound") and not Content.perm_b("snd_import_voice") and not Content.perm_b("snd_pick_builtin"), "public: per-sound/import/builtin closed by default")
	ok(Content.perm_b("snd_toggle") and Content.perm_b("snd_master") and Content.perm_b("snd_music_pick"), "public: old behaviour kept (toggle/master/music)")
	# ---------- پنل بازیکن: عمومی فقط چند کشو
	var box := VBoxContainer.new(); add_child(box)
	SoundPanel.build_player(ui, box)
	await get_tree().process_frame
	var pub_sliders := _count_sliders(box)
	ok(pub_sliders == 2, "public panel: master+music sliders only (%d)" % pub_sliders)
	Content.apply_remote({"perms": {"snd_per_sound": true, "snd_per_char": true, "snd_mix_police": true}})
	SoundPanel.build_player(ui, box)
	await get_tree().process_frame
	ok(_count_sliders(box) > pub_sliders + 20, "owner opened per-sound/char/police -> many sliders (%d)" % _count_sliders(box))
	# ---------- میکس: بازیکن فقط اگر مجاز
	Content.apply_remote({})
	Content.mix_set("sound", "plus", 0.4)
	ok(is_equal_approx(Content.mix_get("sound", "plus"), 1.0), "public cannot mix when perm closed")
	Content.apply_remote({"perms": {"snd_per_sound": true}})
	ok(is_equal_approx(Content.mix_get("sound", "plus"), 0.4), "same value applies once perm opens")
	Content.apply_remote({"perms": {"snd_per_sound": true}, "mix": {"sound": {"plus": 0.5}}})
	ok(is_equal_approx(Content.mix_get("sound", "plus"), 0.4), "player local over owner default")
	Content._local.erase("mix")
	ok(is_equal_approx(Content.mix_get("sound", "plus"), 0.5), "owner default applies to all")
	Content.apply_remote({"mix": {"sound": {"plus": 0.0}}})
	ok(Sfx.gain_of("plus", "world") == 0.0, "owner mute -> gain 0")
	Content.apply_remote({})
	# ---------- سقف بلندی
	Content.apply_remote({"perms": {"snd_vol_max": 40}})
	ok(is_equal_approx(Content.vol_cap(), 0.4), "vol cap 40%")
	ok(Sfx._level("world") <= 0.4001, "level capped (%f)" % Sfx._level("world"))
	Content.apply_remote({"perms": {"snd_per_char": true, "snd_vol_max": 40}})
	Content.mix_set("char", "zz", 1.8)
	ok(Content.mix_get("char", "zz") <= 0.4001, "mix_set clamped to cap")
	Content._local.erase("mix")
	Edition.simulate_public = false
	Content.mix_set("char", "zz", 1.8)
	ok(is_equal_approx(Content.mix_get("char", "zz"), 1.8), "owner can boost to 200%")
	Content._local.erase("mix")
	# ---------- رویدادهای مجاز
	Edition.simulate_public = true
	Content.apply_remote({"perms": {"snd_events": "jump, coin"}})
	ok(Content.perm_event_ok("jump") and Content.perm_event_ok("coin") and not Content.perm_event_ok("slide"), "allowed events list")
	Content.apply_remote({})
	ok(Content.perm_event_ok("slide"), "empty list = all events")
	# ---------- سقف واردکردن
	Content.apply_remote({"perms": {"snd_import_voice": true, "snd_import_max": 1}})
	ok(Content.import_block("voice") == "", "import allowed under limit")
	Rules.library_add({"id": "own_a.wav", "kind": "voice", "name": "a", "arg": "file:a.wav", "char": "", "for": ""})
	ok(Content.import_block("voice") != "", "import blocked at limit")
	Content.apply_remote({"perms": {"snd_import_voice": false}})
	ok(Content.import_block("voice") != "", "import blocked when perm closed")
	Edition.simulate_public = false
	ok(Content.import_block("voice") == "", "owner never blocked")
	Edition.simulate_public = true
	# ---------- صدای فروشیِ مخصوص یک رویداد: نصب خودکار
	var e: Dictionary = Skins.current_entry()
	var ck := Skins.char_key(e)
	Rules.library_add({"id": "it1", "kind": "voice", "name": "پرشِ X", "arg": "plus", "hint": "jump", "char": ck, "for": ""})
	Content.apply_remote({"perms": {"snd_auto_equip": false}})
	ok(Online._auto_equip_voice({"id": "it1", "kind": "voice", "name": "پرشِ X"}, {"event": "jump", "char": ck}) == "", "auto-equip off -> nothing")
	Content.apply_remote({})
	var msg: String = Online._auto_equip_voice({"id": "it1", "kind": "voice", "name": "پرشِ X"}, {"event": "jump", "char": ck})
	ok(msg != "" and Rules.slot_of(String(e.id), "jump", "sound") == "it1", "bought jump sound equipped on that character's jump: " + msg)
	ok(Rules.slot_event_of(String(e.id), "it1") == "jump", "slot_event_of finds it")
	var msg2: String = Online._auto_equip_voice({"id": "it1", "kind": "voice", "name": "x"}, {"event": "", "char": ck})
	ok(msg2 == "", "no event -> library only")
	# ---------- اجرای قانون: رویداد پرش صدای فروشی را پخش می‌کند و جایگزین پیش‌فرض است
	var replaced := Rules.fire("jump", 0.0)
	ok(replaced, "jump event replaces default sound")
	# ---------- پنل ماتریس مالک
	Edition.simulate_public = false
	var pbox := VBoxContainer.new(); add_child(pbox)
	var says := []
	SoundPanel.build_perms(ui, pbox, func(t): says.append(t))
	await get_tree().process_frame
	var nbtn := 0
	for c in pbox.get_children():
		if c is Button: nbtn += 1
	ok(nbtn >= Content.SOUND_ABILITIES.size() + 20, "perm matrix lists abilities + perms (%d buttons)" % nbtn)
	var ex := Content.export_json()
	ok(ex.has("perms") and ex.has("mix"), "export carries perms+mix")
	# ---------- فروشگاه کاراکتر: بخش صداهای خریده‌شده (برای بازیکن)
	Edition.simulate_public = true
	Content.apply_remote({})
	var cs = ui._online.char_shop
	cs.open(e)
	cs._tab = "voice"
	cs._mgr = false
	cs._render()
	await get_tree().process_frame
	await get_tree().process_frame
	var nopt := 0
	var stack := [cs._body]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if n is OptionButton: nopt += 1
		stack.append_array(n.get_children())
	ok(nopt >= 1, "store voice tab shows installed-sound event picker (%d)" % nopt)
	Content.apply_remote({"perms": {"snd_store_tune": false}})
	cs._render()
	await get_tree().process_frame
	await get_tree().process_frame
	nopt = 0
	stack = [cs._body]
	while not stack.is_empty():
		var n2: Node = stack.pop_back()
		if n2 is OptionButton: nopt += 1
		stack.append_array(n2.get_children())
	ok(nopt == 0, "store tune closed by owner -> hidden (%d)" % nopt)
	# مالک: انتخاب رویداد برای فایل جدید
	Edition.simulate_public = false
	cs._mgr = true
	cs._render()
	await get_tree().process_frame
	ok(cs._body.get_child_count() > 2, "manager voice tab renders")
	print("PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
