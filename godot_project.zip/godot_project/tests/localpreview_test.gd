extends Node
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _children_of_type(n: Node, cls: String, out: Array) -> void:
	for c in n.get_children():
		if c.get_class() == cls:
			out.append(c)
		_children_of_type(c, cls, out)
func _ready() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().create_timer(1.0).timeout
	var ui = main.ui
	var host := VBoxContainer.new()
	ui.add_child(host)
	var dir := ProjectSettings.globalize_path("user://lptest")
	DirAccess.make_dir_recursive_absolute(dir)
	var im := Image.create(3000, 1000, false, Image.FORMAT_RGB8)
	im.fill(Color.RED)
	im.save_png(dir.path_join("wide.png"))
	# عکس خیلی عریض: نسبت حفظ شود
	var p1 := LocalPreview.make(ui, dir.path_join("wide.png"))
	host.add_child(p1)
	await get_tree().create_timer(0.5).timeout
	var trs := []
	_children_of_type(p1, "TextureRect", trs)
	ok(trs.size() == 1 and (trs[0] as TextureRect).stretch_mode == TextureRect.STRETCH_KEEP_ASPECT_CENTERED, "image keeps aspect")
	ok((trs[0] as TextureRect).texture.get_width() <= 1024, "image downscaled (%d)" % (trs[0] as TextureRect).texture.get_width())
	# مدل
	var p2 := LocalPreview.make(ui, ProjectSettings.globalize_path("res://samples/sample_robot.glb"))
	host.add_child(p2)
	await get_tree().create_timer(2.0).timeout
	var svcs := []
	_children_of_type(p2, "SubViewportContainer", svcs)
	ok(svcs.size() == 1, "model preview viewport exists")
	# صدا
	var p3 := LocalPreview.make(ui, ProjectSettings.globalize_path("res://assets/music/calm.ogg"))
	host.add_child(p3)
	await get_tree().create_timer(0.8).timeout
	var bts := []
	_children_of_type(p3, "Button", bts)
	ok(bts.size() >= 1, "audio play button")
	(bts[0] as Button).pressed.emit()
	await get_tree().create_timer(0.3).timeout
	ok((bts[0] as Button).text.contains("توقف"), "audio plays")
	(bts[0] as Button).pressed.emit()
	# نوع ناشناخته
	var f := FileAccess.open(dir.path_join("x.dat"), FileAccess.WRITE)
	f.store_string("abc"); f.close()
	var p4 := LocalPreview.make(ui, dir.path_join("x.dat"))
	host.add_child(p4)
	await get_tree().create_timer(0.4).timeout
	var labs := []
	_children_of_type(p4, "Label", labs)
	ok(labs.size() >= 1 and (labs[0] as Label).text.contains("پیش‌نمایش مستقیم ندارد"), "unknown type info")
	print("[LOCALPREVIEW] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
