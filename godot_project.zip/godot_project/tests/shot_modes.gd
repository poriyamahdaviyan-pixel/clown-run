extends Node
func _shot(n: String, w: float = 1.3) -> void:
	await get_tree().create_timer(w).timeout
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [OS.get_environment("SHOT_DIR"), n])
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	await Online.sign_up("md%d" % (Time.get_ticks_msec() % 100000), "secret1")
	Game.intro_on = false
	Game.start_run()
	Game.jet_grace = 99999.0
	await get_tree().create_timer(1.5).timeout
	main.track._spawn_portal(-45.0, "moto")
	await _shot("portal", 1.6)
	for id in Modes.RUN_IDS:
		if Game.mode != "": Game.exit_mode(false)
		Game.enter_mode(id)
		main.track.reset(); main.track._cursor = -38.0
		await _shot("mode_" + id, 3.0)
	get_tree().quit()
