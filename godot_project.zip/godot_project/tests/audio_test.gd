extends Node
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _ready() -> void:
	# --- قوانین: امتیاز / دقیقه / چند صدا
	var cid: String = Skins.current_id
	var pops := [0]
	Game.popup.connect(func(_t, _b): pops[0] += 1)
	Rules._data[cid] = []
	Rules.add_rule(cid, {"event": "score", "at": 0.0, "every": 100.0, "chance": 1.0, "action": "popup", "arg": "s", "replace": false, "max": 0, "cooldown": 0.0})
	Rules.add_rule(cid, {"event": "minute", "at": 0.0, "every": 1.0, "chance": 1.0, "action": "popup", "arg": "m", "replace": false, "max": 0, "cooldown": 0.0})
	Game.is_active = true; Game.over = false
	Game.score = 250
	Rules._elapsed = 130.0
	Rules.tick(10.0)
	ok(pops[0] == 2, "score + minute rules fired once each (%d)" % pops[0])
	Game.score = 350
	Rules.tick(11.0)
	ok(pops[0] == 3, "next 100 points fires again (%d)" % pops[0])
	Rules.tick(12.0)
	ok(pops[0] == 3, "no repeat without new step")
	Game.is_active = false
	var r := {"event": "jump", "action": "sound", "arg": "plus", "args": ["jump", "land"], "pick": "order"}
	Rules._do(r, cid); Rules._do(r, cid); Rules._do(r, cid)
	ok(int(Rules._counts.get("seq:%s:plus" % cid, 0)) == 3, "ordered multi-sound counter")
	r["pick"] = "random"; Rules._do(r, cid)
	r["pick"] = "all"; Rules._do(r, cid)
	ok(true, "random/all modes run")
	# --- موسیقی
	ok(Music.choice("menu") == "menu" and Music.choice("game") == "adventure", "default tracks")
	Music.set_choice("game", "night")
	ok(Music.choice("game") == "night", "choice saved")
	DirAccess.copy_absolute("res://assets/music/calm.ogg", "user://t.ogg")
	var err := Music.import_track(ProjectSettings.globalize_path("user://t.ogg"))
	ok(err == "" and Music.own_tracks().size() == 1, "import own track: " + err)
	var own_id: String = "own:" + String(Music.own_tracks()[0].file)
	Music.set_choice("menu", own_id)
	Game.sound_on = true
	Music.update("menu", 1.0, true)
	ok(Music._player.playing and Music._player.stream != null, "own track plays in menu")
	Music.update("game", 1.0)
	ok(Music._cur_id == "night" and Music._player.playing, "game track differs from menu")
	var bad := Music.import_track("/nonexistent.mp3")
	ok(bad != "", "bad file rejected")
	Music.remove_track(String(Music.own_tracks()[0].file))
	ok(Music.own_tracks().is_empty() and Music.choice("menu") == "none", "remove resets choice")
	# per-player: other uid has own prefs
	var old := Online.user_id
	Online.user_id = "other-user"; Online.token = "x"
	ok(Music.choice("game") == "adventure", "other player has own defaults")
	Online.user_id = old; Online.token = ""
	print("[AUDIO] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
