extends Node
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _wav() -> PackedByteArray:
	var n := 4800
	var pcm := PackedByteArray()
	for i in n:
		var v := int(sin(float(i) * 0.2) * 9000.0)
		pcm.append(v & 0xff); pcm.append((v >> 8) & 0xff)
	var h := PackedByteArray()
	h.append_array("RIFF".to_ascii_buffer()); h.append_array(PackedByteArray([0, 0, 0, 0]))
	h.append_array("WAVEfmt ".to_ascii_buffer())
	h.append_array(PackedByteArray([16, 0, 0, 0, 1, 0, 1, 0, 0x40, 0x1f, 0, 0, 0x80, 0x3e, 0, 0, 2, 0, 16, 0]))
	h.append_array("data".to_ascii_buffer())
	h.append_array(PackedByteArray([n * 2 & 0xff, (n * 2 >> 8) & 0xff, 0, 0]))
	h.append_array(pcm)
	var sz := h.size() - 8
	h[4] = sz & 0xff; h[5] = (sz >> 8) & 0xff
	return h
func _png(col: Color) -> PackedByteArray:
	var im := Image.create(256, 256, false, Image.FORMAT_RGBA8)
	im.fill(Color(0, 0, 0, 0))
	for y in 256:
		for x in 256:
			var d := Vector2(x - 128, y - 128).length()
			if d < 120:
				im.set_pixel(x, y, col.lerp(Color.WHITE, clampf((d - 80.0) / 40.0, 0.0, 1.0) * 0.4))
	return im.save_png_to_buffer()
func _ready() -> void:
	var mode := OS.get_environment("SHOT")
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var nm := "sh%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await _post("/__test/coins/%s/500" % nm)
	await Online.refresh_profile()
	var ui = main.ui
	var scr = ui._online
	Skins.add_glb(ProjectSettings.globalize_path("res://samples/sample_anim.glb"), "رباتِ آبی")
	var e: Dictionary = Skins.current_entry()
	var key := Skins.char_key(e)
	Content.set_char_default(key, "Wave", true)
	await Online.admin_upload("p/coin.png", _png(Color("ffc21a")), "image/png")
	await Online.admin_upload("p/gem.png", _png(Color("46c8ff")), "image/png")
	await Online.admin_upload("p/coin.png", _png(Color("ffc21a")), "image/png", "previews")
	await Online.admin_upload("p/gem.png", _png(Color("46c8ff")), "image/png", "previews")
	await Online.admin_upload("v/s.wav", _wav(), "audio/wav")
	await Online.admin_save_item({"kind": "coin", "name": "سکه‌ی طلایی درخشان", "price": 120, "rarity": "legendary", "featured": true, "status": "approved", "file_path": "p/coin.png", "preview_path": "p/coin.png", "description": "سکه‌ای که زیر نور می‌چرخد و برق می‌زند."})
	await Online.admin_save_item({"kind": "coin", "name": "سکه‌ی یخی", "price": 60, "rarity": "rare", "discount_percent": 25, "status": "approved", "file_path": "p/gem.png", "preview_path": "p/gem.png"})
	await Online.admin_save_item({"kind": "anim_clip", "name": "Jump", "price": 30, "rarity": "epic", "status": "approved", "payload": {"char": key, "char_name": "رباتِ آبی", "clip": "Jump"}})
	await Online.admin_save_item({"kind": "voice", "name": "پرشِ فنری", "price": 20, "rarity": "rare", "status": "approved", "file_path": "v/s.wav", "payload": {"char": key, "char_name": "رباتِ آبی", "event": "jump"}})
	await Online.load_items()
	Edition.simulate_public = (OS.get_environment("PUB") == "1")
	ui._set_screen(ui.Screen.ONLINE_STORE)
	scr.store_filter = ""
	scr.refresh_store()
	if mode.begins_with("studio"):
		scr.store_filter = "@chars"
		scr.studio.sel_key = key
		scr.studio.tab = "voice" if mode.begins_with("studio_voice") else "anim"
		scr.refresh_store()
	elif mode == "detail":
		for it in Online.items:
			if String(it.kind) == "coin":
				scr._open_detail(it); break
	elif mode == "detail_voice":
		for it in Online.items:
			if String(it.kind) == "voice":
				scr._open_detail(it); break
	for i in 10: await get_tree().process_frame
	await get_tree().create_timer(2.0).timeout
	if mode == "home2":
		scr._store_scroll.scroll_vertical = 700
		await get_tree().create_timer(0.3).timeout
	if mode.begins_with("studio") and mode.ends_with("2"):
		scr._store_scroll.scroll_vertical = 760
		await get_tree().create_timer(0.3).timeout
		await get_tree().create_timer(0.3).timeout
	get_viewport().get_texture().get_image().save_png("/tmp/ss_%s.png" % mode)
	get_tree().quit()
