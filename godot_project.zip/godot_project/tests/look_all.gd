extends Node
## عکس از همه‌ی صفحه‌ها در هر شش سبک دکمه (برای بررسی چشمی). خروجی: /tmp/la/<style>_<n>_<name>.png
var main
var f := 0
var ui
var styles := ["classic", "glass", "flat", "neon", "candy", "outline"]
var shots: Array = []     # [name, Callable]
var step := 14
var i := 0
func _ready() -> void:
	DirAccess.make_dir_recursive_absolute("/tmp/la")
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	ui = main.ui
	var nm := "la%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765/__test/admin/%s/0" % nm, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	await Online.refresh_profile()
	await Online.submit_run(900, 300, 45)
	for k in ["glb", "voice", "music", "coin"]:
		await Online.admin_save_item({"kind": k, "name": "نمونه " + k, "price": 120, "discount_percent": 20 if k == "glb" else 0, "stock": 4 if k == "voice" else null, "rarity": "epic", "status": "approved", "featured": k == "glb"})
	await Online.load_items()
	Skins.add_glb("res://samples/sample_robot.glb", "ربات")
	var S = ui.Screen
	shots = [
		["start", func(): ui._set_screen(S.START)],
		["settings", func(): ui._set_screen(S.SETTINGS)],
		["character", func(): ui._set_screen(S.CHARACTER)],
		["store", func(): ui._online.store_filter = ""; ui._set_screen(S.ONLINE_STORE)],
		["store_mgr", func(): ui._online.store_admin.open_manager("glb")],
		["store_form", func(): ui._online.store_admin.open_form({})],
		["account", func(): ui._set_screen(S.ACCOUNT)],
		["missions", func(): ui._set_screen(S.MISSIONS)],
		["shop", func(): ui._set_screen(S.SHOP)],
		["rules", func(): ui._set_screen(S.RULES)],
		["content0", func(): ui._editors._tab = 0; ui._set_screen(S.CONTENT); ui._editors.refresh_content()],
		["content1", func(): ui._editors._tab = 1; ui._set_screen(S.CONTENT); ui._editors.refresh_content()],
		["content2", func(): ui._editors._tab = 2; ui._set_screen(S.CONTENT); ui._editors.refresh_content()],
		["content3", func(): ui._editors._tab = 3; ui._set_screen(S.CONTENT); ui._editors.refresh_content()],
		["gameover", func(): ui._set_screen(S.GAMEOVER)],
	]
	set_process(true)
func _process(_d):
	if shots.is_empty():
		return
	f += 1
	var total := styles.size() * shots.size()
	if i >= total:
		get_tree().quit()
		return
	var si := i / shots.size()
	var pi := i % shots.size()
	var ph := f % step
	if ph == 1:
		Content.look_set("style", styles[si])
		if ui._online.store_admin._over != null and is_instance_valid(ui._online.store_admin._over):
			ui._online.store_admin._over.queue_free()
		shots[pi][1].call()
	elif ph == step - 2:
		get_viewport().get_texture().get_image().save_png("/tmp/la/%s_%02d_%s.png" % [styles[si], pi, shots[pi][0]])
		i += 1
