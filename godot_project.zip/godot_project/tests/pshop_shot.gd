extends Node
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	var mode := OS.get_environment("SHOT")
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var nm := "ps%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/coins/%s/900" % nm)
	await Online.refresh_profile()
	var ui = main.ui
	for id in ["rocket", "shield", "ghost", "magnet"]:
		await Game.buy_boost(id, 2)
	Game.set_loadout("rocket", true); Game.set_loadout("ghost", true)
	Game.auto_start["rocket"] = true
	await get_tree().create_timer(0.3).timeout
	if mode == "hud":
		Game.start_run()
		Game.use_boost("ghost")
		Game.register_power(Game.Power.MAGNET)
		Game.register_power(Game.Power.DOUBLE)
		ui._set_screen(ui.Screen.GAME)
	elif mode == "start":
		ui._set_screen(ui.Screen.START)
	else:
		ui._pshop._tab = "upgrade" if mode == "upg" else "boost"
		ui._set_screen(ui.Screen.SHOP)
		ui._refresh_all()
	for i in 40: await get_tree().process_frame
	await get_tree().create_timer(0.8).timeout
	get_viewport().get_texture().get_image().save_png("/tmp/ps_%s.png" % (mode if mode != "" else "boost"))
	print("SHOT done")
	get_tree().quit()
