extends Node
## تعقیب‌کننده داخل «کاراکتر من»: فقط وقتی فعال است، در فروشگاه عمومی نیست
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var nm := "ch%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	var ui = main.ui
	var scr = ui._online
	var st = scr.studio
	ok(Content.chaser_studio_on(), "owner: chaser studio on")
	var a := await Online.admin_save_item({"kind": "chaser_anim", "name": "دلقک می‌رقصد", "price": 10, "status": "approved", "payload": {"clip": "Wave"}})
	ok(a.ok, "admin adds chaser anim item")
	var v := await Online.admin_save_item({"kind": "chaser_voice", "name": "خنده", "price": 10, "status": "approved", "payload": {"event": "chaser_near"}})
	ok(v.ok, "admin adds chaser voice item")
	await Online.load_items()
	Edition.simulate_public = false
	var vis := Content.store_visible()
	var leaked := false
	for it in Online.items:
		if String(it.kind) in ["chaser_voice", "chaser_anim"] and Content.store_shows_kind(String(it.kind)): leaked = true
	ok(not leaked, "chaser items hidden from public store grid")
	scr.store_filter = "@chars"
	st.sel_key = Rules.CHASER
	st.tab = "voice"
	scr.refresh_store()
	await get_tree().process_frame
	await get_tree().process_frame
	ok(st._is_chaser(), "studio selects chaser pseudo-character")
	ok(st._list != null and st._list.get_child_count() >= 1, "chaser voice list filled (%d)" % st._list.get_child_count())
	st.tab = "anim"; st._fill()
	await get_tree().process_frame
	ok(st._list.get_child_count() >= 1, "chaser anim list filled (%d)" % st._list.get_child_count())
	ok(Rules.CHASER_SLOT_EVENTS.size() == 4, "4 chaser slot events")
	st.sel_key = ""
	Edition.simulate_public = true
	ok(not st._is_chaser(), "public: no chaser target")
	print("[CHASER] " + ("PASSED" if fails == 0 else "FAILED %d" % fails))
	get_tree().quit()
