extends Node
## اسکرین‌شات صفحه‌های نسخه‌ی عمومی (فقط برای تست)
var main
var f := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	Edition.simulate_public = true
	Edition.changed.emit()
func _process(_d: float) -> void:
	f += 1
	var ui = main.ui
	var d := OS.get_environment("SHOT_DIR")
	match f:
		5: ui._set_screen(ui.Screen.START)
		20: get_viewport().get_texture().get_image().save_png(d + "/pub_start.png")
		25: ui._set_screen(ui.Screen.SETTINGS)
		50: get_viewport().get_texture().get_image().save_png(d + "/pub_settings.png")
		55: ui._set_screen(ui.Screen.CHARACTER)
		80: get_viewport().get_texture().get_image().save_png(d + "/pub_char.png")
		85: ui._set_screen(ui.Screen.SHOP)
		110: get_viewport().get_texture().get_image().save_png(d + "/pub_shop.png")
		115: ui._set_screen(ui.Screen.INTRO)
		140: get_viewport().get_texture().get_image().save_png(d + "/pub_intro_ui.png")
		145: get_tree().quit()
