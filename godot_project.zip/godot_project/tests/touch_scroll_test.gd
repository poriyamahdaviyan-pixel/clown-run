extends Node
## کشیدن با انگشت روی لیستی از دکمه‌ها باید اسکرول کند (نه فقط وقتی انگشت روی فضای خالی است)
var main
var f := 0
var sc: ScrollContainer
var start := Vector2.ZERO
func _find_sc(n: Node) -> ScrollContainer:
	if n is ScrollContainer and (n as ScrollContainer).is_visible_in_tree() and (n as ScrollContainer).get_v_scroll_bar().max_value > (n as ScrollContainer).size.y + 20:
		return n
	for c in n.get_children():
		var r := _find_sc(c)
		if r != null:
			return r
	return null
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
func _process(_d: float) -> void:
	f += 1
	var ui = main.ui
	if f == 5:
		ui._set_screen(ui.Screen.CHOOSER)
	if f == 20:
		sc = _find_sc(ui._editors.chooser)
		print("[scroll] found=", sc != null)
		if sc == null:
			print("[TOUCHSCROLL] FAILED no scroll"); get_tree().quit(); return
		# وسط یک OptionButton
		var ob: Control = null
		for c in sc.find_children("*", "OptionButton", true, false):
			ob = c; break
		start = ob.get_global_rect().get_center()
		print("[scroll] pad mouse_filter=", ob.mouse_filter, " start=", start)
		var t := InputEventScreenTouch.new(); t.index = 0; t.position = start; t.pressed = true
		Input.parse_input_event(t)
	if f >= 22 and f < 32:
		var d := InputEventScreenDrag.new(); d.index = 0; d.position = start + Vector2(0, -(f - 21) * 14.0); d.relative = Vector2(0, -14.0)
		Input.parse_input_event(d)
	if f == 33:
		var t2 := InputEventScreenTouch.new(); t2.index = 0; t2.position = start + Vector2(0, -140); t2.pressed = false
		Input.parse_input_event(t2)
	if f == 25:
		var ob2 = sc.find_children("*", "OptionButton", true, false)[0]
		print("[scroll] popup open during drag=", ob2.get_popup().visible)
	if f == 40:
		print("[scroll] scroll_vertical=", sc.scroll_vertical)
		var popup_open: bool = sc.find_children("*", "OptionButton", true, false).any(func(o): return o.get_popup().visible)
		print("[scroll] popup open at end=", popup_open)
		print("[TOUCHSCROLL] ", "PASSED" if sc.scroll_vertical > 40 and not popup_open else "FAILED")
		get_tree().quit()
