extends Node
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _ready() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().create_timer(1.0).timeout
	var ui = main.ui
	var host := Control.new()
	ui.add_child(host)
	host.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v: VBoxContainer = ui.make_scroll_view(host)
	var long_text := "پیش‌نمایش جدا و کوتاه بده تا هرکس آدرسش را بداند نتواند بدون خرید ببیند و همچنین یک جمله‌ی خیلی خیلی بلند دیگر"
	var l := Label.new(); l.text = long_text; v.add_child(l)
	var fl := Label.new(); fl.text = "✓ 9ae5f219-ab40-41a1-913d-d3e0974636de_1234567890123.jpg"; v.add_child(fl)
	var cb := CheckBox.new(); cb.text = long_text; v.add_child(cb)
	var bt := Button.new(); bt.text = long_text; v.add_child(bt)
	var hb := HBoxContainer.new(); v.add_child(hb)
	var hl := Label.new(); hl.text = long_text; hb.add_child(hl)
	var hbtn := Button.new(); hbtn.text = "ثبت"; hb.add_child(hbtn)
	await get_tree().create_timer(0.9).timeout
	var sc: ScrollContainer = v.get_parent()
	print("scroll w ", sc.size.x, " content min w ", v.get_combined_minimum_size().x, " vbox w ", v.size.x)
	var vw := 720.0
	print("viewport w ", vw, " content min w ", v.get_combined_minimum_size().x)
	ok(v.get_combined_minimum_size().x <= vw, "content never wider than the screen")
	ok(l.get_line_count() > 1, "label wraps")
	ok(bt.autowrap_mode != TextServer.AUTOWRAP_OFF, "long button wraps")
	print("[FIT] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
