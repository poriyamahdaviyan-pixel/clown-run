extends Node
const GlbModel := preload("res://scripts/glb_model.gd")
var fails := 0
func ok(c: bool, w: String) -> void:
	if not c:
		fails += 1
		print("[FAIL] ", w)
func _find(sk: Skeleton3D, key: String) -> int:
	for i in sk.get_bone_count():
		if sk.get_bone_name(i).ends_with(key):
			return i
	return -1


func _ready() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var m := GlbModel.new()
	add_child(m)
	ok(m.load_from_file("res://samples/sample_robot.glb", 0), "load sample: " + m.load_error)
	print("height ", m.height_m, " clips ", m.clip_names)
	ok(absf(m.height_m - 1.9) < 0.05, "normalized height")
	ok(m._anim != null and m.clip_for("run") == "run", "animation found")
	var bad := GlbModel.new()
	add_child(bad)
	ok(not bad.load_from_file("res://project.godot", 0) and bad.load_error != "", "reject non-glb")
	# اضافه‌کردن به کاراکترها
	var before: int = Skins.entries.size()
	ok(Skins.add_glb("res://samples/sample_robot.glb", "ربات") == "", "add_glb")
	ok(Skins.entries.size() == before + 1 and Skins.current_is_glb(), "selected glb")
	ok(Skins.add_glb("res://project.godot", "x") != "", "reject wrong ext")
	await get_tree().create_timer(0.3).timeout
	# بازیکن مدل را عوض کرده؟
	var pl = main.player
	ok(pl._model.get("is_glb") == true, "player switched to glb model")
	Skins.cycle_glb_yaw()
	await get_tree().process_frame
	ok(int(Skins.current_entry()["glb_yaw"]) == 1, "yaw cycles")
	Game.start_run()
	for i in 90:
		await get_tree().process_frame
	ok(pl._model.get("is_glb") == true, "still glb in run")
	Game.quit_to_menu()
	# پیش‌نمایش
	main.ui._set_screen(main.ui.Screen.CHARACTER)
	await get_tree().process_frame
	ok(main.ui._pv["char"]["content"].get("is_glb") == true, "preview glb")
	var id: String = Skins.current_id
	Skins.delete_current()
	await get_tree().process_frame
	ok(Skins.current_id == "preset0" and Skins.get_entry(id).is_empty(), "deleted glb -> falls back to preset0")
	Skins.select("preset0")
	await get_tree().process_frame
	ok(pl._model.get("is_glb") != true, "player back to blocky")
	ok(main.ui._pv["char"]["content"].get("is_glb") != true, "preview back to blocky")
	# نسخه‌ی عمومی: افزودن GLB قفل است ولی خرید از فروشگاه (add_glb) کار می‌کند
	Edition.set_simulate_public(true)
	ok(not Edition.can_import_glb(), "public edition: import locked")
	Edition.set_simulate_public(false)
	ok(Edition.can_import_glb(), "owner edition: import allowed")
	# ---- مدل اسکلت‌دار: تشخیص استخوان و حرکت ساختگی ----
	var rg := GlbModel.new()
	add_child(rg)
	ok(rg.load_from_file("res://samples/sample_rigged.glb", 0), "load rigged: " + rg.load_error)
	print(rg.rig_info)
	ok(rg.has_rig, "humanoid rig detected")
	var roles := rg.rig_roles()
	print(roles)
	for need in ["thigh_-1", "thigh_1", "shin_-1", "arm_-1", "arm_1", "fore_1", "head_0", "hips_0"]:
		var found := false
		for r in roles:
			if String(r).begins_with(need):
				found = true
		ok(found, "role " + need)
	var sk: Skeleton3D = rg._skel
	if sk == null:
		print("[FAIL] no skeleton")
		get_tree().quit(1)
		return
	var lthigh := _find(sk, "LeftUpLeg")
	var rthigh := _find(sk, "RightUpLeg")
	var larm := _find(sk, "LeftArm")
	var seen := {}
	for state in GlbModel.STATES:
		var ph := 0.0
		for i in 30:
			ph += 0.3
			rg.animate_state({"moving": state == "run", "speed": 14.0, "phase": ph, "airborne": state == "jump", "sliding": state == "slide", "flying": state == "fly", "hit": state == "hit", "landing": state == "land", "vy": 2.0, "t": ph}, 1.0 / 60.0)
		seen[state] = [sk.get_bone_pose_rotation(lthigh), sk.get_bone_pose_rotation(rthigh), sk.get_bone_pose_rotation(larm)]
		print(state, " lthigh=", seen[state][0].get_euler().x, " larm=", seen[state][2].get_euler().x)
	ok(not seen["run"][0].is_equal_approx(seen["idle"][0]), "run differs from idle")
	ok(not seen["fly"][2].is_equal_approx(seen["idle"][2]), "fly arms differ")
	ok(not seen["jump"][0].is_equal_approx(seen["slide"][0]), "jump differs from slide")
	ok(not seen["run"][0].is_equal_approx(seen["run"][1]), "legs alternate in run")
	# ---- نام استخوان‌های ناشناخته + گره‌ی اسکلت چرخیده (مثل مدل‌های ریگ‌شده‌ی خود کاربر) ----
	var sc := GlbModel.new()
	add_child(sc)
	sc.load_from_file("res://samples/sample_rigged.glb", 0)
	var sk2: Skeleton3D = sc._skel
	for i in sk2.get_bone_count():
		sk2.set_bone_name(i, "b%d" % i)
	sk2.rotation_degrees = Vector3(0, 90, 0) if false else sk2.rotation_degrees
	sc._roles.clear()
	sc._role_of.clear()
	sc._order.clear()
	sc._setup_rig()
	print("scrambled: ", sc.rig_info, " ", sc.rig_roles())
	ok(sc.has_rig, "rig guessed from shape")
	var thL := -1
	for r in sc.rig_roles():
		if String(r).begins_with("thigh_-1"):
			thL = int(String(r).split("← b")[1])
	ok(thL >= 0, "thigh guessed")
	if thL >= 0:
		var q0: Quaternion = sk2.get_bone_pose_rotation(thL)
		for i in 30:
			sc.animate_state({"moving": true, "speed": 14.0, "phase": 0.3 * i, "airborne": false, "sliding": false, "flying": false, "hit": false, "landing": false, "vy": 0.0, "t": 0.3 * i}, 1.0 / 60.0)
		ok(not sk2.get_bone_pose_rotation(thL).is_equal_approx(q0), "guessed thigh moves")
	# کلیپ بی‌نام تبدیل به «دویدن» می‌شود؛ «hair» پرش حساب نمی‌شود
	ok(sc._kw_match("Armature|Run_cycle", "run") and not sc._kw_match("hairflip", "air") and sc._kw_match("Jump", "jump"), "keyword matcher")
	# تنظیمات
	rg.apply_config({"scale": 1.3, "proc": false})
	ok(absf(rg._holder.scale.x - 1.3) < 0.001, "config scale")
	# انتخاب کلیپ دستی
	var rb := GlbModel.new()
	add_child(rb)
	rb.load_from_file("res://samples/sample_robot.glb", 0)
	ok(rb.clip_for("run") == "run" and rb.clip_for("jump") == "", "clip auto-detect")
	rb.apply_config({"map": {"jump": "run"}})
	ok(rb.clip_for("jump") == "run", "clip manual map")
	rb.apply_config({"map": {"run": "-"}})
	ok(rb.clip_for("run") == "", "force procedural")
	print("[GLB TEST] ", "FAILED" if fails > 0 else "PASSED")
	get_tree().quit(1 if fails > 0 else 0)
