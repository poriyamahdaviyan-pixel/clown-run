extends Node
var main
var f := 0
var ob: OptionButton
var got := -1
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
func _process(_d: float) -> void:
	f += 1
	var ui = main.ui
	if f == 4:
		ui._set_screen(ui.Screen.CHOOSER)
	if f == 15:
		ob = null
		for o in ui.find_children("*", "OptionButton", true, false):
			if o.is_visible_in_tree(): ob = o; break
		print("[PICK] ob found=", ob != null, " items=", ob.item_count)
		ob.item_selected.connect(func(i): got = i)
		ob.get_popup().popup()
	if f == 24:
		get_viewport().get_texture().get_image().save_png("/tmp/sh2/pick.png")
	if f == 25:
		print("[PICK] popup visible=", ob.get_popup().visible, " picker=", ui._picker != null)
		var sc: ScrollContainer = ui._picker.find_child("*", true, false) if false else null
		for c in ui._picker.find_children("*", "Button", true, false):
			if (c as Button).text.contains("آماده") or true:
				pass
		var bs: Array = ui._picker.find_children("*", "Button", true, false)
		print("[PICK] buttons=", bs.size()); pass
		bs[2].pressed.emit()
	if f == 30:
		print("[PICK] selected=", got, " picker closed=", ui._picker == null)
		pass
		get_tree().quit()
