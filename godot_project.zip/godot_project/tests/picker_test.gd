extends Node
## انتخابگر فایل: بند‌انگشتی بدون هنگ (نخ جدا)، عکس‌های بزرگ، عدم هنگ حلقه‌ی اصلی
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _ready() -> void:
	var dir := ProjectSettings.globalize_path("user://picktest")
	DirAccess.make_dir_recursive_absolute(dir)
	for i in 10:
		var im := Image.create(4000, 3000, false, Image.FORMAT_RGB8)
		im.fill(Color(randf(), randf(), randf()))
		im.save_jpg(dir.path_join("big%d.jpg" % i), 0.8)
	var fp := preload("res://scripts/file_picker.gd").new()
	add_child(fp)
	fp.setup("t", ["png", "jpg", "jpeg", "webp", "bmp"])
	await get_tree().process_frame
	var t0 := Time.get_ticks_msec()
	fp._show_folder(dir)
	var worst := 0
	var last := Time.get_ticks_msec()
	var done := 0
	for f in 600:
		await get_tree().process_frame
		var now := Time.get_ticks_msec()
		worst = maxi(worst, now - last)
		last = now
		done = 0
		for b in fp._grid.get_children():
			if (b as Button).icon != null:
				done += 1
		if done >= 10:
			break
	print("worst frame ms: ", worst, " thumbs: ", done, " total ms: ", Time.get_ticks_msec() - t0)
	ok(fp._grid.get_child_count() == 10, "10 buttons")
	ok(done == 10, "all thumbnails arrived")
	ok(worst < 400, "main loop never blocked long (worst %d ms)" % worst)
	var got := []
	fp.picked.connect(func(p): got.append(p))
	(fp._grid.get_child(0) as Button).pressed.emit()
	ok(got.size() == 1 and String(got[0]).ends_with(".jpg"), "pick emits path")
	await get_tree().process_frame
	print("[PICKER] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
