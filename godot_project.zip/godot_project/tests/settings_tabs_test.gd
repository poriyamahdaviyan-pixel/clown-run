extends Node
## همه‌ی کنترل‌های تنظیمات باید در یکی از تب‌ها باشند، با متن پر، و با تب درست دیده شوند.
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _ready() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	for i in 3: await get_tree().process_frame
	var s = main.ui._settings
	s.refresh()
	var single := {"_sound_btn": "general", "_vib_btn": "general", "_intro_btn": "general", "_cam_btn": "general",
		"_look_btn": "general", "_theme_btn": "general", "_steer_btn": "general", "_npc_btn": "general",
		"_portal_btn": "portals", "_pskin_btn": "portals", "_pdest_btn": "portals", "_ptrig_btn": "portals",
		"_quality_btn": "general", "_plevel_btn": "portals", "_plen_btn": "portals", "_pret_btn": "portals", "_pretlv_btn": "portals"}
	for nm in single:
		var b: Button = s.get(nm)
		ok(b != null and b.is_inside_tree(), nm + " exists")
		if b == null: continue
		ok(s._pages[single[nm]].is_ancestor_of(b), nm + " is in tab " + single[nm])
		ok(b.text != "", nm + " has text")
	ok(s._mode_btns.size() == Modes.IDS.size(), "one toggle per world/mini-game (%d)" % s._mode_btns.size())
	for mid in s._mode_btns:
		ok(s._pages["portals"].is_ancestor_of(s._mode_btns[mid]) and s._mode_btns[mid].text != "", "mode toggle " + mid)
	ok(s._pages["audio"].is_ancestor_of(s._snd_box) , "sound panel in audio tab")
	for nm in ["_ctrl_head", "_target_box", "_no_glb_box", "_police_box", "_body_box"]:
		ok(s._pages["character"].is_ancestor_of(s.get(nm)), nm + " in character tab")
	ok(s._pages["owner"].is_ancestor_of(s._owner_box), "owner panel in owner tab")
	for k in s._pages:
		s._show_tab(k)
		var vis := 0
		for p in s._pages: if s._pages[p].visible: vis += 1
		ok(vis == 1 or (k == "owner" and not Edition.has_owner_rights()), "only one tab visible for " + k)
	print("[SETTINGSTABS] " + ("PASSED" if fails == 0 else "FAILED"))
	get_tree().quit()
