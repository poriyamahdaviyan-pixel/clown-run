extends Node
var fails := 0
func ok(c: bool, w: String) -> void:
	if not c:
		fails += 1
		print("[FAIL] ", w)
func _ready() -> void:
	await get_tree().process_frame
	for i in 4:
		CoinSkin.select_design(i)
		CoinSkin.set_density(0.2 + 0.2 * i)
		CoinSkin.set_contrast(0.3 + 0.2 * i)
		await get_tree().create_timer(0.3).timeout
		print("design ", i, " build ms=", CoinSkin.build_ms)
		var img := CoinSkin.preview_tex.get_image()
		img.save_png("/tmp/shots/coin_%d.png" % i)
		var dark := 0
		for y in range(0, img.get_height(), 2):
			for x in range(0, img.get_width(), 2):
				var c := img.get_pixel(x, y)
				if c.a > 0.5 and c.r < 0.5:
					dark += 1
		ok(dark > 200, "design %d has ink (%d)" % [i, dark])
	ok(not CoinSkin.draft_is_saved(), "draft differs from saved")
	var ph := Image.create(240, 300, false, Image.FORMAT_RGBA8)
	for y in 300:
		for x in 240:
			var col := Color(0.25, 0.55, 0.85).lerp(Color(0.5, 0.75, 0.95), float(y) / 300.0)
			var fd := Vector2((x - 120) / 62.0, (y - 130) / 80.0).length()
			var hd := Vector2((x - 120) / 70.0, (y - 95) / 60.0).length()
			if y > 200 and absf(x - 120) < 40 + (y - 200) * 0.9:
				col = Color(0.75, 0.15, 0.2).lerp(Color(0.4, 0.05, 0.1), float(x - 80) / 120.0)
			if fd < 1.0:
				col = Color(0.95, 0.75, 0.6).lerp(Color(0.7, 0.45, 0.35), clampf(fd * fd, 0.0, 1.0) * 0.8 + (float(x) - 120.0) / 400.0)
			if hd < 1.0 and y < 100:
				col = Color(0.15, 0.1, 0.07)
			if fd < 1.0 and (Vector2(x - 100, y - 118).length() < 6 or Vector2(x - 140, y - 118).length() < 6):
				col = Color(0.05, 0.05, 0.05)
			ph.set_pixel(x, y, col)
	ph.save_png("/tmp/shots/portrait_src.png")
	ok(CoinSkin.set_image(ph) == "", "photo ok")
	await get_tree().create_timer(0.3).timeout
	CoinSkin.preview_tex.get_image().save_png("/tmp/shots/coin_photo.png")
	var cut := CoinSkin.cutout_image()
	ok(cut != null and cut.get_pixel(3, 3).a < 0.1 and cut.get_pixel(120, 130).a > 0.9, "background removed (corner transparent, face opaque)")
	if cut != null:
		cut.save_png("/tmp/shots/portrait_cut.png")
	CoinSkin.toggle_bg()
	await get_tree().create_timer(0.3).timeout
	CoinSkin.preview_tex.get_image().save_png("/tmp/shots/coin_photo_nobgremoval.png")
	CoinSkin.toggle_bg()
	await get_tree().create_timer(0.3).timeout
	ok(CoinSkin.export_cutout().has("ok"), "export cutout api")
	CoinSkin.save_draft()
	ok(CoinSkin.draft_is_saved(), "saved")
	ok(int(CoinSkin.saved["design"]) == CoinSkin.PHOTO, "saved is photo")
	CoinSkin.reset_default()
	ok(CoinSkin.draft_is_saved() and int(CoinSkin.saved["design"]) == 0, "reset")
	print("[COIN TEST] ", "FAILED" if fails > 0 else "PASSED")
	get_tree().quit(1 if fails > 0 else 0)
