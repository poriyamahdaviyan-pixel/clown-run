extends Node
## مدیریت آیتم فروشگاه با سرور ساختگی: افزودن با فایل zip و عکس، تخفیف، تایمر، موجودی، پنهان، ترتیب، حذف
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var nm := "adm%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	ok(Online.is_admin, "admin")
	var ui = main.ui
	var scr = ui._online
	ui._set_screen(ui.Screen.ONLINE_STORE)
	await get_tree().create_timer(0.5).timeout
	var sa = scr.store_admin
	sa.open_manager("glb")
	await get_tree().create_timer(0.5).timeout
	ok(sa._list.is_empty(), "glb section empty at first")
	sa.open_form({})
	ok(sa._is_new and String(sa._item.kind) == "glb", "new item defaults to section kind")
	# فایل‌ها: zip و عکس
	var base := ProjectSettings.globalize_path("user://sa")
	DirAccess.make_dir_recursive_absolute(base)
	var zp := ZIPPacker.new(); zp.open(base + "/m.zip"); zp.start_file("a.glb")
	zp.write_file(FileAccess.get_file_as_bytes("res://samples/sample_robot.glb")); zp.close_file(); zp.close()
	var img := Image.create(32, 32, false, Image.FORMAT_RGBA8); img.fill(Color.RED); img.save_png(base + "/p.png")
	sa._f.name.text = "ربات زمان‌دار"
	sa._f.price.text = "200"
	sa._f.disc.text = "25"
	sa._keep()
	sa._item["stock"] = 5
	sa._timer_on = true; sa._timer_val = "2"; sa._timer_unit = 2
	sa._start_timer()
	sa._item["featured"] = true
	sa._file_local = base + "/m.zip"; sa._prev_local = base + "/p.png"
	await sa._save()
	await get_tree().create_timer(0.5).timeout
	await sa._reload()
	ok(sa._list.size() == 1, "item created, list=%d" % sa._list.size())
	var it: Dictionary = sa._list[0]
	ok(int(it.price) == 200 and int(it.discount_percent) == 25 and Online.price_of(it) == 150, "price 200 -25%% = %d" % Online.price_of(it))
	ok(int(it.stock) == 5 and bool(it.featured), "stock+featured saved")
	var left := Time.get_unix_time_from_datetime_string(String(it.ends_at).left(19)) - Time.get_unix_time_from_system()
	ok(left > 2 * 86400 - 120 and left < 2 * 86400 + 120, "timer ~2 days (%d s)" % left)
	ok(String(it.file_path).ends_with(".zip") and String(it.file_path).begins_with("glb/"), "zip uploaded as " + String(it.file_path))
	var hp = it.get("preview_path", "")
	ok(hp == null or String(hp) == "" or String(hp).ends_with(".png"), "auto preview optional in headless (no GPU): " + str(hp))
	ok(Online.item_state(it) == "locked", "state locked (buyable)")
	ok(preload("res://scripts/store_admin.gd").ends_text(String(it.ends_at)).contains("روز"), "countdown text: " + preload("res://scripts/store_admin.gd").ends_text(String(it.ends_at)))
	# ویرایش: تخفیف، پایان تایمر، پنهان
	sa.open_form(it)
	sa._f.disc.text = "50"; sa._keep()
	sa._timer_on = false
	sa._item["status"] = "hidden"
	await sa._save()
	await sa._reload()
	it = sa._list[0]
	ok(int(it.discount_percent) == 50 and it.ends_at == null and String(it.status) == "hidden", "edit saved: disc/no timer/hidden")
	ok(String(it.file_path).ends_with(".zip"), "file kept when not replaced")
	# بخش دوم + ترتیب + تخفیف کلی
	sa.open_form_for("glb", {})
	sa._f.name.text = "دوم"; sa._f.price.text = "10"; sa._keep()
	sa._file_local = base + "/p.png"
	await sa._save()
	await sa._reload()
	ok(sa._list.size() == 2, "second item")
	var first := String(sa._list[0].id)
	await sa._move(0, 1)
	ok(String(sa._list[1].id) == first, "moved down")
	await sa._bulk_discount(30)
	ok(int(sa._list[0].discount_percent) == 30 and int(sa._list[1].discount_percent) == 30, "bulk discount")
	# بازیکن عادی: آیتم پنهان دیده نمی‌شود
	var hid := String(sa._list[1].id)
	await sa._delete(hid); await sa._delete(hid)
	await sa._reload()
	ok(sa._list.size() == 1, "deleted after confirm")
	# بخش آهنگ وجود دارد
	var has_music := false
	for sec in Content.store_all():
		if String(sec.kind) == "music": has_music = true
	ok(has_music, "music store section exists")
	print("[STORE_ADMIN] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
