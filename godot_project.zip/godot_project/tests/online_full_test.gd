extends Node
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"
	Online.anon_key = "ANON"
	ok(not Online.gate_open(), "gate closed before login")
	var r := await Online.sign_up("full" + str(randi() % 100000), "secret1")
	ok(r.ok and Online.gate_open(), "sign up opens gate")
	ok(Game.coins == Online.coins and Online.levels.size() == 6, "game mirrors server profile")
	var s := await Online.submit_run(100, 100, 100)
	ok(s.ok and Game.coins == 100, "run coins on server -> Game.coins=%d" % Game.coins)
	await Game.buy_upgrade(0)
	ok(Game.levels[0] == 1 and Game.coins == 60 and Online.coins == 60, "upgrade paid on server coins=%d lvl=%d" % [Game.coins, Game.levels[0]])
	await Game.buy_upgrade(0)
	ok(Game.levels[0] == 2 and Game.coins == 60 - 80 + 0 or Game.coins == 60, "second upgrade rejected (no coins) coins=%d lvl=%d" % [Game.coins, Game.levels[0]])
	Game.over = true; Game.used_revive = false; Game.is_active = true
	ok(Game.can_revive(), "can revive with coins")
	await Game.revive()
	ok(Game.coins == 30 and Game.used_revive, "revive paid on server coins=%d" % Game.coins)
	Game.over = false; Game.is_active = false
	Game.missions[0].prog = 7
	Online.queue_save()
	await get_tree().create_timer(4.5).timeout
	await Online.refresh_profile()
	ok(Online.save_data.has("missions"), "missions saved on server")
	# refresh: levels restored from server
	Game.levels[0] = 0
	await Online.refresh_profile()
	ok(Game.levels[0] == 1, "levels restored from server")
	# بدون اینترنت: بازی قطع نمی‌شود، نتیجه صف می‌شود و بعداً ثبت می‌شود
	var got := [null]
	Online.connection_changed.connect(func(o: bool): got[0] = o)
	var good := Online.url
	Online.url = "http://127.0.0.1:1"
	await Online.check_connection()
	ok(Online.offline and got[0] == false, "connection loss detected")
	var before: int = Online.coins
	await Online._on_game_over({"score": 50, "distance": 50, "coins": 10})
	ok(Online.pending.size() == 1 and Game.coins == before + 10, "offline run queued, coins counted locally: %d" % Game.coins)
	Game.over = true; Game.used_revive = false; Game.is_active = true
	await Game.revive()
	ok(Game.used_revive and Game.coins == before + 10 - Game.REVIVE_PRICE and Online.pending.size() == 2, "offline revive allowed coins=%d" % Game.coins)
	var up := await Online.buy_upgrade(2)
	ok(not up.ok, "upgrade needs internet")
	Game.over = false; Game.is_active = false
	Online.url = good
	await Online.check_connection()
	await get_tree().create_timer(1.0).timeout
	ok(not Online.offline and got[0] == true, "connection back detected")
	ok(Online.pending.is_empty() and Online.coins == before + 10 - 30, "queued results sent to server: coins=%d" % Online.coins)
	Online.sign_out()
	ok(not Online.gate_open(), "sign out closes gate")
	print("[FULL] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
