extends Node
var main
var f := 0
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	await Online.sign_up("bn" + str(randi() % 99999), "secret1")
	Online.url = "http://127.0.0.1:1"
	await Online.check_connection()
	main.ui._set_screen(main.ui.Screen.START)
func _process(_d):
	f += 1
	if f == 40:
		get_viewport().get_texture().get_image().save_png("/tmp/sh3/banner.png")
		get_tree().quit()
