extends Node
var main
var f := 0
var names: Array = []
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
func _process(_d: float) -> void:
	f += 1
	var ui = main.ui
	var keys: Array = ui.Screen.keys()
	var want := ["START", "SETTINGS", "CHARACTER", "CONTENT", "RULES", "CHOOSER", "ONLINE_STORE", "ACCOUNT", "BOARD", "CHALLENGE"]
	var i := (f - 10) / 8
	if f >= 10 and (f - 10) % 8 == 0 and i < want.size():
		if want[i] in keys:
			ui._set_screen(ui.Screen[want[i]])
	if f >= 10 and (f - 10) % 8 == 6 and i < want.size():
		get_viewport().get_texture().get_image().save_png("%s/%02d_%s.png" % [OS.get_environment("SHOT_DIR"), i, want[i]])
	if i >= want.size():
		get_tree().quit()
