extends Node
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"
	Online.anon_key = "ANON"
	var nm := "bst" + str(randi() % 100000)
	var r := await Online.sign_up(nm, "secret1")
	ok(r.ok, "sign up")
	await Online.submit_run(100, 100, 100)   # 100 coins (+ implausible guard ok)
	ok(Game.coins == 100, "coins 100: %d" % Game.coins)
	await Game.buy_boost("rocket", 1)
	ok(Game.boost_count("rocket") == 1 and Game.coins == 40, "buy rocket (60): coins=%d n=%d" % [Game.coins, Game.boost_count("rocket")])
	await Game.buy_boost("life", 1)
	ok(Game.boost_count("life") == 0 and Game.coins == 40, "life (80) rejected: no coins")
	await Game.buy_boost("ghost", 1)
	ok(Game.boost_count("ghost") == 0, "ghost (70) rejected")
	await Game.buy_boost("magnet", 1)
	ok(Game.boost_count("magnet") == 1 and Game.coins == 5, "buy magnet (35) coins=%d" % Game.coins)
	# loadout و استفاده‌ی وسط بازی
	Game.set_loadout("rocket", true)
	Game.set_loadout("magnet", true)
	Game.set_loadout("ghost", true)
	Game.set_loadout("freeze", true)
	ok(Game.loadout.size() == 3 and not "freeze" in Game.loadout, "loadout max 3")
	Game.auto_start["magnet"] = true
	Game.start_run()
	ok(Game.has_power(Game.Power.MAGNET) and Game.boost_count("magnet") == 0, "auto-start magnet consumed")
	ok(not Game.use_boost("ghost"), "cannot use boost not owned")
	ok(Game.use_boost("rocket") and Game.has_power(Game.Power.JET) and Game.is_invincible(), "rocket mid-run -> jet + invincible")
	ok(not Game.use_boost("rocket"), "second rocket: none left")
	Game.ghost_left = 0.0
	ok(Game.run_used.get("rocket", 0) == 1 and Game.run_used.get("magnet", 0) == 1, "run_used tracked")
	Game.quit_to_menu()                       # گزارش مصرف به سرور
	await get_tree().create_timer(1.5).timeout
	await Online.refresh_profile()
	ok(int(Online.boosts.get("rocket", 0)) == 0 and int(Online.boosts.get("magnet", 0)) == 0, "server counts consumed: %s" % str(Online.boosts))
	# تقلب: افزایش محلی با refresh برمی‌گردد
	Game.boosts["rocket"] = 50
	await Online.refresh_profile()
	ok(Game.boost_count("rocket") == 0, "local inflation overwritten by server")
	# بلیت زندگی
	await Online._rpc("buy_boost", {"p_id": "life", "p_qty": 1})  # بدون سکه رد می‌شود
	var admin_ok := true
	var coins_before := Game.coins
	# سکه می‌دهیم
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765/__test/coins/%s/500" % nm, [], HTTPClient.METHOD_POST, "")
	await h.request_completed
	await Online.refresh_profile()
	await Game.buy_boost("life", 2)
	ok(Game.boost_count("life") == 2 and Game.coins == 500 - 160, "bought 2 life tickets coins=%d" % Game.coins)
	Game.over = true; Game.used_revive = false; Game.is_active = true
	ok(Game.has_life_ticket() and Game.can_revive(), "can revive with ticket")
	var c0 := Game.coins
	await Game.revive(true)
	ok(Game.used_revive and Game.coins == c0 and Game.boost_count("life") == 1, "ticket revive free, 1 left")
	await Online.refresh_profile()
	ok(int(Online.boosts.get("life", 0)) == 1, "server life=1")
	# قیمت از تنظیم مالک (سرور مرجع)
	Game.is_active = false; Game.over = false
	Game.apply_remote_config({"BOOSTS": {"shield": {"price": 7, "dur": 9.0, "on": true}, "freeze": {"price": 5, "dur": 4.0, "on": false}}})
	ok(Game.boost_price("shield") == 7 and is_equal_approx(Game.boost_dur("shield"), 9.0) and not Game.boost_on("freeze"), "remote cfg applied")
	# بدون پست config واقعی، سرور قیمت پیش‌فرض را می‌گیرد (۴۵)؛ آزمون سمت سرور:
	var before := Game.coins
	await Game.buy_boost("freeze", 1)
	ok(Game.boost_count("freeze") == 0 and Game.coins == before, "disabled boost not sold (client)")
	Online.sign_out()
	print("[BOOSTS] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
