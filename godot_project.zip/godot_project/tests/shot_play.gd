extends Node
## اسکرین‌شات حین بازی (نیاز به سرور آزمایشی)
var f := 0
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var nm := "pl%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/coins/%s/500" % nm)
	await Online.refresh_profile()
	await get_tree().create_timer(0.5).timeout
	get_viewport().get_texture().get_image().save_png("%s/menu.png" % OS.get_environment("SHOT_DIR"))
	Game.START_SPEED = 24.0
	Game.start_run()
	Game.jet_grace = 99999.0
	for i in 26: Game.register_coin()
	await get_tree().create_timer(1.6).timeout
	for i in 3: Game.register_coin()
	get_viewport().get_texture().get_image().save_png("%s/play1.png" % OS.get_environment("SHOT_DIR"))
	await get_tree().create_timer(3.0).timeout
	get_viewport().get_texture().get_image().save_png("%s/play2.png" % OS.get_environment("SHOT_DIR"))
	get_tree().quit()
