extends Node
## اسکرین‌شات صفحه‌های رابط (فقط برای تست). SHOT_SCREENS=studio,coin,...
var main: Node
var f := 0
var ui
var list: Array = []
var si := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	ui = main.get_node("UI") if main.has_node("UI") else null
	for c in main.get_children():
		if c.has_method("_open_studio"):
			ui = c
	list = OS.get_environment("SHOT_SCREENS").split(",")
func _process(_d: float) -> void:
	f += 1
	if ui == null or si >= list.size():
		if f > 20:
			get_tree().quit()
		return
	var step := 40
	var name: String = list[si]
	if f % step == 3 and name.begins_with("set_"):
		if not Skins.current_is_glb():
			Skins.add_glb(OS.get_environment("SHOT_GLB") if OS.get_environment("SHOT_GLB") != "" else "res://samples/sample_rigged.glb", "انسان")
		ui._set_screen(ui.Screen.SETTINGS)
		ui._settings._set_state(name.substr(4))
	elif f % step == 3:
		match name:
			"start": ui._set_screen(ui.Screen.START)
			"missions": ui._set_screen(ui.Screen.MISSIONS)
			"account": ui._set_screen(ui.Screen.ACCOUNT)
			"live_store":
				Online.url = "http://127.0.0.1:8765"
				Online.anon_key = "ANON"
				await Online.sign_up("demo_user", "secret1")
				await Online.submit_run(900, 300, 45)
				await Online.load_items()
				ui._set_screen(ui.Screen.ONLINE_STORE)
			"live_board":
				ui._set_screen(ui.Screen.BOARD)
			"live_account":
				ui._set_screen(ui.Screen.ACCOUNT)
			"board": ui._set_screen(ui.Screen.BOARD)
			"ostore": ui._set_screen(ui.Screen.ONLINE_STORE)
			"studio":
				ui._open_studio("draft")
				var img := Image.load_from_file("/tmp/photo_skin_test.png")
				if img != null:
					pass
			"studio_paint":
				ui._open_studio("draft")
				var cv = ui._studio.canvas
				cv.set_sym(1)
				cv.set_color(Color("ff2fd2"))
				cv._begin(Vector2(10, 10)); cv._end()
				for i in 30:
					cv._begin(Vector2(150 + i * 3, 210 + i)); cv._end()
			"coin": ui._set_screen(ui.Screen.COIN)
			"char_glb":
				Skins.add_glb("res://samples/sample_robot.glb", "ربات")
				ui._set_screen(ui.Screen.CHARACTER)
			"game_glb":
				Game.start_run()
				Game.jet_grace = 999.0
			"game_jet":
				Game.quit_to_menu()
				Skins.add_glb("res://samples/sample_rigged.glb", "انسان")
				Game.start_run()
				Game.register_power(Game.Power.JET)
			"game_police":
				Game.quit_to_menu()
				Game.start_run()
				Game.register_obstacle_hit()
			"char_back":
				Game.quit_to_menu()
				Skins.delete_current()
			"char": ui._set_screen(ui.Screen.CHARACTER)
	if f % step == step - 2:
		get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT_DIR") + "/ui_%s.png" % name)
		si += 1
