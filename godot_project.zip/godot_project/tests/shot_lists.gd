extends Node
var main
var f := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
func _process(_d: float) -> void:
	f += 1
	var ui = main.ui
	var ed = ui._editors
	var d := OS.get_environment("SHOT_DIR")
	match f:
		4:
			Rules.add_rule(Skins.current_id)
			Rules.add_rule(Skins.current_id, {"event": "distance", "action": "anim", "arg": "spin", "at": 500, "every": 0, "chance": 1.0, "max": 0, "replace": false, "cooldown": 0.0})
			ui._set_screen(ui.Screen.RULES)
		14: get_viewport().get_texture().get_image().save_png(d + "/l_rules.png")
		16:
			ui._set_screen(ui.Screen.CONTENT)
			ed._tab = 0; ed.refresh_content()
		28: get_viewport().get_texture().get_image().save_png(d + "/l_texts.png")
		30: ed._tab = 2; ed.refresh_content()
		42: get_viewport().get_texture().get_image().save_png(d + "/l_store.png")
		44:
			ed._tab = 1; ed.refresh_content()
		56: get_viewport().get_texture().get_image().save_png(d + "/l_menu.png")
		58:
			while Rules.rules_of(Skins.current_id).size() > 0:
				Rules.remove_rule(Skins.current_id, 0)
			get_tree().quit()
