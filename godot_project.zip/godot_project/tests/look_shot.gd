extends Node
var main
var f := 0
var styles := ["classic", "glass", "flat", "neon", "candy", "outline"]
var screens := ["START", "SETTINGS", "CHARACTER", "ONLINE"]
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
func _process(_d):
	f += 1
	var ui = main.ui
	var step := 8
	var total := styles.size() * screens.size()
	var i := (f - 4) / step
	if f >= 4 and (f - 4) % step == 0 and i < total:
		var si := i / screens.size()
		var sc := i % screens.size()
		Content.look_set("style", styles[si])
		var name: String = screens[sc]
		if ui.Screen.has(name):
			ui._set_screen(ui.Screen[name])
	if f >= 4 and (f - 4) % step == 6 and i < total:
		get_viewport().get_texture().get_image().save_png("/tmp/sh3/m_%s_%s.png" % [styles[i / screens.size()], screens[i % screens.size()]])
	if f > 4 + step * total + 2:
		get_tree().quit()
