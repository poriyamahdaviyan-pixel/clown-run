extends Node
## بدون پرش دوربین هنگام تحویل اینترو به بازی
var main
var prev := Transform3D.IDENTITY
var prev_fov := 0.0
var was_intro := false
var max_jump := 0.0
var max_rot := 0.0
var handed := false
var frames_after := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	Game.intro_on = true
	Game.play()
var n := 0
func _process(_d: float) -> void:
	n += 1
	if n > 1500:
		print("[HANDOFF] FAILED timeout")
		get_tree().quit()
	var cam: Camera3D = main.cam
	if was_intro and not Game.intro_active:
		handed = true
	if handed:
		frames_after += 1
		var dp := cam.global_position.distance_to(prev.origin)
		var dr := cam.global_transform.basis.get_rotation_quaternion().angle_to(prev.basis.get_rotation_quaternion())
		print("after#%d dpos=%.3f drot(deg)=%.2f dfov=%.2f" % [frames_after, dp, rad_to_deg(dr), cam.fov - prev_fov])
		max_jump = maxf(max_jump, dp)
		max_rot = maxf(max_rot, rad_to_deg(dr))
	was_intro = Game.intro_active
	prev = cam.global_transform
	prev_fov = cam.fov
	if frames_after >= 6:
		print("[HANDOFF] ", "PASSED" if max_jump < 0.25 and max_rot < 1.5 else "FAILED", " maxpos=%.3f maxrot=%.2f" % [max_jump, max_rot])
		get_tree().quit()
