extends Node
func _shot(n: String, w: float = 1.3) -> void:
	await get_tree().create_timer(w).timeout
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [OS.get_environment("SHOT_DIR"), n])
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	await Online.sign_up("np%d" % (Time.get_ticks_msec() % 100000), "secret1")
	Game.intro_on = false
	Game.start_run()
	Game.jet_grace = 99999.0
	await get_tree().create_timer(1.0).timeout
	# ردیف نمایش همه‌ی NPC ها کنار جاده
	var w = main.world
	var i := 0
	for k in ModesExt.NPC_KINDS:
		ModesExt.npc_spawn(w, 1 if i % 2 == 0 else -1, -3.0 - (i / 2) * 2.2, 0.2, 0.3, RandomNumberGenerator.new(), k)
		i += 1
		await _shot("npc_a", 0.3)
	Game.look_style = 5; Game.look_changed.emit()
	await _shot("look_anime", 0.8)
	Game.look_style = 6; Game.look_changed.emit()
	await _shot("look_pixel", 0.8)
	get_tree().quit()
