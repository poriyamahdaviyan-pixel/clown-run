extends Node
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _wav() -> PackedByteArray:
	var pcm := PackedByteArray()
	for i in 4800:
		var v := int(sin(float(i) * 0.2) * 9000.0)
		pcm.append(v & 0xff); pcm.append((v >> 8) & 0xff)
	var h := PackedByteArray()
	h.append_array("RIFF".to_ascii_buffer()); h.append_array(PackedByteArray([0, 0, 0, 0]))
	h.append_array("WAVEfmt ".to_ascii_buffer())
	h.append_array(PackedByteArray([16, 0, 0, 0, 1, 0, 1, 0, 0x40, 0x1f, 0, 0, 0x80, 0x3e, 0, 0, 2, 0, 16, 0]))
	h.append_array("data".to_ascii_buffer())
	h.append_array(PackedByteArray([9600 & 0xff, (9600 >> 8) & 0xff, 0, 0]))
	h.append_array(pcm)
	return h
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var nm := "is%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	var scr = main.ui._online
	var st = scr.item_studio
	ok(st != null and scr.store_admin.item_studio == st, "item studio wired to store admin")
	Skins.add_glb(ProjectSettings.globalize_path("res://samples/sample_anim.glb"), "رباتِ آبی")
	var e: Dictionary = Skins.current_entry()
	var key := Skins.char_key(e)
	# --- ساخت پیش‌نویس‌ها
	var im := Image.create(64, 64, false, Image.FORMAT_RGBA8); im.fill(Color("ffc21a"))
	var d1: Dictionary = st.add_image_draft("coin", "سکه‌ی تست", im)
	ok(not d1.is_empty() and FileAccess.file_exists(String(d1.file)), "coin draft saved with file")
	var wp := "user://t.wav"
	var f := FileAccess.open(wp, FileAccess.WRITE); f.store_buffer(_wav()); f.close()
	var d2: Dictionary = st.add_draft("voice", "پرش فنری", wp, {"event": "jump", "char": key, "char_name": "رباتِ آبی"})
	ok(not d2.is_empty(), "voice draft saved")
	var d3: Dictionary = st.add_draft("anim_clip", "Wave", "", {"char": key, "char_name": "رباتِ آبی", "clip": "Wave", "event": "start"})
	ok(not d3.is_empty() and String(d3.file) == "", "anim draft has no file")
	ok(st.drafts_of("coin").size() == 1 and st.drafts_of("voice").size() == 1, "drafts listed by kind")
	# باز کردن UI بدون خطا
	st.open()
	await get_tree().process_frame
	await get_tree().process_frame
	ok(st._over != null and is_instance_valid(st._over), "studio overlay opens")
	# --- ارسال صدا/انیمیشن مخصوص کاراکتر
	await st._publish_char_item(d2)
	await st._publish_char_item(d3)
	await Online.load_items()
	var vs := Online.items_of_char(key, "voice")
	var an := Online.items_of_char(key, "anim_clip")
	ok(vs.size() == 1 and String(vs[0].payload.event) == "jump" and String(vs[0].payload.get("pv", "")) != "", "voice published for char with event+pv")
	ok(an.size() == 1 and String(an[0].payload.event) == "start" and String(an[0].payload.clip) == "Wave", "anim published for char with event")
	# --- فرم فروشگاه با پیش‌نویس سکه
	st.close()
	scr.store_admin.open_form_with_draft(d1)
	ok(scr.store_admin._file_local == String(d1.file) and String(scr.store_admin._item.name) == "سکه‌ی تست", "form prefilled from draft")
	await scr.store_admin._save()
	await Online.load_items()
	var coins := Online.items.filter(func(x): return String(x.kind) == "coin" and String(x.name) == "سکه‌ی تست")
	ok(coins.size() == 1 and String(coins[0].file_path) != "", "coin from draft saved to store with file")
	# حذف
	st.remove_draft(String(d1.id))
	ok(st.drafts_of("coin").is_empty() and not FileAccess.file_exists(String(d1.file)), "draft removed with file")
	print("[ISTUDIO] ", "PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
