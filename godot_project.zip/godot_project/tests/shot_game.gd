extends Node
## اسکرین‌شات از قطعه‌های مسیر در هر محیط (فقط برای تست). SHOT_LIST="zone:piece,zone:piece"
var main: Node
var f := 0
var si := 0
var list: PackedStringArray
var OZ := float(OS.get_environment("SHOT_Z")) if OS.get_environment("SHOT_Z") != "" else 0.0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	list = OS.get_environment("SHOT_LIST").split(",", false)
	Game.start_run()
	Game.jet_grace = 99999.0
func _process(_d: float) -> void:
	f += 1
	var step := 30
	if si >= list.size():
		get_tree().quit()
		return
	var parts: PackedStringArray = list[si].split(":")
	var zone := int(parts[0])
	var piece := parts[1]
	var t = main.track
	if f % step == 1:
		Game.distance = zone * Game.ZONE_LENGTH + 20.0
		Game.run_speed = 1.0
		main.world.rebuild_all()
		t.reset()
		t._cursor = -9999.0
		match piece:
			"platform": t._spawn_platform(-14.0, zone)
			"closure": t._spawn_closure(-16.0, zone)
			"pit": t._spawn_pits(-14.0, zone)
			"tunnel": t._spawn_tunnel(-14.0, zone)
			"switcher": t._spawn_switcher(-18.0, zone)
			"roller": t._spawn_roller(0, -14.0)
			"low": for l in [-1, 0, 1]: t._spawn_obstacle(t.Kind.LOW, l, -12.0 + OZ, l + 1 + int(parts[2]) if parts.size() > 2 else l + 1)
			"over": for l in [-1, 0, 1]: t._spawn_obstacle(t.Kind.OVERHEAD, l, -12.0 + OZ, l + 1 + (int(parts[2]) if parts.size() > 2 else 0))
			"full": for l in [-1, 0, 1]: t._spawn_obstacle(t.Kind.FULL, l, -14.0 + OZ, l + 1 + (int(parts[2]) if parts.size() > 2 else 0))
			"power":
				for i in 6:
					t._spawn_power(i, (i - 2.5) * 0.9, -7.0 - float(i % 2) * 0.0)
	if f % step == step - 3:
		get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT_DIR") + "/g_%s_%s.png" % [parts[0], piece + ("" if parts.size() < 3 else parts[2])])
		si += 1
		f = 0
