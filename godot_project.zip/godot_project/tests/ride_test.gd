extends Node
## فیزیک سوارشدن روی رمپ/سکو، افتادن از لبه، برخورد با دیواره، چاله، تونل و وسیله‌ی لِین‌عوض‌کن
var fails := 0
var main
func ok(c: bool, w: String) -> void:
	if not c:
		fails += 1
		print("[FAIL] ", w)
func frames(n: int) -> void:
	for i in n:
		await get_tree().process_frame
## فقط سازه‌ی مورد آزمایش بماند (مانع/قدرت تصادفیِ کناری نتیجه را قاطی نکند)
func strip(t) -> void:
	for e in t.ents.duplicate():
		if (e.kind >= t.Kind.LOW and not e.ride and not e.get("keep")) or e.kind == t.Kind.POWER:
			e.done = true
			if is_instance_valid(e.node):
				e.node.queue_free()
func fresh() -> void:
	Game.quit_to_menu()
	await frames(2)
	Game.start_run()
	Game.jet_grace = 0.0
	main.player.invuln = 0.0
	main.track.reset()
	main.track._cursor = -99999.0
	main.player.lane = 0
	main.player.position.x = 0.0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await frames(2)
	var t = main.track
	var p = main.player
	# --- ۱) بالا رفتن از رمپ و ایستادن روی سکو
	await fresh()
	t._spawn_platform(-12.0, 0, 0)
	strip(t)
	var peak := 0.0
	var crashed := false
	for i in 120:
		await frames(1)
		peak = maxf(peak, p.jump_y)
		if Game.stumble > 0.0:
			crashed = true
	ok(not crashed, "walking up the ramp must not crash")
	ok(peak > 1.55, "player reached the platform top (peak=%.2f)" % peak)
	# --- ۲) از لبه‌ی سکو می‌افتد و فرود می‌آید
	for i in 240:
		await frames(1)
	ok(p.jump_y < 0.05 and p.ground_h < 0.05, "after the platform ends the player is back on the ground (y=%.2f)" % p.jump_y)
	ok(Game.stumble <= 0.0 and Game.is_active, "no crash while riding")
	# --- ۳) ورود از کنار (پایین‌تر از سطح) = برخورد
	await fresh()
	t._spawn_platform(-14.0, 0, 1)
	strip(t)
	p.lane = 1
	p.position.x = Game.LANE_WIDTH
	p.move_lane(-1)      # لِین ۱ پلتفرم دارد؛ بازیکن در لِین ۱ است → از کنار وارد نمی‌شود
	await fresh()
	t._spawn_platform(-8.0, 0, 1)
	strip(t)
	p.lane = 0
	p.position.x = 0.0
	await frames(75)
	p.move_lane(1)
	for i in 60:
		await frames(1)
	ok(Game.stumble > 0.0, "hitting the side wall of a platform crashes (active=%s over=%s stumble=%.2f lane=%d x=%.2f)" % [Game.is_active, Game.over, Game.stumble, p.lane, p.position.x])
	# --- ۴) پرش از روی چاله
	await fresh()
	t._spawn_pits(-16.0, 0, 1)
	var hit := false
	for i in 150:
		if p.jump_y < 0.05 and not hit and i > 20 and t.ents.size() > 0 and -(t.ents[0].node.position.z + t.ents[0].half_d) < 2.5 and -(t.ents[0].node.position.z + t.ents[0].half_d) > 0.8:
			p.jump()
		await frames(1)
		if Game.stumble > 0.0:
			hit = true
	print("pit (with jump) stumble:", hit)
	ok(not hit, "jumping over the pit is safe")
	await fresh()
	t._spawn_pits(-12.0, 0, 1)
	for i in 120:
		await frames(1)
	ok(Game.stumble > 0.0 or not Game.is_active, "running into the pit without jumping crashes")
	# --- ۵) تونل: سُرخوردن عبور می‌دهد، ایستادن نه
	await fresh()
	t._spawn_tunnel(-14.0, 0, 0)
	var slid_ok := true
	for i in 140:
		var tn = null
		for e in t.ents:
			if e.kind == t.Kind.OVERHEAD:
				tn = e
		if tn != null and -(tn.node.position.z + tn.half_d) < 1.5 and p._slide_t < 0.0 and tn.node.position.z < 0.0:
			p.slide()
		await frames(1)
		if Game.stumble > 0.0 and slid_ok:
			slid_ok = false
			var tz := 0.0
			for e in t.ents:
				if e.kind == t.Kind.OVERHEAD:
					tz = e.node.position.z
			print("tunnel crash at i=", i, " tunnel z=", tz, " slide_t=", p._slide_t, " yr=", p.get_y_range())
	ok(slid_ok, "sliding through the tunnel is safe")
	# --- ۶) لِین‌عوض‌کن: بعد از تحریک x تغییر می‌کند
	await fresh()
	t._spawn_switcher(-60.0, 0)
	var sw
	for e in t.ents:
		if e.mv == "switch":
			sw = e
	var x0: float = sw.x
	for i in 240:
		await frames(1)
	ok(sw != null and absf(sw.x - x0) > 1.0, "switcher changed lane (%.2f -> %.2f)" % [x0, sw.x])
	# --- ۷) غلتان نزدیک‌تر می‌آید و می‌چرخد
	await fresh()
	t._spawn_roller(1, -40.0)
	var ro
	for e in t.ents:
		if e.mv == "roll":
			ro = e
	var zr0: float = ro.node.position.z
	var rot0: float = ro.spin_node.rotation.x
	await frames(30)
	ok(ro.node.position.z - zr0 > 5.0 and ro.spin_node.rotation.x != rot0, "roller moves and spins")
	# --- ۸) تولید خودکار همه‌ی قطعه‌ها در همه‌ی محیط‌ها بدون خطا
	for z in 6:
		await fresh()
		Game.distance = z * Game.ZONE_LENGTH + 5.0
		t._cursor = -5.0
		Game.jet_grace = 9999.0
		for i in 400:
			await frames(1)
			if i % 40 == 0:
				Game.distance += 40.0
				Game.distance = fposmod(Game.distance, Game.ZONE_LENGTH) + z * Game.ZONE_LENGTH
	ok(t.ents.size() > 0, "endless spawning works in all zones")
	print("[RIDETEST] ", "PASSED" if fails == 0 else "FAILED")
	get_tree().quit(0 if fails == 0 else 1)
