extends Node
## فریم‌های اینترو و شروع دویدن (فقط برای تست)
var main
var f := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	Game.play()
func _process(_d: float) -> void:
	f += 1
	var d := OS.get_environment("SHOT_DIR")
	for t in [20, 70, 110, 150, 200, 260, 330, 420]:
		if f == t:
			get_viewport().get_texture().get_image().save_png(d + "/intro_%03d.png" % t)
	if f == 421:
		get_tree().quit()
