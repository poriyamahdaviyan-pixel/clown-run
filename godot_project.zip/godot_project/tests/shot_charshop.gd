extends Node
var main
var f := 0
func _post(path: String) -> void:
	var h := HTTPRequest.new()
	add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"
	Online.anon_key = "ANON"
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().create_timer(1.5).timeout
	var nm := "shot%d" % (Time.get_ticks_msec() % 100000)
	var sr = await Online.sign_up(nm, "secret1")
	print("[signup] ", sr)
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	Skins.add_glb(ProjectSettings.globalize_path("res://samples/sample_robot.glb"), "ربات")
	var key := Skins.char_key(Skins.current_entry())
	await Online.admin_save_item({"kind": "anim_clip", "name": "run", "price": 40, "status": "approved", "payload": {"char": key, "clip": "run"}})
	Content.set_char_default(key, "walk", true)
	await Online.load_items()
	f = 1
func _process(_d: float) -> void:
	if f == 0: return
	f += 1
	var ui = main.ui
	var s := OS.get_environment("SHOT_DIR")
	var sc = ui._online
	match f:
		5:
			sc.store_filter = "@chars"
			ui._set_screen(ui.Screen.ONLINE_STORE)
		30: get_viewport().get_texture().get_image().save_png(s + "/cs_grid.png")
		32: sc.char_shop.open(Skins.current_entry())
		50: get_viewport().get_texture().get_image().save_png(s + "/cs_char.png")
		52: sc.char_shop._toggle_mgr()
		90: get_viewport().get_texture().get_image().save_png(s + "/cs_mgr.png")
		92:
			sc.char_shop._tab = "voice"
			sc.char_shop._render()
		110: get_viewport().get_texture().get_image().save_png(s + "/cs_mgr_voice.png")
		112: get_tree().quit()
