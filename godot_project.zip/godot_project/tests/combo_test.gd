extends Node
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _ready() -> void:
	await get_tree().process_frame
	Game.start_run()
	ok(Game.combo_mult == 1, "start: mult 1")
	var s0 := Game.score
	for i in 7: Game.register_coin()
	ok(Game.combo_mult == 1 and Game.run_bonus == 0, "7 coins: no bonus yet")
	Game.register_coin()
	ok(Game.combo_mult == 2, "8 chained coins: x2")
	var b := Game.run_bonus
	Game.register_coin()
	ok(Game.run_bonus == b + Game.COIN_SCORE, "x2 gives +COIN_SCORE bonus per coin")
	for i in 100: Game.register_coin()
	ok(Game.combo_mult == Game.COMBO_MAX, "capped at x%d" % Game.COMBO_MAX)
	ok(Game.score > s0 + 100 * Game.COIN_SCORE, "score includes bonus (%d)" % Game.score)
	Game.combo_time = 0.01
	await get_tree().create_timer(0.2).timeout
	ok(Game.combo_mult == 1 and Game.combo_chain == 0, "combo expires after window")
	for i in 9: Game.register_coin()
	ok(Game.combo_mult == 2, "x2 again")
	Game.register_obstacle_hit(false)
	ok(Game.combo_mult == 1, "hit breaks combo")
	# پاداش روزانه
	Game.streak = 0; Game.last_daily = -1
	var c0 := Game.coins
	var r1 := Game.claim_daily()
	ok(r1 == 10 and Game.streak == 1 and Game.coins == c0 + 10, "day1 reward 10 (r=%d s=%d c=%d/%d)" % [r1, Game.streak, Game.coins, c0])
	ok(Game.claim_daily() == 0, "no second claim same day")
	Game.last_daily = Game._today() - 1
	ok(Game.claim_daily() == 15 and Game.streak == 2, "next day: streak 2 reward 15")
	Game.last_daily = Game._today() - 3
	Game.claim_daily()
	ok(Game.streak == 1, "gap resets streak")
	Game.streak = 7; Game.last_daily = Game._today() - 1
	ok(Game.claim_daily() == 10, "after day 7 cycle restarts (streak 8 -> day1 reward)")
	# سبک تصویر و دوربین
	Game.look_style = 0; Game.cam_view = 0
	for i in LookFx.NAMES.size(): Game.cycle_look()
	ok(Game.look_style == 0, "look style cycles through all and wraps")
	Game.cycle_look()
	ok(Game.look_style == 1, "look style 1 after one more")
	for i in Game.CAM_NAMES.size(): Game.cycle_cam_view()
	ok(Game.cam_view == 0, "camera view cycles and wraps")
	Game.look_style = 0
	Game.save_game()
	print("[COMBO] " + ("PASSED" if fails == 0 else "FAILED %d" % fails))
	get_tree().quit()
