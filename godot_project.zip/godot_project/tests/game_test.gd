extends Node
# منطق ماموریت‌ها، نزدیک‌ردشدن و حرکت آهسته
func _ready() -> void:
	var ok := true
	Game.missions = []
	Game._ensure_missions()
	ok = ok and Game.missions.size() == 3
	Game.missions[0] = {"t": "coins", "goal": 3, "prog": 0, "reward": 10}
	Game.start_run()
	var c0 := Game.coins
	for i in 3:
		Game.register_coin()
	ok = ok and Game.coins == c0 + 3 + 10
	ok = ok and Game.missions.size() == 3
	Game.register_near_miss()
	Game.register_near_miss()
	ok = ok and Game.run_near == 2 and Game.near_streak == 2
	Game.register_power(Game.Power.SLOW)
	ok = ok and Game.has_power(Game.Power.SLOW)
	Game.elapsed = 0.0
	Game.run_speed = Game.START_SPEED
	for i in 120:
		Game._process(1.0 / 60.0)
	ok = ok and Game.run_speed < Game.START_SPEED * 0.8
	print("[GAMETEST] speed=", Game.run_speed, " missions=", Game.missions)
	print("[GAMETEST] ", "PASSED" if ok else "FAILED")
	Game.is_active = false
	get_tree().quit(0 if ok else 1)
