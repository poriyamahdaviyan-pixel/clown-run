extends Node
var main
var f := 0
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	main = load("res://scenes/main.tscn").instantiate(); add_child(main)
	await get_tree().create_timer(1.5).timeout
	var nm := "ps%d" % (Time.get_ticks_msec() % 100000)
	await Online.sign_up(nm, "secret1")
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	DirAccess.make_dir_recursive_absolute(OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS))
	f = 1
func _process(_d: float) -> void:
	if f == 0: return
	f += 1
	var ui = main.ui
	match f:
		5:
			ui._online.store_filter = "all"
			ui._set_screen(ui.Screen.ONLINE_STORE)
		20: ui._online.store_admin.open_form_for("skin", {})
		50: get_viewport().get_texture().get_image().save_png("/tmp/ps_form.png")
		55: ui._custom_pick("item_file")
		100:
			get_viewport().get_texture().get_image().save_png("/tmp/ps_picker.png")
			print("vp ", get_viewport().get_visible_rect())
			for c in ui.get_children():
				if c is Control and c.get_script() != null and String(c.get_script().resource_path).ends_with("file_picker.gd"):
					print("picker rect ", c.get_global_rect(), " size ", c.size)
			get_tree().quit()
