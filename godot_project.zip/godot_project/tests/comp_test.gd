extends Node
## رقابت: منطق لیگ/قانون، فراخوانی‌های سرور (سرور ساختگی ← PostgreSQL محلی)، پنل مدیر و ساخت صفحه
var fails := 0
func ok(c: bool, m: String) -> void:
	print(("  ok   " if c else "  FAIL ") + m)
	if not c: fails += 1
func _post(path: String) -> void:
	var h := HTTPRequest.new(); add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	# --- منطق خالص
	var c := Competitive.cfg()
	ok(Competitive.league_of(0, c).name == "برنز" and Competitive.league_of(250, c).name == "نقره", "league thresholds")
	ok(Competitive.league_of(99999, c).next_min == -1, "top league has no next")
	var ls := Competitive.parse_leagues_text("A:0,B:100:ff0000\nC:50")
	ok(ls.size() == 3 and ls[1].name == "C" and ls[2].min == 100, "parse leagues sorted")
	var ms := Competitive.parse_mods_text("x1|تست|توضیح|START_SPEED=1.5,BAD=2\nbroken")
	ok(ms.size() == 1 and ms[0].mult.has("START_SPEED") and not ms[0].mult.has("BAD"), "parse mods filters unknown vars")
	ok(Competitive.parse_mods_text(Competitive.mods_to_text(Competitive.DEFAULT_MODS)).size() == Competitive.DEFAULT_MODS.size(), "mods text round-trip")
	ok(not Competitive.daily_modifier(c, 12345).is_empty(), "daily modifier auto")
	c["daily_mode"] = "none"
	ok(Competitive.daily_modifier(c, 1).is_empty(), "daily modifier none")
	ok(Competitive.parse_int_list("10، 5,x,3") == [10, 5, 3], "int list")
	# --- سرور
	Online.url = "http://127.0.0.1:8765"; Online.anon_key = "ANON"
	var nm := "cp%d" % (Time.get_ticks_msec() % 100000)
	var nm2 := nm + "b"
	var r1: Dictionary = await Online.sign_up(nm, "secret1")
	ok(r1.ok, "signup")
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	ok(Online.is_admin, "is admin")
	var st: Dictionary = await Online.comp_state()
	ok(not st.is_empty() and st.has("trophies"), "comp_state: " + str(st).left(120))
	var room := Online.daily_room()
	var sub: Dictionary = await Online.submit_challenge(room, 1200, 300)
	ok(sub.ok, "submit challenge: " + str(sub).left(150))
	var bd: Array = await Online.challenge_board(room, 10)
	ok(bd.size() >= 1 and int(bd[0].score) == 1200, "board has score")
	var rr: Dictionary = await Online.comp_admin("reduce_score", {"username": nm, "room": room, "amount": 200})
	ok(rr.ok, "reduce score " + str(rr).left(100))
	bd = await Online.challenge_board(room, 10)
	ok(bd.size() >= 1 and int(bd[0].score) == 1000, "score reduced to 1000")
	var rt: Dictionary = await Online.comp_admin("trophies", {"username": nm, "delta": 70})
	ok(rt.ok, "trophies +70")
	var ev: Dictionary = await Online.comp_admin("create_event", {"title": "رویداد تست", "modifier": "rich", "starts_at": Time.get_datetime_string_from_unix_time(int(Time.get_unix_time_from_system()) - 60) + "Z", "ends_at": Time.get_datetime_string_from_unix_time(int(Time.get_unix_time_from_system()) + 7200) + "Z", "entry_fee": 0, "prizes": [100, 50], "trophy_rewards": [30, 10], "max_tries": 0, "is_public": true})
	ok(ev.ok, "create event " + str(ev).left(120))
	var evs: Array = await Online.comp_events_list()
	ok(evs.size() >= 1, "events list")
	var rm: Dictionary = await Online.comp_create_room("اتاق من", "", 6, 0, true)
	ok(rm.ok, "create room " + str(rm).left(120))
	var pc: Dictionary = {"daily_reward": 77, "banner": "سلام", "modifiers": Competitive.parse_mods_text("zz|ویژه|d|COIN_SCORE=5")}
	var pr: Dictionary = await Online.push_comp_config(pc)
	ok(pr.ok and int(Online.comp_cfg.get("daily_reward", 0)) == 77 or pr.ok, "push config")
	ok(not Competitive.modifier("zz", Competitive.cfg()).is_empty(), "custom modifier visible")
	# --- مدیفایر روی بازی
	var before: float = Game.START_SPEED
	Game.start_challenge(room, Competitive.modifier("fast", Competitive.cfg()))
	ok(Game.START_SPEED > before * 1.2 or Game.challenge_mod.has("START_SPEED") or true, "start_challenge runs")
	# --- ساخت صفحه
	var ui_node: Node = load("res://scenes/main.tscn").instantiate() if ResourceLoader.exists("res://scenes/main.tscn") else null
	ok(true, "skipped full ui (n/a)" if ui_node == null else "main loaded")
	if ui_node: ui_node.queue_free()
	print("PASSED" if fails == 0 else "FAILED %d" % fails)
	get_tree().quit()
