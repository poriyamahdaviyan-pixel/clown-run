extends Node
var main
var f := 0
func _post(path: String) -> void:
	var h := HTTPRequest.new()
	add_child(h)
	h.request("http://127.0.0.1:8765" + path, ["apikey: ANON"], HTTPClient.METHOD_POST, "{}")
	await h.request_completed
	h.queue_free()
func _ready() -> void:
	Online.url = "http://127.0.0.1:8765"
	Online.anon_key = "ANON"
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().create_timer(1.5).timeout
	var nm := "shot%d" % (Time.get_ticks_msec() % 100000)
	var sr = await Online.sign_up(nm, "secret1")
	print("[signup] ", sr)
	await _post("/__test/admin/%s/0" % nm)
	await Online.refresh_profile()
	Skins.add_glb(ProjectSettings.globalize_path("res://samples/sample_robot.glb"), "ربات")
	var key := Skins.char_key(Skins.current_entry())
	await Online.admin_save_item({"kind": "anim_clip", "name": "run", "price": 40, "status": "approved", "payload": {"char": key, "clip": "run"}})
	var ea := Skins.current_entry()
	Skins.add_glb(ProjectSettings.globalize_path("res://samples/sample_anim.glb"), "منبع")
	var src := Skins.current_entry()
	await Online.refresh_profile()
	var cs = main.ui._online.char_shop
	cs._entry = ea
	cs._mgr = true
	await cs._sell_borrowed(src, "Jump", 30)
	Skins.select_entry(ea) if Skins.has_method("select_entry") else null
	Content.set_char_default(key, "walk", true)
	await Online.load_items()
	var im := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	im.fill(Color(0.2, 0.6, 0.9, 1))
	for y in range(8, 16):
		for x in range(8, 16): im.set_pixel(x, y, Color(1, 0.8, 0.6, 1))
	var png := im.save_png_to_buffer()
	for k in ["skin", "coin"]:
		var cid := "44444444-5555-4666-8777-%012d" % (1 if k == "skin" else 2)
		await Online.admin_upload("pv/%s.png" % cid, png, "image/png", "previews")
		await Online.admin_save_item({"id": cid, "kind": k, "name": "نمونه " + k, "price": 20, "status": "approved", "file_path": "x/%s.png" % cid, "payload": {"pv": "pv/%s.png" % cid}})
	await Online.load_items()
	f = 1
func _process(_d: float) -> void:
	if f == 0: return
	f += 1
	var ui = main.ui
	var s := OS.get_environment("SHOT_DIR")
	var sc = ui._online
	match f:
		5:
			sc.store_filter = "@chars"
			ui._set_screen(ui.Screen.ONLINE_STORE)
		40: get_viewport().get_texture().get_image().save_png(s + "/p_store.png")
		42:
			for it in Online.items:
				if bool(it.get("payload", {}).get("pack", false)): sc._open_detail(it)
		120: get_viewport().get_texture().get_image().save_png(s + "/p_detail.png")
		122:
			for it in Online.items:
				if String(it.kind) == "skin": sc._open_detail(it)
		200: get_viewport().get_texture().get_image().save_png(s + "/p_skin.png")
		202:
			for it in Online.items:
				if String(it.kind) == "coin": sc._open_detail(it)
		280: get_viewport().get_texture().get_image().save_png(s + "/p_coin.png")
		281: get_tree().quit()
