extends Node
var main
var f := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
func _report(tag: String, root: Node) -> void:
	var vp := get_viewport().get_visible_rect().size
	for sc in root.find_children("*", "ScrollContainer", true, false):
		var s := sc as ScrollContainer
		if not s.is_visible_in_tree():
			continue
		var content: Control = s.get_child(0)
		var r := s.get_global_rect()
		print("[audit] %s: scroll h=%.0f content=%.0f bottom=%.0f (viewport h=%.0f) %s" % [tag, s.size.y, content.size.y, r.end.y, vp.y, "OVERFLOWS-SCREEN" if r.end.y > vp.y + 2 else ("scrollable" if content.size.y > s.size.y + 2 else "fits")])
func _process(_d: float) -> void:
	f += 1
	var ui = main.ui
	var ed = ui._editors
	match f:
		4:
			Rules.add_rule(Skins.current_id)
			Rules.add_rule(Skins.current_id)
			ui._set_screen(ui.Screen.RULES)
		12: _report("RULES", ed.rules)
		14:
			ui._set_screen(ui.Screen.CONTENT)
			ed._tab = 0; ed.refresh_content()
		24: _report("CONTENT/texts", ed.content)
		26: ed._tab = 1; ed.refresh_content()
		36: _report("CONTENT/menu", ed.content)
		38: ed._tab = 2; ed.refresh_content()
		48: _report("CONTENT/store", ed.content)
		50: ui._set_screen(ui.Screen.CHOOSER)
		60: _report("CHOOSER", ed.chooser)
		62:
			ui._set_screen(ui.Screen.SETTINGS)
		72: _report("SETTINGS", ui._root)
		74:
			ui._set_screen(ui.Screen.START)
		80:
			while Rules.rules_of(Skins.current_id).size() > 0:
				Rules.remove_rule(Skins.current_id, 0)
			get_tree().quit()
