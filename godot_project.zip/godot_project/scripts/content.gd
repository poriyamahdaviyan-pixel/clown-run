extends Node
## محتوای قابل‌ویرایش (Autoload با نام «Content»)
##   • متن‌ها: هر متنی که در رابط کاربری هست (دکمه‌ها، عنوان‌ها، فروشگاه…) با ویرایشگر عوض می‌شود
##   • منوی اصلی: چه بخش‌هایی باشد، ترتیبشان، و بخش‌های سفارشی (باز کردن صفحه / لینک / پیام)
##   • قابلیت‌ها (Ability): هر بخش یا امکان در «نسخه‌ی عمومی» روشن/خاموش می‌شود
## لایه‌ها: پیش‌فرض ← تنظیم سرور (کلید content در جدول config) ← ویرایش‌های محلیِ مالک
## نسخه‌ی مالک همه‌ی قابلیت‌ها را همیشه دارد؛ ویرایش‌ها را با «انتشار» برای همه می‌فرستد.

signal changed

const PREF := "user://content.json"

## [شناسه، توضیح، پیش‌فرض در نسخه‌ی عمومی]
const ABILITIES := [
	["challenge", "رقابت (چالش روزانه و دوئل)", true],
	["leaderboard", "جدول امتیاز", true],
	["account", "حساب من", true],
	["settings", "تنظیمات (صدا)", true],
	["settings_extra", "تنظیمات بیشتر (لرزش، اینترو، کنترل مدل)", false],
	["character", "انتخاب و ویرایش کاراکتر", false],
	["studio", "استودیوی اسکین", false],
	["coin_designer", "طراح سکه", false],
	["power_shop", "فروشگاه قدرت‌ها (ارتقا و ابزارهای مصرفی)", false],
	["item_studio", "استودیوی آیتم‌ها (ساخت پیش‌نویس سکه، صدا، کاراکتر…)", false],
	["online_store", "فروشگاه آنلاین", false],
	["missions", "ماموریت‌ها", false],
	["coins_ui", "نمایش سکه‌ها (منو و حین بازی)", false],
	["store_skin", "بخش فروشگاه: اسکین", true],
	["store_glb", "بخش فروشگاه: مدل سه‌بعدی", true],
	["store_coin", "بخش فروشگاه: طرح سکه", true],
	["chooser", "انتخاب صدا و انیمیشن (برای کاراکتر و تعقیب‌کننده)", false],
	["store_chars", "بخش فروشگاه: کاراکتر من (انیمیشن و صدای هر کاراکتر)", false],
	["store_police", "بخش فروشگاه: ظاهر تعقیب‌کننده", false],
	["store_chaser_voice", "بخش فروشگاه: صدای تعقیب‌کننده", false],
	["store_chaser_anim", "بخش فروشگاه: انیمیشن تعقیب‌کننده", false],
	["chooser_chaser", "انتخاب صدا/انیمیشن تعقیب‌کننده", false],
]

## دسترسی‌های جزئیِ صدا برای «نسخه‌ی عمومی». [شناسه، توضیح، پیش‌فرض، نوع: b=روشن/خاموش | n=عدد | t=متن، کمینه، بیشینه]
## مالک همه را همیشه دارد. پیش‌فرض‌ها محتاط‌اند: فقط آنچه از قبل برای بازیکن بود روشن است.
const PERMS := [
	["snd_toggle", "روشن/خاموش‌کردن صدا", true, "b"],
	["snd_master", "کشوی «صدای کل»", true, "b"],
	["snd_mix_player", "کشوی صدای کاراکتر (قدم، پرش، سُر)", false, "b"],
	["snd_mix_police", "کشوی صدای پلیس/تعقیب‌کننده", false, "b"],
	["snd_mix_world", "کشوی صدای دنیا (سکه، قدرت‌ها)", false, "b"],
	["snd_mix_ui", "کشوی صدای دکمه‌ها", false, "b"],
	["snd_mix_music", "کشوی صدای موسیقی", true, "b"],
	["snd_mix_ambient", "کشوی باد و محیط", false, "b"],
	["snd_per_sound", "تنظیم صدای تک‌تک صداها (و بی‌صدا کردنشان)", false, "b"],
	["snd_per_char", "تنظیم صدای هر کاراکتر جدا", false, "b"],
	["snd_per_chaser", "تنظیم صدای تعقیب‌کننده جدا", false, "b"],
	["snd_voice_style", "انتخاب نوع صدای کاراکتر", false, "b"],
	["snd_music_pick", "انتخاب آهنگ منو و بازی", true, "b"],
	["snd_music_char", "آهنگ مخصوص هر کاراکتر", true, "b"],
	["snd_music_import", "افزودن آهنگ از گوشی", true, "b"],
	["snd_start_pick", "انتخاب صدای شروع بازی", true, "b"],
	["snd_import_voice", "افزودن صدای دلخواه از گوشی (در انتخاب صدا)", false, "b"],
	["snd_pick_builtin", "استفاده از صداهای آماده‌ی بازی در انتخاب صدا", false, "b"],
	["snd_pick_trick", "استفاده از حرکت‌های آماده در انتخاب انیمیشن", false, "b"],
	["snd_store_tune", "تنظیم صدای خریداری‌شده (رویداد و بلندی) داخل فروشگاه", true, "b"],
	["snd_auto_equip", "نصب خودکار صدای خریداری‌شده روی رویداد مخصوصش", true, "b"],
	["snd_vol_max", "سقف بلندی صدا برای بازیکن (درصد)", 100, "n", 10, 100],
	["snd_import_max", "حداکثر تعداد صدا/آهنگ واردشده از گوشی (۰=هیچ)", 5, "n", 0, 60],
	["snd_events", "رویدادهای مجاز برای بازیکن (با ویرگول؛ خالی = همه). مثال: jump,coin", "", "t"],
]
## ابزارهای صدا که در ماتریس دسترسی هم نمایش داده می‌شوند (قابلیت‌های روشن/خاموش)
const SOUND_ABILITIES := ["settings", "chooser", "chooser_chaser", "store_chars", "store_chaser_voice", "store_chaser_anim"]
const MIX_CATS := [["master", "صدای کل"], ["player", "کاراکتر (قدم، پرش، سُر)"], ["police", "پلیس (آژیر، قدم، بوق)"],
	["world", "دنیا (سکه، قدرت‌ها)"], ["ui", "دکمه‌ها"], ["music", "موسیقی"], ["ambient", "باد و محیط"]]

## بخش‌های فروشگاه آنلاین. kind = نوع آیتم (در جدول items)؛ kind خالی = «همه».
## نوع تازه: یک بخش سفارشی با همان kind بساز (و در صورت نیاز در Online.apply_item_file رفتارش را بنویس).
const STORE := [
	{"id": "all", "text": "همه", "kind": ""},
	{"id": "skin", "text": "اسکین", "kind": "skin"},
	{"id": "glb", "text": "کاراکتر", "kind": "glb"},
	{"id": "coin", "text": "سکه", "kind": "coin"},
	{"id": "chars", "text": "کاراکتر من", "kind": "@chars"},
	{"id": "police", "text": "تعقیب‌کننده", "kind": "police"},
	{"id": "chaser_voice", "text": "صدای تعقیب‌کننده", "kind": "chaser_voice", "hidden": true},
	{"id": "chaser_anim", "text": "انیمیشن تعقیب‌کننده", "kind": "chaser_anim", "hidden": true},
]

## بخش‌های پیش‌فرض منوی اصلی؛ half = نیم‌عرض (دو‌تا کنار هم)
const MENU := [
	{"id": "play", "text": "شروع بازی", "act": "play", "style": "Gold", "half": false, "big": true, "ability": ""},
	{"id": "challenge", "text": "رقابت: چالش روزانه و دوئل", "act": "screen:CHALLENGE", "style": "Purple", "half": false, "ability": "challenge"},
	{"id": "character", "text": "کاراکتر", "act": "screen:CHARACTER", "style": "Teal", "half": true, "ability": "character"},
	{"id": "coin_designer", "text": "طراح سکه", "act": "screen:COIN", "style": "", "half": true, "ability": "coin_designer"},
	{"id": "studio", "text": "استودیوی اسکین", "act": "studio", "style": "", "half": false, "ability": "studio"},
	{"id": "power_shop", "text": "فروشگاه قدرت‌ها", "act": "screen:SHOP", "style": "Red", "half": true, "ability": "power_shop"},
	{"id": "online_store", "text": "فروشگاه آنلاین", "act": "screen:ONLINE_STORE", "style": "Gold", "half": true, "ability": "online_store"},
	{"id": "item_studio", "text": "استودیوی آیتم‌ها", "act": "item_studio", "style": "Purple", "half": false, "ability": "item_studio"},
	{"id": "missions", "text": "ماموریت‌ها", "act": "screen:MISSIONS", "style": "Teal", "half": true, "ability": "missions"},
	{"id": "leaderboard", "text": "جدول امتیاز", "act": "screen:BOARD", "style": "Teal", "half": true, "ability": "leaderboard"},
	{"id": "chooser", "text": "صدا و انیمیشن‌ها", "act": "screen:CHOOSER", "style": "Purple", "half": false, "ability": "chooser"},
	{"id": "settings", "text": "تنظیمات", "act": "screen:SETTINGS", "style": "Dark", "half": true, "ability": "settings"},
	{"id": "account", "text": "حساب من", "act": "screen:ACCOUNT", "style": "Dark", "half": true, "ability": "account"},
]

## ------------------------- قابلیت‌های بازی (روشن/خاموش برای همه، از جمله مالک) -------------------------
## برخلاف «Ability» که فقط نسخه‌ی عمومی را محدود می‌کند، این‌ها خود بازی را عوض می‌کنند و با «انتشار» برای همه اعمال می‌شوند.
const ZONE_NAMES := ["ناحیه‌ی شهر", "ناحیه‌ی بیابان", "ناحیه‌ی جنگل", "ناحیه‌ی برفی", "ناحیه‌ی بندر", "ناحیه‌ی آتشفشان"]
const FEATURES_BASE := [
	["portals", "پرتال‌ها (ورود به جهان‌ها و بازی‌های مستقل)", "گیم‌پلی"],
	["combo", "کمبو و ضریب امتیاز", "گیم‌پلی"],
	["powerups", "قدرت‌های روی مسیر (آهنربا، سپر، جت…)", "گیم‌پلی"],
	["pieces", "قطعه‌های ویژه (سکو، تونل، چاله، رمپ و …)", "گیم‌پلی"],
	["rollers", "غلتک‌های متحرک", "گیم‌پلی"],
	["daily", "جایزه‌ی روزانه", "گیم‌پلی"],
	["police", "پلیس و سگ تعقیب‌کننده (ظاهر)", "ظاهر و فضا"],
	["npcs", "شخصیت‌های NPC کنار جاده", "ظاهر و فضا"],
	["weather", "آب‌وهوا و ذرات (برف، باران، ساکورا، حباب…)", "ظاهر و فضا"],
	["look_pick", "دکمه‌ی انتخاب سبک تصویر (انیمه‌ای، پیکسلی…)", "تنظیمات بازیکن"],
	["cam_pick", "دکمه‌ی انتخاب دوربین", "تنظیمات بازیکن"],
	["menu_strip", "نوار جهان‌های پرتال در منو", "تنظیمات بازیکن"],
]


const PIECES := [["platform", "سکو (روی آن بپر و بدو)"], ["closure", "دروازه‌ی بسته‌شونده"], ["pits", "چاله‌ها"], ["tunnel", "تونل"], ["switcher", "تغییر مسیر (سوئیچ)"]]
const OBSTACLES := [["obs_low", "مانع کوتاه (بپر یا روی آن برو)"], ["obs_over", "مانع بالاسر (سُر بخور)"], ["obs_full", "مانع بزرگ (لِین عوض کن)"]]
const FX := [["embers", "جرقه‌های شهر"], ["sand", "شن بیابان"], ["leaves", "برگ جنگل"], ["fireflies", "کرم شب‌تاب"], ["snow", "برف"], ["rain", "باران بندر"],
	["ash", "خاکستر آتشفشان"], ["lava_embers", "جرقه‌ی گدازه"], ["sakura", "گلبرگ ساکورا"], ["sprinkles", "پاشیدنی‌های آب‌نبات"],
	["sparkle", "ستاره‌ریزه‌ها (فضا و آسمان)"], ["bubbles", "حباب (دریا و ریف)"], ["wisps", "شعله‌های سبز روح"]]


## فهرست کامل قابلیت‌ها: [شناسه، متن، گروه]
func features_all() -> Array:
	var out: Array = FEATURES_BASE.duplicate()
	for i in Game.POWER_NAMES.size():
		out.append(["power_%d" % i, Game.POWER_NAMES[i], "قدرت‌های روی مسیر (تک‌تک)"])
	for pc: Array in PIECES:
		out.append(["piece_" + String(pc[0]), pc[1], "قطعه‌های ویژه (تک‌تک)"])
	for ob: Array in OBSTACLES:
		out.append([ob[0], ob[1], "نوع مانع‌ها"])
	for k: String in ModesExt.NPC_KINDS:
		out.append(["npc_" + k, String(ModesExt.NPC_NAMES.get(k, k)), "شخصیت‌های NPC (تک‌تک)"])
	for fx: Array in FX:
		out.append(["fx_" + String(fx[0]), fx[1], "جلوه‌های محیطی (تک‌تک)"])
	for i in PortalSkins.NAMES.size():
		out.append(["portal_skin_%d" % i, PortalSkins.NAMES[i], "ظاهر پرتال‌ها"])
	for i in LookFx.NAMES.size():
		out.append(["look_%d" % i, LookFx.NAMES[i], "سبک‌های تصویر"])
	for i in Game.CAM_NAMES.size():
		out.append(["cam_%d" % i, Game.CAM_NAMES[i], "حالت‌های دوربین"])
	for i in ZONE_NAMES.size():
		out.append(["zone_%d" % i, ZONE_NAMES[i], "ناحیه‌های مسیر"])
	for id: String in Modes.IDS:
		var d: Dictionary = Modes.def(id)
		if Modes.is_mini(id):
			out.append(["mini_" + id, String(d.get("name", id)), "بازی‌های مستقل پرتال"])
		else:
			out.append(["world_" + id, String(d.get("name", id)), "جهان‌های دویدنی پرتال"])
	return out


func feature(id: String) -> bool:
	return bool(_merged("features").get(id, true))


func set_feature(id: String, on: bool) -> void:
	var f: Dictionary = _local.get("features", {})
	f[id] = on
	_local["features"] = f
	_save()


func set_features_group(group: String, on: bool) -> void:
	var f: Dictionary = _local.get("features", {})
	for it: Array in features_all():
		if it[2] == group:
			f[it[0]] = on
	_local["features"] = f
	_save()


func any_power() -> bool:
	if not feature("powerups"):
		return false
	for i in Game.POWER_NAMES.size():
		if feature("power_%d" % i):
			return true
	return false


func enabled_pieces() -> Array[String]:
	var out: Array[String] = []
	if feature("pieces"):
		for pc: Array in PIECES:
			if feature("piece_" + String(pc[0])):
				out.append(String(pc[0]))
	return out


func enabled_npcs() -> Array[String]:
	var out: Array[String] = []
	if feature("npcs"):
		for k: String in ModesExt.NPC_KINDS:
			if feature("npc_" + k):
				out.append(k)
	return out


func mode_feature(id: String) -> bool:
	return feature(("mini_" if Modes.is_mini(id) else "world_") + id)


var _remote: Dictionary = {}
var _local: Dictionary = {}          # {texts:{}, abilities:{}, order:[], custom:[]}
var _seen: Dictionary = {}           # متن‌های اصلیِ دیده‌شده در رابط


func _ready() -> void:
	if FileAccess.file_exists(PREF):
		var d = JSON.parse_string(FileAccess.get_file_as_string(PREF))
		if d is Dictionary:
			_local = d


# ------------------------- لایه‌ها -------------------------
func apply_remote(d) -> void:
	_remote = d if d is Dictionary else {}
	changed.emit()


func _merged(section: String) -> Dictionary:
	var out: Dictionary = {}
	for src in [_remote, _local]:
		var part = src.get(section, {})
		if part is Dictionary:
			out.merge(part, true)
	return out


func _save() -> void:
	var f := FileAccess.open(PREF, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(_local))
		f.close()
	changed.emit()


func export_json() -> Dictionary:
	# آنچه برای همه منتشر می‌شود: ادغامِ سرور و ویرایش‌های محلی
	var out := {"texts": _merged("texts"), "abilities": _merged("abilities")}
	out["order"] = _order()
	out["custom"] = customs()
	out["char_defaults"] = _merged("char_defaults")
	out["perms"] = _merged("perms")
	out["features"] = _merged("features")
	out["cats"] = _merged("cats")
	out["mix"] = mix_export()
	out["store_order"] = _list_of("store_order")
	out["store_custom"] = _list_of("store_custom")
	var lk := _merged("look")
	if String(lk.get("font", "")) == "custom":
		lk["font"] = "vazir"            # فایل فونت فقط روی همین دستگاه است
	out["look"] = lk
	return out


# ------------------------- ظاهر (فونت، سبک و رنگ دکمه‌ها) -------------------------
const LOOK_KINDS := [["Button", "دکمه‌ی اصلی"], ["GoldButton", "طلایی"], ["TealButton", "فیروزه‌ای"], ["RedButton", "قرمز"], ["DarkButton", "تیره"]]
const LOOK_DEFAULT := {"Button": "8b019d", "GoldButton": "ffb02e", "TealButton": "12a8a0", "RedButton": "d6334a", "DarkButton": "3b1f66"}
const LOOK_PRESETS := [
	["بنفش (پیش‌فرض)", {"Button": "8b019d", "GoldButton": "ffb02e", "TealButton": "12a8a0", "RedButton": "d6334a", "DarkButton": "3b1f66"}],
	["اقیانوس", {"Button": "1d6fd8", "GoldButton": "ffc247", "TealButton": "0fb5a6", "RedButton": "e0485f", "DarkButton": "17335c"}],
	["جنگل", {"Button": "2e9b4f", "GoldButton": "f2b632", "TealButton": "1aa59a", "RedButton": "d4503a", "DarkButton": "1f4a33"}],
	["آتش", {"Button": "e2452a", "GoldButton": "ffb42e", "TealButton": "d77a1c", "RedButton": "a81f3a", "DarkButton": "4a1a1a"}],
	["صورتی", {"Button": "e0409a", "GoldButton": "ffc15e", "TealButton": "6c7ae0", "RedButton": "d6334a", "DarkButton": "4a2152"}],
	["شب (مشکی)", {"Button": "3a3f55", "GoldButton": "e7b73a", "TealButton": "2f8f9a", "RedButton": "b0394a", "DarkButton": "15171f"}],
]


func look(key: String, def = null):
	var d := _merged("look")
	return d.get(key, def)


func look_color(kind: String) -> Color:
	var c = look("colors", {})
	if c is Dictionary and c.has(kind):
		return Color(String(c[kind]))
	return Color(String(LOOK_DEFAULT.get(kind, "8b019d")))


func look_set(key: String, value) -> void:
	if not _local.has("look") or not (_local["look"] is Dictionary):
		_local["look"] = {}
	_local["look"][key] = value
	_save()


func look_set_colors(cols: Dictionary) -> void:
	look_set("colors", cols.duplicate())


func look_palettes() -> Array:
	var p = look("palettes", [])
	return p if p is Array else []


func reset_local() -> void:
	_local = {}
	_save()


# ------------------------- قابلیت‌ها -------------------------
func ability_default(id: String) -> bool:
	for a in ABILITIES:
		if a[0] == id:
			return bool(a[2])
	return true       # بخش سفارشی: به‌طور پیش‌فرض روشن


## آیا این قابلیت الان در دسترس است؟ (مالک همه را دارد)
func can(id: String) -> bool:
	if id == "" or Edition.is_owner():
		return true
	# بعد از خرید اولین صدا/انیمیشن، صفحه‌ی انتخابش خودکار باز می‌شود (تعقیب‌کننده فقط با آیتم مخصوص خودش)
	if id == "chooser" and not Rules.library.is_empty():
		return true
	if id == "chooser_chaser" and Rules.library_has_chaser():
		return true
	return public_enabled(id)


## وضعیت قابلیت برای «نسخه‌ی عمومی» (مستقل از اینکه مالک هستی)
func public_enabled(id: String) -> bool:
	var m := _merged("abilities")
	return bool(m.get(id, ability_default(id)))


func set_ability(id: String, on: bool) -> void:
	var a: Dictionary = _local.get("abilities", {})
	a[id] = on
	_local["abilities"] = a
	_save()


# ------------------------- دسترسی‌های جزئیِ صدا -------------------------
func _perm_def(id: String) -> Array:
	for p in PERMS:
		if p[0] == id:
			return p
	return []


## مقدار این دسترسی برای «نسخه‌ی عمومی» (مستقل از مالک بودن)
func perm_public(id: String):
	var d := _perm_def(id)
	if d.is_empty():
		return false
	var m := _merged("perms")
	var v = m.get(id, d[2])
	match String(d[3]):
		"b": return bool(v)
		"n": return clampi(int(v), int(d[4]), int(d[5]))
		_: return String(v)


## آیا بازیکنِ فعلی این کار را می‌تواند بکند؟ (مالک همیشه)
func perm_b(id: String) -> bool:
	return true if Edition.is_owner() else bool(perm_public(id))


func perm_n(id: String) -> int:
	if Edition.is_owner():
		var d := _perm_def(id)
		return int(d[5]) if not d.is_empty() else 0
	return int(perm_public(id))


func set_perm(id: String, v) -> void:
	var a: Dictionary = _local.get("perms", {})
	a[id] = v
	_local["perms"] = a
	_save()


## رویدادهایی که بازیکن اجازه‌ی تغییرشان را دارد؛ [] = همه
func perm_events() -> Array:
	if Edition.is_owner():
		return []
	var out: Array = []
	for e in String(perm_public("snd_events")).split(",", false):
		var t: String = e.strip_edges()
		if t != "":
			out.append(t)
	return out


func perm_event_ok(ev: String) -> bool:
	var l := perm_events()
	return l.is_empty() or ev in l


## بلندی نهایی که بازیکن می‌تواند بدهد (۰..۱)
func vol_cap() -> float:
	return 1.0 if Edition.is_owner() else float(perm_n("snd_vol_max")) / 100.0


## چند صدا/آهنگ بازیکن خودش از گوشی آورده؟
func import_count() -> int:
	var n := Music.own_tracks().size()
	for e in Rules.library:
		if String(e.get("id", "")).begins_with("own_"):
			n += 1
	return n


## "" = مجاز؛ وگرنه دلیل (برای پیام به بازیکن). نوع: voice | music
func import_block(kind: String) -> String:
	if Edition.is_owner():
		return ""
	if kind == "music" and not perm_b("snd_music_import"):
		return "افزودن آهنگ برای این نسخه بسته است"
	if kind == "voice" and not perm_b("snd_import_voice"):
		return "افزودن صدای دلخواه برای این نسخه بسته است"
	if import_count() >= perm_n("snd_import_max"):
		return "به سقف مجاز (%d فایل) رسیده‌ای" % perm_n("snd_import_max")
	return ""


# ------------------------- میکس صدا (بلندی هر صدا / کاراکتر / تعقیب‌کننده) -------------------------
## نوع‌ها: sound (نام صدا یا file:…)، char (کلید کاراکتر)، chaser ("@chaser")
## لایه‌ها: پیش‌فرضِ مالک (از سرور) × انتخاب خودِ بازیکن (فقط اگر مجاز باشد). ۱.۰ = بدون تغییر، ۰ = بی‌صدا.
const MIX_PERM := {"sound": "snd_per_sound", "char": "snd_per_char", "chaser": "snd_per_chaser"}


func _mix_layer(src: Dictionary, kind: String, key: String):
	var m = src.get("mix", {})
	if m is Dictionary and m.get(kind) is Dictionary and (m[kind] as Dictionary).has(key):
		return float(m[kind][key])
	return null


func mix_get(kind: String, key: String) -> float:
	var g := 1.0
	var r = _mix_layer(_remote, kind, key)
	if r != null:
		g = float(r)
	# مالک: انتخاب محلیِ خودش همیشه اثر دارد؛ بازیکن فقط وقتی مالک اجازه داده
	if Edition.is_owner() or bool(perm_public(String(MIX_PERM.get(kind, "")))):
		var l = _mix_layer(_local, kind, key)
		if l != null:
			g = float(l)
	return g


func mix_set(kind: String, key: String, v: float) -> void:
	var m: Dictionary = _local.get("mix", {})
	var part: Dictionary = m.get(kind, {})
	var lim := 2.0 if Edition.is_owner() else vol_cap()
	var val := clampf(v, 0.0, lim)
	if is_equal_approx(val, 1.0):
		part.erase(key)
	else:
		part[key] = val
	m[kind] = part
	_local["mix"] = m
	_save()


func mix_export() -> Dictionary:
	var out := {}
	for kind in MIX_PERM:
		var part: Dictionary = {}
		for src in [_remote, _local]:
			var m = src.get("mix", {})
			if m is Dictionary and m.get(kind) is Dictionary:
				part.merge(m[kind], true)
		out[kind] = part
	return out


# ------------------------- منو -------------------------
func customs() -> Array:
	var out: Array = []
	var m: Array = []
	for src in [_remote, _local]:
		if src.get("custom") is Array:
			m = src.get("custom")
	for c in m:
		if c is Dictionary:
			out.append(c)
	return out


func _order() -> Array:
	var o: Array = []
	for src in [_remote, _local]:
		if src.get("order") is Array:
			o = src.get("order")
	return o


## همه‌ی بخش‌ها (حتی غیرفعال‌ها) به ترتیب فعلی
func menu_all() -> Array:
	var items: Array = []
	for d in MENU:
		items.append((d as Dictionary).duplicate())
	for c in customs():
		var it: Dictionary = {"id": String(c.get("id", "")), "text": String(c.get("text", "بخش")), "act": String(c.get("act", "text:")),
			"style": "Teal", "half": bool(c.get("half", false)), "ability": "custom_" + String(c.get("id", "")), "custom": true}
		items.append(it)
	var order := _order()
	items.sort_custom(func(a, b):
		var ia := order.find(a.id)
		var ib := order.find(b.id)
		if ia == -1: ia = 1000 + items.find(a)
		if ib == -1: ib = 1000 + items.find(b)
		return ia < ib)
	return items


## بخش‌هایی که همین الان نمایش داده می‌شوند
func menu_visible() -> Array:
	var out: Array = []
	for it in menu_all():
		if can(String(it.ability)):
			out.append(it)
	return out


func move_item(id: String, dir: int) -> void:
	var ids: Array = []
	for it in menu_all():
		ids.append(it.id)
	var i := ids.find(id)
	var j := clampi(i + dir, 0, ids.size() - 1)
	if i < 0 or i == j:
		return
	ids.remove_at(i)
	ids.insert(j, id)
	_local["order"] = ids
	_save()


func add_custom(text: String, act: String, half: bool) -> void:
	var list: Array = customs().duplicate()
	var id := "c%d" % (Time.get_ticks_msec() % 1000000)
	list.append({"id": id, "text": text, "act": act, "half": half})
	_local["custom"] = list
	_save()


func remove_custom(id: String) -> void:
	var list: Array = []
	for c in customs():
		if String(c.id) != id:
			list.append(c)
	_local["custom"] = list
	_save()


# ------------------------- انیمیشن‌های پیش‌فرضِ هر کاراکتر -------------------------
## کلیپ‌هایی که مالک برای یک کاراکتر «پیش‌فرض و رایگان» گذاشته (بقیه یا فروشی‌اند یا پنهان)
func char_defaults(key: String) -> Array:
	var d = _merged("char_defaults").get(key, [])
	return d if d is Array else []


func set_char_default(key: String, clip: String, on: bool) -> void:
	var all: Dictionary = _local.get("char_defaults", {})
	var list: Array = char_defaults(key).duplicate()
	if on and not clip in list:
		list.append(clip)
	if not on:
		list.erase(clip)
	all[key] = list
	_local["char_defaults"] = all
	_save()


# ------------------------- بخش‌های فروشگاه -------------------------
func _list_of(key: String) -> Array:
	var o: Array = []
	for src in [_remote, _local]:
		if src.get(key) is Array:
			o = src.get(key)
	return o


## همه‌ی بخش‌های فروشگاه (حتی غیرفعال‌ها) به ترتیب فعلی؛ هر کدام: id, text, kind, ability, custom
func store_all() -> Array:
	var items: Array = []
	for d: Dictionary in STORE:
		var it := d.duplicate()
		it["ability"] = "" if d.id == "all" else "store_" + String(d.id)
		items.append(it)
	for c in _list_of("store_custom"):
		if c is Dictionary:
			items.append({"id": String(c.get("id", "")), "text": String(c.get("text", "بخش")), "kind": String(c.get("kind", "")),
				"ability": "store_" + String(c.get("id", "")), "custom": true})
	var order := _list_of("store_order")
	var idx := {}
	for i in items.size():
		idx[items[i].id] = order.find(items[i].id) if order.find(items[i].id) != -1 else 1000 + i
	items.sort_custom(func(a, b): return idx[a.id] < idx[b.id])
	return items


func store_visible() -> Array:
	var out: Array = []
	for it in store_all():
		if can(String(it.ability)) and not bool(it.get("hidden", false)):
			out.append(it)
	return out


## تعقیب‌کننده فقط داخل «کاراکتر من» دیده می‌شود (نه در شبکه‌ی عمومی فروشگاه)
func chaser_studio_on() -> bool:
	return Edition.is_owner() or can("store_chaser_voice") or can("store_chaser_anim") or can("chooser_chaser")


## آیا آیتمی از این نوع باید در فروشگاه نمایش داده شود؟ (حداقل یک بخش فعال با همین نوع)
func store_shows_kind(kind: String) -> bool:
	for it in store_visible():
		if String(it.kind) == kind:
			return true
	return false


func move_store(id: String, dir: int) -> void:
	var ids: Array = []
	for it in store_all():
		ids.append(it.id)
	var i := ids.find(id)
	var j := clampi(i + dir, 0, ids.size() - 1)
	if i < 0 or i == j:
		return
	ids.remove_at(i)
	ids.insert(j, id)
	_local["store_order"] = ids
	_save()


func add_store(text: String, kind: String) -> void:
	var list: Array = _list_of("store_custom").duplicate()
	list.append({"id": "s%d" % (Time.get_ticks_msec() % 1000000), "text": text, "kind": kind.strip_edges().to_lower()})
	_local["store_custom"] = list
	_save()


func remove_store(id: String) -> void:
	var list: Array = []
	for c in _list_of("store_custom"):
		if String(c.id) != id:
			list.append(c)
	_local["store_custom"] = list
	_save()


# ------------------------- متن‌ها -------------------------
func _trackable(t: String) -> bool:
	if t.strip_edges() == "" or t.length() > 140:
		return false
	for ch in t:
		var u := ch.unicode_at(0)
		if (u >= 48 and u <= 57) or (u >= 0x06F0 and u <= 0x06F9) or (u >= 0x0660 and u <= 0x0669) or ch == "%":
			return false
	return true


func set_text(original: String, value: String) -> void:
	var t: Dictionary = _local.get("texts", {})
	if value == "" or value == original:
		t.erase(original)
	else:
		t[original] = value
	_local["texts"] = t
	_save()


func has_text_edits() -> bool:
	return not (_merged("texts") as Dictionary).is_empty()


## متن پویا (پاپ‌آپ، توست، پیام مینی‌بازی…): اول تطبیق دقیق، بعد قالب‌هایی مثل «کمبو ×%d» (%d و %s با مقدار واقعی پر می‌شوند)
func dyn(t: String) -> String:
	var tx: Dictionary = _merged("texts")
	if tx.is_empty():
		return t
	if tx.has(t):
		return String(tx[t])
	for k: String in tx.keys():
		if k.find("%") == -1:
			continue
		var pat := "^" + _rx_escape(k).replace("%d", "(\\d+)").replace("%s", "(.+?)") + "$"
		var re := RegEx.new()
		if re.compile(pat) != OK:
			continue
		var m := re.search(t)
		if m == null:
			continue
		var out := String(tx[k])
		var gi := 1
		var i := 0
		var res := ""
		while i < out.length():
			if i + 1 < out.length() and out[i] == "%" and (out[i + 1] == "d" or out[i + 1] == "s") and gi <= m.get_group_count():
				res += m.get_string(gi)
				gi += 1
				i += 2
			else:
				res += out[i]
				i += 1
		return res
	return t


func _rx_escape(s: String) -> String:
	var out := ""
	for ch in s:
		if ".^$*+?()[]{}|\\".find(ch) != -1:
			out += "\\" + ch
		else:
			out += ch
	return out


## همه‌ی متن‌های بازی: [متن، شماره‌ی دسته]؛ دسته‌ی ‎-1‎ = متنی که فقط هنگام اجرا دیده شده
func known_entries() -> Array:
	var out: Array = []
	var have := {}
	for r: Array in TextsCatalog.ROWS:
		out.append(r)
		have[r[0]] = true
	for k: String in known_texts():
		if not have.has(k):
			out.append([k, -1])
	return out


func text_for(original: String) -> String:
	return String(_merged("texts").get(original, original))


## متن‌های ثابتِ رابط که تا حالا دیده شده‌اند (برای ویرایشگر)
func known_texts() -> Array:
	var keys: Array = []
	for k: String in _seen.keys():
		if k.strip_edges().length() >= 3 and not k.is_valid_int():
			keys.append(k)
	keys.sort()
	return keys


## متن‌های ویرایش‌شده را روی همه‌ی نودهای زیر root اعمال می‌کند
func apply_tree(n: Node) -> void:
	if n.has_meta("ct_skip"):
		return
	if (n is Label or n is Button) and not (n is OptionButton):
		var cur: String = n.text
		if n.has_meta("ct_cur") and cur != String(n.get_meta("ct_cur")):
			n.remove_meta("ct_orig")          # کد متن را عوض کرده؛ دوباره از صفر
		var orig: String = String(n.get_meta("ct_orig")) if n.has_meta("ct_orig") else cur
		if not _trackable(orig) and has_text_edits() and orig.length() <= 140:
			var dv := dyn(orig)
			if dv != orig:
				n.text = dv
		elif _trackable(orig):
			n.set_meta("ct_orig", orig)
			_seen[orig] = true
			var nv := text_for(orig)
			if nv != cur:
				n.text = nv
			n.set_meta("ct_cur", n.text)
	for c in n.get_children():
		apply_tree(c)


# ------------------------- دسته‌بندیِ انیمیشن/صدا بر اساس رویداد -------------------------
const CAT_WORDS := {"jump": ["jump", "hop", "leap", "پرش"], "slide": ["slide", "slid", "crouch", "duck", "roll", "سر"], "land": ["land", "فرود"],
	"lane": ["strafe", "side", "left", "right", "lane", "dodge"], "coin": ["coin", "collect", "pick", "سکه"], "start": ["start", "idle", "intro", "wave", "run", "walk"],
	"crash": ["crash", "hit", "die", "death", "fall", "hurt", "ouch", "fail"]}


## دسته‌ی (رویدادِ) یک کلیپ/صدا؛ مالک می‌تواند تغییر دهد، وگرنه از روی نام حدس زده می‌شود. "" = سایر
func cat_of(char_key: String, name: String) -> String:
	var m := _merged("cats")
	var k := "%s|%s" % [char_key, name]
	if m.has(k):
		return String(m[k])
	var low := name.to_lower()
	for ev in CAT_WORDS:
		for w in CAT_WORDS[ev]:
			if low.find(String(w)) >= 0:
				return String(ev)
	return ""


func set_cat(char_key: String, name: String, ev: String) -> void:
	var a: Dictionary = _local.get("cats", {})
	a["%s|%s" % [char_key, name]] = ev
	_local["cats"] = a
	_save()
