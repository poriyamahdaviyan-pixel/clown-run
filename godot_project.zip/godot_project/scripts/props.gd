extends RefCounted
## ابزار مشترک ساخت اجسام سه‌بعدی با کد: مصالح کش‌شده، چنبره، و مدل‌های «آیتم‌های ویژه»
## (آهنربا، سپر، ×۲، جت‌پک، فنر، ساعت). هیچ فایل خارجی لازم نیست.

const Gfx := preload("res://scripts/gfx.gd")

static var _m := {}


## مصالح کش‌شده: m("ff3030", 0.0, 0.4, 0.3)  ← رنگ، تابش، زبری، فلزی‌بودن
static func m(hex: String, emit: float = 0.0, rough: float = 0.8, metal: float = 0.0) -> StandardMaterial3D:
	var key := "%s_%.2f_%.2f_%.2f" % [hex, emit, rough, metal]
	if _m.has(key):
		return _m[key]
	var mt := Gfx.mat(Color(hex), emit, null, rough)
	mt.metallic = metal
	_m[key] = mt
	return mt


static func tex_m(tex: Texture2D, tint: String = "ffffff", rough: float = 0.85) -> StandardMaterial3D:
	var key := "tex_%d_%s" % [tex.get_rid().get_id(), tint]
	if _m.has(key):
		return _m[key]
	var mt := Gfx.mat(Color(tint), 0.0, tex, rough)
	_m[key] = mt
	return mt


## حلقه با «شعاع اصلی» R و «شعاع لوله» r (torus بالا شعاع بیرونی/درونی می‌گیرد)
static func ring(parent: Node3D, big_r: float, tube_r: float, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO, segs: int = 16) -> MeshInstance3D:
	return torus(parent, big_r + tube_r, maxf(big_r - tube_r, 0.001), pos, mat, rot_deg, segs)


static func torus(parent: Node3D, outer: float, inner: float, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO, segs: int = 16) -> MeshInstance3D:
	var key := "tor_%.3f_%.3f_%d" % [outer, inner, segs]
	var tm: TorusMesh
	if Gfx._mesh_cache.has(key):
		tm = Gfx._mesh_cache[key]
	else:
		tm = TorusMesh.new()
		tm.outer_radius = outer
		tm.inner_radius = inner
		tm.rings = segs
		tm.ring_segments = 8
		Gfx._mesh_cache[key] = tm
	var mi := MeshInstance3D.new()
	mi.mesh = tm
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


## استوانه‌ای که محورش به سمت بیننده (Z) است (دیسک ایستاده)
static func disc(parent: Node3D, r: float, thick: float, pos: Vector3, mat: Material, segs: int = 20) -> MeshInstance3D:
	return Gfx.cyl(parent, r, r, thick, pos, mat, Vector3(90, 0, 0), segs)


# ============================================================
#                    مدل‌های آیتم‌های ویژه
# ============================================================
## id: 0 آهنربا، 1 سپر، 2 ×۲، 3 جت‌پک، 4 فنر، 5 ساعت (حرکت آهسته). بزرگی تقریبی ۱ متر.
static func power_model(parent: Node3D, id: int) -> void:
	match id:
		0: _magnet(parent)
		1: _shield(parent)
		2: _double(parent)
		3: _jet(parent)
		4: _spring(parent)
		_: _stopwatch(parent)


static func _magnet(p: Node3D) -> void:
	var red := m("e02424", 0.0, 0.3, 0.35)
	var dark := m("7a1010", 0.0, 0.4, 0.3)
	var steel := m("dfe4ea", 0.0, 0.18, 1.0)
	var R := 0.34
	var seg := 10
	# قوس نعل اسبی (نیم‌دایره‌ی بالایی)
	for i in seg:
		var a0 := PI * float(i) / float(seg)
		var a1 := PI * float(i + 1) / float(seg)
		var am := (a0 + a1) * 0.5
		var c := Vector3(cos(am) * R, sin(am) * R + 0.12, 0.0)
		var ln := 2.0 * R * sin((a1 - a0) * 0.5) + 0.03
		Gfx.box(p, Vector3(ln, 0.2, 0.2), c, red if i % 2 == 0 else dark, Vector3(0, 0, rad_to_deg(am) - 90.0))
	# بازوها + نوک‌های نقره‌ای
	for s in [-1.0, 1.0]:
		Gfx.box(p, Vector3(0.2, 0.34, 0.2), Vector3(s * R, -0.05, 0.0), red)
		Gfx.box(p, Vector3(0.2, 0.2, 0.2), Vector3(s * R, -0.3, 0.0), steel)
		Gfx.box(p, Vector3(0.22, 0.03, 0.22), Vector3(s * R, -0.22, 0.0), dark)
	# جرقه‌ی میدان
	Gfx.glow(p, Vector3(0, -0.3, 0.2), 0.9, Color(0.6, 0.8, 1.0, 0.45))


static func _shield(p: Node3D) -> void:
	var steel := m("cfd6de", 0.0, 0.2, 1.0)
	var blue := m("1f6fe0", 0.25, 0.3, 0.2)
	var navy := m("123a80", 0.0, 0.4, 0.2)
	var gold := m("ffcf4a", 0.3, 0.25, 0.9)
	disc(p, 0.5, 0.08, Vector3(0, 0, -0.02), navy, 28)
	torus(p, 0.5, 0.45, Vector3(0, 0, 0.03), steel, Vector3(90, 0, 0), 28)
	disc(p, 0.43, 0.06, Vector3(0, 0, 0.04), blue, 28)
	# ستاره‌ی طلایی روی سپر
	for k in 5:
		Gfx.box(p, Vector3(0.1, 0.34, 0.03), Vector3(0, 0, 0.09), gold, Vector3(0, 0, 36.0 * k))
	Gfx.sphere(p, 0.09, Vector3(0, 0, 0.1), steel, 10)
	for k in 8:
		var a := TAU * float(k) / 8.0
		Gfx.sphere(p, 0.025, Vector3(cos(a) * 0.38, sin(a) * 0.38, 0.08), gold, 6)
	Gfx.glow(p, Vector3(0, 0, 0.15), 1.3, Color(0.4, 0.8, 1.0, 0.35))


static func _double(p: Node3D) -> void:
	var gold := m("ffc823", 0.45, 0.25, 0.9)
	var edge := m("c98a0e", 0.2, 0.3, 0.9)
	for off in [Vector3(-0.2, -0.04, -0.06), Vector3(0.2, 0.06, 0.06)]:
		disc(p, 0.34, 0.09, off, edge, 24)
		disc(p, 0.3, 0.1, off + Vector3(0, 0, 0.005), gold, 24)
		torus(p, 0.31, 0.26, off + Vector3(0, 0, 0.06), edge, Vector3(90, 0, 0), 24)
	var l := Gfx.label(p, "×2", Vector3(0.2, 0.06, 0.14), 90, Color("fff2b0"), 0.0075)
	l.double_sided = true
	l.no_depth_test = false
	Gfx.glow(p, Vector3.ZERO, 1.5, Color(1.0, 0.8, 0.2, 0.4))


static func _jet(p: Node3D) -> void:
	var orange := m("ff7a1a", 0.0, 0.3, 0.5)
	var steel := m("c9d0d8", 0.0, 0.2, 1.0)
	var dark := m("2a2f36", 0.0, 0.5, 0.4)
	var flame := m("ffb040", 3.0, 0.5)
	Gfx.box(p, Vector3(0.62, 0.5, 0.18), Vector3(0, 0.05, -0.16), dark)           # صفحه‌ی پشتی
	for s in [-1.0, 1.0]:
		var x: float = s * 0.17
		Gfx.cyl(p, 0.14, 0.14, 0.62, Vector3(x, 0.1, 0), orange, Vector3.ZERO, 14)
		Gfx.sphere(p, 0.14, Vector3(x, 0.41, 0), steel, 12)
		Gfx.cyl(p, 0.15, 0.15, 0.05, Vector3(x, 0.16, 0), steel, Vector3.ZERO, 14)  # کمربند فلزی
		Gfx.cyl(p, 0.1, 0.16, 0.16, Vector3(x, -0.29, 0), dark, Vector3.ZERO, 12)   # نازل
		Gfx.cyl(p, 0.001, 0.09, 0.3, Vector3(x, -0.5, 0), flame, Vector3.ZERO, 8)   # شعله
		Gfx.glow(p, Vector3(x, -0.5, 0), 0.7, Color(1.0, 0.6, 0.2, 0.7))
	Gfx.box(p, Vector3(0.5, 0.06, 0.06), Vector3(0, 0.12, 0.0), steel)
	Gfx.box(p, Vector3(0.08, 0.34, 0.04), Vector3(-0.28, 0.0, -0.18), m("3a3f46"))
	Gfx.box(p, Vector3(0.08, 0.34, 0.04), Vector3(0.28, 0.0, -0.18), m("3a3f46"))


static func _spring(p: Node3D) -> void:
	var green := m("3ddc4a", 0.35, 0.3, 0.6)
	var steel := m("d6dce2", 0.0, 0.2, 1.0)
	Gfx.cyl(p, 0.28, 0.28, 0.06, Vector3(0, -0.4, 0), steel, Vector3.ZERO, 20)
	Gfx.cyl(p, 0.28, 0.28, 0.06, Vector3(0, 0.4, 0), steel, Vector3.ZERO, 20)
	Gfx.cyl(p, 0.1, 0.1, 0.1, Vector3(0, 0.48, 0), steel, Vector3.ZERO, 12)
	for i in 9:
		var y := -0.34 + float(i) * 0.085
		var tilt := 14.0 if i % 2 == 0 else -14.0
		torus(p, 0.27, 0.2, Vector3(0, y, 0), green, Vector3(tilt, 0, 0), 20)
	Gfx.glow(p, Vector3(0, 0, 0.2), 1.3, Color(0.4, 1.0, 0.4, 0.3))


static func _stopwatch(p: Node3D) -> void:
	var steel := m("dfe3ea", 0.0, 0.2, 1.0)
	var face := m("f7f7f2", 0.1, 0.5)
	var dark := m("20232a", 0.0, 0.5)
	var purple := m("b07aff", 1.4, 0.4)
	var red := m("ff3a4a", 0.8, 0.5)
	disc(p, 0.4, 0.14, Vector3.ZERO, steel, 28)
	disc(p, 0.34, 0.03, Vector3(0, 0, 0.075), face, 28)
	torus(p, 0.37, 0.33, Vector3(0, 0, 0.07), purple, Vector3(90, 0, 0), 28)
	for k in 12:
		var a := TAU * float(k) / 12.0
		var big := k % 3 == 0
		Gfx.box(p, Vector3(0.025, 0.07 if big else 0.04, 0.02), Vector3(sin(a) * 0.27, cos(a) * 0.27, 0.095), dark, Vector3(0, 0, -rad_to_deg(a)))
	Gfx.box(p, Vector3(0.03, 0.2, 0.025), Vector3(0.0, 0.1, 0.105), dark)                    # عقربه‌ی بلند
	Gfx.box(p, Vector3(0.025, 0.14, 0.025), Vector3(0.07, -0.03, 0.11), red, Vector3(0, 0, -50.0))
	Gfx.sphere(p, 0.035, Vector3(0, 0, 0.115), dark, 8)
	Gfx.cyl(p, 0.07, 0.07, 0.12, Vector3(0, 0.46, 0), steel, Vector3.ZERO, 12)               # دکمه‌ی بالا
	Gfx.cyl(p, 0.1, 0.1, 0.04, Vector3(0, 0.54, 0), steel, Vector3.ZERO, 12)
	Gfx.cyl(p, 0.045, 0.045, 0.1, Vector3(0.3, 0.3, 0), steel, Vector3(0, 0, -45.0), 8)       # دکمه‌ی کناری
	torus(p, 0.14, 0.1, Vector3(0, 0.6, 0), steel, Vector3.ZERO, 12)
	Gfx.glow(p, Vector3(0, 0, 0.2), 1.3, Color(0.7, 0.5, 1.0, 0.35))
