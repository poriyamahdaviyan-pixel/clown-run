extends Node
## نسخه‌ها و بروزرسانی (فقط مدیر): انتشار APK با لینک دانلود، انتشار «وصله» برای بروزرسانی بدون نصب دوباره،
## مدیریت کلید امضا، نمایش/مخفی/حذف نسخه‌ها.
## منطق جدا از رابط است تا بدون صفحه هم قابل آزمایش باشد (publish_patch, publish_apk, ...).

const PRIV_PATH := "user://owner_update_priv.pem"
const PUB_PATH := "user://owner_update_pub.pem"

var ui
var _over: Control
var _body: VBoxContainer
var _note: Label
var _rows: Array = []
var _f := {"kind": "patch", "name": "", "code": "", "base": "", "edition": "all", "notes": "", "mandatory": false, "file": "", "url": "", "purl": ""}
var _busy := false


const URL_MEMO := "user://release_patch_url.txt"


func setup(owner_ui) -> void:
	ui = owner_ui
	if FileAccess.file_exists(URL_MEMO):
		_f["purl"] = FileAccess.get_file_as_string(URL_MEMO).strip_edges()
	Online.transfer.connect(func(t: String): if t != "": _say(t))


# ------------------------- کلید امضا -------------------------
func has_private_key() -> bool:
	return FileAccess.file_exists(PRIV_PATH)


func private_pem() -> String:
	return FileAccess.get_file_as_string(PRIV_PATH) if has_private_key() else ""


func public_pem() -> String:
	return FileAccess.get_file_as_string(PUB_PATH) if FileAccess.file_exists(PUB_PATH) else ""


func make_keys() -> bool:
	var crypto := Crypto.new()
	var key := crypto.generate_rsa(2048)
	if key == null:
		return false
	var pf := FileAccess.open(PRIV_PATH, FileAccess.WRITE)
	var uf := FileAccess.open(PUB_PATH, FileAccess.WRITE)
	if pf == null or uf == null:
		return false
	pf.store_string(key.save_to_string(false))
	uf.store_string(key.save_to_string(true))
	pf.close()
	uf.close()
	return true


func import_private(pem: String) -> bool:
	var key := CryptoKey.new()
	if key.load_from_string(pem.strip_edges() + "\n", false) != OK:
		return false
	var pf := FileAccess.open(PRIV_PATH, FileAccess.WRITE)
	var uf := FileAccess.open(PUB_PATH, FileAccess.WRITE)
	pf.store_string(key.save_to_string(false))
	uf.store_string(key.save_to_string(true))
	pf.close()
	uf.close()
	return true


# ------------------------- عملیات سرور (بدون رابط) -------------------------
func list_all() -> Array:
	var r: Dictionary = await Online._req(HTTPClient.METHOD_GET, "/rest/v1/app_releases?select=*&order=version_code.desc,created_at.desc")
	_rows = r.data if (r.ok and r.data is Array) else []
	return _rows


func _insert(row: Dictionary) -> Dictionary:
	var r: Dictionary = await Online._req(HTTPClient.METHOD_POST, "/rest/v1/app_releases", row, true, false, PackedStringArray(["Prefer: return=representation"]))
	if not r.ok:
		return {"ok": false, "error": String(r.error)}
	return {"ok": true, "error": "", "row": (r.data[0] if (r.data is Array and r.data.size() > 0) else row)}


## فایل را از یک لینک https (مثلاً GitHub Releases) در حافظه‌ی برنامه دانلود می‌کند؛ بدون نیاز به انتخابگر فایل.
## برمی‌گرداند {ok, path, error}
func download_url(url: String) -> Dictionary:
	url = url.strip_edges()
	if not url.begins_with("https://") and not url.begins_with("http://127.0.0.1"):
		return {"ok": false, "path": "", "error": "لینک باید با https:// شروع شود"}
	var dest := "user://dl_patch.pck"
	if FileAccess.file_exists(dest):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(dest))
	var h := HTTPRequest.new()
	h.download_file = ProjectSettings.globalize_path(dest)
	h.max_redirects = 8
	h.timeout = 180.0
	add_child(h)
	var err := h.request(url, ["User-Agent: ClownRun"])
	if err != OK:
		h.queue_free()
		return {"ok": false, "path": "", "error": "درخواست شروع نشد (کد %d)" % err}
	var res: Array = await h.request_completed
	h.queue_free()
	if int(res[0]) != HTTPRequest.RESULT_SUCCESS or int(res[1]) != 200:
		return {"ok": false, "path": "", "error": "دانلود نشد (کد %d / %d). لینک را بررسی کن و مخزن باید Public باشد." % [int(res[0]), int(res[1])]}
	if not FileAccess.file_exists(dest):
		return {"ok": false, "path": "", "error": "فایل ذخیره نشد"}
	return {"ok": true, "path": dest, "error": ""}


## وصله: فایل pck را امضا و آپلود می‌کند. base = شماره‌ی ساخت APKی که این وصله روی آن کار می‌کند
func publish_patch(path: String, version_code: int, version_name: String, notes: String, mandatory: bool, base: int = -1) -> Dictionary:
	if not Online.is_admin:
		return {"ok": false, "error": "فقط مدیر"}
	if not has_private_key():
		return {"ok": false, "error": "اول کلید امضا بساز (یا وارد کن)"}
	if base < 0:
		base = Updater.BUILD
	var bytes := FileAccess.get_file_as_bytes(path)
	if bytes.is_empty():
		return {"ok": false, "error": "فایل خوانده نشد"}
	if bytes.size() < 16 or bytes.slice(0, 4).get_string_from_ascii() != "GDPC":
		return {"ok": false, "error": "این فایل خروجی pck گودو نیست"}
	var sha := FileAccess.get_sha256(path)
	var sig := Updater.sign(base, version_code, sha, private_pem())
	if sig == "":
		return {"ok": false, "error": "امضا ممکن نشد"}
	var rpath := "patch/b%d_v%d.pck" % [base, version_code]
	var up: Dictionary = await Online.admin_upload(rpath, bytes, "application/octet-stream", "releases")
	if not up.ok:
		return up
	return await _insert({"kind": "patch", "version_name": version_name, "version_code": version_code, "base_code": base, "file_path": rpath,
		"size": bytes.size(), "sha256": sha, "sig": sig, "notes": notes, "mandatory": mandatory, "published": true})


## APK: تا ۴۵ مگابایت مستقیم روی سرور؛ بزرگ‌تر باید لینک بیرونی (مثلاً GitHub Releases) داده شود
func publish_apk(path: String, ext_url: String, version_code: int, version_name: String, notes: String, mandatory: bool, edition: String = "all") -> Dictionary:
	if not Online.is_admin:
		return {"ok": false, "error": "فقط مدیر"}
	var row := {"kind": "apk", "version_name": version_name, "version_code": version_code, "edition": edition, "notes": notes, "mandatory": mandatory, "published": true}
	if ext_url.strip_edges() != "":
		if not ext_url.begins_with("https://"):
			return {"ok": false, "error": "لینک باید با https:// شروع شود"}
		row["url"] = ext_url.strip_edges()
		if path != "" and FileAccess.file_exists(path):
			var fz := FileAccess.open(path, FileAccess.READ)
			row["size"] = fz.get_length()
			fz.close()
		return await _insert(row)
	if path == "" or not FileAccess.file_exists(path):
		return {"ok": false, "error": "فایل APK یا لینک دانلود را بده"}
	var fa := FileAccess.open(path, FileAccess.READ)
	var size := fa.get_length()
	fa.close()
	if size > Online.SINGLE_MAX:
		return {"ok": false, "error": "APK بزرگ‌تر از %d مگابایت است؛ روی سرور رایگان یک لینک مستقیم نمی‌شود. آن را در GitHub Releases (یا هر میزبان دیگر) بگذار و فقط لینک را اینجا بده." % (Online.SINGLE_MAX / 1048576)}
	var bytes := FileAccess.get_file_as_bytes(path)
	var rpath := "apk/%s_v%d.apk" % ["owner" if edition == "owner" else "game", version_code]
	var up: Dictionary = await Online.admin_upload(rpath, bytes, "application/vnd.android.package-archive", "releases")
	if not up.ok:
		return up
	row["file_path"] = rpath
	row["size"] = size
	row["sha256"] = FileAccess.get_sha256(path)
	return await _insert(row)


func set_published(row: Dictionary, on: bool) -> Dictionary:
	var r: Dictionary = await Online._req(HTTPClient.METHOD_PATCH, "/rest/v1/app_releases?id=eq." + String(row.id), {"published": on})
	return {"ok": r.ok, "error": String(r.error)}


func delete_release(row: Dictionary) -> Dictionary:
	var r: Dictionary = await Online._req(HTTPClient.METHOD_DELETE, "/rest/v1/app_releases?id=eq." + String(row.id))
	if r.ok and String(row.get("file_path", "")) != "":
		var fp := String(row.file_path)
		var names: Array = [fp]
		for i in int(ceil(float(int(row.get("size", 0))) / float(Online.CHUNK))):
			names.append("%s.part%04d" % [fp, i + 1])
		await Online._req(HTTPClient.METHOD_DELETE, "/storage/v1/object/releases", {"prefixes": names})
	return {"ok": r.ok, "error": String(r.error)}


# ------------------------- رابط -------------------------
func _say(t: String) -> void:
	if _note != null and is_instance_valid(_note):
		_note.text = t


func _lbl(t: String, size: int = 24, color: Color = Color("c9d6e6")) -> Label:
	var l: Label = ui._label(t, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(560, 0)
	return l


func _edit(key: String, hint: String, numeric: bool = false, multi: bool = false) -> Control:
	var e := LineEdit.new()
	e.text = String(_f[key])
	e.placeholder_text = hint
	e.add_theme_font_size_override("font_size", 26)
	e.custom_minimum_size = Vector2(0, 66)
	e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if numeric:
		e.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	e.text_changed.connect(func(t: String): _f[key] = t)
	return e


func open() -> void:
	if not Online.is_admin:
		return
	_render()
	var rows := await list_all()
	_rows = rows
	_render()


func _close() -> void:
	if _over != null and is_instance_valid(_over):
		_over.queue_free()


func _chips(options: Array, key: String) -> HFlowContainer:
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 8)
	fl.add_theme_constant_override("v_separation", 8)
	for o in options:
		var on := String(_f[key]) == String(o[0])
		fl.add_child(ui._button(("✓ " if on else "") + String(o[1]), func(): _f[key] = o[0]; _render(), Vector2(0, 62), 22, "Gold" if on else "Dark"))
	return fl


func _render() -> void:
	if _over != null and is_instance_valid(_over):
		_over.queue_free()
	_over = Control.new()
	ui._add_full(ui._root, _over)
	var bg := ColorRect.new()
	bg.color = Color("1d0c36")
	ui._add_full(_over, bg)
	var m := MarginContainer.new()
	ui._add_full(_over, m)
	for k in ["left", "right", "bottom"]:
		m.add_theme_constant_override("margin_" + k, 22)
	m.add_theme_constant_override("margin_top", 56)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	m.add_child(col)
	col.add_child(ui._label("نسخه‌ها و بروزرسانی", 40, Color.WHITE))
	_note = _lbl("", 24, Color("ffd27a"))
	col.add_child(_note)
	col.add_child(ui._button("بستن", func(): _close(), Vector2(0, 66), 24, "Dark"))
	_body = ui.make_scroll_view(col)
	var B := _body
	# --- وضعیت
	B.add_child(_lbl("شماره‌ی ساخت این APK: %d  •  وصله‌ی نصب‌شده: %s" % [Updater.BUILD, str(Updater.active.get("version", "هیچ"))], 24, Color.WHITE))
	B.add_child(_lbl("کلید عمومی داخل بازی (update_key.pub): " + ("هست ✓" if Updater.key_ok else "نیست ✗  ← بدون آن وصله اجرا نمی‌شود"), 22, Color("7dff9a") if Updater.key_ok else Color("ff8a8a")))
	B.add_child(_lbl("کلید امضا روی این گوشی: " + ("هست ✓" if has_private_key() else "نیست"), 22, Color("7dff9a") if has_private_key() else Color("ffd27a")))
	var kr := HFlowContainer.new()
	kr.add_theme_constant_override("h_separation", 8)
	kr.add_theme_constant_override("v_separation", 8)
	B.add_child(kr)
	kr.add_child(ui._button("ساخت کلید امضا (یک‌بار)", func(): _make_keys_ui(), Vector2(0, 60), 22, "Teal"))
	kr.add_child(ui._button("کپی کلید عمومی", func(): DisplayServer.clipboard_set(public_pem()); _say("کلید عمومی کپی شد" if public_pem() != "" else "هنوز کلیدی نساخته‌ای"), Vector2(0, 60), 22, "Dark"))
	kr.add_child(ui._button("کپی کلید خصوصی (پشتیبان؛ پیش کسی نگذار)", func(): DisplayServer.clipboard_set(private_pem()); _say("کلید خصوصی کپی شد؛ جای امنی نگهش دار" if has_private_key() else "کلیدی نیست"), Vector2(0, 60), 22, "Dark"))
	kr.add_child(ui._button("وارد کردن کلید خصوصی از کلیپ‌بورد", func(): _say("کلید وارد شد" if import_private(DisplayServer.clipboard_get()) else "متن کلیپ‌بورد کلید معتبر نیست"), Vector2(0, 60), 22, "Dark"))
	# --- انتشار
	B.add_child(ui._label("انتشار نسخه‌ی تازه", 32, Color("ffb02e")))
	B.add_child(_chips([["patch", "وصله (بروزرسانی بدون نصب)"], ["apk", "APK جدید (لینک دانلود)"]], "kind"))
	B.add_child(_edit("name", "نام نسخه (مثلاً 1.2)"))
	B.add_child(_edit("code", "شماره‌ی نسخه (عدد؛ هر بار بیشتر)", true))
	if _f.kind == "patch":
		B.add_child(_edit("base", "روی کدام ساخت APK (خالی = همین ساخت %d)" % Updater.BUILD, true))
		B.add_child(_edit("purl", "لینک patch.pck (GitHub Releases ← patch.pck ← نگه‌داشتن ← کپی لینک)"))
		B.add_child(_lbl("روی گوشی لینک فایل patch.pck را بچسبان تا خود بازی دانلودش کند. روی کامپیوتر می‌توانی فایل را هم انتخاب کنی. امضا و آپلود خودکار است.", 20))
	else:
		B.add_child(_chips([["all", "همه"], ["public", "عمومی"], ["owner", "مالک"]], "edition"))
		B.add_child(_edit("url", "لینک دانلود بیرونی (https://…) — برای APK بزرگ"))
		B.add_child(_lbl("اگر APK کمتر از %d مگابایت است، فایل را انتخاب کن تا لینک مستقیم ساخته شود؛ وگرنه لینک GitHub Releases را بگذار." % (Online.SINGLE_MAX / 1048576), 20))
	B.add_child(_edit("notes", "توضیح تغییرات (به بازیکن نشان داده می‌شود)"))
	if OS.get_name() != "Android":
		B.add_child(ui._button("انتخاب فایل: " + (String(_f.file).get_file() if String(_f.file) != "" else "هنوز نیست"), func(): ui.pick_file("item_file", func(p): _f["file"] = String(p); _render()), Vector2(0, 72), 24, "Teal"))
	var mc := CheckBox.new()
	mc.text = "اجباری (بازیکن قبل از بازی باید بروز کند)"
	mc.button_pressed = bool(_f.mandatory)
	mc.add_theme_font_size_override("font_size", 26)
	mc.toggled.connect(func(v: bool): _f["mandatory"] = v)
	B.add_child(mc)
	B.add_child(ui._button("انتشار", func(): _do_publish(), Vector2(0, 84), 32, "Gold"))
	# --- فهرست
	B.add_child(ui._label("نسخه‌های منتشرشده", 32, Color("ffb02e")))
	if _rows.is_empty():
		B.add_child(_lbl("هنوز نسخه‌ای منتشر نشده.", 22))
	for row: Dictionary in _rows:
		B.add_child(_row_ui(row))


func _row_ui(row: Dictionary) -> Control:
	var p := PanelContainer.new()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	p.add_child(v)
	var kind_txt := "وصله" if String(row.kind) == "patch" else "APK"
	var size_mb := float(row.get("size", 0)) / 1048576.0
	var base_txt := ("، روی ساخت %d" % int(row.base_code)) if String(row.kind) == "patch" else ""
	var hid_txt := "" if bool(row.get("published", true)) else "  •  پنهان"
	var man_txt := "  •  اجباری" if bool(row.get("mandatory", false)) else ""
	v.add_child(_lbl("%s  %s  (شماره %d%s)  •  %.1f مگابایت%s%s" % [kind_txt, String(row.get("version_name", "")), int(row.get("version_code", 0)), base_txt, size_mb, hid_txt, man_txt], 22, Color.WHITE))
	if String(row.get("notes", "")) != "":
		v.add_child(_lbl(String(row.notes), 20))
	var br := HFlowContainer.new()
	br.add_theme_constant_override("h_separation", 8)
	br.add_theme_constant_override("v_separation", 8)
	v.add_child(br)
	if String(row.kind) == "apk":
		br.add_child(ui._button("کپی لینک دانلود", func(): DisplayServer.clipboard_set(Updater.link_of(row)); _say("لینک کپی شد: " + Updater.link_of(row)), Vector2(0, 56), 20, "Teal"))
	br.add_child(ui._button("نمایش" if not bool(row.get("published", true)) else "پنهان‌کردن", func(): _toggle(row), Vector2(0, 56), 20, "Dark"))
	br.add_child(ui._button("حذف", func(): _del(row), Vector2(0, 56), 20, "Red"))
	return p


func _make_keys_ui() -> void:
	if has_private_key():
		_say("کلید از قبل هست. برای ساخت کلید تازه، باید APK جدید با کلید عمومی تازه بسازی؛ پس نگهش دار.")
	else:
		_say("کلید ساخته شد. «کپی کلید عمومی» را بزن و در فایل update_key.pub پروژه بگذار، بعد APK را یک‌بار دوباره بساز." if make_keys() else "ساخت کلید ممکن نشد")


func _toggle(row: Dictionary) -> void:
	await set_published(row, not bool(row.get("published", true)))
	open()


func _del(row: Dictionary) -> void:
	if row.get("_confirm", false):
		await delete_release(row)
		open()
	else:
		row["_confirm"] = true
		_say("برای حذف دوباره «حذف» را بزن")


func _do_publish() -> void:
	if _busy:
		return
	var code := int(String(_f.code))
	if code <= 0:
		_say("شماره‌ی نسخه را بنویس")
		return
	_busy = true
	_say("در حال انتشار…")
	var r: Dictionary
	if _f.kind == "patch":
		var pfile := String(_f.file)
		if String(_f.purl).strip_edges() != "":
			_say("در حال دانلود وصله…")
			var dl: Dictionary = await download_url(String(_f.purl))
			if not dl.ok:
				_busy = false
				_say("انجام نشد: " + String(dl.error))
				return
			pfile = String(dl.path)
			var fm := FileAccess.open(URL_MEMO, FileAccess.WRITE)
			if fm != null:
				fm.store_string(String(_f.purl).strip_edges())
				fm.close()
		if pfile == "":
			_busy = false
			_say("لینک patch.pck را بنویس")
			return
		var base := int(String(_f.base)) if String(_f.base) != "" else -1
		r = await publish_patch(pfile, code, String(_f.name), String(_f.notes), bool(_f.mandatory), base)
	else:
		r = await publish_apk(String(_f.file), String(_f.url), code, String(_f.name), String(_f.notes), bool(_f.mandatory), String(_f.edition))
	_busy = false
	if r.ok:
		_f["file"] = ""
		_f["code"] = ""
		await open()
		_say("منتشر شد ✓" + (("  لینک دانلود: " + Updater.link_of(r.row)) if String(r.row.get("kind", "")) == "apk" else ""))
	else:
		_say("انجام نشد: " + String(r.error))
