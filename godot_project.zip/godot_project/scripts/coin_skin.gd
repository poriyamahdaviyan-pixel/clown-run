extends Node
## موتور سکه (Autoload با نام «CoinSkin») — «طراح سکه».
## • ۴ طرح آماده: ستاره، الماس، قلب، خورشید (حکاکی خطی شبیه اسکناس)
## • یا عکس خودت: به «حکاکی خطی» تبدیل و روی دو وجه سکه‌ی سه‌بعدی چرخان چاپ می‌شود
## • اسلایدر تراکم خط و کنتراست با پیش‌نمایش زنده
## • دو دسته تنظیم: «پیش‌نویس» (فقط پیش‌نمایش طراح) و «ذخیره‌شده» (همه‌ی سکه‌های بازی).
##   با «ذخیره این طرح» پیش‌نویس به بازی می‌رود.

signal changed          # طرح ذخیره‌شده (بازی) عوض شد
signal draft_changed    # پیش‌نویس عوض شد

const SkinLib := preload("res://scripts/skin_lib.gd")

const SIZE := 192
const RADIUS := 0.36
const THICK := 0.07
const SRC_PATH := "user://coin_src.png"
const CFG_PATH := "user://coin.cfg"
const STYLE_NAMES := ["حکاکی خطی (اسکناسی)", "رنگی"]
const DESIGN_NAMES := ["ستاره", "الماس", "قلب", "خورشید", "عکس من"]
const PHOTO := 4

# design: 0..3 طرح آماده ، 4 = عکس. density و contrast بین 0 و 1
var saved := {"design": 0, "density": 0.5, "contrast": 0.5, "style": 0, "bg": 1}
var draft := {"design": 0, "density": 0.5, "contrast": 0.5, "style": 0, "bg": 1}

var face_tex: ImageTexture       # صورت سکه‌ی ذخیره‌شده (برای HUD)
var face_mat: StandardMaterial3D # سکه‌های بازی
var rim_mat: StandardMaterial3D
var preview_mat: StandardMaterial3D
var preview_tex: ImageTexture
var has_photo := false           # عکسی در دسترس است (برای طرح «عکس من»)
var build_ms := 0.0
var bg_removed_ok := true        # حذف پس‌زمینه‌ی عکس فعلی موفق بود؟
var _cut_cache := {}              # زمان آخرین ساخت (برای تست)

var _src_saved: Image
var _src_draft: Image
var _rim_mesh: CylinderMesh
var _face_mesh: QuadMesh
var _pending := false
var _cooldown := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rim_mesh = CylinderMesh.new()
	_rim_mesh.top_radius = RADIUS
	_rim_mesh.bottom_radius = RADIUS
	_rim_mesh.height = THICK
	_rim_mesh.radial_segments = 28
	_rim_mesh.rings = 1
	_face_mesh = QuadMesh.new()
	_face_mesh.size = Vector2(RADIUS * 2.0, RADIUS * 2.0)

	face_mat = _new_face_mat()
	preview_mat = _new_face_mat()
	rim_mat = StandardMaterial3D.new()
	rim_mat.albedo_color = Color(0.95, 0.74, 0.2)
	rim_mat.metallic = 0.45
	rim_mat.roughness = 0.35
	rim_mat.emission_enabled = true
	rim_mat.emission = Color(0.4, 0.28, 0.04)
	rim_mat.emission_energy_multiplier = 0.5

	_load()
	draft = saved.duplicate()
	_src_draft = _src_saved
	_build_into(saved, _src_saved, face_mat, true)
	_build_into(draft, _src_draft, preview_mat, false)


func _new_face_mat() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	m.alpha_scissor_threshold = 0.5
	m.metallic = 0.35
	m.roughness = 0.38
	m.normal_enabled = true
	m.normal_scale = 1.0
	m.emission_enabled = true
	m.emission = Color(0.38, 0.28, 0.06)
	m.emission_energy_multiplier = 0.55
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	return m


func _process(delta: float) -> void:
	if _cooldown > 0.0:
		_cooldown -= delta
	if _pending and _cooldown <= 0.0:
		_pending = false
		_cooldown = 0.12
		_build_into(draft, _src_draft, preview_mat, false)
		draft_changed.emit()


# ------------------------- ساخت سکه‌ی سه‌بعدی -------------------------
## preview=true → با متریال پیش‌نویس (برای صفحه‌ی طراح)
func make_coin(preview: bool = false) -> Node3D:
	var mat := preview_mat if preview else face_mat
	var root := Node3D.new()
	var rim := MeshInstance3D.new()
	rim.mesh = _rim_mesh
	rim.material_override = rim_mat
	rim.rotation_degrees = Vector3(90.0, 0.0, 0.0)
	rim.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(rim)
	var front := MeshInstance3D.new()
	front.mesh = _face_mesh
	front.material_override = mat
	front.position = Vector3(0.0, 0.0, THICK * 0.5 + 0.002)
	front.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(front)
	var back := MeshInstance3D.new()
	back.mesh = _face_mesh
	back.material_override = mat
	back.position = Vector3(0.0, 0.0, -THICK * 0.5 - 0.002)
	back.rotation_degrees = Vector3(0.0, 180.0, 0.0)
	back.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(back)
	return root


# ------------------------- تنظیمات پیش‌نویس (طراح) -------------------------
func select_design(i: int) -> void:
	if i == PHOTO and _src_draft == null:
		return
	draft["design"] = clampi(i, 0, PHOTO)
	_queue()


func set_density(v: float) -> void:
	draft["density"] = clampf(v, 0.0, 1.0)
	_queue()


func set_contrast(v: float) -> void:
	draft["contrast"] = clampf(v, 0.0, 1.0)
	_queue()


func toggle_bg() -> void:
	draft["bg"] = 1 - int(draft["bg"])
	_queue()


## عکس بدون پس‌زمینه (RGBA) برای نمایش/ذخیره. null اگر عکسی نیست
func cutout_image() -> Image:
	if _src_draft == null:
		return null
	return _prepared(_src_draft, 1)


func export_cutout() -> Dictionary:
	var im := cutout_image()
	if im == null:
		return {"ok": false, "path": ""}
	return Skins.export_image(im, "coin", "cutout")


func _prepared(src: Image, bg: int) -> Image:
	if src == null:
		return null
	if bg == 0:
		return src
	var key := src.get_instance_id()
	if not _cut_cache.has(key):
		var r := SkinLib.cutout(src)
		bg_removed_ok = bool(r["ok"])
		_cut_cache = {key: r["image"]}
	return _cut_cache[key]


func cycle_style() -> void:
	draft["style"] = (int(draft["style"]) + 1) % STYLE_NAMES.size()
	_queue()


## عکس را به‌عنوان پیش‌نویس می‌پذیرد (هنوز در بازی اعمال نمی‌شود). خطا یا "".
func set_image(img: Image) -> String:
	if img == null or img.is_empty() or img.get_width() < 8 or img.get_height() < 8:
		return "تصویر معتبر نیست"
	var im := img.duplicate() as Image
	im.convert(Image.FORMAT_RGBA8)
	var m := maxi(im.get_width(), im.get_height())
	if m > 512:
		var f := 512.0 / float(m)
		im.resize(maxi(8, int(im.get_width() * f)), maxi(8, int(im.get_height() * f)), Image.INTERPOLATE_LANCZOS)
	_src_draft = im
	has_photo = true
	_prepared(im, 1)
	draft["design"] = PHOTO
	_queue()
	return ""


func _queue() -> void:
	_pending = true
	draft_changed.emit()


func draft_is_saved() -> bool:
	if _pending:
		return false
	for k in saved:
		if k == "design" and int(saved[k]) == PHOTO and int(draft[k]) == PHOTO:
			if _src_saved != _src_draft:
				return false
			continue
		if is_equal_approx(float(saved[k]), float(draft[k])) == false:
			return false
	return true


## پیش‌نویس را برای همه‌ی سکه‌های بازی ذخیره می‌کند
func save_draft() -> void:
	if _pending:
		_pending = false
		_build_into(draft, _src_draft, preview_mat, false)
	saved = draft.duplicate()
	_src_saved = _src_draft
	if int(saved["design"]) == PHOTO and _src_saved != null:
		_src_saved.save_png(SRC_PATH)
	_build_into(saved, _src_saved, face_mat, true)
	_save()
	changed.emit()


## پیش‌نویس و بازی هر دو به ستاره‌ی پیش‌فرض برمی‌گردند
func reset_default() -> void:
	saved = {"design": 0, "density": 0.5, "contrast": 0.5, "style": 0, "bg": 1}
	draft = saved.duplicate()
	_build_into(saved, _src_saved, face_mat, true)
	_build_into(draft, _src_draft, preview_mat, false)
	_save()
	changed.emit()
	draft_changed.emit()


func _load() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(CFG_PATH) == OK:
		saved["design"] = clampi(int(cfg.get_value("coin", "design", 0)), 0, PHOTO)
		saved["density"] = clampf(float(cfg.get_value("coin", "density", 0.5)), 0.0, 1.0)
		saved["contrast"] = clampf(float(cfg.get_value("coin", "contrast", 0.5)), 0.0, 1.0)
		saved["style"] = clampi(int(cfg.get_value("coin", "style", 0)), 0, STYLE_NAMES.size() - 1)
		saved["bg"] = clampi(int(cfg.get_value("coin", "bg", 1)), 0, 1)
	if FileAccess.file_exists(SRC_PATH):
		var im := Image.load_from_file(SRC_PATH)
		if im != null and not im.is_empty():
			im.convert(Image.FORMAT_RGBA8)
			_src_saved = im
			has_photo = true
	if int(saved["design"]) == PHOTO and _src_saved == null:
		saved["design"] = 0


func _save() -> void:
	var cfg := ConfigFile.new()
	for k in saved:
		cfg.set_value("coin", k, saved[k])
	cfg.save(CFG_PATH)


# ------------------------- ساخت تکسچر -------------------------
func _build_into(p: Dictionary, src: Image, mat: StandardMaterial3D, is_game: bool) -> void:
	var t0 := Time.get_ticks_usec()
	var n := SIZE
	var density: float = p["density"]
	var contrast: float = p["contrast"]
	var ink: PackedFloat32Array
	var color_img: Image = null
	if int(p["design"]) == PHOTO and src != null:
		var sq := _square_crop(_prepared(src, int(p["bg"])), n)
		if int(p["style"]) == 1:
			color_img = sq
		ink = _engrave(sq, n, density, contrast)
	else:
		ink = _design_ink(int(p["design"]) if int(p["design"]) < PHOTO else 0, n, density, contrast)
	var res := _compose(ink, color_img, n)
	var face: Image = res[0]
	var normal: Image = res[1]
	face.generate_mipmaps()
	normal.generate_mipmaps()
	var ft := ImageTexture.create_from_image(face)
	var nt := ImageTexture.create_from_image(normal)
	mat.albedo_texture = ft
	mat.normal_texture = nt
	if is_game:
		face_tex = ft
	else:
		preview_tex = ft
	build_ms = float(Time.get_ticks_usec() - t0) / 1000.0


## برش مربعی: اگر تصویر پس‌زمینه‌ی شفاف دارد، دور سوژه برش می‌خورد و وسط قرار می‌گیرد؛ وگرنه برش مرکزی
func _square_crop(src: Image, n: int) -> Image:
	var w := src.get_width()
	var h := src.get_height()
	var x0 := 0
	var y0 := 0
	var x1 := w
	var y1 := h
	var cutout := false
	var minx := w
	var miny := h
	var maxx := -1
	var maxy := -1
	for y in range(0, h, 2):
		for x in range(0, w, 2):
			if src.get_pixel(x, y).a > 0.5:
				minx = mini(minx, x)
				maxx = maxi(maxx, x)
				miny = mini(miny, y)
				maxy = maxi(maxy, y)
			else:
				cutout = true
	var out: Image
	if cutout and maxx > minx and maxy > miny:
		var bw := maxx - minx + 2
		var bh := maxy - miny + 2
		var side := int(float(maxi(bw, bh)) * 1.08)
		out = Image.create(side, side, false, Image.FORMAT_RGBA8)
		var piece := src.get_region(Rect2i(minx, miny, mini(bw, w - minx), mini(bh, h - miny)))
		out.blit_rect(piece, Rect2i(Vector2i.ZERO, piece.get_size()), Vector2i((side - bw) / 2, (side - bh) / 2))
	else:
		var side2 := mini(w, h)
		x0 = (w - side2) / 2
		y0 = int((h - side2) * 0.3)
		out = src.get_region(Rect2i(x0, y0, side2, side2))
	out.resize(n, n, Image.INTERPOLATE_LANCZOS)
	return out


# ------------------------- طرح‌های آماده -------------------------
func _seg_dist(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	var t := clampf((p - a).dot(ab) / maxf(ab.length_squared(), 0.0001), 0.0, 1.0)
	return p.distance_to(a + ab * t)


func _in_poly(p: Vector2, poly: PackedVector2Array) -> bool:
	return Geometry2D.is_point_in_polygon(p, poly)


## هر طرح: ماسک (داخل شکل)، سایه‌ی نورپردازی (۰ تاریک … ۱ روشن) و خطوط تزئینی؛ سپس هاشور حکاکی می‌شود
func _design_ink(id: int, n: int, density: float, contrast: float) -> PackedFloat32Array:
	var mask := PackedByteArray()
	mask.resize(n * n)
	var shade := PackedFloat32Array()
	shade.resize(n * n)
	var extra := PackedFloat32Array()
	extra.resize(n * n)
	var half := float(n) * 0.5
	var k := lerpf(0.55, 2.0, contrast)
	var gem := PackedVector2Array([Vector2(-0.30, -0.50), Vector2(0.30, -0.50), Vector2(0.64, -0.16), Vector2(0.0, 0.64), Vector2(-0.64, -0.16)])
	var lw := 1.6 / half   # ضخامت خط تزئینی
	var star := PackedVector2Array()
	for j in 10:
		var ang := -PI * 0.5 + float(j) * TAU / 10.0
		var rad := 0.68 if j % 2 == 0 else 0.28
		star.append(Vector2(cos(ang), sin(ang)) * rad)
	var sun := PackedVector2Array()
	for j in 24:
		var ang2 := -PI * 0.5 + float(j) * TAU / 24.0
		var rad2 := 0.84 if j % 2 == 0 else 0.42
		sun.append(Vector2(cos(ang2), sin(ang2)) * rad2)
	for y in n:
		for x in n:
			var px := (float(x) + 0.5 - half) / half
			var py := (float(y) + 0.5 - half) / half
			var r := sqrt(px * px + py * py)
			var a := atan2(py, px) + PI * 0.5
			var i := y * n + x
			var inside := false
			var sh := 0.5
			var ex := 0.0
			match id:
				0:  # ستاره‌ی پنج‌پر با وجه‌های روشن/تاریک
					inside = _in_poly(Vector2(px, py), star)
					var kk := fposmod(a + TAU / 10.0, TAU / 5.0) / (TAU / 5.0)
					sh = 0.28 if kk < 0.5 else 0.78
					if r < 0.12:
						sh = 0.9
				1:  # الماس تراش‌خورده
					var p := Vector2(px, py)
					inside = _in_poly(p, gem)
					if inside:
						if py < -0.16:
							sh = 0.85 if absf(px) < 0.2 else (0.55 if px < 0.0 else 0.35)
						else:
							sh = 0.3 if px < -0.1 else (0.62 if px < 0.1 else 0.78)
						for seg in [[Vector2(-0.64, -0.16), Vector2(0.64, -0.16)], [Vector2(-0.30, -0.50), Vector2(-0.20, -0.16)], [Vector2(0.30, -0.50), Vector2(0.20, -0.16)], [Vector2(-0.20, -0.16), Vector2(0.0, 0.64)], [Vector2(0.20, -0.16), Vector2(0.0, 0.64)], [Vector2(-0.64, -0.16), Vector2(-0.20, -0.16)], [Vector2(-0.20, -0.50 + 0.34), Vector2(0.0, -0.5)]]:
							if _seg_dist(p, seg[0], seg[1]) < lw:
								ex = 1.0
				2:  # قلب
					var hx := px * 1.95
					var hy := -py * 1.95 + 0.15
					var f := pow(hx * hx + hy * hy - 1.0, 3.0) - hx * hx * pow(hy, 3.0)
					inside = f <= 0.0
					var d := Vector2(px + 0.32, py + 0.22).length()
					sh = clampf(0.98 - d * 0.65, 0.35, 0.98)
					if absf(px) < lw * 0.9 and py < -0.12 and py > -0.4:
						ex = 1.0
				_:  # خورشید: قرص + ۱۲ پرتو
					inside = r < 0.4 or _in_poly(Vector2(px, py), sun)
					var kk2 := fposmod(a + TAU / 24.0, TAU / 12.0) / (TAU / 12.0)
					if r < 0.4:
						sh = clampf(0.92 - r * 0.9, 0.3, 0.92)
						if absf(r - 0.27) < lw:
							ex = 1.0
					else:
						sh = 0.3 if kk2 < 0.5 else 0.75
			mask[i] = 1 if inside else 0
			shade[i] = clampf((sh - 0.5) * k + 0.5, 0.0, 1.0)
			extra[i] = ex
	# لبه: دو بار فرسایش
	var e1 := _erode(mask, n)
	var e2 := _erode(e1, n)
	var period := lerpf(9.0, 3.0, density) * float(n) / 192.0
	var ink := PackedFloat32Array()
	ink.resize(n * n)
	for y in n:
		for x in n:
			var i := y * n + x
			var v := 0.0
			var px := (float(x) + 0.5 - half) / half
			var py := (float(y) + 0.5 - half) / half
			var r := sqrt(px * px + py * py)
			if mask[i] == 1:
				v = _hatch(x, y, shade[i], period)
				if e2[i] == 0:
					v = 1.0
				v = maxf(v, extra[i])
			if absf(r - 0.78) < 0.016:
				v = 1.0
			ink[i] = v
	return ink


func _erode(m: PackedByteArray, n: int) -> PackedByteArray:
	var o := PackedByteArray()
	o.resize(n * n)
	for y in range(1, n - 1):
		for x in range(1, n - 1):
			var i := y * n + x
			if m[i] == 1 and m[i - 1] == 1 and m[i + 1] == 1 and m[i - n] == 1 and m[i + n] == 1:
				o[i] = 1
	return o


## هاشور موجی؛ تیره‌تر ← خط ضخیم‌تر، خیلی تیره ← هاشور متقاطع
func _hatch(x: int, y: int, gv: float, period: float) -> float:
	var phase := fposmod(float(y) / period + 0.8 * sin(float(x) * 0.05) + 0.4 * sin(float(x + y) * 0.021), 1.0)
	var d := absf(phase - 0.5) * 2.0
	var t := clampf((1.0 - gv) * 1.2, 0.0, 1.0)
	var line := clampf((t - d) * 3.0, 0.0, 1.0)
	if gv < 0.3:
		var p2 := fposmod(float(x + y) / (period * 1.2), 1.0)
		var d2 := absf(p2 - 0.5) * 2.0
		line = maxf(line, clampf(((0.3 - gv) * 2.6 - d2) * 3.0, 0.0, 1.0))
	return line


## عکس → حکاکی خطی: هاشور موجی با ضخامت متناسب با تیرگی + خط دور اشکال
func _engrave(img: Image, n: int, density: float, contrast: float) -> PackedFloat32Array:
	var g := PackedFloat32Array()
	g.resize(n * n)
	var hist := PackedInt32Array()
	hist.resize(64)
	var subj := PackedByteArray()
	subj.resize(n * n)
	var subj_count := 0
	for y in n:
		for x in n:
			var c := img.get_pixel(x, y)
			var lum := 0.299 * c.r + 0.587 * c.g + 0.114 * c.b
			if c.a < 0.5:
				lum = 1.0
				subj[y * n + x] = 0
			else:
				subj[y * n + x] = 1
				hist[clampi(int(lum * 63.0), 0, 63)] += 1
				subj_count += 1
			g[y * n + x] = lum
	var total := maxi(subj_count, 1)
	var acc := 0
	var lo := 0.0
	var hi := 1.0
	var got_lo := false
	for i in 64:
		acc += hist[i]
		if not got_lo and acc >= int(total * 0.04):
			lo = float(i) / 63.0
			got_lo = true
		if acc >= int(total * 0.96):
			hi = float(i) / 63.0
			break
	if hi - lo < 0.15:
		lo = maxf(0.0, lo - 0.1)
		hi = minf(1.0, hi + 0.1)
	var k := lerpf(0.55, 2.0, contrast)
	for i in n * n:
		var v := clampf((g[i] - lo) / (hi - lo), 0.0, 1.0)
		g[i] = clampf((v - 0.5) * k + 0.5, 0.0, 1.0)
	var ink := PackedFloat32Array()
	ink.resize(n * n)
	var period := lerpf(9.0, 3.0, density) * float(n) / 192.0
	for y in n:
		for x in n:
			var i := y * n + x
			var line := _hatch(x, y, g[i], period)
			var edge := 0.0
			if x > 0 and y > 0 and x < n - 1 and y < n - 1:
				var gx := g[i + 1] - g[i - 1]
				var gy := g[i + n] - g[i - n]
				edge = clampf((sqrt(gx * gx + gy * gy) - 0.22) * 3.5, 0.0, 1.0)
			if subj[i] == 0:
				line = 0.0
				edge = 0.0
				# حاشیه‌ی بیرونی سوژه (۱ پیکسل بیرون‌تر) خط کناره را می‌سازد
				if x > 0 and y > 0 and x < n - 1 and y < n - 1 and (subj[i - 1] + subj[i + 1] + subj[i - n] + subj[i + n]) > 0:
					edge = 1.0
			elif x > 0 and y > 0 and x < n - 1 and y < n - 1 and (subj[i - 1] == 0 or subj[i + 1] == 0 or subj[i - n] == 0 or subj[i + n] == 0):
				edge = 1.0
			ink[i] = maxf(line, edge * 0.95)
	return ink


## طرح را روی صورت سکه (طلا، لبه‌ی برجسته، دندانه‌ها) می‌نشاند → [آلبیدو، نرمال‌مپ]
func _compose(ink: PackedFloat32Array, color_img: Image, n: int) -> Array:
	var albedo := Image.create(n, n, false, Image.FORMAT_RGBA8)
	var height := PackedFloat32Array()
	height.resize(n * n)
	var half := float(n) * 0.5
	var gold_hi := Color(1.0, 0.88, 0.45)
	var gold_lo := Color(0.82, 0.58, 0.14)
	var ink_col := Color(0.04, 0.03, 0.02)
	for y in n:
		for x in n:
			var px := (float(x) + 0.5 - half) / half
			var py := (float(y) + 0.5 - half) / half
			var r := sqrt(px * px + py * py)
			var i := y * n + x
			if r > 0.99:
				albedo.set_pixel(x, y, Color(0, 0, 0, 0))
				height[i] = 0.0
				continue
			var noise := 1.0 + (float(((x * 73856093) ^ (y * 19349663)) & 255) / 255.0 - 0.5) * 0.05
			var base := gold_hi.lerp(gold_lo, clampf(r * 0.9 + 0.1 * py, 0.0, 1.0))
			var h := 0.5
			var col := base
			if r > 0.88:
				# لبه‌ی برجسته با دندانه‌های ریز
				var ang := atan2(py, px)
				var bead := 0.5 + 0.5 * sin(ang * 64.0)
				col = base.lerp(gold_hi, 0.35)
				if r > 0.905 and r < 0.965:
					col = col.darkened(0.14 * (1.0 - bead))
					h = 0.9 + 0.1 * bead
				else:
					h = 1.0
				if r > 0.972:
					col = col.darkened(0.3)
			else:
				col = base.darkened(0.06)
				var m := 1.0
				if r > 0.8:
					m = clampf((0.86 - r) / 0.06, 0.0, 1.0)
				var iv := ink[i] * m
				if color_img != null:
					var pc := color_img.get_pixel(x, y)
					if pc.a < 0.5:
						pc = col
					var pcol := Color(pc.r, pc.g, pc.b).lerp(gold_hi, 0.12)
					col = col.lerp(pcol, m)
					h = 0.5 - 0.2 * (1.0 - (pc.r + pc.g + pc.b) / 3.0) * m
				else:
					col = col.lerp(ink_col, iv * 0.97)
					h = 0.5 - iv * 0.3
			col = Color(clampf(col.r * noise, 0, 1), clampf(col.g * noise, 0, 1), clampf(col.b * noise, 0, 1), 1.0)
			albedo.set_pixel(x, y, col)
			height[i] = h
	var normal := Image.create(n, n, false, Image.FORMAT_RGBA8)
	var k := 3.0
	for y in n:
		for x in n:
			var x0 := maxi(x - 1, 0)
			var x1 := mini(x + 1, n - 1)
			var y0 := maxi(y - 1, 0)
			var y1 := mini(y + 1, n - 1)
			var dx := (height[y * n + x1] - height[y * n + x0]) * k
			var dy := (height[y1 * n + x] - height[y0 * n + x]) * k
			var nv := Vector3(-dx, dy, 1.0).normalized()
			normal.set_pixel(x, y, Color(nv.x * 0.5 + 0.5, nv.y * 0.5 + 0.5, nv.z * 0.5 + 0.5, 1.0))
	return [albedo, normal]
