extends VBoxContainer
## پیش‌نمایش قفل‌شده‌ی هر آیتم فروشگاه، روی خودِ کاراکتر:
##  • مدل (glb…): نمایشگر سه‌بعدی چرخان           • صدا: کاراکتر می‌پرد و همان لحظه صدا پخش می‌شود
##  • آهنگ پس‌زمینه: کاراکتر ایستاده + پخش         • انیمیشن: همان حرکت روی کاراکتر اجرا می‌شود
##  • بقیه‌ی فایل‌ها: اطلاعات فایل (قابل نمایش نیست)
## قفل بودن یعنی: نصب و انتخاب فقط بعد از خرید. فایل پیش‌نمایش نسخه‌ی عمومی است (payload.pv).
const GlbModel := preload("res://scripts/glb_model.gd")
const CharacterModel := preload("res://scripts/character_model.gd")
const SkinLibRef := preload("res://scripts/skin_lib.gd")
const MAX_PLAY := 25.0
const STAND_IN := "res://samples/sample_rigged.glb"

var ui
var _key := ""
var it: Dictionary = {}
var _audio: AudioStreamPlayer
var _note: Label
var _stage: Control
var _model                          # GlbModel یا CharacterModel
var _local := ""
var _kind := ""
var _payload: Dictionary = {}
var _loop_t: Timer
var _tricks: Array = []
var _trick_i := 0
var _stand_in := false


func setup(owner_ui, item: Dictionary) -> void:
	ui = owner_ui
	_key = "ipv%d" % get_instance_id()
	it = item
	_kind = String(it.kind)
	var p = it.get("payload", {})
	_payload = p if p is Dictionary else {}
	add_theme_constant_override("separation", 8)
	custom_minimum_size = Vector2(580, 0)
	tree_exiting.connect(_cleanup)
	_build.call_deferred()


func _cleanup() -> void:
	if ui != null and ui._pv.has(_key):
		ui._pv.erase(_key)
	if _audio != null and is_instance_valid(_audio):
		_audio.stop()
	Music.hold = false


func _say(t: String) -> void:
	if _note != null and is_instance_valid(_note):
		_note.text = t


func _lbl(t: String, size: int = 22, color: Color = Color("c9d6e6")) -> Label:
	var l: Label = ui._label(t, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(10, 0)
	return l


## کاراکتری که پیش‌نمایش روی آن اجرا می‌شود: کاراکتر مربوط به آیتم، وگرنه کاراکتر فعلی
func _target_entry() -> Dictionary:
	var key := String(_payload.get("char", ""))
	if key != "":
		for e: Dictionary in Skins.entries:
			if Skins.char_key(e) == key:
				return e
	return Skins.current_entry()


func _build() -> void:
	_note = _lbl("", 22, Color("ffd27a"))
	var state := Online.item_state(it)
	var locked := state != "owned"
	var needs_rig := _kind in ["anim_clip", "anim", "chaser_anim"]
	var is_model := _kind in ["glb", "police"]
	var plain_kinds := ["voice", "chaser_voice", "music"]
	var mode := ""             # برای بخش‌های دیگر: نوع نمایش بر اساس خودِ فایل
	if not (is_model or needs_rig or _kind in plain_kinds or _kind in ["skin", "coin"]):
		_say("در حال دریافت پیش‌نمایش…")
		var lp := await Online.preview_file(it)
		if not is_instance_valid(self):
			return
		mode = _mode_of_file(lp)
		if mode == "model":
			is_model = true
		elif mode == "audio":
			plain_kinds = ["music"]
			_kind = "music"
	if _kind in ["skin", "coin"] or (mode != "" and mode != "model" and mode != "audio"):
		await _build_other(locked, mode)
		return
	_say("در حال دریافت پیش‌نمایش…")
	_local = await Online.preview_file(it)
	if not is_instance_valid(self):
		return
	var holder: Control
	var entry := _target_entry()
	if is_model and _local != "":
		var gm := GlbModel.new()
		holder = ui._make_preview(_key, 400, gm, false)
		add_child(holder)
		ui.preview_toolbar(_key)
		if not gm.load_from_file(_local, int(it.get("glb_yaw", 0))):
			_say("مدل بارگذاری نشد: " + gm.load_error)
		_model = gm
		_say("")
	elif is_model:
		add_child(_lbl("برای این مدل نسخه‌ی پیش‌نمایش ثبت نشده؛ فقط عکس نمایش داده می‌شود.", 22))
		return
	else:
		var content: Node3D = CharacterModel.new()
		var use := entry
		if needs_rig and not Skins.is_glb(entry):
			use = {"id": "standin", "glb": STAND_IN, "glb_yaw": 0, "glb_cfg": GlbModel.DEFAULT_CFG.duplicate(true), "name": "نمونه"}
			_stand_in = true
		holder = ui._make_preview(_key, 400, content, false)
		add_child(holder)
		ui.preview_toolbar(_key)
		ui._sync_preview_model(_key, use)
		_model = ui._pv[_key]["content"]
	_stage = holder
	if locked:
		var lk: Label = ui._label("قفل  •  پیش‌نمایش", 24, Color("ffd24a"))
		lk.position = Vector2(10, 6)
		lk.set_meta(ui.FIT_META, true)
		lk.autowrap_mode = TextServer.AUTOWRAP_OFF
		holder.add_child(lk)
	add_child(_note)
	_say("")
	match _kind:
		"voice", "chaser_voice": _controls_voice()
		"music": _controls_music()
		"anim_clip", "anim", "chaser_anim": _controls_anim()
	if _stand_in:
		add_child(_lbl("کاراکتر فعلی مدل بلوکی است؛ انیمیشن روی مدل نمونه نشان داده می‌شود.", 20))
	Content.apply_tree.call_deferred(self)


# ------------------------- اسکین، سکه و هر بخش دیگر -------------------------
func _mode_of_file(path: String) -> String:
	if path == "":
		return "card"
	var ext := path.get_extension().to_lower()
	if ext in ["png", "jpg", "jpeg", "webp", "bmp", "svg", "tga"]:
		return "image"
	if ext in ["wav", "mp3", "ogg", "flac", "m4a", "aac"]:
		return "audio"
	if ModelImport.is_model(path) and ext != "zip":
		return "model"
	if ext in ["txt", "json", "md", "csv", "cfg"]:
		return "text"
	return "info"


func _texture_for_preview() -> Texture2D:
	var path := _local
	if path != "" and _mode_of_file(path) == "image":
		var img := Image.new()
		if img.load(path) == OK:
			return ImageTexture.create_from_image(img)
	return await Online.preview(it)


func _lock_badge(holder: Control, locked: bool) -> void:
	if locked:
		var lk: Label = ui._label("قفل  •  پیش‌نمایش", 24, Color("ffd24a"))
		lk.position = Vector2(10, 6)
		lk.set_meta(ui.FIT_META, true)
		lk.autowrap_mode = TextServer.AUTOWRAP_OFF
		holder.add_child(lk)


func _build_other(locked: bool, mode: String) -> void:
	_say("در حال دریافت پیش‌نمایش…")
	_local = await Online.preview_file(it)
	if not is_instance_valid(self):
		return
	if mode == "":
		mode = _kind
	var tex: Texture2D = null
	if mode in ["skin", "coin", "image", "card"]:
		tex = await _texture_for_preview()
		if not is_instance_valid(self):
			return
	var holder: Control = null
	match mode:
		"skin":
			if tex != null:
				var cm := CharacterModel.new()
				holder = ui._make_preview(_key, 420, cm, false)
				add_child(holder)
				ui.preview_toolbar(_key)
				var slim := false
				var im := tex.get_image()
				if im != null:
					slim = SkinLibRef.detect_slim(im)
				ui._pv[_key]["content"].set_skin(tex, slim, false)
				_model = ui._pv[_key]["content"]
				_lbl_hint("با انگشت بچرخانش؛ نصب و انتخاب بعد از خرید.")
		"coin":
			if tex != null:
				var cimg := tex.get_image()
				holder = ui._make_preview(_key, 380, CoinSkin.make_coin_for_image(cimg) if cimg != null else _make_coin(tex), true)
				add_child(holder)
				ui.preview_toolbar(_key)
				_lbl_hint("سکه می‌چرخد؛ بعد از خرید روی همه‌ی سکه‌های بازی اعمال می‌شود.")
		"image", "card":
			if tex != null:
				holder = Control.new()
				holder.custom_minimum_size = Vector2(0, 380)
				var tr := TextureRect.new()
				tr.texture = tex
				tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
				tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
				ui._add_full(holder, tr)
				add_child(holder)
		"text":
			var txt := FileAccess.get_file_as_string(_local).substr(0, 600)
			var tl := _lbl(txt if txt != "" else "فایل متنی خالی است.", 20)
			holder = PanelContainer.new()
			holder.add_child(tl)
			add_child(holder)
		"info":
			var sz := 0
			if _local != "":
				var f := FileAccess.open(_local, FileAccess.READ)
				if f != null:
					sz = f.get_length()
			add_child(_lbl("فایل «%s» (%s) — نوع فایل برای نمایش مستقیم شناخته‌شده نیست.%s" % [_local.get_file(), String.humanize_size(sz), "" if _local != "" else " برای آن پیش‌نمایشی ثبت نشده."], 22))
	if holder == null:
		add_child(_lbl("برای این آیتم پیش‌نمایش (عکس یا نسخه‌ی کوتاه) ثبت نشده؛ بعد از خرید نصب می‌شود.", 22))
	else:
		_lock_badge(holder, locked)
	_say("")
	Content.apply_tree.call_deferred(self)


func _lbl_hint(t: String) -> void:
	add_child(_lbl(t, 20))


func _make_coin(tex: Texture2D) -> Node3D:
	var root := Node3D.new()
	var r := 0.5
	var th := 0.09
	var rim := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = r
	cyl.bottom_radius = r
	cyl.height = th
	rim.mesh = cyl
	var rm := StandardMaterial3D.new()
	rm.albedo_color = Color("d9a520")
	rm.metallic = 0.6
	rm.roughness = 0.35
	rim.material_override = rm
	rim.rotation_degrees = Vector3(90, 0, 0)
	root.add_child(rim)
	for side in 2:
		var q := MeshInstance3D.new()
		var qm := CylinderMesh.new()          # قرص نازک: درپوش گرد، عکس دایره‌ای می‌افتد
		qm.top_radius = r * 0.97
		qm.bottom_radius = r * 0.97
		qm.height = 0.004
		q.mesh = qm
		var m := StandardMaterial3D.new()
		m.albedo_texture = tex
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		q.material_override = m
		q.position = Vector3(0, 0, (th * 0.5 + 0.003) * (1 if side == 0 else -1))
		q.rotation_degrees = Vector3(90 if side == 0 else -90, 0, 0)
		root.add_child(q)
	return root


# ------------------------- صدا -------------------------
func _stream() -> AudioStream:
	if _local == "":
		return null
	return Rules.stream_from_path(_local)


func _play_audio(loop: bool) -> bool:
	var st := _stream()
	if st == null:
		_say("برای این آیتم فایل پیش‌نمایش صوتی ثبت نشده یا خوانده نشد.")
		return false
	if _audio == null:
		_audio = AudioStreamPlayer.new()
		add_child(_audio)
	if loop and st.has_method("set_loop"):
		st.set_loop(true)
	elif loop and "loop" in st:
		st.set("loop", true)
	Music.hold = true
	_audio.stream = st
	_audio.volume_db = linear_to_db(maxf(float(Game.vol.get("master", 1.0)) * float(Game.vol.get("sfx", 1.0)), 0.3))
	_audio.play()
	get_tree().create_timer(MAX_PLAY).timeout.connect(func():
		if is_instance_valid(_audio) and _audio.playing:
			_audio.stop())
	return true


func _controls_voice() -> void:
	var ev := String(_payload.get("event", ""))
	var act := _action_for(ev)
	add_child(ui._button("پخش صدا روی کاراکتر (%s)" % _action_title(act), func(): _play_voice(act), Vector2(0, 72), 26, "Teal"))
	add_child(_lbl("کاراکتر در لحظه‌ی «%s» این صدا را می‌دهد؛ فقط تا %d ثانیه پخش می‌شود." % [_action_title(act), int(MAX_PLAY)], 20))


func _action_for(ev: String) -> String:
	match ev:
		"slide": return "slide"
		"hit", "crash", "gameover": return "hit"
		"coin", "score": return "bounce"
		_: return "jump"


func _action_title(a: String) -> String:
	return {"jump": "پرش", "slide": "سُرخوردن", "hit": "برخورد", "bounce": "جمع کردن سکه"}.get(a, a)


func _play_voice(act: String) -> void:
	if not _play_audio(false):
		return
	_do_action(act)


# ------------------------- آهنگ -------------------------
func _controls_music() -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	add_child(row)
	row.add_child(ui._button("پخش آهنگ", func(): _play_audio(true), Vector2(0, 72), 26, "Teal"))
	row.get_child(0).size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(ui._button("توقف", func(): if _audio != null: _audio.stop(); Music.hold = false, Vector2(150, 72), 26, "Dark"))
	add_child(_lbl("کاراکتر ایستاده است و آهنگ پخش می‌شود (فقط تا %d ثانیه)." % int(MAX_PLAY), 20))


# ------------------------- انیمیشن -------------------------
func _controls_anim() -> void:
	_tricks.clear()
	var clip := String(_payload.get("clip", ""))
	if _kind == "anim_clip":
		if bool(_payload.get("pack", false)):
			var pk := AnimPack.parse(FileAccess.get_file_as_string(_local)) if _local != "" else {}
			if pk.is_empty():
				_say("برای این انیمیشن فایل پیش‌نمایش ثبت نشده یا خراب است.")
				return
			AnimPack.save("pv_" + String(it.id), pk)
			_tricks.append("clip:pack:pv_" + String(it.id))
		elif clip != "":
			_tricks.append("clip:" + clip)
	else:
		var pack := Rules.parse_pack(FileAccess.get_file_as_string(_local)) if _local != "" else []
		for r in pack:
			if r is Dictionary and String(r.get("action", "")) == "anim" and String(r.get("arg", "")) != "":
				_tricks.append(String(r.arg))
	if _tricks.is_empty():
		_say("حرکتی برای نمایش پیدا نشد.")
		return
	add_child(ui._button("نمایش حرکت روی کاراکتر", func(): _next_trick(), Vector2(0, 72), 26, "Teal"))
	_loop_t = Timer.new()
	_loop_t.wait_time = 3.2
	_loop_t.autostart = true
	_loop_t.timeout.connect(_next_trick)
	add_child(_loop_t)
	_next_trick.call_deferred()


func _next_trick() -> void:
	if _tricks.is_empty() or _model == null:
		return
	_do_action(String(_tricks[_trick_i % _tricks.size()]), 2.6)
	_trick_i += 1


## یک حرکت را روی مدل پیش‌نمایش اجرا می‌کند (حالت‌های ساده‌ی بلوکی یا کلیپ مدل GLB)
func _do_action(act: String, dur: float = 1.0) -> void:
	var pv: Node3D = ui._pv[_key]["pivot"] if ui._pv.has(_key) else null
	play_action(self, _model, pv, act, dur)


## یک حرکت را روی هر مدل پیش‌نمایش اجرا می‌کند (host برای تایمر و Tween؛ در فروشگاه هم استفاده می‌شود)
static func play_action(host: Node, model, pivot: Node3D, act: String, dur: float = 1.0) -> void:
	if model == null or not is_instance_valid(model):
		return
	if act.begins_with("clip:"):
		if model.has_method("play_clip_once"):
			model.play_clip_once(act.substr(5), dur)
		return
	if model.get("is_glb") == true and act in ["jump", "slide", "hit"]:
		model.preview_state = act
		host.get_tree().create_timer(dur + 0.4).timeout.connect(func():
			if is_instance_valid(model):
				model.preview_state = "")
		return
	if pivot == null:
		return
	var tw := host.create_tween()
	match act:
		"jump":
			tw.tween_property(pivot, "position:y", 0.8, 0.32).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
			tw.tween_property(pivot, "position:y", 0.0, 0.32).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
		"bounce":
			for i in 2:
				tw.tween_property(pivot, "position:y", 0.35, 0.16)
				tw.tween_property(pivot, "position:y", 0.0, 0.16)
		"slide", "crouch":
			tw.tween_property(pivot, "scale:y", 0.6, 0.2)
			tw.tween_interval(0.5)
			tw.tween_property(pivot, "scale:y", 1.0, 0.2)
		"hit", "shake":
			for i in 3:
				tw.tween_property(pivot, "position:x", 0.12, 0.05)
				tw.tween_property(pivot, "position:x", -0.12, 0.05)
			tw.tween_property(pivot, "position:x", 0.0, 0.05)
		"spin":
			tw.tween_property(pivot, "rotation:y", pivot.rotation.y + TAU, 0.9)
		"flip":
			tw.tween_property(pivot, "rotation:x", -TAU, 0.9)
			tw.tween_property(pivot, "rotation:x", 0.0, 0.0)
		"wave":
			for i in 3:
				tw.tween_property(pivot, "rotation:z", 0.3, 0.15)
				tw.tween_property(pivot, "rotation:z", -0.3, 0.15)
			tw.tween_property(pivot, "rotation:z", 0.0, 0.1)
