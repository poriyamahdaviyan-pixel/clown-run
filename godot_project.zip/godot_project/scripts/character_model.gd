extends Node3D
## مدل بلوکی دقیقاً هم‌ابعاد ماینکرفت (سر ۸، تنه ۸×۱۲×۴، دست و پا ۴×۱۲×۴ پیکسل) با UV استاندارد اسکین.
## لایه‌ی اول مات است و لایه‌ی دوم (کلاه/ژاکت/آستین/شلوار) کمی بزرگ‌تر و با شفافیت رسم می‌شود.
## جلوی کاراکتر = محور منفی Z ، سمت راست کاراکتر = محور مثبت X.

const SkinLib := preload("res://scripts/skin_lib.gd")

const PX := 0.0594   # هر پیکسل اسکین = ۵.۹۴ سانتی‌متر → قد ۳۲ پیکسل = ۱.۹ متر

var head: Node3D
var body: Node3D
var arms: Array[Node3D] = []   # [0] راست کاراکتر (+X) ، [1] چپ (-X)
var legs: Array[Node3D] = []   # [0] راست ، [1] چپ

var _tex: Texture2D
var _slim := false
var _smooth := false
var _mat_base: StandardMaterial3D
var _mat_over: StandardMaterial3D


func set_skin(tex: Texture2D, slim: bool, smooth: bool) -> void:
	_tex = tex
	_slim = slim
	_smooth = smooth
	_rebuild()


## حالت ایستاده‌ی ملایم (برای پیش‌نمایش)
func pose_idle(t: float) -> void:
	if arms.size() < 2:
		return
	var s := sin(t * 1.8) * 0.08
	arms[0].rotation.x = s
	arms[1].rotation.x = -s
	legs[0].rotation.x = 0.0
	legs[1].rotation.x = 0.0
	head.rotation.y = sin(t * 0.9) * 0.18


func _rebuild() -> void:
	for c in get_children():
		remove_child(c)
		c.queue_free()
	arms.clear()
	legs.clear()
	_make_materials()

	head = _pivot(Vector3(0.0, 24.0 * PX, 0.0))
	_add_box(head, SkinLib.HEAD, 0.0, Vector3(0.0, 4.0 * PX, 0.0), false)
	_add_box(head, SkinLib.HAT, 0.5, Vector3(0.0, 4.0 * PX, 0.0), true)

	body = _pivot(Vector3(0.0, 18.0 * PX, 0.0))
	_add_box(body, SkinLib.BODY, 0.0, Vector3.ZERO, false)
	_add_box(body, SkinLib.JACKET, 0.25, Vector3.ZERO, true)

	var aw := 3.0 if _slim else 4.0
	var ax := (4.0 + aw * 0.5) * PX
	var ra := _pivot(Vector3(ax, 22.0 * PX, 0.0))
	_add_box(ra, SkinLib.arm_box(SkinLib.R_ARM, _slim), 0.0, Vector3(0.0, -4.0 * PX, 0.0), false)
	_add_box(ra, SkinLib.arm_box(SkinLib.R_SLEEVE, _slim), 0.25, Vector3(0.0, -4.0 * PX, 0.0), true)
	var la := _pivot(Vector3(-ax, 22.0 * PX, 0.0))
	_add_box(la, SkinLib.arm_box(SkinLib.L_ARM, _slim), 0.0, Vector3(0.0, -4.0 * PX, 0.0), false)
	_add_box(la, SkinLib.arm_box(SkinLib.L_SLEEVE, _slim), 0.25, Vector3(0.0, -4.0 * PX, 0.0), true)
	arms.append(ra)
	arms.append(la)

	var rl := _pivot(Vector3(2.0 * PX, 12.0 * PX, 0.0))
	_add_box(rl, SkinLib.R_LEG, 0.0, Vector3(0.0, -6.0 * PX, 0.0), false)
	_add_box(rl, SkinLib.R_PANTS, 0.25, Vector3(0.0, -6.0 * PX, 0.0), true)
	var ll := _pivot(Vector3(-2.0 * PX, 12.0 * PX, 0.0))
	_add_box(ll, SkinLib.L_LEG, 0.0, Vector3(0.0, -6.0 * PX, 0.0), false)
	_add_box(ll, SkinLib.L_PANTS, 0.25, Vector3(0.0, -6.0 * PX, 0.0), true)
	_add_shoe(rl)
	_add_shoe(ll)
	legs.append(rl)
	legs.append(ll)


## کفش واقعی: پنجه‌ی جلوتر از ساق، پاشنه و زیره‌ی تیره تا پا «ناقص» دیده نشود
func _add_shoe(leg: Node3D) -> void:
	var col := Color("2b2b33")
	if _tex != null:
		var img := _tex.get_image()
		if img != null:
			var sc := maxi(1, img.get_width() / 64)
			var r := SkinLib.face_rect(SkinLib.R_LEG, SkinLib.Face.FRONT)
			var c := img.get_pixel(clampi((r.position.x + r.size.x / 2) * sc, 0, img.get_width() - 1), clampi((r.position.y + r.size.y - 1) * sc, 0, img.get_height() - 1))
			if c.a > 0.5:
				col = c.darkened(0.45)
	var shoe := StandardMaterial3D.new()
	shoe.albedo_color = col
	shoe.roughness = 0.8
	var sole := StandardMaterial3D.new()
	sole.albedo_color = Color("ececec")
	sole.roughness = 0.9
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(4.6 * PX, 2.6 * PX, 7.2 * PX)
	bm.material = shoe
	body.mesh = bm
	body.position = Vector3(0.0, -10.7 * PX, -1.4 * PX)
	leg.add_child(body)
	var sl := MeshInstance3D.new()
	var sm := BoxMesh.new()
	sm.size = Vector3(4.8 * PX, 0.8 * PX, 7.4 * PX)
	sm.material = sole
	sl.mesh = sm
	sl.position = Vector3(0.0, -12.0 * PX + 0.4 * PX, -1.4 * PX)
	leg.add_child(sl)


func _make_materials() -> void:
	_mat_base = StandardMaterial3D.new()
	_mat_base.albedo_texture = _tex
	_mat_base.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS if _smooth else BaseMaterial3D.TEXTURE_FILTER_NEAREST
	_mat_base.roughness = 1.0
	_mat_base.metallic_specular = 0.15
	# کمی خودروشنی تا کاراکتر در سایه گم نشود
	_mat_base.emission_enabled = true
	_mat_base.emission_operator = BaseMaterial3D.EMISSION_OP_MULTIPLY  # پیش‌فرض ADD است و رنگ‌ها را سفید می‌کند
	_mat_base.emission = Color(0.1, 0.1, 0.1)
	_mat_base.emission_texture = _tex
	_mat_over = _mat_base.duplicate() as StandardMaterial3D
	_mat_over.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	_mat_over.alpha_scissor_threshold = 0.5


func _pivot(pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	add_child(n)
	return n


func _add_box(parent: Node3D, box: Array, inflate: float, offset: Vector3, overlay: bool) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = _box_mesh(box, inflate)
	mi.material_override = _mat_over if overlay else _mat_base
	mi.position = offset
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)


func _box_mesh(box: Array, inflate: float) -> ArrayMesh:
	var hx := (float(box[2]) * 0.5 + inflate) * PX
	var hy := (float(box[3]) * 0.5 + inflate) * PX
	var hz := (float(box[4]) * 0.5 + inflate) * PX
	var F := SkinLib.Face
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	# گوشه‌ها به ترتیب: بالا-چپ، بالا-راست، پایین-راست، پایین-چپ (از دید ناظر بیرونی)
	_quad(st, [Vector3(hx, hy, -hz), Vector3(-hx, hy, -hz), Vector3(-hx, -hy, -hz), Vector3(hx, -hy, -hz)], Vector3(0, 0, -1), SkinLib.face_rect(box, F.FRONT), false)
	_quad(st, [Vector3(-hx, hy, hz), Vector3(hx, hy, hz), Vector3(hx, -hy, hz), Vector3(-hx, -hy, hz)], Vector3(0, 0, 1), SkinLib.face_rect(box, F.BACK), false)
	_quad(st, [Vector3(hx, hy, hz), Vector3(hx, hy, -hz), Vector3(hx, -hy, -hz), Vector3(hx, -hy, hz)], Vector3(1, 0, 0), SkinLib.face_rect(box, F.RIGHT), false)
	_quad(st, [Vector3(-hx, hy, -hz), Vector3(-hx, hy, hz), Vector3(-hx, -hy, hz), Vector3(-hx, -hy, -hz)], Vector3(-1, 0, 0), SkinLib.face_rect(box, F.LEFT), false)
	_quad(st, [Vector3(hx, hy, hz), Vector3(-hx, hy, hz), Vector3(-hx, hy, -hz), Vector3(hx, hy, -hz)], Vector3(0, 1, 0), SkinLib.face_rect(box, F.TOP), false)
	_quad(st, [Vector3(-hx, -hy, hz), Vector3(hx, -hy, hz), Vector3(hx, -hy, -hz), Vector3(-hx, -hy, -hz)], Vector3(0, -1, 0), SkinLib.face_rect(box, F.BOTTOM), true)
	return st.commit()


func _quad(st: SurfaceTool, c: Array, n: Vector3, r: Rect2i, mirror_u: bool) -> void:
	var u0 := float(r.position.x) / 64.0
	var v0 := float(r.position.y) / 64.0
	var u1 := float(r.end.x) / 64.0
	var v1 := float(r.end.y) / 64.0
	var uv: Array
	if mirror_u:
		uv = [Vector2(u1, v0), Vector2(u0, v0), Vector2(u0, v1), Vector2(u1, v1)]
	else:
		uv = [Vector2(u0, v0), Vector2(u1, v0), Vector2(u1, v1), Vector2(u0, v1)]
	for i in [0, 1, 2, 0, 2, 3]:
		st.set_normal(n)
		st.set_uv(uv[i])
		st.add_vertex(c[i])
