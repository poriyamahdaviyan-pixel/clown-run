extends HBoxContainer
## دکمه‌های ابزارهای همراه حین بازی (پایین صفحه). با لمس، ابزار مصرف می‌شود (اول یا وسط بازی).

var ui
var _sig := ""
var _cells := {}      # id → {icon, count, bar}


func setup(owner_ui) -> void:
	ui = owner_ui
	alignment = BoxContainer.ALIGNMENT_CENTER
	add_theme_constant_override("separation", 22)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	Game.boosts_changed.connect(func(): _sig = "")


func _active_frac(id: String) -> float:
	var d := Game.boost_def(id)
	if id == "ghost":
		return Game.ghost_left / maxf(Game.ghost_total, 0.1) if Game.ghost_left > 0.0 else 0.0
	var pw := int(d.get("power", -1))
	if pw >= 0 and Game.power_left[pw] > 0.0:
		return Game.power_left[pw] / maxf(Game.power_total[pw], 0.1)
	return 0.0


func _rebuild() -> void:
	for c in get_children():
		c.queue_free()
	_cells.clear()
	for id in Game.loadout:
		var sid := String(id)
		if sid == "life":
			continue
		var d := Game.boost_def(sid)
		if d.is_empty():
			continue
		var cell := Control.new()
		cell.custom_minimum_size = Vector2(132, 150)
		cell.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(cell)
		var ic := BoostIcon.make(String(d.icon), Color(String(d.color)), 120)
		ic.position = Vector2(6, 0)
		cell.add_child(ic)
		var cnt: Label = ui._label("", 28, Color.WHITE)
		cnt.add_theme_color_override("font_outline_color", Color.BLACK)
		cnt.add_theme_constant_override("outline_size", 8)
		cnt.set_meta(ui.FIT_META, true)
		cnt.autowrap_mode = TextServer.AUTOWRAP_OFF
		cnt.position = Vector2(82, 82)
		cell.add_child(cnt)
		var bar := ProgressBar.new()
		bar.show_percentage = false
		bar.max_value = 1.0
		bar.size = Vector2(110, 10)
		bar.position = Vector2(11, 128)
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(String(d.color))
		sb.set_corner_radius_all(5)
		bar.add_theme_stylebox_override("fill", sb)
		var bg := StyleBoxFlat.new()
		bg.bg_color = Color(0, 0, 0, 0.5)
		bg.set_corner_radius_all(5)
		bar.add_theme_stylebox_override("background", bg)
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cell.add_child(bar)
		var hit := Button.new()
		hit.flat = true
		hit.focus_mode = Control.FOCUS_NONE
		hit.size = Vector2(132, 150)
		hit.pressed.connect(func():
			if not Game.use_boost(sid):
				Sfx.play("error"))
		cell.add_child(hit)
		_cells[sid] = {"icon": ic, "count": cnt, "bar": bar}


func tick() -> void:
	var sig := "%s|%s" % [str(Game.loadout), str(Game.boosts)]
	if sig != _sig:
		_sig = sig
		_rebuild()
	for id in _cells.keys():
		var c: Dictionary = _cells[id]
		var n := Game.boost_count(String(id))
		var fr := _active_frac(String(id))
		(c.count as Label).text = "×%d" % n
		(c.icon as BoostIcon).dim = n <= 0 and fr <= 0.0
		(c.icon as BoostIcon).set_pulse(fr > 0.0)
		(c.bar as ProgressBar).value = fr
		(c.bar as ProgressBar).visible = fr > 0.0
