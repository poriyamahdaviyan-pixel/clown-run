extends RefCounted
## ابزارهای اسکین به سبک ماینکرفت (همه static؛ با preload استفاده می‌شود):
##  - چیدمان استاندارد UV اسکین ۶۴×۶۴ (و HD با ضریب ۲، ۴، ۸ ...)
##  - تبدیل اسکین قدیمی ۶۴×۳۲ به ۶۴×۶۴
##  - تشخیص بازوی باریک (Alex)
##  - تبدیل «عکس معمولی» به اسکین که کل بدن را بپوشاند
##  - چند کاراکتر آماده (ساخته‌شده با کد)

enum Face { TOP, BOTTOM, RIGHT, FRONT, LEFT, BACK }

# هر جعبه: [tu, tv, عرض, ارتفاع, عمق] بر حسب پیکسل اسکین (مبدأ UV در گوشه‌ی بالا-چپ)
const HEAD := [0, 0, 8, 8, 8]
const HAT := [32, 0, 8, 8, 8]
const BODY := [16, 16, 8, 12, 4]
const JACKET := [16, 32, 8, 12, 4]
const R_ARM := [40, 16, 4, 12, 4]
const R_SLEEVE := [40, 32, 4, 12, 4]
const L_ARM := [32, 48, 4, 12, 4]
const L_SLEEVE := [48, 48, 4, 12, 4]
const R_LEG := [0, 16, 4, 12, 4]
const R_PANTS := [0, 32, 4, 12, 4]
const L_LEG := [16, 48, 4, 12, 4]
const L_PANTS := [0, 48, 4, 12, 4]

const PHOTO_SCALE := 8      # عکس‌ها به اسکین ۵۱۲×۵۱۲ تبدیل می‌شوند
const MAX_SKIN_SIDE := 1024


# ===================== چیدمان UV =====================
static func arm_box(box: Array, slim: bool) -> Array:
	return [box[0], box[1], 3 if slim else 4, box[3], box[4]]


static func face_rect(box: Array, face: int) -> Rect2i:
	var tu: int = box[0]
	var tv: int = box[1]
	var w: int = box[2]
	var h: int = box[3]
	var d: int = box[4]
	match face:
		Face.TOP:
			return Rect2i(tu + d, tv, w, d)
		Face.BOTTOM:
			return Rect2i(tu + d + w, tv, w, d)
		Face.RIGHT:
			return Rect2i(tu, tv + d, d, h)
		Face.FRONT:
			return Rect2i(tu + d, tv + d, w, h)
		Face.LEFT:
			return Rect2i(tu + d + w, tv + d, d, h)
		_:
			return Rect2i(tu + d + w + d, tv + d, w, h)


static func _sc(r: Rect2i, s: int) -> Rect2i:
	return Rect2i(r.position * s, r.size * s)


# ===================== تشخیص و تبدیل فرمت =====================
## آیا این تصویر شبیه یک اسکین ماینکرفت است؟
static func looks_like_skin(img: Image) -> bool:
	var w := img.get_width()
	var h := img.get_height()
	if w < 64 or w > MAX_SKIN_SIDE or w % 64 != 0:
		return false
	if not (w == h or w == h * 2):
		return false
	if w == 64:
		return true
	# اسکین HD: نواحی بلااستفاده‌ی چیدمان معمولاً شفاف‌اند، ولی عکس معمولی کاملاً مات است
	var s := w / 64
	var total := 0.0
	var count := 0
	for r in [Rect2i(0, 0, 8, 8), Rect2i(24, 0, 8, 8), Rect2i(56, 0, 8, 8)]:
		var rr := _sc(r, s)
		for y in range(rr.position.y, rr.end.y, maxi(1, s)):
			for x in range(rr.position.x, rr.end.x, maxi(1, s)):
				total += img.get_pixel(x, y).a
				count += 1
	return count > 0 and (total / float(count)) < 0.15


## فقط ابعاد (۶۴×۶۴ یا ۶۴×۳۲ و مضرب‌ها) — برای اسکین‌های دریافتی از اینترنت
static func looks_like_skin_dims(img: Image) -> bool:
	var w := img.get_width()
	var h := img.get_height()
	return w >= 64 and w % 64 == 0 and (w == h or w == h * 2)


static func is_legacy(img: Image) -> bool:
	return img.get_width() == img.get_height() * 2


## ابعاد را به یک اسکین معتبر (مربع یا ۲:۱، مضرب ۶۴) تبدیل می‌کند
static func normalize_dims(img: Image) -> Image:
	var w := img.get_width()
	var h := img.get_height()
	if w % 64 == 0 and w <= MAX_SKIN_SIDE and (w == h or w == h * 2):
		return img
	var s := clampi(roundi(float(maxi(w, h)) / 64.0), 1, 8)
	var out := img.duplicate() as Image
	out.resize(64 * s, 64 * s, Image.INTERPOLATE_NEAREST)
	return out


## اسکین قدیمی ۶۴×۳۲ → ۶۴×۶۴ (پای و دست چپ از آینه‌ی راست ساخته می‌شود، دقیقاً مثل خود ماینکرفت)
static func expand_legacy(img: Image) -> Image:
	var wd := img.get_width()
	var s := wd / 64
	var out := Image.create(wd, wd, false, Image.FORMAT_RGBA8)
	out.blit_rect(img, Rect2i(0, 0, wd, img.get_height()), Vector2i.ZERO)
	# [منبع x, منبع y, مقصد x, مقصد y, عرض, ارتفاع]
	var copies := [
		[4, 16, 20, 48, 4, 4], [8, 16, 24, 48, 4, 4], [0, 20, 24, 52, 4, 12],
		[4, 20, 20, 52, 4, 12], [8, 20, 16, 52, 4, 12], [12, 20, 28, 52, 4, 12],
		[44, 16, 36, 48, 4, 4], [48, 16, 40, 48, 4, 4], [40, 20, 40, 52, 4, 12],
		[44, 20, 36, 52, 4, 12], [48, 20, 32, 52, 4, 12], [52, 20, 44, 52, 4, 12],
	]
	for c in copies:
		var r := Rect2i(c[0] * s, c[1] * s, c[4] * s, c[5] * s)
		var piece := img.get_region(r)
		piece.flip_x()
		out.blit_rect(piece, Rect2i(Vector2i.ZERO, r.size), Vector2i(c[2] * s, c[3] * s))
	return out


## بازوی باریک (Alex): ستون‌های آخر پشتِ بازوی راست شفاف‌اند
static func detect_slim(img: Image) -> bool:
	var s := img.get_width() / 64
	for y in range(20 * s, 32 * s):
		for x in range(54 * s, 56 * s):
			if img.get_pixel(x, y).a > 0.02:
				return false
	return true


## خروجی: {image, slim, photo, scale}
## mode: 0 خودکار، 1 اجبار به اسکین، 2 اجبار به عکس — slim_mode: 0 خودکار، 1 کلاسیک، 2 باریک
## style (فقط برای عکس): 0 پیکسلی ۶۴×۶۴ (اسکین واقعی ماینکرفت)، 1 HD
static func process(src: Image, mode: int = 0, slim_mode: int = 0, style: int = 0) -> Dictionary:
	var img := src.duplicate() as Image
	img.convert(Image.FORMAT_RGBA8)
	var photo := false
	match mode:
		0:
			photo = not looks_like_skin(img)
		2:
			photo = true
	var out: Image
	var slim := false
	if photo:
		var built := build_from_photos({"front": img}, style)
		if built.has("error"):
			return built
		return built
	img = normalize_dims(img)
	if is_legacy(img):
		out = expand_legacy(img)
	else:
		out = img
		slim = detect_slim(out)
	match slim_mode:
		1:
			slim = false
		2:
			slim = true
	return {"image": out, "slim": slim, "photo": false, "scale": out.get_width() / 64}


# ===================== ساخت اسکین از عکس (یک یا چند زاویه) =====================
## اسلات‌ها: صورت (اختیاری، برای جزئیات چهره)، جلو، پشت، راست، چپ.
##  - «جلو» یک عکس تمام‌قد از روبه‌رو. اگر عکس بیشتر پرتره بود، به‌عنوان صورت استفاده می‌شود.
##  - «راست»: عکس نیم‌رخ که فرد رو به راست تصویر است (سمت راست بدنش دیده می‌شود)؛ «چپ» برعکس.
##  - اسلاتی که نباشد از رنگ‌های سایر عکس‌ها ساخته می‌شود (مثلاً پشت سر = رنگ مو).
##  - اگر فقط یک نیم‌رخ باشد، برای طرف دیگر آینه می‌شود.
## style 0: پیکسلی (دقیقاً یک اسکین ۶۴×۶۴ استاندارد)، style 1: HD (۵۱۲×۵۱۲)
const SLOT_NAMES := ["face", "front", "back", "right", "left"]
const STYLE_NAMES := ["پیکسلی ۶۴×۶۴", "HD"]


static func _resize_smooth(img: Image, w: int, h: int) -> Image:
	var out := img.duplicate() as Image
	var guard := 0
	while (out.get_width() > w * 2 or out.get_height() > h * 2) and guard < 12:
		out.resize(maxi(w, out.get_width() / 2), maxi(h, out.get_height() / 2), Image.INTERPOLATE_BILINEAR)
		guard += 1
	out.resize(w, h, Image.INTERPOLATE_LANCZOS)
	return out


static func _avg(img: Image, r: Rect2i, mask: Image = null) -> Color:
	var rr := r.intersection(Rect2i(Vector2i.ZERO, img.get_size()))
	var sum := Vector3.ZERO
	var n := 0.0
	for y in range(rr.position.y, rr.end.y):
		for x in range(rr.position.x, rr.end.x):
			if mask != null and mask.get_pixel(x, y).r < 0.5:
				continue
			var c := img.get_pixel(x, y)
			sum += Vector3(c.r, c.g, c.b)
			n += 1.0
	if n < 1.0:
		return Color(-1, -1, -1)
	sum /= n
	return Color(sum.x, sum.y, sum.z, 1.0)


static func _shade(c: Color, f: float) -> Color:
	return Color(clampf(c.r * f, 0.0, 1.0), clampf(c.g * f, 0.0, 1.0), clampf(c.b * f, 0.0, 1.0), 1.0)


static func _valid(c: Color) -> bool:
	return c.r >= 0.0


## فاصله‌ی دو رنگ
static func _cdist(a: Color, b: Color) -> float:
	return Vector3(a.r - b.r, a.g - b.g, a.b - b.b).length()


## حذف خودکار پس‌زمینه: از حاشیه‌ی تصویر شروع می‌کنیم و روی ناحیه‌های هم‌رنگ/تدریجی رشد می‌کنیم
## (دیوار ساده، آسمان، پرده‌ی عکاسی، پس‌زمینه‌ی شفاف). خروجی: {ok, mask (۱=سوژه), w, h, scale}
static func subject_mask(img: Image) -> Dictionary:
	var w := img.get_width()
	var h := img.get_height()
	var sc := 160.0 / float(maxi(w, h))
	var sw := maxi(8, int(w * sc))
	var sh := maxi(8, int(h * sc))
	var small := _resize_smooth(img, sw, sh)
	var total := sw * sh
	# میانگین حاشیه
	var sum := Vector3.ZERO
	var nb := 0
	var transparent := 0
	for x in sw:
		for y in [0, sh - 1]:
			var c := small.get_pixel(x, y)
			sum += Vector3(c.r, c.g, c.b)
			nb += 1
			if c.a < 0.5:
				transparent += 1
	for y in range(1, sh - 1):
		for x in [0, sw - 1]:
			var c2 := small.get_pixel(x, y)
			sum += Vector3(c2.r, c2.g, c2.b)
			nb += 1
			if c2.a < 0.5:
				transparent += 1
	sum /= float(nb)
	var mean := Color(sum.x, sum.y, sum.z)
	var bg := PackedByteArray()
	bg.resize(total)
	var stack: Array[int] = []
	for x in sw:
		for y in [0, sh - 1]:
			var c3 := small.get_pixel(x, y)
			if c3.a < 0.5 or _cdist(c3, mean) < 0.3:
				if bg[y * sw + x] == 0:
					bg[y * sw + x] = 1
					stack.append(y * sw + x)
	for y in range(1, sh - 1):
		for x in [0, sw - 1]:
			var c4 := small.get_pixel(x, y)
			if c4.a < 0.5 or _cdist(c4, mean) < 0.3:
				if bg[y * sw + x] == 0:
					bg[y * sw + x] = 1
					stack.append(y * sw + x)
	var nbrs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	var count := stack.size()
	while not stack.is_empty():
		var idx: int = stack.pop_back()
		var cx := idx % sw
		var cy := idx / sw
		var cc := small.get_pixel(cx, cy)
		for d in nbrs:
			var nx: int = cx + d.x
			var ny: int = cy + d.y
			if nx < 0 or ny < 0 or nx >= sw or ny >= sh:
				continue
			var ni := ny * sw + nx
			if bg[ni] != 0:
				continue
			var nc := small.get_pixel(nx, ny)
			if nc.a < 0.5 or (_cdist(nc, cc) < 0.07 and _cdist(nc, mean) < 0.55):
				bg[ni] = 1
				count += 1
				stack.append(ni)
	var frac := float(count) / float(total)
	if frac < 0.12 or frac > 0.97:
		return {"ok": false}
	# فرسایش یک پیکسلی سوژه (حذف هاله‌ی لبه)
	var fg := PackedByteArray()
	fg.resize(total)
	for y in sh:
		for x in sw:
			var i := y * sw + x
			if bg[i] != 0:
				continue
			var edge := false
			for d in nbrs:
				var qx: int = x + d.x
				var qy: int = y + d.y
				if qx >= 0 and qy >= 0 and qx < sw and qy < sh and bg[qy * sw + qx] != 0:
					edge = true
					break
			fg[i] = 0 if edge else 1
	return {"ok": true, "mask": fg, "w": sw, "h": sh, "scale": sc}


## حذف خودکار پس‌زمینه: تصویر RGBA با پس‌زمینه‌ی شفاف (مثل یک PNG بریده‌شده).
## اگر تصویر از قبل شفاف باشد دست‌نخورده می‌ماند. خروجی: {ok, image, native}
static func cutout(src: Image) -> Dictionary:
	var img := src.duplicate() as Image
	img.convert(Image.FORMAT_RGBA8)
	var w := img.get_width()
	var h := img.get_height()
	var transp := 0
	var samples := 0
	for y in range(0, h, maxi(1, h / 40)):
		for x in range(0, w, maxi(1, w / 40)):
			samples += 1
			if img.get_pixel(x, y).a < 0.5:
				transp += 1
	if samples > 0 and float(transp) / float(samples) > 0.03:
		return {"ok": true, "image": img, "native": true}
	var sm := subject_mask(img)
	if not sm.get("ok", false):
		return {"ok": false, "image": img, "native": false}
	var mw: int = sm["w"]
	var mh: int = sm["h"]
	var raw: PackedByteArray = sm["mask"]
	var data := PackedByteArray()
	data.resize(mw * mh)
	for i in mw * mh:
		data[i] = 255 if raw[i] != 0 else 0
	var m := Image.create_from_data(mw, mh, false, Image.FORMAT_L8, data)
	m.resize(w, h, Image.INTERPOLATE_BILINEAR)
	for y in h:
		for x in w:
			var v := m.get_pixel(x, y).r
			var a := clampf((v - 0.35) / 0.3, 0.0, 1.0)
			var c := img.get_pixel(x, y)
			img.set_pixel(x, y, Color(c.r, c.g, c.b, a * c.a))
	return {"ok": true, "image": img, "native": false}


## کادر سوژه (روی تصویر اصلی) از روی ماسک؛ ستون/ردیف‌های تقریباً خالی نادیده گرفته می‌شوند
static func _mask_bbox(sm: Dictionary, src_w: int, src_h: int) -> Rect2i:
	var sw: int = sm["w"]
	var sh: int = sm["h"]
	var mask: PackedByteArray = sm["mask"]
	var cols := PackedInt32Array()
	cols.resize(sw)
	var rows := PackedInt32Array()
	rows.resize(sh)
	for y in sh:
		for x in sw:
			if mask[y * sw + x] != 0:
				cols[x] += 1
				rows[y] += 1
	var x0 := 0
	while x0 < sw and cols[x0] < 2:
		x0 += 1
	var x1 := sw - 1
	while x1 > x0 and cols[x1] < 2:
		x1 -= 1
	var y0 := 0
	while y0 < sh and rows[y0] < 2:
		y0 += 1
	var y1 := sh - 1
	while y1 > y0 and rows[y1] < 2:
		y1 -= 1
	if x1 <= x0 or y1 <= y0:
		return Rect2i(0, 0, src_w, src_h)
	var fx := float(src_w) / float(sw)
	var fy := float(src_h) / float(sh)
	var pad_x := int(sw * 0.012) + 1
	var pad_y := int(sh * 0.012) + 1
	var rx := maxi(0, x0 - pad_x)
	var ry := maxi(0, y0 - pad_y)
	var rx1 := mini(sw, x1 + 1 + pad_x)
	var ry1 := mini(sh, y1 + 1 + pad_y)
	return Rect2i(int(rx * fx), int(ry * fy), maxi(2, int((rx1 - rx) * fx)), maxi(2, int((ry1 - ry) * fy)))


## عکس → «پوستر» ۱۶×۳۲ واحدی (+ ماسک سوژه)
static func _poster(src: Image, S: int) -> Dictionary:
	var sm := subject_mask(src)
	var crop: Rect2i
	if sm["ok"]:
		crop = _mask_bbox(sm, src.get_width(), src.get_height())
	else:
		var w := src.get_width()
		var h := src.get_height()
		var ratio := float(h) / float(w)
		if ratio > 2.2:
			var ch := int(w * 2.2)
			crop = Rect2i(0, int((h - ch) * 0.1), w, ch)
		else:
			crop = Rect2i(0, 0, w, h)
	var piece := _resize_smooth(src.get_region(crop), 16 * S, 32 * S)
	var base := Image.create(16 * S, 32 * S, false, Image.FORMAT_RGBA8)
	base.fill(Color.WHITE)
	base.blend_rect(piece, Rect2i(Vector2i.ZERO, piece.get_size()), Vector2i.ZERO)
	var mask: Image = null
	if sm["ok"]:
		mask = Image.create(16 * S, 32 * S, false, Image.FORMAT_L8)
		var sw: int = sm["w"]
		var sh: int = sm["h"]
		var sc: float = sm["scale"]
		var mk: PackedByteArray = sm["mask"]
		for y in 32 * S:
			for x in 16 * S:
				var sx := int((float(crop.position.x) + (float(x) + 0.5) / float(16 * S) * float(crop.size.x)) * sc)
				var sy := int((float(crop.position.y) + (float(y) + 0.5) / float(32 * S) * float(crop.size.y)) * sc)
				sx = clampi(sx, 0, sw - 1)
				sy = clampi(sy, 0, sh - 1)
				var v := float(mk[sy * sw + sx])
				mask.set_pixel(x, y, Color(v, v, v))
	return {"img": base, "mask": mask}


static func _flip_poster(p: Dictionary) -> Dictionary:
	var im := (p["img"] as Image).duplicate() as Image
	im.flip_x()
	var mk: Image = null
	if p["mask"] != null:
		mk = (p["mask"] as Image).duplicate() as Image
		mk.flip_x()
	return {"img": im, "mask": mk}


static func _front_rects() -> Array:
	return [Rect2i(4, 0, 8, 8), Rect2i(4, 8, 8, 12), Rect2i(0, 8, 4, 12), Rect2i(12, 8, 4, 12), Rect2i(4, 20, 4, 12), Rect2i(8, 20, 4, 12)]


static func _mirror_rect(r: Rect2i) -> Rect2i:
	return Rect2i(16 - r.position.x - r.size.x, r.position.y, r.size.x, r.size.y)


## پیکسل‌های پس‌زمینه را با میانگین رنگ همان قطعه پر می‌کند (تا سفیدیِ دور بدن نماند)
static func _clean(p: Dictionary, rects: Array, S: int) -> void:
	if p.is_empty() or p["mask"] == null:
		return
	var im: Image = p["img"]
	var mk: Image = p["mask"]
	var global := _avg(im, Rect2i(0, 0, im.get_width(), im.get_height()), mk)
	for r in rects:
		var rr := _sc(r, S)
		var avg := _avg(im, rr, mk)
		if not _valid(avg):
			avg = global if _valid(global) else Color("8a8a8a")
		for y in range(rr.position.y, rr.end.y):
			for x in range(rr.position.x, rr.end.x):
				if mk.get_pixel(x, y).r < 0.5:
					im.set_pixel(x, y, avg)


static func _face_square(src: Image, S: int) -> Image:
	var w := src.get_width()
	var h := src.get_height()
	var side := mini(w, h)
	var x0 := (w - side) / 2
	var y0 := int((h - side) * 0.3)
	return _resize_smooth(src.get_region(Rect2i(x0, y0, side, side)), 8 * S, 8 * S)


static func _jitter(x: int, y: int) -> float:
	var n := ((x * 73856093) ^ (y * 19349663)) & 1023
	return (float(n) / 1023.0 - 0.5) * 0.07


## ردیف‌به‌ردیف یک ناحیه را با میانگین هر ردیف از منبع پر می‌کند (برای وجه‌های ساده‌ی کناره/پشت)
static func _row_means(img: Image, r: Rect2i) -> Array[Color]:
	var rows: Array[Color] = []
	for y in range(r.position.y, r.end.y):
		var c := _avg(img, Rect2i(r.position.x, y, r.size.x, 1))
		rows.append(c if _valid(c) else Color("808080"))
	return rows


static func _fill_rows(skin: Image, dst: Rect2i, rows: Array[Color], f: float, jit: bool) -> void:
	for y in dst.size.y:
		var c: Color = rows[mini(rows.size() - 1, int(float(y) * rows.size() / dst.size.y))]
		for x in dst.size.x:
			var k := f * (1.0 + (_jitter(dst.position.x + x, dst.position.y + y) if jit else 0.0))
			skin.set_pixel(dst.position.x + x, dst.position.y + y, _shade(c, k))


static func _fill_solid(skin: Image, dst: Rect2i, c: Color, jit: bool = true) -> void:
	for y in dst.size.y:
		for x in dst.size.x:
			var k := 1.0 + (_jitter(dst.position.x + x, dst.position.y + y) if jit else 0.0)
			skin.set_pixel(dst.position.x + x, dst.position.y + y, _shade(c, k))


static func _blit_scaled(skin: Image, src: Image, src_r: Rect2i, dst: Rect2i) -> void:
	var piece := src.get_region(src_r)
	if piece.get_size() != dst.size:
		piece.resize(dst.size.x, dst.size.y, Image.INTERPOLATE_BILINEAR)
	skin.blit_rect(piece, Rect2i(Vector2i.ZERO, dst.size), dst.position)


## افزایش اشباع و کنتراست برای حالت پیکسلی (تا در ۶۴×۶۴ شبیه اسکین‌های واقعی «پر‌رنگ» باشد)
static func _pop(skin: Image) -> void:
	for y in skin.get_height():
		for x in skin.get_width():
			var c := skin.get_pixel(x, y)
			if c.a < 0.5:
				continue
			var l := (c.r + c.g + c.b) / 3.0
			var r := l + (c.r - l) * 1.18
			var g := l + (c.g - l) * 1.18
			var b := l + (c.b - l) * 1.18
			r = (r - 0.5) * 1.08 + 0.5
			g = (g - 0.5) * 1.08 + 0.5
			b = (b - 0.5) * 1.08 + 0.5
			skin.set_pixel(x, y, Color(clampf(r, 0, 1), clampf(g, 0, 1), clampf(b, 0, 1), 1.0))


static func build_from_photos(slots: Dictionary, style: int = 0) -> Dictionary:
	var S := 1 if style == 0 else 8
	var imgs := {}
	for k in SLOT_NAMES:
		if slots.has(k) and slots[k] is Image and not (slots[k] as Image).is_empty():
			var im := (slots[k] as Image).duplicate() as Image
			im.convert(Image.FORMAT_RGBA8)
			imgs[k] = im
	var face_src: Image = imgs.get("face")
	var front_src: Image = imgs.get("front")
	# عکس پرتره (کوتاه‌تر از ۱٫۳ برابر عرض) تمام‌قد حساب نمی‌شود → فقط برای صورت
	if front_src != null and float(front_src.get_height()) / float(front_src.get_width()) < 1.3:
		if face_src == null:
			face_src = front_src
		front_src = null
	if face_src == null and front_src == null:
		return {"error": "حداقل عکس «جلو» یا «صورت» لازم است"}

	var fp := {}
	var bp := {}
	var rp := {}
	var lp := {}
	if front_src != null:
		fp = _poster(front_src, S)
		_clean(fp, _front_rects(), S)
	if imgs.has("back"):
		bp = _poster(imgs["back"], S)
		var mir: Array = []
		for r in _front_rects():
			mir.append(_mirror_rect(r))
		_clean(bp, mir, S)
	var side_rects := [Rect2i(3, 0, 10, 8), Rect2i(5, 8, 6, 12), Rect2i(5, 20, 6, 12)]
	if imgs.has("right"):
		rp = _poster(imgs["right"], S)
		_clean(rp, side_rects, S)
	if imgs.has("left"):
		lp = _poster(imgs["left"], S)
		_clean(lp, side_rects, S)
	if rp.is_empty() and not lp.is_empty():
		rp = _flip_poster(lp)
	if lp.is_empty() and not rp.is_empty():
		lp = _flip_poster(rp)

	# صورت
	var face: Image = null
	if face_src != null:
		face = _face_square(face_src, S)
	elif not fp.is_empty():
		face = (fp["img"] as Image).get_region(_sc(Rect2i(4, 0, 8, 8), S))

	# رنگ‌های پایه
	var skin_c := Color("e8b896")
	var hair_c := Color("4a3426")
	if face != null:
		var fw := face.get_width()
		var c1 := _avg(face, Rect2i(int(fw * 0.25), int(fw * 0.4), int(fw * 0.5), int(fw * 0.35)))
		if _valid(c1):
			skin_c = c1
		var c2 := _avg(face, Rect2i(int(fw * 0.2), 0, int(fw * 0.6), maxi(1, int(fw * 0.14))))
		if _valid(c2):
			hair_c = c2
	var shirt_c := Color("3a5fc8")
	var pants_c := Color("2b3350")
	var shoe_c := Color("1e1e24")
	if face_src != null and fp.is_empty():
		var bottom := face_src.get_region(Rect2i(int(face_src.get_width() * 0.2), int(face_src.get_height() * 0.88), int(face_src.get_width() * 0.6), maxi(1, int(face_src.get_height() * 0.1))))
		var cs := _avg(bottom, Rect2i(Vector2i.ZERO, bottom.get_size()))
		if _valid(cs):
			shirt_c = cs
			pants_c = cs.darkened(0.55).lerp(Color("2b3350"), 0.5)
	var ctx := {"fp": fp, "bp": bp, "rp": rp, "lp": lp, "face": face, "skin": skin_c, "hair": hair_c, "shirt": shirt_c, "pants": pants_c, "shoe": shoe_c}

	var skin := Image.create(64 * S, 64 * S, false, Image.FORMAT_RGBA8)
	var parts := [
		{"id": "head", "box": HEAD, "front": Rect2i(4, 0, 8, 8), "side": Rect2i(3, 0, 10, 8)},
		{"id": "body", "box": BODY, "front": Rect2i(4, 8, 8, 12), "side": Rect2i(5, 8, 6, 12)},
		{"id": "r_arm", "box": R_ARM, "front": Rect2i(0, 8, 4, 12), "side": Rect2i(5, 8, 6, 12)},
		{"id": "l_arm", "box": L_ARM, "front": Rect2i(12, 8, 4, 12), "side": Rect2i(5, 8, 6, 12)},
		{"id": "r_leg", "box": R_LEG, "front": Rect2i(4, 20, 4, 12), "side": Rect2i(5, 20, 6, 12)},
		{"id": "l_leg", "box": L_LEG, "front": Rect2i(8, 20, 4, 12), "side": Rect2i(5, 20, 6, 12)},
	]
	for p in parts:
		_build_part(skin, p, ctx, S)
	if style == 0:
		_pop(skin)
	return {"image": skin, "slim": false, "photo": false, "built": true, "scale": S, "had_back": not bp.is_empty(), "had_sides": not rp.is_empty()}


static func _build_part(skin: Image, p: Dictionary, ctx: Dictionary, S: int) -> void:
	var box: Array = p["box"]
	var id: String = p["id"]
	var fr: Rect2i = p["front"]
	var fp: Dictionary = ctx["fp"]
	var bp: Dictionary = ctx["bp"]
	var d_front := _sc(face_rect(box, Face.FRONT), S)
	var d_back := _sc(face_rect(box, Face.BACK), S)
	var d_right := _sc(face_rect(box, Face.RIGHT), S)
	var d_left := _sc(face_rect(box, Face.LEFT), S)
	var d_top := _sc(face_rect(box, Face.TOP), S)
	var d_bottom := _sc(face_rect(box, Face.BOTTOM), S)
	var skin_c: Color = ctx["skin"]
	var hair_c: Color = ctx["hair"]

	# ---- جلو ----
	if id == "head" and ctx["face"] != null:
		skin.blit_rect(ctx["face"], Rect2i(Vector2i.ZERO, d_front.size), d_front.position)
	elif not fp.is_empty():
		skin.blit_rect(fp["img"], _sc(fr, S), d_front.position)
	else:
		_paint_avatar_front(skin, id, d_front, ctx, S)
	var rows := _row_means(skin, d_front)

	# ---- پشت ----
	if not bp.is_empty():
		_blit_scaled(skin, bp["img"], _sc(_mirror_rect(fr), S), d_back)
	elif id == "head":
		_fill_solid(skin, d_back, hair_c)
		_fill_solid(skin, Rect2i(d_back.position.x, d_back.position.y + d_back.size.y - maxi(1, S), d_back.size.x, maxi(1, S)), _shade(skin_c, 0.85))
	else:
		_fill_rows(skin, d_back, rows, 0.93, true)

	# ---- کناره‌ها ----
	var inner_right := id == "l_arm" or id == "l_leg"
	var inner_left := id == "r_arm" or id == "r_leg"
	_paint_side(skin, id, d_right, ctx["rp"], p["side"], rows, inner_right, ctx, S)
	_paint_side(skin, id, d_left, ctx["lp"], p["side"], rows, inner_left, ctx, S)

	# ---- بالا و پایین ----
	match id:
		"head":
			_fill_solid(skin, d_top, hair_c)
			_fill_solid(skin, d_bottom, _shade(skin_c, 0.8))
		"body":
			_fill_solid(skin, d_top, rows[0])
			_fill_solid(skin, d_bottom, _shade(rows[rows.size() - 1], 0.8))
		"r_arm", "l_arm":
			_fill_solid(skin, d_top, rows[0])
			_fill_solid(skin, d_bottom, _shade(rows[rows.size() - 1], 0.85))
		_:
			_fill_solid(skin, d_top, rows[0])
			_fill_solid(skin, d_bottom, _shade(rows[rows.size() - 1], 0.75))


static func _paint_side(skin: Image, id: String, dst: Rect2i, poster: Dictionary, side_r: Rect2i, rows: Array[Color], inner: bool, ctx: Dictionary, S: int) -> void:
	var skin_c: Color = ctx["skin"]
	if not poster.is_empty() and not inner:
		_blit_scaled(skin, poster["img"], _sc(side_r, S), dst)
		return
	if id == "head":
		_fill_solid(skin, dst, skin_c)
		_fill_solid(skin, Rect2i(dst.position.x, dst.position.y, dst.size.x, maxi(1, int(round(dst.size.y * 0.38)))), ctx["hair"])
		var e := maxi(1, S)
		_fill_solid(skin, Rect2i(dst.position.x + dst.size.x / 2 - e, dst.position.y + dst.size.y / 2, e * 2, e * 2), _shade(skin_c, 0.88), false)
		return
	_fill_rows(skin, dst, rows, 0.78 if inner else 0.9, true)


## قطعه‌ی جلو وقتی عکس تمام‌قد نیست (فقط صورت): آواتار ساده با رنگ‌های میانگین
static func _paint_avatar_front(skin: Image, id: String, dst: Rect2i, ctx: Dictionary, S: int) -> void:
	var skin_c: Color = ctx["skin"]
	var shirt_c: Color = ctx["shirt"]
	var pants_c: Color = ctx["pants"]
	var shoe_c: Color = ctx["shoe"]
	match id:
		"head":
			_fill_solid(skin, dst, skin_c)
			_fill_solid(skin, Rect2i(dst.position.x, dst.position.y, dst.size.x, maxi(1, dst.size.y / 4)), ctx["hair"])
		"body":
			_fill_solid(skin, dst, shirt_c)
		"r_arm", "l_arm":
			_fill_solid(skin, dst, skin_c)
			_fill_solid(skin, Rect2i(dst.position.x, dst.position.y, dst.size.x, dst.size.y / 3), shirt_c)
		_:
			_fill_solid(skin, dst, pants_c)
			var sh := maxi(1, dst.size.y / 6)
			_fill_solid(skin, Rect2i(dst.position.x, dst.position.y + dst.size.y - sh, dst.size.x, sh), shoe_c)


# ===================== کاراکترهای آماده =====================
const PRESET_NAMES := ["رانر", "نینجا", "ربات", "فضانورد", "کلاسیک", "طلایی", "نئون"]


static func preset(index: int) -> Image:
	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	match index:
		0:
			_paint_runner(img)
		1:
			_paint_ninja(img)
		2:
			_paint_robot(img)
		3:
			_paint_astronaut(img)
		4:
			_paint_classic(img)
		5:
			_paint_golden(img)
		_:
			_paint_neon(img)
	return img


static func _box_all(img: Image, box: Array, c: Color) -> void:
	for f in 6:
		img.fill_rect(face_rect(box, f), c)


static func _box_face(img: Image, box: Array, face: int, c: Color) -> void:
	img.fill_rect(face_rect(box, face), c)


## مستطیل نسبی داخل یک وجه
static func _sub(img: Image, box: Array, face: int, x: int, y: int, w: int, h: int, c: Color) -> void:
	var r := face_rect(box, face)
	img.fill_rect(Rect2i(r.position.x + x, r.position.y + y, w, h), c)


## نواری که دور ۴ وجه‌ی کناری می‌چرخد
static func _around(img: Image, box: Array, y: int, h: int, c: Color) -> void:
	for f in [Face.RIGHT, Face.FRONT, Face.LEFT, Face.BACK]:
		var r := face_rect(box, f)
		_sub(img, box, f, 0, y, r.size.x, h, c)


static func _human_base(img: Image, skin: Color, shirt: Color, pants: Color, shoe: Color) -> void:
	_box_all(img, HEAD, skin)
	_box_all(img, BODY, shirt)
	for arm in [R_ARM, L_ARM]:
		_box_all(img, arm, skin)
		_around(img, arm, 0, 4, shirt)
		_box_face(img, arm, Face.TOP, shirt)
	for leg in [R_LEG, L_LEG]:
		_box_all(img, leg, pants)
		_around(img, leg, 10, 2, shoe)
		_box_face(img, leg, Face.BOTTOM, shoe)


static func _eyes(img: Image, y: int, white: Color, pupil: Color) -> void:
	for x in [1, 5]:
		_sub(img, HEAD, Face.FRONT, x, y, 2, 1, white)
	_sub(img, HEAD, Face.FRONT, 2, y, 1, 1, pupil)
	_sub(img, HEAD, Face.FRONT, 5, y, 1, 1, pupil)


static func _paint_runner(img: Image) -> void:
	var skin := Color("f2c9a0")
	var hair := Color("5a3a22")
	var cap := Color("8b019d")
	var yellow := Color("ffd54a")
	_human_base(img, skin, Color("c026d3"), Color("2a1038"), yellow)
	# موی زیر کلاه
	_box_face(img, HEAD, Face.TOP, hair)
	_around(img, HEAD, 0, 3, hair)
	_sub(img, HEAD, Face.FRONT, 0, 2, 1, 1, hair)
	_sub(img, HEAD, Face.FRONT, 7, 2, 1, 1, hair)
	_eyes(img, 4, Color.WHITE, Color("1a1a2e"))
	_sub(img, HEAD, Face.FRONT, 3, 6, 2, 1, Color("c98a6a"))
	# کلاه (لایه‌ی روکش)
	_box_face(img, HAT, Face.TOP, cap)
	_around(img, HAT, 0, 2, cap)
	_sub(img, HAT, Face.FRONT, 0, 2, 8, 1, yellow)
	_sub(img, HAT, Face.RIGHT, 0, 2, 8, 1, cap)
	_sub(img, HAT, Face.LEFT, 0, 2, 8, 1, cap)
	# راه‌راه زرد روی پیراهن
	for f in [Face.FRONT, Face.BACK]:
		_sub(img, BODY, f, 0, 5, 8, 1, yellow)
	for arm in [R_ARM, L_ARM]:
		_around(img, arm, 3, 1, yellow)


static func _paint_ninja(img: Image) -> void:
	var black := Color("17171d")
	var dark := Color("2c2c38")
	var red := Color("e0243c")
	var skin := Color("f2c9a0")
	_box_all(img, HEAD, black)
	_box_all(img, BODY, black)
	for arm in [R_ARM, L_ARM]:
		_box_all(img, arm, black)
		_around(img, arm, 9, 1, red)
	for leg in [R_LEG, L_LEG]:
		_box_all(img, leg, black)
		_around(img, leg, 10, 2, dark)
	_sub(img, HEAD, Face.FRONT, 0, 3, 8, 2, skin)
	_eyes(img, 3, Color.WHITE, Color("2a1a10"))
	_around(img, HEAD, 1, 2, red)
	_sub(img, HEAD, Face.FRONT, 0, 1, 8, 2, red)
	_around(img, BODY, 9, 2, red)
	_sub(img, BODY, Face.FRONT, 3, 4, 2, 2, dark)


static func _paint_robot(img: Image) -> void:
	var metal := Color("9aa3b0")
	var metal_d := Color("6b7482")
	var dark := Color("2f3540")
	var cyan := Color("5ae6ff")
	var red := Color("ff4d5e")
	_box_all(img, HEAD, metal)
	_box_all(img, BODY, metal_d)
	for arm in [R_ARM, L_ARM]:
		_box_all(img, arm, metal)
		_around(img, arm, 5, 1, dark)
		_around(img, arm, 10, 2, dark)
	for leg in [R_LEG, L_LEG]:
		_box_all(img, leg, dark)
		_around(img, leg, 10, 2, metal)
		_box_face(img, leg, Face.BOTTOM, metal)
	_sub(img, HEAD, Face.FRONT, 1, 2, 6, 3, dark)
	_sub(img, HEAD, Face.FRONT, 2, 3, 1, 1, cyan)
	_sub(img, HEAD, Face.FRONT, 5, 3, 1, 1, cyan)
	_sub(img, HEAD, Face.FRONT, 2, 6, 4, 1, dark)
	_sub(img, HEAD, Face.RIGHT, 3, 3, 2, 2, dark)
	_sub(img, HEAD, Face.LEFT, 3, 3, 2, 2, dark)
	_sub(img, HAT, Face.TOP, 3, 3, 2, 2, red)
	_sub(img, BODY, Face.FRONT, 2, 2, 4, 6, dark)
	_sub(img, BODY, Face.FRONT, 3, 3, 2, 1, cyan)
	_sub(img, BODY, Face.FRONT, 3, 5, 2, 1, red)


static func _paint_astronaut(img: Image) -> void:
	var white := Color("f1f2f7")
	var shade := Color("c3c7d6")
	var visor := Color("1f2a52")
	var hl := Color("5b86ff")
	var orange := Color("ff7a1a")
	_box_all(img, HEAD, white)
	_box_all(img, BODY, white)
	for arm in [R_ARM, L_ARM]:
		_box_all(img, arm, white)
		_around(img, arm, 10, 2, shade)
	for leg in [R_LEG, L_LEG]:
		_box_all(img, leg, white)
		_around(img, leg, 10, 2, orange)
		_box_face(img, leg, Face.BOTTOM, orange)
	_around(img, HEAD, 6, 2, shade)
	_sub(img, HEAD, Face.FRONT, 1, 2, 6, 4, visor)
	_sub(img, HEAD, Face.FRONT, 2, 3, 1, 2, hl)
	_sub(img, BODY, Face.FRONT, 5, 2, 2, 2, orange)
	_sub(img, BODY, Face.FRONT, 1, 2, 2, 2, hl)
	_around(img, BODY, 10, 2, shade)
	_sub(img, R_ARM, Face.FRONT, 1, 1, 2, 2, orange)



## بافت پیکسلی ریز روی جعبه‌ها (برای اینکه رنگ‌ها تخت و پلاستیکی نباشند)
static func _speckle(img: Image, boxes: Array, amp: float, seed_v: int = 7) -> void:
	for box in boxes:
		for f in 6:
			var r := face_rect(box, f)
			for y in range(r.position.y, r.end.y):
				for x in range(r.position.x, r.end.x):
					var c := img.get_pixel(x, y)
					if c.a < 0.5:
						continue
					var n := (((x + seed_v) * 73856093) ^ ((y + seed_v * 3) * 19349663)) & 255
					var k := 1.0 + (float(n) / 255.0 - 0.5) * 2.0 * amp
					img.set_pixel(x, y, Color(clampf(c.r * k, 0, 1), clampf(c.g * k, 0, 1), clampf(c.b * k, 0, 1), c.a))


static func _all_base_boxes() -> Array:
	return [HEAD, BODY, R_ARM, L_ARM, R_LEG, L_LEG]


## کلاسیک: شبیه اسکین پیش‌فرض ماینکرفت (برای شروع نقاشی عالی است)
static func _paint_classic(img: Image) -> void:
	var skin := Color("e8b48a")
	var skin_d := Color("c98f68")
	var hair := Color("4a2f1c")
	var shirt := Color("2aa6b4")
	var shirt_d := Color("1f8590")
	var pants := Color("3a46a0")
	var pants_d := Color("2c3680")
	var shoe := Color("5b5b66")
	_box_all(img, HEAD, skin)
	_box_all(img, BODY, shirt)
	for arm in [R_ARM, L_ARM]:
		_box_all(img, arm, skin)
		_sub(img, arm, Face.FRONT, 0, 0, 4, 4, shirt)
		_sub(img, arm, Face.BACK, 0, 0, 4, 4, shirt)
		_sub(img, arm, Face.RIGHT, 0, 0, 4, 4, shirt)
		_sub(img, arm, Face.LEFT, 0, 0, 4, 4, shirt)
		_box_face(img, arm, Face.TOP, shirt)
		_box_face(img, arm, Face.BOTTOM, skin_d)
	for leg in [R_LEG, L_LEG]:
		_box_all(img, leg, pants)
		_sub(img, leg, Face.FRONT, 0, 10, 4, 2, shoe)
		_sub(img, leg, Face.BACK, 0, 10, 4, 2, shoe)
		_sub(img, leg, Face.RIGHT, 0, 10, 4, 2, shoe)
		_sub(img, leg, Face.LEFT, 0, 10, 4, 2, shoe)
		_box_face(img, leg, Face.BOTTOM, shoe)
		_sub(img, leg, Face.FRONT, 0, 6, 4, 4, pants_d)
	# موی سر
	_box_face(img, HEAD, Face.TOP, hair)
	_box_face(img, HEAD, Face.BACK, hair)
	_around(img, HEAD, 0, 2, hair)
	_sub(img, HEAD, Face.BACK, 0, 0, 8, 8, hair)
	_sub(img, HEAD, Face.FRONT, 0, 2, 1, 2, hair)
	_sub(img, HEAD, Face.FRONT, 7, 2, 1, 2, hair)
	# صورت
	_eyes(img, 4, Color.WHITE, Color("3b2a8f"))
	_sub(img, HEAD, Face.FRONT, 3, 5, 2, 1, skin_d)
	_sub(img, HEAD, Face.FRONT, 2, 6, 4, 1, Color("a8555a"))
	# یقه و دکمه
	_sub(img, BODY, Face.FRONT, 2, 0, 4, 1, shirt_d)
	_sub(img, BODY, Face.FRONT, 3, 1, 2, 1, shirt_d)
	_sub(img, BODY, Face.FRONT, 0, 11, 8, 1, shirt_d)
	_speckle(img, _all_base_boxes(), 0.05)


## طلایی: زره‌ی سلطنتی با تاج و جواهر
static func _paint_golden(img: Image) -> void:
	var gold := Color("f2c233")
	var gold_d := Color("c4901c")
	var gold_l := Color("ffe888")
	var dark := Color("3a2610")
	var ruby := Color("e0243c")
	var sapph := Color("2f7bff")
	var skin := Color("f0c49c")
	_box_all(img, HEAD, gold)
	_box_all(img, BODY, gold)
	for arm in [R_ARM, L_ARM]:
		_box_all(img, arm, gold)
		_around(img, arm, 0, 3, gold_l)
		_around(img, arm, 9, 3, gold_d)
	for leg in [R_LEG, L_LEG]:
		_box_all(img, leg, gold)
		_around(img, leg, 3, 1, gold_d)
		_around(img, leg, 9, 3, gold_d)
		_box_face(img, leg, Face.BOTTOM, dark)
	# صورت: شکاف کلاهخود + چشم
	_sub(img, HEAD, Face.FRONT, 1, 3, 6, 2, dark)
	_sub(img, HEAD, Face.FRONT, 2, 3, 1, 1, sapph)
	_sub(img, HEAD, Face.FRONT, 5, 3, 1, 1, sapph)
	_sub(img, HEAD, Face.FRONT, 3, 5, 2, 3, gold_d)
	_sub(img, HEAD, Face.FRONT, 2, 6, 4, 1, skin)
	_sub(img, HEAD, Face.RIGHT, 2, 3, 4, 1, dark)
	_sub(img, HEAD, Face.LEFT, 2, 3, 4, 1, dark)
	# تاج (لایه‌ی روکش)
	_box_face(img, HAT, Face.TOP, gold_l)
	_around(img, HAT, 0, 2, gold_l)
	_around(img, HAT, 2, 1, gold)
	for x in [1, 3, 5]:
		_sub(img, HAT, Face.FRONT, x, 0, 1, 1, Color(0, 0, 0, 0))
	_sub(img, HAT, Face.FRONT, 3, 1, 2, 1, ruby)
	_sub(img, HAT, Face.FRONT, 0, 1, 1, 1, sapph)
	_sub(img, HAT, Face.FRONT, 7, 1, 1, 1, sapph)
	# سینه‌بند
	_sub(img, BODY, Face.FRONT, 2, 1, 4, 5, gold_l)
	_sub(img, BODY, Face.FRONT, 3, 2, 2, 3, gold_d)
	_sub(img, BODY, Face.FRONT, 3, 3, 2, 1, ruby)
	_around(img, BODY, 8, 1, dark)
	_sub(img, BODY, Face.FRONT, 3, 8, 2, 1, gold_l)
	# شانه‌بند (آستین‌ها)
	for sl in [R_SLEEVE, L_SLEEVE]:
		_box_face(img, sl, Face.TOP, gold_l)
		_around(img, sl, 0, 2, gold_l)
		_around(img, sl, 2, 1, gold_d)
	# ژاکت: دامن زره
	_around(img, JACKET, 9, 3, gold_d)
	_around(img, JACKET, 9, 1, gold_l)
	for pn in [R_PANTS, L_PANTS]:
		_around(img, pn, 9, 3, gold_l)
	_speckle(img, _all_base_boxes(), 0.06, 11)


## نئون: لباس تیره‌ی سایبری با خطوط درخشان
static func _paint_neon(img: Image) -> void:
	var base := Color("141226")
	var base_l := Color("221d40")
	var cyan := Color("27f3ff")
	var pink := Color("ff2fd2")
	var lime := Color("9dff3c")
	var skin := Color("d9b4a0")
	_box_all(img, HEAD, base_l)
	_box_all(img, BODY, base)
	for arm in [R_ARM, L_ARM]:
		_box_all(img, arm, base)
		_around(img, arm, 4, 1, cyan)
		_around(img, arm, 8, 1, pink)
		_box_face(img, arm, Face.BOTTOM, cyan)
	for leg in [R_LEG, L_LEG]:
		_box_all(img, leg, base)
		_around(img, leg, 2, 1, pink)
		_around(img, leg, 6, 1, cyan)
		_around(img, leg, 10, 2, base_l)
		_box_face(img, leg, Face.BOTTOM, pink)
	# چهره و ویزر
	_sub(img, HEAD, Face.FRONT, 1, 2, 6, 3, base)
	_sub(img, HEAD, Face.FRONT, 1, 3, 6, 1, cyan)
	_sub(img, HEAD, Face.FRONT, 3, 5, 2, 1, skin)
	_sub(img, HEAD, Face.FRONT, 2, 6, 4, 1, pink)
	_sub(img, HEAD, Face.RIGHT, 2, 3, 6, 1, cyan)
	_sub(img, HEAD, Face.LEFT, 2, 3, 6, 1, cyan)
	_sub(img, HEAD, Face.BACK, 2, 3, 4, 1, pink)
	# موی مصنوعی نئونی روی لایه‌ی کلاه
	_box_face(img, HAT, Face.TOP, pink)
	_around(img, HAT, 0, 1, pink)
	_sub(img, HAT, Face.FRONT, 0, 1, 1, 1, pink)
	_sub(img, HAT, Face.FRONT, 7, 1, 1, 1, pink)
	_sub(img, HAT, Face.FRONT, 3, 1, 2, 1, cyan)
	# مدار روی سینه
	_sub(img, BODY, Face.FRONT, 3, 2, 2, 2, cyan)
	_sub(img, BODY, Face.FRONT, 1, 4, 6, 1, pink)
	_sub(img, BODY, Face.FRONT, 1, 4, 1, 4, pink)
	_sub(img, BODY, Face.FRONT, 6, 4, 1, 3, cyan)
	_sub(img, BODY, Face.FRONT, 3, 8, 2, 1, lime)
	_sub(img, BODY, Face.BACK, 2, 2, 4, 1, cyan)
	_sub(img, BODY, Face.BACK, 3, 3, 1, 5, pink)
	_sub(img, BODY, Face.BACK, 4, 5, 1, 3, cyan)
	_speckle(img, _all_base_boxes(), 0.035, 5)


# ===================== ابزارهای ادیتور نقاشی =====================
## فهرست قطعه‌ها: id, جعبه، جفتِ آینه‌ای (اندیس)، آیا دست/پا است، برچسب راهنما
static func parts(slim: bool) -> Array:
	return [
		{"id": "head", "box": HEAD, "pair": 0, "limb": false, "label": "HEAD"},
		{"id": "hat", "box": HAT, "pair": 1, "limb": false, "label": "HAT"},
		{"id": "body", "box": BODY, "pair": 2, "limb": false, "label": "BODY"},
		{"id": "jacket", "box": JACKET, "pair": 3, "limb": false, "label": "JACKET"},
		{"id": "r_arm", "box": arm_box(R_ARM, slim), "pair": 6, "limb": true, "label": "R-ARM"},
		{"id": "r_sleeve", "box": arm_box(R_SLEEVE, slim), "pair": 7, "limb": true, "label": "R-SLV"},
		{"id": "l_arm", "box": arm_box(L_ARM, slim), "pair": 4, "limb": true, "label": "L-ARM"},
		{"id": "l_sleeve", "box": arm_box(L_SLEEVE, slim), "pair": 5, "limb": true, "label": "L-SLV"},
		{"id": "r_leg", "box": R_LEG, "pair": 10, "limb": true, "label": "R-LEG"},
		{"id": "r_pants", "box": R_PANTS, "pair": 11, "limb": true, "label": "R-PNT"},
		{"id": "l_leg", "box": L_LEG, "pair": 8, "limb": true, "label": "L-LEG"},
		{"id": "l_pants", "box": L_PANTS, "pair": 9, "limb": true, "label": "L-PNT"},
	]


## کدام وجه از کدام قطعه روی این پیکسل است؟ → {part, face, rect} یا {}
static func locate(px: Vector2i, slim: bool) -> Dictionary:
	var ps := parts(slim)
	for i in ps.size():
		for f in 6:
			var r := face_rect(ps[i]["box"], f)
			if r.has_point(px):
				return {"part": i, "face": f, "rect": r}
	return {}


## تقارن: mode 0 خاموش، 1 دست‌وپا (هوشمند)، 2 همه. اگر قرینه‌ای نباشد (-1,-1)
static func mirror_of(px: Vector2i, slim: bool, mode: int) -> Vector2i:
	var none := Vector2i(-1, -1)
	if mode == 0:
		return none
	var loc := locate(px, slim)
	if loc.is_empty():
		return none
	var ps := parts(slim)
	var part: Dictionary = ps[loc["part"]]
	if mode == 1 and not part["limb"]:
		return none
	var face: int = loc["face"]
	var tface := face
	if face == Face.RIGHT:
		tface = Face.LEFT
	elif face == Face.LEFT:
		tface = Face.RIGHT
	var r: Rect2i = loc["rect"]
	var tr := face_rect(ps[part["pair"]]["box"], tface)
	var lx := px.x - r.position.x
	var ly := px.y - r.position.y
	var nx := tr.position.x + (tr.size.x - 1 - lx)
	var ny := tr.position.y + ly
	if nx < tr.position.x or nx >= tr.end.x or ny < tr.position.y or ny >= tr.end.y:
		return none
	return Vector2i(nx, ny)


## جعبه‌های لایه‌ی اول (مات)
static func base_parts(slim: bool) -> Array:
	return [HEAD, BODY, arm_box(R_ARM, slim), arm_box(L_ARM, slim), R_LEG, L_LEG]


## پیکسل‌های شفاف لایه‌ی اول (سوراخ) را پر می‌کند تا مدل سه‌بعدی سوراخ نداشته باشد.
## برای هر وجه از میانگین پیکسل‌های مات همان وجه استفاده می‌شود (یا خاکستری روشن).
static func flatten_base(img: Image, slim: bool) -> void:
	var S := img.get_width() / 64
	for box in base_parts(slim):
		for f in 6:
			var r := _sc(face_rect(box, f), S)
			var sum := Vector3.ZERO
			var n := 0
			var holes := 0
			for y in range(r.position.y, r.end.y):
				for x in range(r.position.x, r.end.x):
					var c := img.get_pixel(x, y)
					if c.a >= 0.99:
						sum += Vector3(c.r, c.g, c.b)
						n += 1
					else:
						holes += 1
			if holes == 0:
				continue
			var fill := Color(0.72, 0.72, 0.72, 1.0)
			if n > 0:
				sum /= float(n)
				fill = Color(sum.x, sum.y, sum.z, 1.0)
			for y in range(r.position.y, r.end.y):
				for x in range(r.position.x, r.end.x):
					var c2 := img.get_pixel(x, y)
					if c2.a < 0.99:
						img.set_pixel(x, y, Color(fill.r, fill.g, fill.b, 1.0))


## هر تصویر اسکین (۶۴×۳۲، ۶۴×۶۴، HD) → ۶۴×۶۴ استاندارد. خروجی: {image, slim}
static func to_editor_image(src: Image) -> Dictionary:
	var img := src.duplicate() as Image
	img.convert(Image.FORMAT_RGBA8)
	img = normalize_dims(img)
	if is_legacy(img):
		img = expand_legacy(img)
	var slim := detect_slim(img)
	if img.get_width() != 64:
		img.resize(64, 64, Image.INTERPOLATE_NEAREST)
	return {"image": img, "slim": slim}


static func _arm_boxes_all() -> Array:
	return [R_ARM, R_SLEEVE, L_ARM, L_SLEEVE]


## تبدیل بازوها بین کلاسیک (۴ پیکسل) و باریک/Alex (۳ پیکسل): هر وجه به جای جدیدش می‌رود
## (ستون اضافه حذف یا با کپی ستون آخر ساخته می‌شود). تصویر درجا تغییر می‌کند.
static func convert_arms(img: Image, from_slim: bool, to_slim: bool) -> void:
	if from_slim == to_slim:
		return
	var S := img.get_width() / 64
	for base: Array in _arm_boxes_all():
		var ob := arm_box(base, from_slim)
		var nb := arm_box(base, to_slim)
		var olds: Array[Image] = []
		for f in 6:
			olds.append(img.get_region(_sc(face_rect(ob, f), S)))
		img.fill_rect(_sc(Rect2i(int(base[0]), int(base[1]), 16, 16), S), Color(0, 0, 0, 0))
		for f in 6:
			var piece: Image = olds[f]
			var nr := _sc(face_rect(nb, f), S)
			if piece.get_width() != nr.size.x:
				var np := Image.create(nr.size.x, nr.size.y, false, Image.FORMAT_RGBA8)
				var keep_w := mini(piece.get_width(), nr.size.x)
				np.blit_rect(piece, Rect2i(0, 0, keep_w, piece.get_height()), Vector2i.ZERO)
				if nr.size.x > piece.get_width():
					var last := piece.get_region(Rect2i(piece.get_width() - S, 0, S, piece.get_height()))
					np.blit_rect(last, Rect2i(0, 0, S, last.get_height()), Vector2i(piece.get_width(), 0))
				piece = np
			img.blit_rect(piece, Rect2i(Vector2i.ZERO, piece.get_size()), nr.position)


## نسخه‌ی آماده‌ی خروجی: برای بازوی باریک، پیکسل‌های بلااستفاده را شفاف می‌کند تا ماینکرفت (و ادیتورها) آن را Alex بشناسند
static func finalize_for_export(img: Image, slim: bool) -> Image:
	var out := img.duplicate() as Image
	if slim:
		var S := out.get_width() / 64
		for base: Array in _arm_boxes_all():
			var sb := arm_box(base, true)
			var keep: Array[Image] = []
			for f in 6:
				keep.append(out.get_region(_sc(face_rect(sb, f), S)))
			out.fill_rect(_sc(Rect2i(int(base[0]), int(base[1]), 16, 16), S), Color(0, 0, 0, 0))
			for f in 6:
				var kp: Image = keep[f]
				out.blit_rect(kp, Rect2i(Vector2i.ZERO, kp.get_size()), _sc(face_rect(sb, f), S).position)
	return out
