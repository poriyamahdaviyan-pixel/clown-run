class_name MiniBase
extends Node3D
## پایه‌ی بازی‌های مستقل داخل پرتال: دوربین و محیط خودش، آنالوگ، نوار بالا (زمان، سکه، هدف) و پایان با نتیجه

signal finished(result: Dictionary)

var duration := 45.0
var time_left := 45.0
var coins := 0
var bonus := 0
var title := ""
var hint := ""
var accent := Color("ffb02e")
var running := false
var cam: Camera3D
var stick: VirtualStick
var _hud: CanvasLayer
var _lbl_time: Label
var _lbl_coins: Label
var _lbl_title: Label
var _lbl_msg: Label
var _msg_t := 0.0
var _radar: Control
var _done := false


func _build_base(env: Environment) -> void:
	cam = Camera3D.new()
	cam.environment = env
	cam.fov = 62.0
	cam.far = 400.0
	add_child(cam)
	cam.make_current()
	_hud = CanvasLayer.new()
	_hud.layer = 4
	add_child(_hud)
	stick = VirtualStick.new()
	_hud.add_child(stick)
	var top := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.03, 0.12, 0.72)
	sb.set_corner_radius_all(18)
	sb.border_color = accent
	sb.set_border_width_all(3)
	sb.content_margin_left = 20
	sb.content_margin_right = 20
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	top.add_theme_stylebox_override("panel", sb)
	top.anchor_left = 0.5
	top.anchor_right = 0.5
	top.anchor_top = 0.0
	top.anchor_bottom = 0.0
	top.grow_horizontal = Control.GROW_DIRECTION_BOTH
	top.offset_top = 36
	_hud.add_child(top)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 26)
	top.add_child(hb)
	_lbl_coins = Label.new()
	_lbl_coins.add_theme_font_size_override("font_size", 34)
	_lbl_coins.add_theme_color_override("font_color", Color("ffd27a"))
	hb.add_child(_lbl_coins)
	_lbl_title = Label.new()
	_lbl_title.add_theme_font_size_override("font_size", 30)
	_lbl_title.add_theme_color_override("font_color", accent)
	_lbl_title.text = Content.dyn(title)
	hb.add_child(_lbl_title)
	_lbl_time = Label.new()
	_lbl_time.add_theme_font_size_override("font_size", 38)
	_lbl_time.add_theme_color_override("font_color", Color.WHITE)
	hb.add_child(_lbl_time)
	_lbl_msg = Label.new()
	_lbl_msg.add_theme_font_size_override("font_size", 34)
	_lbl_msg.add_theme_color_override("font_color", Color.WHITE)
	_lbl_msg.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	_lbl_msg.add_theme_constant_override("outline_size", 8)
	_lbl_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_lbl_msg.set_anchors_preset(Control.PRESET_CENTER)
	_lbl_msg.position = Vector2(-340, -520)
	_lbl_msg.size = Vector2(680, 200)
	_lbl_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hud.add_child(_lbl_msg)
	time_left = duration
	say(Content.dyn(title) + "\n" + Content.dyn(hint), 3.2)
	_refresh_hud()
	running = true


func say(t: String, secs: float = 1.2) -> void:
	if _lbl_msg == null:
		return
	_lbl_msg.text = Content.dyn(t)
	_lbl_msg.visible = true
	_msg_t = secs


func add_coins(n: int) -> void:
	coins += n
	_refresh_hud()


func _refresh_hud() -> void:
	if _lbl_coins == null:
		return
	_lbl_coins.text = "%d" % coins
	_lbl_time.text = "%d" % int(ceilf(maxf(time_left, 0.0)))


func _process(delta: float) -> void:
	if not running:
		return
	if _msg_t > 0.0:
		_msg_t -= delta
		if _msg_t <= 0.0 and _lbl_msg != null:
			_lbl_msg.visible = false
	time_left -= delta
	_tick(delta)
	_refresh_hud()
	if _radar != null:
		_radar.queue_redraw()
	if time_left <= 0.0:
		finish()


func _tick(_delta: float) -> void:
	pass


func finish() -> void:
	if _done:
		return
	_done = true
	running = false
	say("پایان! +%d سکه" % coins, 1.5)
	await get_tree().create_timer(1.2).timeout
	finished.emit({"coins": coins, "bonus": bonus})


static func make_env(top: Color, hor: Color, fog: Color, fog_den: float, amb: Color, amb_e: float) -> Environment:
	var env := Environment.new()
	var sky := ProceduralSkyMaterial.new()
	sky.sky_top_color = top
	sky.sky_horizon_color = hor
	sky.ground_horizon_color = hor
	sky.ground_bottom_color = fog
	var s := Sky.new()
	s.sky_material = sky
	env.sky = s
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = amb
	env.ambient_light_energy = amb_e
	env.fog_enabled = true
	env.fog_light_color = fog
	env.fog_density = fog_den
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	return env


func add_sun(col: Color, energy: float, rot: Vector3) -> DirectionalLight3D:
	var l := DirectionalLight3D.new()
	l.light_color = col
	l.light_energy = energy
	l.rotation_degrees = rot
	l.shadow_enabled = false
	add_child(l)
	return l
