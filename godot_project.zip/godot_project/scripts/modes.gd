class_name Modes
extends RefCounted
## «پرتال‌ها و جهان‌ها»: وسط بازی یک پرتال می‌آید؛ واردش شوی تصادفی در یکی از جهان‌های زیر می‌افتی
## (پس‌زمینه، جاده، موانع، سکه‌ها و حتی نوع بازی فرق می‌کند) و بعد از مسافتی از پرتال خروج برمی‌گردی.
##   brick : جهان آجری (سبک لگو)           — بازی عادی با موانع/سکه‌ی آجری
##   moto  : موتورسواری شبانه (سبک GTA)    — فرمان آزاد با کشیدن انگشت، سرعت بیشتر، ماشین‌ها
##   crate : جزیره‌ی جعبه‌ها (سبک کراش)    — جعبه‌ها را با سُرخوردن (چرخش) بشکن، روی جعبه‌ها بپر
##   ring  : تپه‌ی حلقه‌ها (سبک سونیک)     — خیلی سریع؛ با داشتن حلقه، برخورد نمی‌کُشد و حلقه‌ها پخش می‌شوند

const Gfx := preload("res://scripts/gfx.gd")
const P := preload("res://scripts/props.gd")

const RUN_IDS: Array[String] = ["brick", "moto", "crate", "ring", "space", "candy", "shrine", "pirate", "haunted", "volcano", "sky", "reef"]
const IDS: Array[String] = ["brick", "moto", "crate", "ring", "space", "candy", "shrine", "pirate", "haunted", "volcano", "sky", "reef", "drive", "craft", "shooter", "fruit", "stack"]

const DEFS := {
	"brick": {
		"name": "جهان آجری", "desc": "همه‌چیز از آجر ساخته شده؛ بازی عادی است.",
		"len": 380.0, "speed": 1.0, "steer": "lane", "tint": Color("ffd23f"),
		"top": Color("5ab8ff"), "hor": Color("d9f1ff"), "gnd": Color("4fa84a"), "fog": Color("cfeaff"), "den": 0.008,
		"amb": Color("ffffff"), "ambe": 1.1, "lcol": Color("fff4d8"), "le": 1.25, "road": Color("c9d2e0"),
		"ground": Color("52b04c"), "sun": Color("fff0a0"), "sunpos": Vector3(-22, 34, -175), "sunsize": 6.0,
	},
	"moto": {
		"name": "موتورسواری شبانه", "desc": "فرمان آزاد: انگشت را بکش و بین ماشین‌ها بپیچ. بالا/پایین = پرش/ترمز.",
		"len": 460.0, "speed": 1.32, "steer": "free", "tint": Color("ff2d95"),
		"top": Color("0a0420"), "hor": Color("ff2d95"), "gnd": Color("05010f"), "fog": Color("2a0a4a"), "den": 0.016,
		"amb": Color("8a6cff"), "ambe": 0.75, "lcol": Color("ff7ad0"), "le": 0.9, "road": Color("6a6a88"),
		"ground": Color("0a0618"), "sun": Color("ff4fb0"), "sunpos": Vector3(0, 18, -175), "sunsize": 13.0,
	},
	"crate": {
		"name": "جزیره‌ی جعبه‌ها", "desc": "با سُرخوردن جعبه‌ها را بشکن؛ روی جعبه‌ها هم می‌شود دوید.",
		"len": 400.0, "speed": 1.08, "steer": "lane", "tint": Color("ff8a1f"),
		"top": Color("3fc0ff"), "hor": Color("fff2b0"), "gnd": Color("4c7a28"), "fog": Color("d8f2a8"), "den": 0.011,
		"amb": Color("fff0c8"), "ambe": 1.0, "lcol": Color("fff2c0"), "le": 1.3, "road": Color("c8a46c"),
		"ground": Color("5f9330"), "sun": Color("fff6b0"), "sunpos": Vector3(-26, 40, -175), "sunsize": 7.0,
	},
	"ring": {
		"name": "تپه‌ی حلقه‌ها", "desc": "خیلی سریع! با داشتن حلقه، برخورد نمی‌کُشد و حلقه‌ها پخش می‌شوند.",
		"len": 420.0, "speed": 1.5, "steer": "lane", "tint": Color("ffd000"),
		"top": Color("2f8cff"), "hor": Color("c8f0ff"), "gnd": Color("3a9a2a"), "fog": Color("b8e4ff"), "den": 0.007,
		"amb": Color("ffffff"), "ambe": 1.15, "lcol": Color("ffffff"), "le": 1.35, "road": Color("b88a50"),
		"ground": Color("4aa832"), "sun": Color("ffffff"), "sunpos": Vector3(-14, 46, -175), "sunsize": 5.0,
	},
}

const MINI := {
	"drive": {"name": "رانندگی شهر باز", "desc": "یک شهر آزاد با آنالوگ: سکه و جعبه بگیر، نیترو بزن، به ترافیک نخور.", "kind": "mini", "tint": Color("27e8ff")},
	"shooter": {"name": "نبرد فضایی", "desc": "تیراندازی فضایی با آنالوگ: دشمن‌ها را بزن، ستاره بردار، از شهاب‌سنگ‌ها فرار کن.", "kind": "mini", "tint": Color("7a5cff")},
	"fruit": {"name": "برش میوه", "desc": "انگشت را بکش و میوه‌ها را ببُر؛ به بمب نزن! کمبو و میوه‌ی طلایی دارد.", "kind": "mini", "tint": Color("3de06a")},
	"stack": {"name": "برج‌چینی", "desc": "با لمس بلوک را رها کن و برج را بالا ببر؛ دقیق بیفتد کمبو می‌گیری.", "kind": "mini", "tint": Color("ff7a1f")},
	"craft": {"name": "جهان مکعبی", "desc": "دنیای مکعبی با آنالوگ: الماس و طلا بردار و از کریپرها فرار کن.", "kind": "mini", "tint": Color("5be26a")},
}

const BRICK_COLORS: Array[String] = ["e3342f", "2f7fe0", "f6c915", "2faa4a", "f28c1c", "8a4fd0", "ffffff"]


static func def(id: String) -> Dictionary:
	var d: Dictionary = {}
	if MINI.has(id):
		d = MINI[id]
	elif ModesExt.DEFS.has(id):
		d = ModesExt.DEFS[id]
	else:
		d = DEFS.get(id, {})
	if d.is_empty() or not Content.has_text_edits():
		return d
	var o := d.duplicate()
	o["name"] = Content.text_for(String(d.get("name", "")))
	o["desc"] = Content.text_for(String(d.get("desc", "")))
	return o


static func is_run(id: String) -> bool:
	return DEFS.has(id) or ModesExt.DEFS.has(id)


static func is_mini(id: String) -> bool:
	return MINI.has(id)


static func enabled_ids() -> Array[String]:
	var out: Array[String] = []
	for id in IDS:
		if not Game.mode_off.get(id, false) and Content.mode_feature(id):
			out.append(id)
	return out


# ============================================================
#                         مصالح و ابزار
# ============================================================
static func _m(hex: String, emit: float = 0.0, rough: float = 0.55, metal: float = 0.0) -> StandardMaterial3D:
	return P.m(hex, emit, rough, metal)


static func _brick(n: Node3D, size: Vector3, pos: Vector3, hex: String, studs: bool = true) -> void:
	var mat := _m(hex, 0.0, 0.35)
	Gfx.box(n, size, pos, mat)
	if not studs:
		return
	var nx := maxi(1, int(round(size.x / 0.5)))
	var nz := maxi(1, int(round(size.z / 0.5)))
	for ix in nx:
		for iz in nz:
			var sx := (float(ix) - float(nx - 1) * 0.5) * 0.5
			var sz := (float(iz) - float(nz - 1) * 0.5) * 0.5
			Gfx.cyl(n, 0.13, 0.13, 0.1, pos + Vector3(sx, size.y * 0.5 + 0.05, sz), mat, Vector3.ZERO, 8)


static func _pick(rng: RandomNumberGenerator, arr: Array) -> Variant:
	return arr[rng.randi() % arr.size()]


# ============================================================
#                        تزئینات دو طرف جاده
# ============================================================
static func decor(parent: Node3D, id: String, rng: RandomNumberGenerator, road_half: float, shoulder: float) -> void:
	for side: int in [-1, 1]:
		for slot in 2:
			var z := (-6.0 if slot == 0 else 6.0) + rng.randf_range(-2.0, 2.0)
			var x := float(side) * (road_half + shoulder + 1.0 + rng.randf_range(0.5, 6.0))
			var n := Node3D.new()
			n.position = Vector3(x, 0.0, z)
			parent.add_child(n)
			match id:
				"brick": _decor_brick(n, rng)
				"moto": _decor_moto(n, rng, side)
				"crate": _decor_crate(n, rng)
				"ring": _decor_ring(n, rng)
				_: ModesExt.decor(n, id, rng, side)


static func _decor_brick(n: Node3D, rng: RandomNumberGenerator) -> void:
	var r := rng.randi() % 3
	if r == 0:
		# برج آجری رنگارنگ
		var floors := rng.randi_range(4, 11)
		var w := rng.randf_range(3.0, 5.0)
		var d := rng.randf_range(3.0, 5.0)
		for i in floors:
			_brick(n, Vector3(w, 1.8, d), Vector3(0, 0.9 + i * 1.8, 0), _pick(rng, BRICK_COLORS), i == floors - 1)
	elif r == 1:
		# درخت آجری
		Gfx.box(n, Vector3(0.5, 2.0, 0.5), Vector3(0, 1.0, 0), _m("8a5a2a"))
		_brick(n, Vector3(2.0, 0.9, 2.0), Vector3(0, 2.4, 0), "2faa4a")
		_brick(n, Vector3(1.4, 0.9, 1.4), Vector3(0, 3.3, 0), "3cc05a")
	else:
		# خانه‌ی آجری با سقف
		_brick(n, Vector3(3.0, 1.8, 3.0), Vector3(0, 0.9, 0), _pick(rng, BRICK_COLORS))
		_brick(n, Vector3(3.2, 0.5, 3.2), Vector3(0, 2.05, 0), "e3342f")
		_brick(n, Vector3(1.6, 0.5, 1.6), Vector3(0, 2.55, 0), "c02a24")


static func _decor_moto(n: Node3D, rng: RandomNumberGenerator, side: int) -> void:
	var h := rng.randf_range(10.0, 34.0)
	var w := rng.randf_range(3.5, 6.0)
	Gfx.box(n, Vector3(w, h, 5.0), Vector3(0, h * 0.5, 0), _m("14102a", 0.0, 0.5, 0.2))
	var neon: String = _pick(rng, ["ff2d95", "27e8ff", "9d5cff", "3dff9a"])
	var nm := _m(neon, 2.2, 0.4)
	for i in int(h / 3.0):
		if rng.randf() < 0.75:
			Gfx.box(n, Vector3(w * 0.7, 0.28, 0.06), Vector3(0, 1.6 + i * 3.0, 2.52), nm)
			Gfx.box(n, Vector3(0.06, 0.28, 3.4), Vector3(-float(side) * (w * 0.5 + 0.03), 1.6 + i * 3.0, 0), nm)
	Gfx.box(n, Vector3(w + 0.2, 0.25, 5.2), Vector3(0, h + 0.1, 0), nm)
	if rng.randf() < 0.35:
		Gfx.box(n, Vector3(0.06, 2.4, 3.6), Vector3(-float(side) * (w * 0.5 + 0.5), h * 0.45, 0), _m(neon, 1.6, 0.5))


static func _decor_crate(n: Node3D, rng: RandomNumberGenerator) -> void:
	var r := rng.randi() % 3
	if r == 0:
		# نخل
		var lean := rng.randf_range(-12.0, 12.0)
		Gfx.cyl(n, 0.22, 0.32, 5.0, Vector3(0, 2.5, 0), _m("8a5a2a", 0.0, 0.9), Vector3(0, 0, lean), 8)
		for i in 6:
			Gfx.box(n, Vector3(0.35, 0.08, 2.6), Vector3(0, 5.1, 0), _m("2f9a3a"), Vector3(-18, i * 60.0, 0))
	elif r == 1:
		# توتم سنگی
		for i in 3:
			Gfx.box(n, Vector3(1.4, 1.1, 1.4), Vector3(0, 0.55 + i * 1.1, 0), _m("8a8f98" if i % 2 == 0 else "6f757e", 0.0, 0.9))
			Gfx.box(n, Vector3(0.9, 0.2, 0.05), Vector3(0, 0.6 + i * 1.1, 0.72), _m("1c1c20"))
	else:
		# پشته‌ی جعبه‌ی چوبی
		var k := rng.randi_range(2, 5)
		for i in k:
			Gfx.box(n, Vector3(1.3, 1.3, 1.3), Vector3(rng.randf_range(-0.2, 0.2), 0.65 + i * 1.3, 0), _m("c8873a", 0.0, 0.8), Vector3(0, rng.randf_range(-12.0, 12.0), 0))


static func _decor_ring(n: Node3D, rng: RandomNumberGenerator) -> void:
	var r := rng.randi() % 3
	if r == 0:
		# صخره‌ی شطرنجی
		var floors := rng.randi_range(3, 7)
		for i in floors:
			Gfx.box(n, Vector3(4.0, 1.2, 4.0), Vector3(0, 0.6 + i * 1.2, 0), _m("7a4a22" if i % 2 == 0 else "d9a85a", 0.0, 0.9))
		Gfx.box(n, Vector3(4.2, 0.4, 4.2), Vector3(0, floors * 1.2 + 0.2, 0), _m("4aa832"))
	elif r == 1:
		# گل آفتابگردان
		Gfx.cyl(n, 0.07, 0.07, 2.0, Vector3(0, 1.0, 0), _m("2f9a3a"), Vector3.ZERO, 6)
		Gfx.cyl(n, 0.55, 0.55, 0.12, Vector3(0, 2.1, 0), _m("ffd000", 0.3), Vector3(90, 0, 0), 12)
		Gfx.cyl(n, 0.25, 0.25, 0.14, Vector3(0, 2.1, 0.02), _m("7a4a22"), Vector3(90, 0, 0), 10)
	else:
		# طاق حلقه‌ی بزرگ کنار جاده
		P.ring(n, 2.6, 0.35, Vector3(0, 3.0, 0), _m("ffd000", 0.5, 0.3, 0.6), Vector3(0, 90, 0), 18)
		Gfx.box(n, Vector3(0.9, 3.0, 0.9), Vector3(0, 1.5, 0), _m("7a4a22" if rng.randf() < 0.5 else "d9a85a", 0.0, 0.9))


# ============================================================
#                              موانع
# ============================================================
## ابعاد را در e می‌گذارد و مدل را در node می‌سازد؛ true یعنی این جهان مانع را ساخت
static func obstacle(id: String, kind: int, variant: int, e: Object, node: Node3D) -> bool:
	var v := variant % 4
	match id:
		"brick": _obs_brick(kind, v, e, node)
		"moto": _obs_moto(kind, v, e, node)
		"crate": _obs_crate(kind, v, e, node)
		"ring": _obs_ring(kind, v, e, node)
		_:
			if not ModesExt.DEFS.has(id):
				return false
			ModesExt.obstacle(id, kind, v, e, node)
	return true


static func _obs_brick(kind: int, v: int, e: Object, n: Node3D) -> void:
	var c1: String = BRICK_COLORS[v % BRICK_COLORS.size()]
	var c2: String = BRICK_COLORS[(v + 2) % BRICK_COLORS.size()]
	if kind == 2:   # LOW: دو آجر رویهم
		e.y0 = 0.0; e.y1 = 0.9; e.half_d = 0.45
		_brick(n, Vector3(1.9, 0.45, 0.8), Vector3(0, 0.225, 0), c1)
		_brick(n, Vector3(1.9, 0.45, 0.8), Vector3(0, 0.675, 0), c2)
	elif kind == 3: # OVERHEAD: طاق آجری
		e.y0 = 1.0; e.y1 = 6.0; e.half_d = 0.9
		for sx in [-0.95, 0.95]:
			for i in 3:
				_brick(n, Vector3(0.5, 0.45, 0.8), Vector3(sx, 0.225 + i * 0.45, 0), c1 if i % 2 == 0 else c2)
		_brick(n, Vector3(2.3, 0.5, 0.9), Vector3(0, 1.55, 0), c2)
		_brick(n, Vector3(2.3, 0.5, 0.9), Vector3(0, 2.05, 0), c1)
		for i in 5:
			Gfx.box(n, Vector3(0.5, 0.5, 0.5), Vector3(-1.0 + i * 0.5, 2.55, 0), _m(BRICK_COLORS[(v + i) % BRICK_COLORS.size()], 0.0, 0.4))
	else:           # FULL: برج
		e.y0 = 0.0; e.y1 = 2.8; e.half_d = 1.3
		for i in 6:
			_brick(n, Vector3(1.9, 0.47, 2.3), Vector3(0, 0.235 + i * 0.47, 0), BRICK_COLORS[(v + i) % BRICK_COLORS.size()])


static func _obs_moto(kind: int, v: int, e: Object, n: Node3D) -> void:
	var body_cols: Array[String] = ["e3342f", "2f7fe0", "f6c915", "20c8c0"]
	if kind == 2:   # LOW: سد راه با چراغ نئون
		e.y0 = 0.0; e.y1 = 0.9; e.half_d = 0.45
		Gfx.box(n, Vector3(1.9, 0.55, 0.5), Vector3(0, 0.3, 0), _m("23203a", 0.0, 0.6))
		Gfx.box(n, Vector3(1.92, 0.12, 0.54), Vector3(0, 0.62, 0), _m("ff2d95", 2.4))
		Gfx.box(n, Vector3(1.92, 0.12, 0.54), Vector3(0, 0.12, 0), _m("27e8ff", 2.0))
	elif kind == 3: # OVERHEAD: روگذر با تابلو
		e.y0 = 1.0; e.y1 = 6.0; e.half_d = 0.9
		for sx in [-1.0, 1.0]:
			Gfx.box(n, Vector3(0.2, 3.2, 0.2), Vector3(sx, 1.6, 0), _m("23203a"))
		Gfx.box(n, Vector3(2.4, 0.9, 0.4), Vector3(0, 2.4, 0), _m("14102a"))
		Gfx.box(n, Vector3(2.2, 0.12, 0.44), Vector3(0, 1.98, 0), _m("27e8ff", 2.6))
		Gfx.box(n, Vector3(2.2, 0.12, 0.44), Vector3(0, 2.82, 0), _m("ff2d95", 2.6))
	else:           # FULL: ماشین
		e.y0 = 0.0; e.y1 = 1.7; e.half_d = 1.3
		var col: String = body_cols[v % body_cols.size()]
		Gfx.box(n, Vector3(1.75, 0.6, 3.6), Vector3(0, 0.55, 0), _m(col, 0.0, 0.3, 0.4))
		Gfx.box(n, Vector3(1.5, 0.55, 1.9), Vector3(0, 1.12, 0.1), _m("101018", 0.0, 0.2, 0.2))
		Gfx.box(n, Vector3(1.4, 0.1, 0.05), Vector3(0, 0.72, 1.8), _m("ff2a2a", 3.0))
		Gfx.box(n, Vector3(1.4, 0.1, 0.05), Vector3(0, 0.72, -1.8), _m("fffbd0", 3.0))
		for sx in [-0.9, 0.9]:
			for sz in [-1.15, 1.15]:
				Gfx.cyl(n, 0.34, 0.34, 0.24, Vector3(sx, 0.34, sz), _m("0c0c0e", 0.0, 0.9), Vector3(0, 0, 90), 10)
		Gfx.box(n, Vector3(1.78, 0.06, 3.4), Vector3(0, 0.06, 0), _m("27e8ff", 1.6))
		e.y1 = 1.7


static func _obs_crate(kind: int, v: int, e: Object, n: Node3D) -> void:
	var wood := _m("c8873a", 0.0, 0.8)
	var dark := _m("7a4a1c", 0.0, 0.85)
	if kind == 2:   # LOW: یک جعبه (قابل شکستن/سوارشدن)
		e.y0 = 0.0; e.y1 = 0.9; e.half_d = 0.55
		Gfx.box(n, Vector3(1.0, 0.9, 1.0), Vector3(-0.5, 0.45, 0), wood)
		Gfx.box(n, Vector3(1.0, 0.9, 1.0), Vector3(0.5, 0.45, 0), wood, Vector3(0, 6, 0))
		for sx in [-0.5, 0.5]:
			Gfx.box(n, Vector3(1.04, 0.1, 1.04), Vector3(sx, 0.05, 0), dark)
			Gfx.box(n, Vector3(1.04, 0.1, 1.04), Vector3(sx, 0.85, 0), dark)
			Gfx.box(n, Vector3(0.12, 0.9, 1.04), Vector3(sx - 0.43, 0.45, 0), dark)
			Gfx.box(n, Vector3(0.12, 0.9, 1.04), Vector3(sx + 0.43, 0.45, 0), dark)
		if v % 2 == 0:
			Gfx.label(n, "!", Vector3(0.0, 0.5, 0.56), 90, Color("ff3b2f"), 0.012)
	elif kind == 3: # OVERHEAD: چوب افقی روی دو تیر
		e.y0 = 1.0; e.y1 = 6.0; e.half_d = 0.9
		for sx in [-1.0, 1.0]:
			Gfx.cyl(n, 0.16, 0.2, 3.0, Vector3(sx, 1.5, 0), dark, Vector3.ZERO, 8)
		Gfx.cyl(n, 0.22, 0.22, 2.4, Vector3(0, 2.3, 0), wood, Vector3(0, 0, 90), 8)
		Gfx.box(n, Vector3(2.4, 0.12, 0.5), Vector3(0, 1.98, 0), _m("ff8a1f", 1.0))
	else:           # FULL: ستون جعبه‌های فلزی
		e.y0 = 0.0; e.y1 = 2.8; e.half_d = 1.3
		for i in 3:
			Gfx.box(n, Vector3(1.9, 0.92, 2.3), Vector3(0, 0.46 + i * 0.92, 0), _m("5a6270", 0.0, 0.4, 0.6) if i != 1 else wood)
			Gfx.box(n, Vector3(1.95, 0.1, 2.35), Vector3(0, 0.05 + i * 0.92, 0), dark)


static func _obs_ring(kind: int, v: int, e: Object, n: Node3D) -> void:
	if kind == 2:   # LOW: ردیف خار
		e.y0 = 0.0; e.y1 = 0.9; e.half_d = 0.45
		Gfx.box(n, Vector3(1.9, 0.14, 0.9), Vector3(0, 0.07, 0), _m("4a4f58", 0.0, 0.4, 0.8))
		for i in 5:
			Gfx.cyl(n, 0.001, 0.17, 0.8, Vector3(-0.76 + i * 0.38, 0.5, 0), _m("dfe6ee", 0.0, 0.2, 0.9), Vector3.ZERO, 6)
	elif kind == 3: # OVERHEAD: پل چوبی/صخره‌ای
		e.y0 = 1.0; e.y1 = 6.0; e.half_d = 0.9
		for sx in [-1.0, 1.0]:
			Gfx.box(n, Vector3(0.7, 3.0, 0.9), Vector3(sx, 1.5, 0), _m("7a4a22" if v % 2 == 0 else "d9a85a", 0.0, 0.9))
		Gfx.box(n, Vector3(2.7, 0.9, 1.0), Vector3(0, 2.5, 0), _m("d9a85a" if v % 2 == 0 else "7a4a22", 0.0, 0.9))
		Gfx.box(n, Vector3(2.7, 0.1, 1.04), Vector3(0, 3.0, 0), _m("4aa832"))
	else:           # FULL: دیوار شطرنجی
		e.y0 = 0.0; e.y1 = 2.8; e.half_d = 1.3
		for ix in 2:
			for iy in 3:
				var dark := (ix + iy) % 2 == 0
				Gfx.box(n, Vector3(0.95, 0.93, 2.3), Vector3(-0.475 + ix * 0.95, 0.465 + iy * 0.93, 0), _m("7a4a22" if dark else "d9a85a", 0.0, 0.9))


# ============================================================
#                             سکه‌ها
# ============================================================
static func coin_model(id: String) -> Node3D:
	var n := Node3D.new()
	match id:
		"brick":
			_brick(n, Vector3(0.5, 0.28, 0.5), Vector3.ZERO, "f6c915")
			n.scale = Vector3.ONE * 1.4
		"moto":
			Gfx.cyl(n, 0.4, 0.4, 0.1, Vector3.ZERO, _m("27ffa0", 2.0, 0.3), Vector3(90, 0, 0), 6)
			Gfx.cyl(n, 0.22, 0.22, 0.12, Vector3.ZERO, _m("003a24", 0.0, 0.4), Vector3(90, 0, 0), 6)
		"crate":
			Gfx.sphere(n, 0.34, Vector3(0, 0, 0), _m("ff8a1f", 0.25, 0.5), 10)
			Gfx.box(n, Vector3(0.28, 0.06, 0.12), Vector3(0.08, 0.36, 0), _m("2faa4a"), Vector3(0, 0, 25))
		"ring":
			P.ring(n, 0.42, 0.11, Vector3.ZERO, _m("ffd000", 1.1, 0.25, 0.7), Vector3(90, 0, 0), 16)
		_:
			n.free()
			return ModesExt.coin(id)
	return n


# ============================================================
#                        پرتال و وسیله‌ی نقلیه
# ============================================================
static func portal_model(color: Color, label: String, skin: int = 0) -> Node3D:
	return PortalSkins.build(skin, color, label)


## ماشین/موتور بازیکن (ظاهر کامل سواره جایگزین مدل کاراکتر می‌شود)
static func vehicle(id: String) -> Node3D:
	var n := Node3D.new()
	if id == "moto":
		var body := _m("ff2d95", 0.0, 0.25, 0.5)
		for sz in [-0.55, 0.6]:
			Gfx.cyl(n, 0.32, 0.32, 0.16, Vector3(0, 0.32, sz), _m("101014", 0.0, 0.9), Vector3(0, 0, 90), 12)
			Gfx.cyl(n, 0.18, 0.18, 0.18, Vector3(0, 0.32, sz), _m("27e8ff", 1.5, 0.3), Vector3(0, 0, 90), 10)
		Gfx.box(n, Vector3(0.34, 0.34, 1.0), Vector3(0, 0.62, 0.0), body)
		Gfx.box(n, Vector3(0.3, 0.1, 0.55), Vector3(0, 0.86, 0.15), _m("1a1a22"))
		Gfx.box(n, Vector3(0.6, 0.06, 0.06), Vector3(0, 1.0, -0.45), _m("c8ccd4", 0.0, 0.2, 0.9))
		Gfx.box(n, Vector3(0.22, 0.2, 0.06), Vector3(0, 0.78, -0.62), _m("fff4c0", 3.0))
		Gfx.box(n, Vector3(0.3, 0.06, 0.04), Vector3(0, 0.72, 0.62), _m("ff2a2a", 3.0))
		# سوار
		Gfx.box(n, Vector3(0.42, 0.62, 0.3), Vector3(0, 1.2, 0.22), _m("20243a", 0.0, 0.6), Vector3(-18, 0, 0))
		Gfx.sphere(n, 0.24, Vector3(0, 1.72, 0.1), _m("e8eef8", 0.0, 0.3, 0.4), 10)
		Gfx.box(n, Vector3(0.34, 0.12, 0.2), Vector3(0, 1.74, -0.06), _m("27e8ff", 1.6))
		Gfx.glow(n, Vector3(0, 0.1, 0.0), 2.4, Color(1.0, 0.2, 0.6, 0.35))
	return n
