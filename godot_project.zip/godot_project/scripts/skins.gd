extends Node
## مدیریت کاراکترها (Autoload با نام «Skins»):
## کاراکترهای آماده + کاراکترهای دلخواه کاربر:
##   • اسکین ماینکرفت (PNG)         • یک عکس معمولی
##   • ساخت از چند عکس (صورت، جلو، پشت، راست، چپ) با سبک پیکسلی ۶۴×۶۴ یا HD
## ذخیره/بارگذاری، انتخاب، حذف، خروجی PNG اسکین و ساخت تصویر بندانگشتی.

signal changed
signal glb_cfg_changed

const SkinLib := preload("res://scripts/skin_lib.gd")
const GlbModel := preload("res://scripts/glb_model.gd")
const DIR := "user://skins/"
const INDEX := "user://skins.cfg"
const MAX_CUSTOM := 500
const MAX_PHOTO_SIDE := 768
const MODE_NAMES := ["خودکار", "اسکین", "عکس"]
const SLIM_NAMES := ["خودکار", "کلاسیک", "باریک"]

## هر ورودی: {id, name, preset (اندیس یا -1), file, files (اسلات→مسیر)، mode, slim_mode, style}
var entries: Array[Dictionary] = []
var current_id := "preset0"

var texture: ImageTexture
var slim := false
var smooth := false
var is_photo := false      # عکس‌محور (تک‌عکس یا چندعکس)
var info := ""

var _results := {}
var _thumbs := {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in SkinLib.PRESET_NAMES.size():
		entries.append(_new_entry("preset%d" % i, SkinLib.PRESET_NAMES[i], i))
	_load_index()
	if get_entry(current_id).is_empty():
		current_id = "preset0"
	_apply()


func _new_entry(id: String, nm: String, preset: int) -> Dictionary:
	return {"id": id, "name": nm, "preset": preset, "file": "", "files": {}, "mode": 0, "slim_mode": 0, "style": 0, "glb": "", "glb_yaw": 0, "glb_cfg": {}, "origin": ""}


# ------------------------- جستجو -------------------------
func get_entry(id: String) -> Dictionary:
	for e in entries:
		if e["id"] == id:
			return e
	return {}


func current_entry() -> Dictionary:
	return get_entry(current_id)


func is_custom(e: Dictionary) -> bool:
	return not e.is_empty() and int(e["preset"]) < 0


## کلید پایدار کاراکتر برای فروشگاه (آیتم‌های انیمیشن/صدای هر کاراکتر به آن وصل‌اند):
## کاراکترِ نصب‌شده از فروشگاه = شناسه‌ی آیتمش؛ بقیه = شناسه‌ی خودشان
func char_key(e: Dictionary) -> String:
	var o := String(e.get("origin", ""))
	return o if (o != "" and o != "paint") else String(e.get("id", ""))


func set_origin(id: String, origin: String) -> void:
	var e := get_entry(id)
	if not e.is_empty():
		e["origin"] = origin
		_save_index()


func is_glb(e: Dictionary) -> bool:
	return not e.is_empty() and str(e.get("glb", "")) != ""


func current_is_glb() -> bool:
	return is_glb(current_entry())


func is_multi(e: Dictionary) -> bool:
	return is_custom(e) and not (e["files"] as Dictionary).is_empty()


func custom_count() -> int:
	var n := 0
	for e in entries:
		if int(e["preset"]) < 0:
			n += 1
	return n


# ------------------------- انتخاب -------------------------
func select(id: String) -> void:
	if get_entry(id).is_empty():
		return
	current_id = id
	_apply()
	_save_index()
	changed.emit()


# ------------------------- افزودن / حذف -------------------------
func _prepare(src: Image) -> Image:
	var img := src.duplicate() as Image
	img.convert(Image.FORMAT_RGBA8)
	if not SkinLib.looks_like_skin(img):
		var m := maxi(img.get_width(), img.get_height())
		if m > MAX_PHOTO_SIDE:
			var f := float(MAX_PHOTO_SIDE) / float(m)
			img.resize(maxi(8, int(img.get_width() * f)), maxi(8, int(img.get_height() * f)), Image.INTERPOLATE_LANCZOS)
	return img


func _new_id() -> String:
	var id := "c%d" % int(Time.get_unix_time_from_system() * 1000.0)
	while not get_entry(id).is_empty():
		id += "x"
	return id


## تصویر (اسکین ماینکرفت یا یک عکس) را به‌عنوان کاراکتر جدید اضافه و انتخاب می‌کند.
## در صورت خطا متن خطا را برمی‌گرداند، وگرنه "".
func add_image(src: Image, display_name: String) -> String:
	if custom_count() >= MAX_CUSTOM:
		return "حداکثر %d کاراکتر ذخیره می‌شود؛ اول یکی را حذف کن" % MAX_CUSTOM
	if src == null or src.is_empty() or src.get_width() < 8 or src.get_height() < 8:
		return "تصویر معتبر نیست"
	var img := _prepare(src)
	DirAccess.make_dir_recursive_absolute(DIR)
	var id := _new_id()
	var file := "%s%s.png" % [DIR, id]
	if img.save_png(file) != OK:
		return "ذخیره‌ی تصویر ناموفق بود"
	var e := _new_entry(id, _clean_name(display_name), -1)
	e["file"] = file
	entries.append(e)
	select(id)
	return ""


## ساخت کاراکتر از چند عکس. slots: {"face","front","back","right","left"} → Image
func add_multi(slots: Dictionary, style: int, display_name: String) -> String:
	if custom_count() >= MAX_CUSTOM:
		return "حداکثر %d کاراکتر ذخیره می‌شود؛ اول یکی را حذف کن" % MAX_CUSTOM
	var prepared := {}
	for k in SkinLib.SLOT_NAMES:
		if slots.has(k) and slots[k] is Image and not (slots[k] as Image).is_empty():
			prepared[k] = _prepare(slots[k])
	var test := SkinLib.build_from_photos(prepared, style)
	if test.has("error"):
		return str(test["error"])
	DirAccess.make_dir_recursive_absolute(DIR)
	var id := _new_id()
	var files := {}
	for k in prepared:
		var path := "%s%s_%s.png" % [DIR, id, k]
		if (prepared[k] as Image).save_png(path) != OK:
			return "ذخیره‌ی تصویر ناموفق بود"
		files[k] = path
	var e := _new_entry(id, _clean_name(display_name), -1)
	e["files"] = files
	e["style"] = style
	entries.append(e)
	select(id)
	return ""


## کاراکتر سه‌بعدی GLB. فایل در حافظه‌ی برنامه کپی می‌شود. خطا یا "".
func add_glb(path: String, display_name: String) -> String:
	if custom_count() >= MAX_CUSTOM:
		return "حداکثر %d کاراکتر ذخیره می‌شود؛ اول یکی را حذف کن" % MAX_CUSTOM
	DirAccess.make_dir_recursive_absolute(DIR)
	var id := _new_id()
	var dst := "%s%s.glb" % [DIR, id]
	var cerr := ModelImport.to_glb(path, dst)
	if cerr != "":
		DirAccess.remove_absolute(dst)
		return cerr
	var test := GlbModel.new()
	add_child(test)
	var ok := test.load_from_file(dst, 0)
	var msg := test.load_error
	test.queue_free()
	if not ok:
		DirAccess.remove_absolute(dst)
		return msg if msg != "" else "مدل بارگذاری نشد"
	var nm := display_name if display_name.strip_edges() != "" else path.get_file().get_basename()
	var e := _new_entry(id, _clean_name(nm), -1)
	e["glb"] = dst
	entries.append(e)
	select(id)
	return ""


## تنظیمات بدن/حرکت مدل GLB انتخاب‌شده (با پیش‌فرض‌ها ادغام می‌شود)
func glb_cfg(e: Dictionary) -> Dictionary:
	var out: Dictionary = GlbModel.DEFAULT_CFG.duplicate(true)
	var mine: Dictionary = e.get("glb_cfg", {})
	for k in mine:
		out[k] = mine[k]
	return out


func set_glb_cfg(key: String, value) -> void:
	var e := current_entry()
	if not is_glb(e):
		return
	var c: Dictionary = e.get("glb_cfg", {})
	c[key] = value
	e["glb_cfg"] = c
	_save_index()
	glb_cfg_changed.emit()


func set_glb_map(state: String, clip: String) -> void:
	var e := current_entry()
	if not is_glb(e):
		return
	var c: Dictionary = e.get("glb_cfg", {})
	var m: Dictionary = c.get("map", {})
	if clip == "":
		m.erase(state)
	else:
		m[state] = clip
	c["map"] = m
	e["glb_cfg"] = c
	_save_index()
	glb_cfg_changed.emit()


func reset_glb_cfg() -> void:
	var e := current_entry()
	if is_glb(e):
		e["glb_cfg"] = {}
		_save_index()
		glb_cfg_changed.emit()


func cycle_glb_yaw() -> void:
	var e := current_entry()
	if not is_glb(e):
		return
	e["glb_yaw"] = (int(e["glb_yaw"]) + 1) % 4
	_refresh_entry(e)


func _clean_name(display_name: String) -> String:
	var nm := display_name.strip_edges()
	if nm.is_empty():
		nm = "کاراکتر %d" % (custom_count() + 1)
	return nm.left(16)


func delete_current() -> void:
	var e := current_entry()
	if not is_custom(e):
		return
	delete(e["id"])


func delete(id: String) -> void:
	var e := get_entry(id)
	if not is_custom(e):
		return
	if str(e["file"]) != "" and FileAccess.file_exists(e["file"]):
		DirAccess.remove_absolute(e["file"])
	if is_glb(e) and FileAccess.file_exists(e["glb"]):
		DirAccess.remove_absolute(e["glb"])
	for k in (e["files"] as Dictionary):
		var path: String = e["files"][k]
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
	entries.erase(e)
	_forget(id)
	if current_id == id:
		current_id = "preset0"
	_apply()
	_save_index()
	changed.emit()


# ------------------------- تنظیمات هر کاراکتر دلخواه -------------------------
func cycle_mode() -> void:
	var e := current_entry()
	if not is_custom(e) or is_multi(e):
		return
	e["mode"] = (int(e["mode"]) + 1) % MODE_NAMES.size()
	_refresh_entry(e)


func cycle_slim() -> void:
	var e := current_entry()
	if not is_custom(e) or is_multi(e):
		return
	e["slim_mode"] = (int(e["slim_mode"]) + 1) % SLIM_NAMES.size()
	_refresh_entry(e)


## سبک عکس‌محور: پیکسلی ↔ HD
func cycle_style() -> void:
	var e := current_entry()
	if not is_custom(e):
		return
	e["style"] = (int(e["style"]) + 1) % SkinLib.STYLE_NAMES.size()
	_refresh_entry(e)


func _refresh_entry(e: Dictionary) -> void:
	_forget(e["id"])
	_apply()
	_save_index()
	changed.emit()


func _forget(id: String) -> void:
	for k in _results.keys():
		if str(k).begins_with(id + "|"):
			_results.erase(k)
	_thumbs.erase(id)


# ------------------------- پردازش و اعمال -------------------------
func result_for(e: Dictionary) -> Dictionary:
	var key := "%s|%d|%d|%d" % [e["id"], int(e["mode"]), int(e["slim_mode"]), int(e["style"])]
	if _results.has(key):
		return _results[key]
	var res: Dictionary
	if int(e["preset"]) >= 0:
		res = SkinLib.process(SkinLib.preset(int(e["preset"])), 1, 1)
	elif is_glb(e):
		res = SkinLib.process(SkinLib.preset(0), 1, 1)
	elif is_multi(e):
		var slots := {}
		for k in (e["files"] as Dictionary):
			var im := Image.load_from_file(e["files"][k])
			if im != null and not im.is_empty():
				slots[k] = im
		res = SkinLib.build_from_photos(slots, int(e["style"]))
		if res.has("error"):
			res = SkinLib.process(SkinLib.preset(0), 1, 1)
			res["missing"] = true
	else:
		var src := Image.load_from_file(e["file"])
		if src == null or src.is_empty():
			res = SkinLib.process(SkinLib.preset(0), 1, 1)
			res["missing"] = true
		else:
			res = SkinLib.process(src, int(e["mode"]), int(e["slim_mode"]), int(e["style"]))
			if res.has("error"):
				res = SkinLib.process(SkinLib.preset(0), 1, 1)
				res["missing"] = true
	_results[key] = res
	return res


## نتیجه‌ی ساخت از اسلات‌های موقت (برای پیش‌نمایش زنده‌ی صفحه‌ی ساخت)
func preview_from_slots(slots: Dictionary, style: int) -> Dictionary:
	var prepared := {}
	for k in SkinLib.SLOT_NAMES:
		if slots.has(k) and slots[k] is Image and not (slots[k] as Image).is_empty():
			prepared[k] = _prepare(slots[k])
	return SkinLib.build_from_photos(prepared, style)


func _apply() -> void:
	var e := current_entry()
	if e.is_empty():
		e = entries[0]
		current_id = e["id"]
	var res := result_for(e)
	var img: Image = (res["image"] as Image).duplicate()
	slim = res["slim"]
	is_photo = bool(res.get("built", false))
	smooth = int(res["scale"]) > 1
	if smooth:
		img.generate_mipmaps()
	texture = ImageTexture.create_from_image(img)
	var s: int = res["scale"]
	if is_glb(e):
		info = "مدل سه‌بعدی GLB — جهت: %d°" % (int(e["glb_yaw"]) * 90)
	elif res.get("missing", false):
		info = "فایل این کاراکتر پیدا نشد"
	elif int(e["preset"]) >= 0:
		info = "کاراکتر آماده"
	elif is_multi(e):
		info = "ساخته‌شده از %d عکس — %s" % [(e["files"] as Dictionary).size(), "پیکسلی ۶۴×۶۴ (اسکین واقعی)" if s == 1 else "HD %d×%d" % [64 * s, 64 * s]]
	elif is_photo:
		info = "عکس — %s" % ("پیکسلی ۶۴×۶۴ (اسکین واقعی)" if s == 1 else "HD %d×%d" % [64 * s, 64 * s])
	else:
		info = "اسکین ماینکرفت %d×%d — بازوی %s" % [64 * s, 64 * s, "باریک" if slim else "کلاسیک"]


# ------------------------- خروجی PNG اسکین -------------------------
## اسکین فعلی را به‌صورت PNG استاندارد ماینکرفت ذخیره می‌کند. برمی‌گرداند: {"ok": bool, "path": String}
func export_current() -> Dictionary:
	var e := current_entry()
	if is_glb(e):
		return {"ok": false, "path": ""}
	var res := result_for(e)
	return export_image(res["image"], str(e["name"]))


## هر تصویر اسکین را در پوشه‌ی Pictures/SekkeRunner (یا user://exports) ذخیره می‌کند
func export_image(img: Image, nm: String, prefix: String = "skin") -> Dictionary:
	var base := "%s_%s.png" % [prefix, nm.validate_filename()]
	var dirs: Array[String] = []
	if OS.get_name() == "Android":
		dirs.append("/storage/emulated/0/Pictures/SekkeRunner")
	else:
		var pics := OS.get_system_dir(OS.SYSTEM_DIR_PICTURES)
		if pics != "":
			dirs.append(pics.path_join("SekkeRunner"))
	dirs.append("user://exports")
	for d in dirs:
		if DirAccess.make_dir_recursive_absolute(d) == OK or DirAccess.dir_exists_absolute(d):
			var path := d.path_join(base)
			if img.save_png(path) == OK:
				return {"ok": true, "path": ProjectSettings.globalize_path(path) if path.begins_with("user://") else path}
	return {"ok": false, "path": ""}


## کاراکتر نقاشی‌شده در استودیو را ذخیره می‌کند. اگر id یکی از کاراکترهای دلخواه تک‌فایلی باشد روی همان می‌نویسد.
## برمی‌گرداند: خطا یا "" ؛ id ذخیره‌شده در out_id
func save_painted(id: String, img: Image, p_slim: bool, display_name: String) -> Dictionary:
	var e := get_entry(id)
	var overwrite := is_custom(e) and not is_multi(e) and str(e["file"]) != "" and not str(e["file"]).begins_with("glb:")
	if not overwrite and custom_count() >= MAX_CUSTOM:
		return {"error": "حداکثر %d کاراکتر ذخیره می‌شود؛ اول یکی را حذف کن" % MAX_CUSTOM}
	DirAccess.make_dir_recursive_absolute(DIR)
	if overwrite:
		if img.save_png(e["file"]) != OK:
			return {"error": "ذخیره‌ی تصویر ناموفق بود"}
		e["mode"] = 1
		e["slim_mode"] = 2 if p_slim else 1
		e["origin"] = "paint"
		if display_name.strip_edges() != "":
			e["name"] = _clean_name(display_name)
		_refresh_entry(e)
		select(e["id"])
		return {"id": e["id"]}
	var nid := _new_id()
	var file := "%s%s.png" % [DIR, nid]
	if img.save_png(file) != OK:
		return {"error": "ذخیره‌ی تصویر ناموفق بود"}
	var ne := _new_entry(nid, _clean_name(display_name), -1)
	ne["file"] = file
	ne["mode"] = 1
	ne["slim_mode"] = 2 if p_slim else 1
	ne["origin"] = "paint"
	entries.append(ne)
	select(nid)
	return {"id": nid}


# ------------------------- تصویر بندانگشتی (صورت کاراکتر) -------------------------
func thumbnail(e: Dictionary) -> Texture2D:
	var id: String = e["id"]
	if _thumbs.has(id):
		return _thumbs[id]
	if is_glb(e):
		return _glb_thumb(e)
	var res := result_for(e)
	var img: Image = res["image"]
	var s: int = res["scale"]
	var face := img.get_region(Rect2i(8 * s, 8 * s, 8 * s, 8 * s))
	var hat := img.get_region(Rect2i(40 * s, 8 * s, 8 * s, 8 * s))
	face.convert(Image.FORMAT_RGB8)
	face.convert(Image.FORMAT_RGBA8)
	face.blend_rect(hat, Rect2i(0, 0, 8 * s, 8 * s), Vector2i.ZERO)
	face.resize(96, 96, Image.INTERPOLATE_NEAREST if s == 1 else Image.INTERPOLATE_LANCZOS)
	var t := ImageTexture.create_from_image(face)
	_thumbs[id] = t
	return t


# ------------------------- تصویر بندانگشتی مدل GLB (رندر یک‌باره) -------------------------
func _glb_thumb(e: Dictionary) -> Texture2D:
	var id: String = e["id"]
	var ph := Image.create(128, 128, false, Image.FORMAT_RGBA8)
	for y in 128:
		for x in 128:
			var d := Vector2(x - 64, y - 64).length() / 90.0
			ph.set_pixel(x, y, Color("5a1a8a").lerp(Color("c66bff"), clampf(1.0 - d, 0.0, 1.0)))
	var t := ImageTexture.create_from_image(ph)
	_thumbs[id] = t
	_render_glb_thumb(e, t)
	return t


func _render_glb_thumb(e: Dictionary, t: ImageTexture) -> void:
	var vp := SubViewport.new()
	vp.size = Vector2i(128, 128)
	vp.own_world_3d = true
	vp.transparent_bg = true
	vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(vp)
	var env := Environment.new()
	env.background_mode = Environment.BG_CLEAR_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("ffe6c8")
	env.ambient_light_energy = 0.9
	var cam := Camera3D.new()
	cam.environment = env
	cam.fov = 30.0
	vp.add_child(cam)
	cam.transform = Transform3D(Basis.looking_at(Vector3(0, 1.0, 0) - Vector3(0, 1.1, 4.4), Vector3.UP), Vector3(0, 1.1, 4.4))
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-35.0, 30.0, 0.0)
	vp.add_child(light)
	var m := GlbModel.new()
	vp.add_child(m)
	if m.load_from_file(str(e["glb"]), int(e["glb_yaw"])):
		m.rotation.y = PI
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	if is_instance_valid(vp):
		var img := vp.get_texture().get_image()
		if img != null and not img.is_empty():
			img.convert(Image.FORMAT_RGBA8)
			if img.get_size() == Vector2i(128, 128):
				t.update(img)
		vp.queue_free()


# ------------------------- ذخیره‌سازی -------------------------
func _save_index() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("main", "current", current_id)
	for e in entries:
		if int(e["preset"]) < 0:
			var sec := "skin_" + str(e["id"])
			cfg.set_value(sec, "name", e["name"])
			cfg.set_value(sec, "file", e["file"])
			cfg.set_value(sec, "mode", e["mode"])
			cfg.set_value(sec, "slim_mode", e["slim_mode"])
			cfg.set_value(sec, "style", e["style"])
			cfg.set_value(sec, "glb", e["glb"])
			cfg.set_value(sec, "glb_yaw", e["glb_yaw"])
			cfg.set_value(sec, "glb_cfg", var_to_str(e["glb_cfg"]))
			cfg.set_value(sec, "origin", e["origin"])
			for k in (e["files"] as Dictionary):
				cfg.set_value(sec, "slot_" + str(k), e["files"][k])
	cfg.save(INDEX)


func _load_index() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(INDEX) != OK:
		return
	current_id = str(cfg.get_value("main", "current", "preset0"))
	for sec in cfg.get_sections():
		if not sec.begins_with("skin_"):
			continue
		var e := _new_entry(sec.trim_prefix("skin_"), str(cfg.get_value(sec, "name", "کاراکتر")), -1)
		e["mode"] = int(cfg.get_value(sec, "mode", 0))
		e["slim_mode"] = int(cfg.get_value(sec, "slim_mode", 0))
		e["style"] = int(cfg.get_value(sec, "style", 0))
		var files := {}
		for k in SkinLib.SLOT_NAMES:
			var p := str(cfg.get_value(sec, "slot_" + k, ""))
			if p != "" and FileAccess.file_exists(p):
				files[k] = p
		var file := str(cfg.get_value(sec, "file", ""))
		var glb := str(cfg.get_value(sec, "glb", ""))
		if glb != "" and FileAccess.file_exists(glb):
			e["glb"] = glb
			e["glb_yaw"] = int(cfg.get_value(sec, "glb_yaw", 0))
			var parsed = str_to_var(str(cfg.get_value(sec, "glb_cfg", "{}")))
			e["glb_cfg"] = parsed if parsed is Dictionary else {}
		elif not files.is_empty():
			e["files"] = files
		elif file != "" and FileAccess.file_exists(file):
			e["file"] = file
		else:
			continue
		e["origin"] = str(cfg.get_value(sec, "origin", ""))
		entries.append(e)
