class_name PortalSkins
extends RefCounted
## ظاهرهای مختلف پرتال (همه از صفر ساخته شده). هر ظاهر رنگ جهان مقصد را می‌گیرد.

const Gfx := preload("res://scripts/gfx.gd")
const P := preload("res://scripts/props.gd")

const NAMES: Array[String] = ["حلقه‌ی نئونی", "دروازه‌ی سنگی باستانی", "گرداب مارپیچ", "کریستال بلورین", "قوس برقی", "تُوری سرخ", "سیاه‌چاله", "قاب پیکسلی"]


static func _m(hex: String, emit: float = 0.0, rough: float = 0.5, metal: float = 0.0) -> StandardMaterial3D:
	return P.m(hex, emit, rough, metal)


static func _disc_mat(c: Color, a: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(c.r, c.g, c.b, a)
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m


## ظاهر و برچسب دروازه‌ی بازگشت هر جهان: [شماره‌ی ظاهر, نوشته]
const RETURN_STYLES := {
	"brick": [7, "برگشت به جاده"], "moto": [4, "خروج از شهر نئون"], "crate": [1, "درِ خروج"],
	"ring": [0, "حلقه‌ی بازگشت"], "space": [6, "سیاه‌چاله‌ی بازگشت"], "candy": [3, "کریستال شیرین بازگشت"],
	"shrine": [5, "تُوری بازگشت"], "pirate": [2, "گرداب بازگشت"], "haunted": [1, "دروازه‌ی گورستان"],
	"volcano": [4, "جرقه‌ی بازگشت"], "sky": [0, "حلقه‌ی ابری بازگشت"], "reef": [2, "گرداب مرجانی بازگشت"],
}


static func return_style(world_id: String) -> Array:
	return RETURN_STYLES.get(world_id, [0, "بازگشت به جهان اصلی"])


## گردابِ سه‌بعدی: قیف شیشه‌ای + حلقه‌های تونل + بازوهای مارپیچ + جرقه‌های چرخان
static func _vortex(n: Node3D, color: Color, R: float) -> void:
	var hex := color.to_html(false)
	var glow := _m(hex, 3.0, 0.3)
	var white := _m("ffffff", 3.0, 0.3)
	# قیف
	var fm := _disc_mat(color, 0.38)
	var fun := Gfx.cyl(n, R * 0.95, R * 0.35, 2.6, Vector3(0, 3.7, -1.3), fm, Vector3(90, 0, 0), 24)
	fun.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# حلقه‌های تونل (در عمق، کوچک‌تر)
	var tun := _pivot(n, -55.0, -0.2)
	for i in 4:
		var z := -0.5 - float(i) * 0.6
		var r := R * (0.88 - float(i) * 0.15)
		P.ring(tun, r, 0.13, Vector3(0, 0, z), _m(hex if i % 2 == 0 else "ffffff", 2.6, 0.3), Vector3(90, 0, 0), 24)
		Gfx.box(tun, Vector3(0.35, 0.12, 0.12), Vector3(r, 0, z), white)
	# بازوهای مارپیچ
	var spi := _pivot(n, 95.0, -0.15)
	for arm in 3:
		for k in 7:
			var f := float(k) / 6.0
			var a := deg_to_rad(arm * 120.0 + f * 150.0)
			var rr := R * (0.28 + f * 0.62)
			Gfx.sphere(spi, 0.2 + 0.22 * f, Vector3(cos(a) * rr, sin(a) * rr, -0.2 - (1.0 - f) * 1.2), glow if k % 2 == 0 else white, 6)
	# جرقه‌های مداری روی لبه
	var orb := _pivot(n, 150.0, 0.05)
	for i in 6:
		var a2 := TAU * float(i) / 6.0
		Gfx.sphere(orb, 0.24, Vector3(cos(a2) * R * 1.08, sin(a2) * R * 1.08, 0.0), white, 6)
		Gfx.glow(orb, Vector3(cos(a2) * R * 1.08, sin(a2) * R * 1.08, 0.0), 0.9, Color(color.r, color.g, color.b, 0.5))


static func _pivot(n: Node3D, speed: float, z: float = 0.0) -> Node3D:
	var pv := Node3D.new()
	pv.position = Vector3(0, 3.7, z)
	n.add_child(pv)
	var l: Array = n.get_meta("spin", [])
	l.append([pv, speed])
	n.set_meta("spin", l)
	return pv


static func _base(n: Node3D, ring: StandardMaterial3D) -> void:
	for sx in [-3.7, 3.7]:
		Gfx.box(n, Vector3(0.55, 0.5, 0.9), Vector3(sx, 0.25, 0), _m("23203a", 0.0, 0.5, 0.3))
		Gfx.box(n, Vector3(0.2, 0.5, 0.95), Vector3(sx, 0.25, 0), ring)


static func build(skin: int, color: Color, label: String) -> Node3D:
	var n := Node3D.new()
	var hex := color.to_html(false)
	var ring := _m(hex, 2.4, 0.3)
	var white := _m("ffffff", 2.0, 0.3)
	var cy := Vector3(0, 3.7, 0)
	match skin:
		1:       # دروازه‌ی سنگی با رون‌های درخشان
			var stone := _m("6a6a76", 0.0, 0.95)
			for sx in [-3.4, 3.4]:
				Gfx.box(n, Vector3(1.1, 7.0, 1.1), Vector3(sx, 3.5, 0), stone)
				Gfx.box(n, Vector3(1.4, 0.5, 1.4), Vector3(sx, 0.25, 0), _m("4a4a56", 0.0, 0.95))
				for i in 4:
					Gfx.box(n, Vector3(0.5, 0.14, 0.05), Vector3(sx, 1.4 + i * 1.4, 0.56), ring)
			Gfx.box(n, Vector3(8.6, 1.1, 1.2), Vector3(0, 7.2, 0), stone)
			Gfx.box(n, Vector3(2.0, 0.5, 0.06), Vector3(0, 7.2, 0.62), ring)
			Gfx.sphere(n, 0.4, Vector3(0, 8.1, 0), ring, 8)
			var dsc := P.disc(n, 3.2, 0.04, cy, _disc_mat(color, 0.3), 32)
			dsc.rotation_degrees.x = 90.0
			dsc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		2:       # گرداب مارپیچ
			for i in 5:
				var pv := _pivot(n, (60.0 + i * 25.0) * (1.0 if i % 2 == 0 else -1.0))
				P.ring(pv, 3.8 - i * 0.62, 0.16 - i * 0.015, Vector3.ZERO, _m(hex if i % 2 == 0 else "ffffff", 2.4, 0.3), Vector3(90, 0, 0), 28)
				Gfx.box(pv, Vector3(0.5, 0.18, 0.18), Vector3(3.8 - i * 0.62, 0, 0), white)
			var dsc2 := P.disc(n, 3.5, 0.04, cy, _disc_mat(color, 0.4), 32)
			dsc2.rotation_degrees.x = 90.0
			dsc2.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			_base(n, ring)
		3:       # کریستال
			for sgn in [-1.0, 1.0]:
				Gfx.box(n, Vector3(0.7, 7.0, 0.7), Vector3(sgn * 2.6, 3.7, 0), ring, Vector3(0, 0, sgn * 18.0))
			Gfx.box(n, Vector3(5.2, 0.7, 0.7), Vector3(0, 7.2, 0), ring, Vector3.ZERO)
			Gfx.box(n, Vector3(5.2, 0.7, 0.7), Vector3(0, 0.3, 0), ring, Vector3.ZERO)
			for i in 6:
				var sx2 := -3.6 if i % 2 == 0 else 3.6
				Gfx.cyl(n, 0.001, 0.35, 1.4 + (i % 3) * 0.5, Vector3(sx2 + (i % 3) * 0.2 * signf(sx2), 0.9 + i * 0.95, 0), _m("ffffff", 2.2, 0.1), Vector3(0, 0, sx2 * 4.0), 5)
			var dsc3 := P.disc(n, 3.0, 0.04, cy, _disc_mat(color, 0.3), 4)
			dsc3.basis = Basis(Vector3.RIGHT, PI * 0.5) * Basis(Vector3.UP, PI * 0.25)
			dsc3.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			_base(n, ring)
		4:       # قوس برقی
			P.ring(n, 3.7, 0.1, cy, ring, Vector3(90, 0, 0), 28)
			var pv4 := _pivot(n, 220.0)
			for i in 10:
				var a := TAU * float(i) / 10.0
				Gfx.box(pv4, Vector3(0.12, 0.7 + (i % 3) * 0.3, 0.12), Vector3(cos(a) * 3.7, sin(a) * 3.7, 0), white, Vector3(0, 0, rad_to_deg(a) + 90.0))
				Gfx.sphere(pv4, 0.2, Vector3(cos(a) * 3.2, sin(a) * 3.2, 0), ring, 6)
			var dsc4 := P.disc(n, 3.5, 0.04, cy, _disc_mat(color, 0.2), 32)
			dsc4.rotation_degrees.x = 90.0
			dsc4.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			_base(n, ring)
		5:       # تُوری سرخ
			var red := _m("d8261f", 0.3, 0.45)
			for sx in [-3.2, 3.2]:
				Gfx.cyl(n, 0.4, 0.46, 7.4, Vector3(sx, 3.7, 0), red, Vector3.ZERO, 10)
			Gfx.box(n, Vector3(9.4, 0.5, 0.8), Vector3(0, 7.5, 0), _m("1a1a20", 0.0, 0.5), Vector3.ZERO)
			Gfx.box(n, Vector3(7.8, 0.4, 0.6), Vector3(0, 6.4, 0), red)
			Gfx.box(n, Vector3(0.6, 1.1, 0.6), Vector3(0, 6.9, 0), red)
			Gfx.box(n, Vector3(0.8, 0.8, 0.1), Vector3(0, 6.9, 0.36), _m(hex, 2.0))
			var dsc5 := P.disc(n, 3.0, 0.04, Vector3(0, 3.2, 0), _disc_mat(color, 0.3), 32)
			dsc5.rotation_degrees.x = 90.0
			dsc5.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		6:       # سیاه‌چاله
			var dk := StandardMaterial3D.new()
			dk.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			dk.albedo_color = Color(0.0, 0.0, 0.02, 1.0)
			var core := P.disc(n, 3.1, 0.06, cy, dk, 32)
			core.rotation_degrees.x = 90.0
			core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			var pv6 := _pivot(n, 40.0)
			P.ring(pv6, 3.6, 0.35, Vector3.ZERO, _m("ffb050", 3.0, 0.3), Vector3(90, 0, 0), 32)
			P.ring(pv6, 4.2, 0.16, Vector3.ZERO, ring, Vector3(90, 0, 0), 32)
			Gfx.sphere(pv6, 0.3, Vector3(3.6, 0, 0), white, 6)
			Gfx.glow(n, Vector3(0, 3.7, -0.6), 11.0, Color(color.r, color.g, color.b, 0.16))
			_base(n, ring)
		7:       # قاب پیکسلی
			var cols: Array[String] = [hex, "ffffff", "ffd23f", hex]
			for i in 28:
				var a2 := TAU * float(i) / 28.0
				var px := roundf(cos(a2) * 3.6 / 0.6) * 0.6
				var py := roundf(sin(a2) * 3.6 / 0.6) * 0.6
				Gfx.box(n, Vector3(0.6, 0.6, 0.6), Vector3(px, 3.7 + py, 0), _m(cols[i % cols.size()], 1.8, 0.6))
			var pv7 := _pivot(n, 0.0)
			for i in 12:
				Gfx.box(pv7, Vector3(0.45, 0.45, 0.1), Vector3(sin(float(i) * 2.4) * 2.2, cos(float(i) * 1.7) * 2.2, 0), _m(hex, 2.2, 0.6))
			var dsc7 := P.disc(n, 3.1, 0.04, cy, _disc_mat(color, 0.25), 4)
			dsc7.basis = Basis(Vector3.RIGHT, PI * 0.5) * Basis(Vector3.UP, PI * 0.25)
			dsc7.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			_base(n, ring)
		_:       # حلقه‌ی نئونی (پیش‌فرض)
			P.ring(n, 3.7, 0.28, cy, ring, Vector3(90, 0, 0), 28)
			P.ring(n, 3.2, 0.12, cy, white, Vector3(90, 0, 0), 28)
			var dsc0 := P.disc(n, 3.3, 0.04, cy, _disc_mat(color, 0.32), 32)
			dsc0.rotation_degrees.x = 90.0
			dsc0.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			_base(n, ring)
	if skin != 6:
		_vortex(n, color, 3.0)
	# ستون نور: از دور دیده شود
	var bm := _disc_mat(color, 0.16)
	var beam := Gfx.cyl(n, 0.9, 1.4, 22.0, Vector3(0, 11.0, -0.4), bm, Vector3.ZERO, 12)
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Gfx.glow(n, Vector3(0, 3.7, -0.6), 8.0, Color(color.r, color.g, color.b, 0.14))
	if label != "":
		Gfx.label(n, label, Vector3(0, 9.4 if skin == 1 or skin == 5 else 8.7, 0.0), 80, Color.WHITE, 0.028)
	return n


## بعد از add_child صدا بزن: بخش‌های چرخان را می‌چرخاند
static func animate(n: Node3D) -> void:
	if not n.has_meta("spin"):
		return
	for it: Array in n.get_meta("spin"):
		var pv: Node3D = it[0]
		var sp: float = it[1]
		if absf(sp) < 0.1:
			continue
		var tw := pv.create_tween().set_loops()
		tw.tween_property(pv, "rotation_degrees:z", 360.0 * signf(sp), 360.0 / absf(sp)).from(0.0)
