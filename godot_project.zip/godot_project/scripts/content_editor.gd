extends Node
## ویرایشگرهای مالک:
##   «ویرایشگر محتوا»: متن‌ها، بخش‌های منو (افزودن/حذف/ترتیب/سفارشی)، قابلیت‌های نسخه‌ی عمومی، انتشار برای همه
##   «قوانین کاراکتر»: صدا و انیمیشن مخصوص هر کاراکتر بر اساس رویداد (مسافت، پرش، سکه، ...)

var ui
var content: Control
var rules: Control
var chooser: Control
var _ch_target := "char"
var _ch_list: VBoxContainer
var _ch_title: Label
var _ch_chaser_btn: Button
var _ch_add: Button
var _rl_target := "char"
const UiArt := preload("res://scripts/ui_art.gd")
const SoundPanel := preload("res://scripts/sound_panel.gd")
var _tab := 0
var _tab_btns := {}
var _look_list: VBoxContainer
var _panels: Array[Control] = []
var _text_list: VBoxContainer
var _search: LineEdit
var _menu_list: VBoxContainer
var _store_list: VBoxContainer
var _st_name: LineEdit
var _st_kind: LineEdit
var _status: Label
var _rule_list: VBoxContainer
var _rule_title: Label
var _cust_name: LineEdit
var _cust_kind: OptionButton
var _cust_arg: LineEdit
var _cust_half: CheckBox


func build(owner_ui, root: Control) -> void:
	ui = owner_ui
	content = _make_screen(root, "ویرایشگر محتوا و منو", Color("14202e"))
	rules = _make_screen(root, "قوانین صدا و انیمیشن", Color("1a1634"))
	chooser = _make_screen(root, "صدا و انیمیشن‌ها", Color("12263a"), false)
	_build_chooser()
	_build_content()
	_build_rules()


func _make_screen(root: Control, title: String, bg: Color, skip: bool = true) -> Control:
	var c := Control.new()
	if skip:
		c.set_meta("ct_skip", true)      # متن‌های خود ویرایشگر قابل‌تغییر نیستند
	ui._add_full(root, c)
	var r := ColorRect.new()
	r.color = bg
	ui._add_full(c, r)
	var m := MarginContainer.new()
	ui._add_full(c, m)
	for k in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + k, 24)
	m.add_theme_constant_override("margin_top", 50)
	var col := VBoxContainer.new()
	col.name = "Col"
	col.add_theme_constant_override("separation", 10)
	m.add_child(col)
	col.add_child(ui._label(title, 46, Color.WHITE))
	c.visible = false
	return c


func _col(c: Control) -> VBoxContainer:
	return c.get_child(1).get_child(0)


func _scroll(col: Control) -> VBoxContainer:
	return ui.make_scroll_view(col)


func _small(text: String, size: int = 22, color: Color = Color("c9d6e6")) -> Label:
	var l: Label = ui._label(text, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func _edit(text: String, w: float = 0.0) -> LineEdit:
	var e := LineEdit.new()
	e.text = text
	e.add_theme_font_size_override("font_size", 26)
	e.custom_minimum_size = Vector2(w, 64)
	if w == 0.0:
		e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return e


func _spin(v: float, lo: float, hi: float, step: float) -> SpinBox:
	var s := SpinBox.new()
	s.min_value = lo
	s.max_value = hi
	s.step = step
	s.value = v
	s.custom_minimum_size = Vector2(150, 60)
	s.get_line_edit().add_theme_font_size_override("font_size", 24)
	return s


func _opt(items: Array, selected: int) -> OptionButton:
	var o := OptionButton.new()
	o.add_theme_font_size_override("font_size", 24)
	o.custom_minimum_size = Vector2(0, 60)
	o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for i in items.size():
		o.add_item(String(items[i]), i)
	o.select(clampi(selected, 0, maxi(items.size() - 1, 0)))
	return o


# ======================================================== ویرایشگر محتوا
func _build_content() -> void:
	var col := _col(content)
	var tabs := HFlowContainer.new()
	tabs.add_theme_constant_override("h_separation", 8)
	tabs.add_theme_constant_override("v_separation", 8)
	col.add_child(tabs)
	var names := ["متن‌ها", "منو", "فروشگاه", "ظاهر", "انتشار", "قابلیت‌های بازی"]
	# ترتیب نمایش: از «چی در بازی هست» تا «انتشار»؛ شماره‌ی تب‌ها (ایندکس) ثابت می‌ماند
	for i in [5, 0, 1, 2, 3, 4]:
		var idx: int = i
		var tbn: Button = ui._button(names[idx], func(): _tab = idx; refresh_content(), Vector2(160, 70), 26, "Teal")
		tabs.add_child(tbn)
		_tab_btns[idx] = tbn
	# --- تب متن‌ها
	var p0 := VBoxContainer.new()
	p0.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(p0)
	p0.add_child(_small("همه‌ی متن‌های بازی اینجاست (جهان‌ها، پرتال، مینی‌بازی‌ها، پیام‌ها، منو، تنظیمات و …) دسته‌بندی‌شده. جست‌وجو کن، متن را عوض کن و بیرون از کادر بزن تا ذخیره شود. خالی‌گذاشتن = متن اصلی. در قالب‌هایی مثل «×%d» همان %d را نگه دار تا عدد واقعی جایش بیاید."))
	_search = _edit("")
	_search.placeholder_text = "جست‌وجو در متن‌ها (متن اصلی یا ویرایش‌شده)"
	_search.text_changed.connect(func(_t: String): _text_limit = 60; _fill_texts())
	p0.add_child(_search)
	var frow := HBoxContainer.new()
	frow.add_theme_constant_override("separation", 10)
	p0.add_child(frow)
	_cat_pick = OptionButton.new()
	_cat_pick.add_theme_font_size_override("font_size", 24)
	_cat_pick.custom_minimum_size = Vector2(330, 60)
	_cat_pick.add_item("همه‌ی دسته‌ها", 0)
	for ci in TextsCatalog.CATS.size():
		_cat_pick.add_item(TextsCatalog.CATS[ci], ci + 1)
	_cat_pick.item_selected.connect(func(_i: int): _text_limit = 60; _fill_texts())
	frow.add_child(_cat_pick)
	_only_edited = CheckBox.new()
	_only_edited.text = "فقط ویرایش‌شده‌ها"
	_only_edited.add_theme_font_size_override("font_size", 24)
	_only_edited.toggled.connect(func(_v: bool): _text_limit = 60; _fill_texts())
	frow.add_child(_only_edited)
	_text_count = _small("", 22, Color("ffd27a"))
	p0.add_child(_text_count)
	_text_list = _scroll(p0)
	_panels.append(p0)
	# --- تب منو
	var p1 := VBoxContainer.new()
	p1.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(p1)
	_menu_list = _scroll(p1)
	_panels.append(p1)
	# --- تب فروشگاه
	var ps := VBoxContainer.new()
	ps.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(ps)
	_store_list = _scroll(ps)
	_panels.append(ps)
	# --- تب ظاهر
	var pl := VBoxContainer.new()
	pl.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(pl)
	_look_list = _scroll(pl)
	_panels.append(pl)
	# --- تب انتشار
	var p2 := VBoxContainer.new()
	p2.size_flags_vertical = Control.SIZE_EXPAND_FILL
	p2.add_theme_constant_override("separation", 12)
	col.add_child(p2)
	p2.add_child(_small("ویرایش‌ها روی همین دستگاه ذخیره می‌شوند. «انتشار» آن‌ها را (متن‌ها، منو، قابلیت‌های نسخه‌ی عمومی) روی سرور می‌گذارد تا بازیکن‌ها در اجرای بعدی ببینند. برای انتشار باید با حساب مدیر وارد باشی.", 24))
	p2.add_child(ui._button("انتشار برای همه‌ی بازیکن‌ها", func(): _publish(), Vector2(600, 84), 30, "Gold"))
	p2.add_child(ui._button("پیش‌نمایش نسخه‌ی عمومی (روشن/خاموش)", func(): Edition.set_simulate_public(not Edition.simulate_public), Vector2(600, 72), 26, "Teal"))
	p2.add_child(ui._button("پاک‌کردن همه‌ی ویرایش‌های محلی", func(): Content.reset_local(); _set_status("همه‌ی ویرایش‌های محلی پاک شد"), Vector2(600, 72), 26, "Red"))
	p2.add_child(ui._button("تغییر مدل پلیس (انتخاب فایل GLB)", func(): ui.settings_open_police(), Vector2(600, 72), 26, "Gold"))
	_status = _small("", 24, Color("ffd24a"))
	p2.add_child(_status)
	_panels.append(p2)
	var pf := VBoxContainer.new()
	pf.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(pf)
	_feat_list = _scroll(pf)
	_panels.append(pf)
	col.add_child(ui._button("بازگشت", func(): ui._set_screen(ui.Screen.START), Vector2(540, 76), 32, "Dark"))


func _set_status(t: String) -> void:
	if _status != null:
		_status.text = t


func _publish() -> void:
	if not Online.is_admin:
		_set_status("برای انتشار باید با حساب مدیر وارد شوی (بخش «حساب من»)")
		return
	_set_status("در حال انتشار…")
	var r: Dictionary = await Online.push_content(Content.export_json())
	_set_status("منتشر شد ✓" if r.ok else "ناموفق: " + String(r.error))


func refresh_content() -> void:
	for i in _panels.size():
		_panels[i].visible = i == _tab
	for k in _tab_btns:
		_tab_btns[k].modulate = Color.WHITE if k == _tab else Color(1, 1, 1, 0.55)
	if _tab == 0:
		_fill_texts()
	elif _tab == 1:
		_fill_menu()
	elif _tab == 2:
		_fill_store()
	elif _tab == 3:
		_fill_look()
	elif _tab == 5:
		_fill_features()


# ------------------------- تب ظاهر -------------------------
func _fill_look() -> void:
	for c in _look_list.get_children():
		c.queue_free()
	var L := _look_list
	L.add_theme_constant_override("separation", 10)
	var cur_style := String(Content.look("style", "classic"))
	var cur_font := String(Content.look("font", "vazir"))
	# پیش‌نمایش زنده
	L.add_child(_small("پیش‌نمایش", 26, Color("ffd24a")))
	var pv := HFlowContainer.new()
	pv.add_theme_constant_override("h_separation", 10)
	pv.add_theme_constant_override("v_separation", 10)
	L.add_child(pv)
	for k in Content.LOOK_KINDS:
		pv.add_child(ui._button(String(k[1]), func(): pass, Vector2(170, 76), 26, "" if k[0] == "Button" else String(k[0]).trim_suffix("Button")))
	# سبک دکمه
	L.add_child(_small("سبک دکمه‌ها", 26, Color("ffd24a")))
	var sf := HFlowContainer.new()
	sf.add_theme_constant_override("h_separation", 8)
	sf.add_theme_constant_override("v_separation", 8)
	L.add_child(sf)
	for st in UiArt.STYLES:
		var sid: String = st[0]
		sf.add_child(ui._button(("✓ " if sid == cur_style else "") + String(st[1]), func():
			Content.look_set("style", sid)
			_fill_look(), Vector2(200, 70), 24, "Gold" if sid == cur_style else "Dark"))
	# فونت
	L.add_child(_small("فونت (فارسی)", 26, Color("ffd24a")))
	var ff := HFlowContainer.new()
	ff.add_theme_constant_override("h_separation", 8)
	ff.add_theme_constant_override("v_separation", 8)
	L.add_child(ff)
	for fo in [["vazir", "وزیرمتن (پیش‌فرض)"], ["vazir_bold", "وزیرمتن ضخیم"], ["vazir_black", "وزیرمتن خیلی ضخیم"], ["system", "فونت سیستم"]]:
		var fid: String = fo[0]
		ff.add_child(ui._button(("✓ " if fid == cur_font else "") + String(fo[1]), func():
			Content.look_set("font", fid)
			_fill_look(), Vector2(200, 70), 24, "Gold" if fid == cur_font else "Dark"))
	ff.add_child(ui._button(("✓ " if cur_font == "custom" else "") + "فونت از فایل‌های من…", func(): ui.pick_file("font", func(_p): _fill_look()), Vector2(260, 70), 24, "Teal"))
	L.add_child(_small("فونت دلخواه فقط روی همین دستگاه می‌ماند (در «انتشار» برای همه نمی‌رود). حرف‌هایی که فونتت ندارد، با وزیرمتن نمایش داده می‌شود.", 20))
	# رنگ‌ها
	L.add_child(_small("رنگ‌های آماده", 26, Color("ffd24a")))
	var pf := HFlowContainer.new()
	pf.add_theme_constant_override("h_separation", 8)
	pf.add_theme_constant_override("v_separation", 8)
	L.add_child(pf)
	for pr in Content.LOOK_PRESETS:
		var cols: Dictionary = pr[1]
		pf.add_child(ui._button(String(pr[0]), func():
			Content.look_set_colors(cols)
			_fill_look(), Vector2(200, 70), 24, "Dark"))
	var pals := Content.look_palettes()
	for i in pals.size():
		var pi := i
		var row := HBoxContainer.new()
		pf.add_child(row)
		row.add_child(ui._button(String(pals[i].get("name", "پالت")), func():
			Content.look_set_colors(pals[pi].colors)
			_fill_look(), Vector2(170, 70), 24, "Teal"))
		row.add_child(ui._button("✕", func():
			var np := Content.look_palettes().duplicate()
			np.remove_at(pi)
			Content.look_set("palettes", np)
			_fill_look(), Vector2(64, 70), 24, "Red"))
	L.add_child(_small("ساخت و تغییر رنگ (روی رنگ بزن؛ بعد از بستن پنجره اعمال می‌شود)", 26, Color("ffd24a")))
	var colors := {}
	for k in Content.LOOK_KINDS:
		colors[k[0]] = Content.look_color(k[0]).to_html(false)
		var row2 := HBoxContainer.new()
		row2.add_theme_constant_override("separation", 12)
		L.add_child(row2)
		var cp := ColorPickerButton.new()
		cp.color = Content.look_color(k[0])
		cp.edit_alpha = false
		cp.custom_minimum_size = Vector2(160, 64)
		var kid: String = k[0]
		cp.popup_closed.connect(func():
			var cc: Dictionary = {}
			for kk in Content.LOOK_KINDS:
				cc[kk[0]] = Content.look_color(kk[0]).to_html(false)
			cc[kid] = cp.color.to_html(false)
			Content.look_set_colors(cc)
			_fill_look())
		row2.add_child(cp)
		row2.add_child(_small(String(k[1]), 26, Color.WHITE))
	L.add_child(ui._button("ذخیره‌ی رنگ‌های فعلی به‌عنوان پالت من", func():
		var np2 := Content.look_palettes().duplicate()
		np2.append({"name": "پالت %d" % (np2.size() + 1), "colors": colors.duplicate()})
		Content.look_set("palettes", np2)
		_fill_look(), Vector2(600, 72), 24, "Teal"))
	L.add_child(_small("عکس بازی (لوگوی بالای منو)", 26, Color("ffd24a")))
	var lr := HFlowContainer.new()
	lr.add_theme_constant_override("h_separation", 8)
	lr.add_theme_constant_override("v_separation", 8)
	L.add_child(lr)
	lr.add_child(ui._button("انتخاب عکس از فایل‌های من…", func(): ui.pick_file("logo", func(_p): _fill_look()), Vector2(300, 70), 24, "Teal"))
	lr.add_child(ui._button("حذف لوگو", func(): ui.clear_logo(); _fill_look(), Vector2(200, 70), 24, "Red"))
	L.add_child(_small("این فقط عکس داخل بازی است. آیکن برنامه روی گوشی را با ابزار «icon_maker.html» یا tools/set_branding.py عوض کن (راهنمای_انتشار.md).", 20))
	L.add_child(ui._button("بازگشت به ظاهر پیش‌فرض", func():
		Content.look_set("style", "classic")
		Content.look_set("font", "vazir")
		Content.look_set_colors(Content.LOOK_DEFAULT)
		_fill_look(), Vector2(600, 72), 24, "Red"))
	L.add_child(_small("ظاهر (سبک، رنگ‌ها، فونت‌های پیش‌فرض) با «انتشار» به نسخه‌ی عمومی هم می‌رسد.", 20))


var _cat_pick: OptionButton
var _only_edited: CheckBox
var _text_count: Label
var _text_limit := 60


func _fill_texts() -> void:
	for c in _text_list.get_children():
		c.queue_free()
	var q := _search.text.strip_edges()
	var cat_sel := _cat_pick.get_selected_id() - 1        # -1 = همه
	var edited_only := _only_edited.button_pressed
	var rows: Array = []
	for e: Array in Content.known_entries():
		var orig: String = e[0]
		var cat: int = e[1]
		var is_ed := Content.text_for(orig) != orig
		if cat_sel >= 0 and cat != cat_sel:
			continue
		if edited_only and not is_ed:
			continue
		if q != "" and orig.find(q) == -1 and Content.text_for(orig).find(q) == -1:
			continue
		rows.append(e)
	var total := rows.size()
	var shown := 0
	var last_cat := -2
	for e: Array in rows:
		if shown >= _text_limit:
			break
		shown += 1
		var orig: String = e[0]
		var cat: int = e[1]
		if cat != last_cat:
			last_cat = cat
			var hl: Label = ui._label(TextsCatalog.CATS[cat] if cat >= 0 else "دیده‌شده هنگام اجرا", 28, Color("ffb02e"))
			_text_list.add_child(hl)
		var cur := Content.text_for(orig)
		var box := VBoxContainer.new()
		box.add_theme_constant_override("separation", 2)
		var tag := ("✎ ویرایش‌شده — اصلی: " if cur != orig else "اصلی: ") + orig.replace("\n", " ⏎ ")
		box.add_child(_small(tag, 20, Color("7fe0a0") if cur != orig else Color("8fa3bd")))
		var le := TextEdit.new()
		le.text = cur
		le.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
		le.scroll_fit_content_height = true
		le.add_theme_font_size_override("font_size", 26)
		le.custom_minimum_size = Vector2(0, 66)
		var o := orig
		le.focus_exited.connect(func(): Content.set_text(o, le.text))
		box.add_child(le)
		if cur != orig:
			box.add_child(ui._button("بازگردانی به اصلی", func(): Content.set_text(o, o); _fill_texts(), Vector2(260, 52), 20, "Red"))
		_text_list.add_child(box)
	_text_count.text = "%d متن پیدا شد" % total + (" (نمایش %d تای اول)" % shown if total > shown else "")
	if total > shown:
		_text_list.add_child(ui._button("نمایش ۶۰ متن بعدی", func(): _text_limit += 60; _fill_texts(), Vector2(400, 64), 24, "Teal"))
	if total == 0:
		_text_list.add_child(_small("متنی پیدا نشد."))


var _feat_list: VBoxContainer


## تب «قابلیت‌های بازی»: هر بخش بازی را حذف/اضافه کن (برای همه‌ی بازیکن‌ها بعد از «انتشار»)
func _fill_features() -> void:
	for c in _feat_list.get_children():
		c.queue_free()
	_feat_list.add_child(_small("تیک = این بخش در بازی هست. برداشتن تیک آن را از بازی حذف می‌کند (همین‌جا روی دستگاه خودت هم اثر دارد). برای بقیه‌ی بازیکن‌ها از تب «انتشار» منتشر کن."))
	var groups: Array = []
	for it: Array in Content.features_all():
		if not groups.has(it[2]):
			groups.append(it[2])
	for g: String in groups:
		var head := HBoxContainer.new()
		head.add_theme_constant_override("separation", 8)
		var gl: Label = ui._label(g, 30, Color("ffb02e"))
		gl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		head.add_child(gl)
		head.add_child(ui._button("همه روشن", func(): Content.set_features_group(g, true); _fill_features(), Vector2(150, 56), 22, "Teal"))
		head.add_child(ui._button("همه خاموش", func(): Content.set_features_group(g, false); _fill_features(), Vector2(150, 56), 22, "Red"))
		_feat_list.add_child(head)
		for it: Array in Content.features_all():
			if it[2] != g:
				continue
			var fid: String = it[0]
			var cb := CheckBox.new()
			cb.text = String(it[1])
			cb.add_theme_font_size_override("font_size", 24)
			cb.button_pressed = Content.feature(fid)
			cb.toggled.connect(func(v: bool): Content.set_feature(fid, v))
			_feat_list.add_child(cb)


func _fill_menu() -> void:
	for c in _menu_list.get_children():
		c.queue_free()
	_menu_list.add_child(_small("تیک = این بخش در «نسخه‌ی عمومی» دیده می‌شود. نسخه‌ی مالک همیشه همه‌چیز را دارد (بخش‌های مخفی با «مخفی در عمومی» نشان داده می‌شوند). با فلش‌ها ترتیب را عوض کن."))
	var items: Array = Content.menu_all()
	for it: Dictionary in items:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		var id := String(it.id)
		var ab := String(it.ability)
		if ab != "":
			var cb := CheckBox.new()
			cb.button_pressed = Content.public_enabled(ab)
			cb.custom_minimum_size = Vector2(60, 60)
			cb.toggled.connect(func(v: bool): Content.set_ability(ab, v))
			row.add_child(cb)
		else:
			var sp := Control.new()
			sp.custom_minimum_size = Vector2(60, 60)
			row.add_child(sp)
		var nm: Label = _small(String(it.text), 26, Color.WHITE)
		row.add_child(nm)
		row.add_child(ui._button("▲", func(): Content.move_item(id, -1); _fill_menu(), Vector2(64, 60), 24))
		row.add_child(ui._button("▼", func(): Content.move_item(id, 1); _fill_menu(), Vector2(64, 60), 24))
		if bool(it.get("custom", false)):
			row.add_child(ui._button("حذف", func(): Content.remove_custom(id); _fill_menu(), Vector2(90, 60), 22, "Red"))
		_menu_list.add_child(row)
	_menu_list.add_child(ui._label("امکانات دیگر", 30, Color("ffb02e")))
	for a in Content.ABILITIES:
		var aid: String = a[0]
		if aid in ["settings_extra", "coins_ui"]:
			var cb2 := CheckBox.new()
			cb2.text = String(a[1])
			cb2.add_theme_font_size_override("font_size", 24)
			cb2.button_pressed = Content.public_enabled(aid)
			cb2.toggled.connect(func(v: bool): Content.set_ability(aid, v))
			_menu_list.add_child(cb2)
	_menu_list.add_child(ui._label("افزودن بخش سفارشی به منو", 30, Color("ffb02e")))
	_cust_name = _edit("")
	_cust_name.placeholder_text = "نام دکمه"
	_menu_list.add_child(_cust_name)
	_cust_kind = _opt(["باز کردن یک صفحه‌ی بازی", "باز کردن لینک اینترنتی", "نمایش یک پیام"], 2)
	_menu_list.add_child(_cust_kind)
	_cust_arg = _edit("")
	_cust_arg.placeholder_text = "نام صفحه (مثل SETTINGS) / آدرس لینک / متن پیام"
	_menu_list.add_child(_cust_arg)
	_cust_half = CheckBox.new()
	_cust_half.text = "نیم‌عرض (دو دکمه کنار هم)"
	_cust_half.add_theme_font_size_override("font_size", 24)
	_menu_list.add_child(_cust_half)
	_menu_list.add_child(_small("نام صفحه‌ها: " + ", ".join(ui.Screen.keys()), 20, Color("8fa3bd")))
	_menu_list.add_child(ui._button("افزودن به منو", func():
		if _cust_name.text.strip_edges() == "":
			return
		var kind := ["screen:", "url:", "text:"][_cust_kind.selected] as String
		Content.add_custom(_cust_name.text.strip_edges(), kind + _cust_arg.text.strip_edges(), _cust_half.button_pressed)
		_fill_menu(), Vector2(540, 70), 28, "Gold"))


func _fill_store() -> void:
	for c in _store_list.get_children():
		c.queue_free()
	_store_list.add_child(_small("بخش‌های فروشگاه آنلاین. تیک = برای بازیکن‌ها دیده شود (تیک‌نخورده = حذف از فروشگاه عمومی؛ آیتم‌های آن نوع هم پنهان می‌شوند). نسخه‌ی مالک همیشه همه را می‌بیند."))
	for it: Dictionary in Content.store_all():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		var id := String(it.id)
		var ab := String(it.ability)
		if ab != "":
			var cb := CheckBox.new()
			cb.button_pressed = Content.public_enabled(ab)
			cb.custom_minimum_size = Vector2(60, 60)
			cb.toggled.connect(func(v: bool): Content.set_ability(ab, v))
			row.add_child(cb)
		else:
			var sp := Control.new()
			sp.custom_minimum_size = Vector2(60, 60)
			row.add_child(sp)
		row.add_child(_small("%s  (نوع: %s)" % [String(it.text), String(it.kind) if String(it.kind) != "" else "همه"], 24, Color.WHITE))
		row.add_child(ui._button("▲", func(): Content.move_store(id, -1); _fill_store(), Vector2(64, 60), 24))
		row.add_child(ui._button("▼", func(): Content.move_store(id, 1); _fill_store(), Vector2(64, 60), 24))
		if bool(it.get("custom", false)):
			row.add_child(ui._button("حذف", func(): Content.remove_store(id); _fill_store(), Vector2(90, 60), 22, "Red"))
		_store_list.add_child(row)
	_store_list.add_child(ui._label("افزودن بخش به فروشگاه", 30, Color("ffb02e")))
	_st_name = _edit("")
	_st_name.placeholder_text = "نام بخش (مثلاً «انیمیشن‌های ویژه»)"
	_store_list.add_child(_st_name)
	_st_kind = _edit("")
	_st_kind.placeholder_text = "نوع آیتم‌ها: skin / glb / coin / voice / anim / police یا نوع تازه"
	_store_list.add_child(_st_kind)
	_store_list.add_child(_small("آیتم‌های این بخش همان‌هایی‌اند که در پنل مدیر با همین «نوع» ثبت شده‌اند. چند بخش می‌توانند یک نوع داشته باشند.", 20, Color("8fa3bd")))
	_store_list.add_child(ui._button("افزودن به فروشگاه", func():
		var k := _st_kind.text.strip_edges().to_lower()
		if _st_name.text.strip_edges() == "" or not k.is_valid_identifier():
			_set_status("نام و نوع (فقط حروف انگلیسی/عدد/_) لازم است")
			return
		Content.add_store(_st_name.text.strip_edges(), k)
		_fill_store(), Vector2(540, 70), 28, "Gold"))


# ======================================================== قوانین صدا و انیمیشن
func _build_rules() -> void:
	var col := _col(rules)
	_rule_title = _small("", 28, Color("ffd24a"))
	col.add_child(_rule_title)
	col.add_child(_small("قانون: «وقتی [رویداد] ... → صدا / انیمیشن / نوشته». مثلاً وقتی ۵۰۰ متر دوید «خنده» بگوید، یا به‌جای صدای پرش صدای دلخواه خودت. قوانین برای کاراکترِ انتخاب‌شده ذخیره می‌شوند (کاراکتر را از بخش «کاراکتر» عوض کن). «جایگزین پیش‌فرض» یعنی صدای عادیِ همان رویداد پخش نشود.", 22))
	var top := HFlowContainer.new()
	top.add_theme_constant_override("h_separation", 8)
	top.add_theme_constant_override("v_separation", 8)
	col.add_child(top)
	top.add_child(ui._button("افزودن قانون", func():
		var r := Rules.new_rule()
		if _rl_target == "chaser":
			r.merge({"event": "chaser_approach", "action": "sound", "arg": "horn", "max": 0}, true)
		Rules.add_rule(Rules.CHASER if _rl_target == "chaser" else Skins.current_id, r)
		refresh_rules(), Vector2(260, 68), 26, "Gold"))
	top.add_child(ui._button("+ صدا از فایل گوشی", func():
		var ck := Skins.char_key(Skins.current_entry())
		var ch := _rl_target == "chaser"
		ui.pick_file("voice", func(vn: String):
			var fname := vn.substr(5) if vn.begins_with("file:") else vn
			Rules.library_add({"id": "own_" + fname, "kind": "voice", "name": fname.get_basename(), "arg": vn, "char": "" if ch else ck, "for": "chaser" if ch else ""})
			refresh_rules()), Vector2(300, 68), 24, "Gold"))
	top.add_child(ui._button("کاراکتر ⇄ تعقیب‌کننده", func(): _rl_target = "chaser" if _rl_target == "char" else "char"; refresh_rules(), Vector2(330, 68), 24, "Teal"))
	top.add_child(ui._button("بازگشت", func(): ui._set_screen(ui.Screen.START), Vector2(200, 68), 26, "Dark"))
	_rule_list = _scroll(col)


func refresh_rules() -> void:
	var chaser := _rl_target == "chaser"
	var cid: String = Rules.CHASER if chaser else String(Skins.current_id)
	var entry := Skins.current_entry()
	_rule_title.text = "تعقیب‌کننده" if chaser else "کاراکتر: %s" % String(entry.get("name", cid))
	for c in _rule_list.get_children():
		c.queue_free()
	var list := Rules.rules_of(cid)
	if list.is_empty():
		_rule_list.add_child(_small("هنوز قانونی نیست. «افزودن قانون» را بزن."))
	var ev_ids: Array = []
	var ev_names: Array = []
	for e in (Rules.CHASER_EVENTS if chaser else Rules.EVENTS):
		ev_ids.append(e[0])
		ev_names.append(e[1])
	var act_ids: Array = []
	var act_names: Array = []
	for a in Rules.ACTIONS:
		act_ids.append(a[0])
		act_names.append(a[1])
	for i in list.size():
		var r: Dictionary = list[i]
		var idx := i
		var card := PanelContainer.new()
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(1, 1, 1, 0.07)
		sb.set_corner_radius_all(14)
		sb.set_content_margin_all(12)
		card.add_theme_stylebox_override("panel", sb)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 6)
		card.add_child(v)
		# رویداد
		var evo := _opt(ev_names, ev_ids.find(String(r.get("event", "distance"))))
		evo.item_selected.connect(func(k: int): Rules.update_rule(cid, idx, "event", ev_ids[k]); refresh_rules())
		v.add_child(evo)
		var event := String(r.get("event", ""))
		var row2 := GridContainer.new()
		row2.columns = 2
		row2.add_theme_constant_override("h_separation", 8)
		row2.add_theme_constant_override("v_separation", 6)
		v.add_child(row2)
		if event == "distance":
			row2.add_child(_small("در متر:", 22))
			var sa := _spin(float(r.get("at", 0.0)), 0, 100000, 50)
			sa.value_changed.connect(func(x: float): Rules.update_rule(cid, idx, "at", x))
			row2.add_child(sa)
			row2.add_child(_small("یا هر … متر (۰=غیرفعال):", 22))
		elif event == "score":
			row2.add_child(_small("در امتیاز:", 22))
			var ss := _spin(float(r.get("at", 0.0)), 0, 10000000, 100)
			ss.value_changed.connect(func(x: float): Rules.update_rule(cid, idx, "at", x))
			row2.add_child(ss)
			row2.add_child(_small("یا هر … امتیاز (۰=غیرفعال):", 22))
		elif event == "minute":
			row2.add_child(_small("در دقیقه:", 22))
			var sm := _spin(float(r.get("at", 0.0)), 0, 600, 0.5)
			sm.value_changed.connect(func(x: float): Rules.update_rule(cid, idx, "at", x))
			row2.add_child(sm)
			row2.add_child(_small("یا هر … دقیقه (۰=غیرفعال):", 22))
		elif event not in ["start", "zone", "crash"] and not event.begins_with("chaser_"):
			row2.add_child(_small("هر … بار (۰ یا ۱ = هر بار):", 22))
		if event != "start" and event != "crash" and event != "zone" and not event.begins_with("chaser_"):
			var se := _spin(float(r.get("every", 0.0)), 0, 10000000, 50 if event == "distance" else (100 if event == "score" else (0.5 if event == "minute" else 1)))
			se.value_changed.connect(func(x: float): Rules.update_rule(cid, idx, "every", x))
			row2.add_child(se)
		# عمل
		var acto := _opt(act_names, act_ids.find(String(r.get("action", "sound"))))
		acto.item_selected.connect(func(k: int):
			Rules.update_rule(cid, idx, "action", act_ids[k])
			Rules.update_rule(cid, idx, "arg", ["laugh", "spin", "سلام!"][k])
			refresh_rules())
		v.add_child(acto)
		var action := String(r.get("action", "sound"))
		var arg := String(r.get("arg", ""))
		if action == "sound":
			var names: Array = Sfx.builtin_names()
			var vals: Array = names.duplicate()
			var shown: Array = names.duplicate()
			for e in Rules.library_of("voice", chaser, "" if chaser else Skins.char_key(entry)):
				vals.append(String(e.arg))
				shown.append("★ " + String(e.name))
			var cur := vals.find(arg)
			if cur == -1 and arg.begins_with("file:"):
				vals.append(arg)
				shown.append("فایل: " + arg.substr(5))
				cur = shown.size() - 1
			var so := _opt(shown, cur)
			so.item_selected.connect(func(k: int):
				Rules.update_rule(cid, idx, "arg", vals[k])
				Sfx.play_any(vals[k]))
			v.add_child(so)
			v.add_child(ui._button("انتخاب فایل صوتی از دستگاه (ogg / mp3 / wav)", func():
				ui.pick_file("voice", func(vn: String):
					Rules.update_rule(cid, idx, "arg", vn)
					Sfx.play_any(vn)
					refresh_rules()), Vector2(0, 62), 22, "Teal"))
			# چند صدا برای یک کار: هر بار یکی (تصادفی / به‌ترتیب) یا همه با هم
			var extras: Array = (r.get("args", []) as Array).duplicate() if r.get("args") is Array else []
			for ei in extras.size():
				var eidx := ei
				var evals: Array = vals.duplicate()
				var eshown: Array = shown.duplicate()
				var ecur := evals.find(String(extras[ei]))
				if ecur == -1 and String(extras[ei]).begins_with("file:"):
					evals.append(String(extras[ei]))
					eshown.append("فایل: " + String(extras[ei]).substr(5))
					ecur = eshown.size() - 1
				var erow := HBoxContainer.new()
				erow.add_theme_constant_override("separation", 6)
				var eo := _opt(eshown, ecur)
				eo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				eo.item_selected.connect(func(k: int):
					var na: Array = (Rules.rules_of(cid)[idx].get("args", []) as Array).duplicate()
					na[eidx] = evals[k]
					Rules.update_rule(cid, idx, "args", na)
					Sfx.play_any(evals[k]))
				erow.add_child(eo)
				erow.add_child(ui._button("✕", func():
					var na2: Array = (Rules.rules_of(cid)[idx].get("args", []) as Array).duplicate()
					na2.remove_at(eidx)
					Rules.update_rule(cid, idx, "args", na2)
					refresh_rules(), Vector2(70, 56), 22, "Red"))
				v.add_child(erow)
			var mrow := HFlowContainer.new()
			mrow.add_theme_constant_override("h_separation", 8)
			mrow.add_theme_constant_override("v_separation", 8)
			v.add_child(mrow)
			mrow.add_child(ui._button("+ صدای دیگر برای همین کار", func():
				var na3: Array = (Rules.rules_of(cid)[idx].get("args", []) as Array).duplicate() if Rules.rules_of(cid)[idx].get("args") is Array else []
				na3.append("laugh")
				Rules.update_rule(cid, idx, "args", na3)
				refresh_rules(), Vector2(0, 56), 22, "Teal"))
			if not extras.is_empty():
				var pk := String(r.get("pick", "random"))
				var pn := {"random": "هر بار تصادفی", "order": "به‌ترتیب", "all": "همه با هم"}
				mrow.add_child(ui._button("حالت: " + String(pn.get(pk, "")), func():
					var order := ["random", "order", "all"]
					Rules.update_rule(cid, idx, "pick", order[(order.find(pk) + 1) % 3])
					refresh_rules(), Vector2(0, 56), 22, "Gold"))
		elif action == "anim":
			var tn: Array = []
			var tids: Array = []
			for t in Rules.TRICKS:
				tn.append(String(Rules.TRICK_NAMES[t]))
				tids.append(t)
			var pl = ui.get_tree().root.find_child("Police" if chaser else "Player", true, false)
			var pm = null
			if pl != null:
				pm = pl.get("_gm") if chaser else pl.get("_model")
			if pm != null and pm.has_method("clip_list"):
				for cn in pm.clip_list():
					tn.append("کلیپ مدل: " + String(cn))
					tids.append("clip:" + String(cn))
			var ao := _opt(tn, tids.find(arg))
			ao.item_selected.connect(func(k: int): Rules.update_rule(cid, idx, "arg", tids[k]); Rules.test_rule(Rules.rules_of(cid)[idx], cid))
			v.add_child(ao)
		else:
			var pe := _edit(arg)
			pe.text_submitted.connect(func(t: String): Rules.update_rule(cid, idx, "arg", t))
			pe.focus_exited.connect(func(): Rules.update_rule(cid, idx, "arg", pe.text))
			v.add_child(pe)
		# شرایط
		var row3 := GridContainer.new()
		row3.columns = 2
		row3.add_theme_constant_override("h_separation", 8)
		row3.add_theme_constant_override("v_separation", 6)
		v.add_child(row3)
		row3.add_child(_small("شانس٪", 22))
		var sc := _spin(float(r.get("chance", 1.0)) * 100.0, 1, 100, 5)
		sc.value_changed.connect(func(x: float): Rules.update_rule(cid, idx, "chance", x / 100.0))
		row3.add_child(sc)
		row3.add_child(_small("حداکثر در هر دور (۰=بی‌نهایت)", 22))
		var sm := _spin(float(r.get("max", 0)), 0, 999, 1)
		sm.value_changed.connect(func(x: float): Rules.update_rule(cid, idx, "max", int(x)))
		row3.add_child(sm)
		var row4 := HFlowContainer.new()
		row4.add_theme_constant_override("h_separation", 8)
		row4.add_theme_constant_override("v_separation", 6)
		v.add_child(row4)
		var rep := CheckBox.new()
		rep.text = "جایگزین پیش‌فرض"
		rep.add_theme_font_size_override("font_size", 22)
		rep.button_pressed = bool(r.get("replace", false))
		rep.toggled.connect(func(x: bool): Rules.update_rule(cid, idx, "replace", x))
		row4.add_child(rep)
		row4.add_child(ui._button("تست", func(): Rules.test_rule(Rules.rules_of(cid)[idx], cid), Vector2(110, 58), 22, "Teal"))
		row4.add_child(ui._button("حذف", func(): Rules.remove_rule(cid, idx); refresh_rules(), Vector2(110, 58), 22, "Red"))
		_rule_list.add_child(card)


# ======================================================== انتخاب صدا و انیمیشن (کتابخانه + اسلات)
func _build_chooser() -> void:
	var col := _col(chooser)
	_ch_title = _small("", 28, Color("ffd24a"))
	col.add_child(_ch_title)
	col.add_child(_small("برای هر رویداد، صدا یا انیمیشن دلخواهت را از آنچه خریده‌ای (یا از آماده‌ها) انتخاب کن. «پیش‌فرض» یعنی همان صدا/حرکت اصلیِ کاراکتر."))
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 8)
	col.add_child(top)
	top.add_child(ui._button("کاراکتر", func(): _ch_target = "char"; refresh_chooser(), Vector2(200, 64), 26, "Teal"))
	_ch_chaser_btn = ui._button("تعقیب‌کننده", func(): _ch_target = "chaser"; refresh_chooser(), Vector2(220, 64), 26, "Teal")
	top.add_child(_ch_chaser_btn)
	top.add_child(ui._button("بازگشت", func(): ui._set_screen(ui.Screen.START), Vector2(200, 64), 26, "Dark"))
	_ch_add = ui._button("+ افزودن صدا از فایل‌های گوشی", func(): _add_voice_file(), Vector2(0, 72), 28, "Gold")
	col.add_child(_ch_add)
	_ch_list = _scroll(col)


## صدای خودت را از فایل‌های گوشی به کتابخانه‌ی همین کاراکتر (یا تعقیب‌کننده) اضافه می‌کند
func _add_voice_file() -> void:
	var why := Content.import_block("voice")
	if why != "":
		ui._show_toast(why)
		return
	var chaser := _ch_target == "chaser"
	var ckey := "" if chaser else Skins.char_key(Skins.current_entry())
	ui.pick_file("voice", func(vn: String):
		var fname := vn.substr(5) if vn.begins_with("file:") else vn
		Rules.library_add({"id": "own_" + fname, "kind": "voice", "name": fname.get_basename(), "arg": vn, "char": ckey, "for": "chaser" if chaser else ""})
		refresh_chooser())


func _ev_name(ev: String) -> String:
	for e in Rules.EVENTS + Rules.CHASER_EVENTS:
		if e[0] == ev:
			return e[1]
	return ev


func _slot_option(target: String, ev: String, action: String, ids: Array, names: Array) -> OptionButton:
	var cur := Rules.slot_of(target, ev, action)
	var o := _opt(names, maxi(ids.find(cur), 0))
	o.item_selected.connect(func(k: int):
		var src: String = ids[k]
		var ok := Rules.set_slot(target, ev, action, src)
		if ok and src != "":
			Rules.test_rule(Rules.rules_of(target).filter(func(r): return String(r.get("slot", "")) == ev + ":" + action)[0], target)
		if not ok:
			refresh_chooser())
	return o


func refresh_chooser() -> void:
	var can_chaser := Content.can("chooser_chaser")
	if not can_chaser:
		_ch_target = "char"
	_ch_chaser_btn.visible = can_chaser
	_ch_add.visible = Content.perm_b("snd_import_voice")
	for c in _ch_list.get_children():
		c.queue_free()
	var chaser := _ch_target == "chaser"
	var target: String = Rules.CHASER if chaser else String(Skins.current_id)
	var ckey := "" if chaser else Skins.char_key(Skins.current_entry())
	_ch_title.text = "هدف: تعقیب‌کننده" if chaser else "هدف: کاراکتر %s" % String(Skins.current_entry().get("name", Skins.current_id))
	# ---- صدا
	_ch_list.add_child(ui._label("صدا", 32, Color("ffb02e")))
	var s_ids: Array = [""]
	var s_names: Array = ["پیش‌فرض"]
	for e in Rules.library_of("voice", chaser, ckey):
		s_ids.append(String(e.id))
		s_names.append("★ " + String(e.name))
	if Content.perm_b("snd_pick_builtin"):
		for bn in Sfx.builtin_names():
			s_ids.append("builtin:" + bn)
			s_names.append("آماده: " + bn)
	var s_events: Array = Rules.CHASER_SLOT_EVENTS if chaser else Rules.SLOT_EVENTS
	s_events = s_events.filter(func(x): return Content.perm_event_ok(String(x)))
	for ev: String in s_events:
		var box := VBoxContainer.new()
		box.add_child(_small(_ev_name(ev), 22, Color("8fa3bd")))
		box.add_child(_slot_option(target, ev, "sound", s_ids, s_names))
		_ch_list.add_child(box)
	# ---- انیمیشن
	if true:
		_ch_list.add_child(ui._label("انیمیشن", 32, Color("ffb02e")))
		for ev: String in s_events:
			var a_ids: Array = [""]
			var a_names: Array = ["پیش‌فرض"]
			if not chaser:
				for dc in Content.char_defaults(ckey):
					a_ids.append("clip:" + String(dc))
					a_names.append("پیش‌فرض کاراکتر: " + String(dc))
			for e in Rules.library_of("anim", chaser, ckey):
				if Rules.pack_has(e, ev):
					a_ids.append(String(e.id))
					a_names.append("★ " + String(e.name))
			if Content.perm_b("snd_pick_trick"):
				for t in Rules.TRICKS:
					a_ids.append("trick:" + String(t))
					a_names.append("آماده: " + String(Rules.TRICK_NAMES[t]))
			var box2 := VBoxContainer.new()
			box2.add_child(_small(_ev_name(ev), 22, Color("8fa3bd")))
			box2.add_child(_slot_option(target, ev, "anim", a_ids, a_names))
			_ch_list.add_child(box2)
	# ---- کتابخانه
	var lib: Array = Rules.library
	if not lib.is_empty():
		_ch_list.add_child(ui._label("کتابخانه‌ی من", 32, Color("ffb02e")))
		for e in lib:
			var row := HBoxContainer.new()
			var id := String(e.id)
			row.add_child(_small("%s (%s)" % [String(e.name), "صدا" if e.kind == "voice" else "انیمیشن"], 24, Color.WHITE))
			row.add_child(ui._button("حذف", func(): Rules.library_remove(id); refresh_chooser(), Vector2(100, 56), 22, "Red"))
			_ch_list.add_child(row)
			if String(e.kind) == "voice" and Content.perm_b("snd_store_tune"):
				SoundPanel.sound_row(ui, _ch_list, "بلندی", String(e.get("arg", "")), Rules.CHASER if String(e.get("for", "")) == "chaser" else "")
	else:
		_ch_list.add_child(_small("کتابخانه خالی است. صدا و انیمیشن‌هایی که از فروشگاه می‌گیری اینجا می‌آید.", 22))
	Content.apply_tree.call_deferred(chooser)
