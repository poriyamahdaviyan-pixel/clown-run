class_name HudFx
extends Control
## افکت‌های حین بازی: خطوط سرعت کنار صفحه و نمایشگر کمبو (ضریب و نوار زمان)

const LINES := 26
var _seed: Array[float] = []
var _t := 0.0
var _pop := 0.0
var _last_mult := 1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	for i in LINES:
		_seed.append(randf())
	Game.combo_changed.connect(_on_combo)


func _on_combo(m: int, _chain: int) -> void:
	if m > _last_mult:
		_pop = 1.0
	_last_mult = m


func _process(delta: float) -> void:
	var show_fx := Game.is_active and not Game.is_paused and not Game.intro_active
	if not show_fx and not _drawn_empty:
		queue_redraw()
		_drawn_empty = true
		return
	if not show_fx:
		return
	_drawn_empty = false
	_t += delta
	_pop = maxf(0.0, _pop - delta * 3.0)
	queue_redraw()

var _drawn_empty := false


func _draw() -> void:
	if not (Game.is_active and not Game.is_paused and not Game.intro_active):
		return
	var sz := size
	# --- خطوط سرعت: فقط وقتی سرعت از حد معمول بالاتر است
	var k := clampf((Game.run_speed - 14.0) / 11.0, 0.0, 1.0)
	if k > 0.02:
		var c := Vector2(sz.x * 0.5, sz.y * 0.42)
		for i in LINES:
			var s: float = _seed[i]
			var ph := fmod(_t * (0.9 + s * 0.8) + s * 7.0, 1.0)
			var side := -1.0 if i % 2 == 0 else 1.0
			var ang := PI * 0.5 + side * (0.35 + s * 0.9)
			var dir := Vector2(cos(ang), sin(ang)).normalized()
			if absf(dir.x) < 0.25:
				dir.x = side * 0.25
				dir = dir.normalized()
			var r0 := lerpf(sz.x * 0.35, sz.x * 0.75, ph)
			var r1 := r0 + sz.x * (0.10 + 0.22 * ph)
			var a := sin(ph * PI) * 0.22 * k
			draw_line(c + dir * r0, c + dir * r1, Color(1, 1, 1, a), 2.0 + 2.0 * ph)
	# --- نوار جهان فعلی
	if Game.mode != "":
		var f2 := get_theme_default_font()
		var dfn := Game.mode_def()
		var tint: Color = dfn.get("tint", Color.WHITE)
		var w2 := 330.0
		var h2 := 46.0
		var p2 := Vector2((sz.x - w2) * 0.5, 150.0)
		draw_rect(Rect2(p2, Vector2(w2, h2)), Color(0.06, 0.04, 0.14, 0.72))
		var fr: float = Game.ret_progress()
		draw_rect(Rect2(p2 + Vector2(0, h2 - 7.0), Vector2(w2 * fr, 7.0)), tint)
		draw_rect(Rect2(p2, Vector2(w2, h2)), Color(tint.r, tint.g, tint.b, 0.9), false, 2.0)
		if f2 != null:
			var txt := String(dfn.get("name", ""))
			draw_string(f2, p2 + Vector2(10.0, 29.0), txt, HORIZONTAL_ALIGNMENT_RIGHT, w2 - 20.0, 24, Color.WHITE)
			var extra := ("حلقه: %d   " % Game.rings if Game.mode == "ring" else "") + Game.ret_left_text()
			draw_string(f2, p2 + Vector2(10.0, 29.0), extra, HORIZONTAL_ALIGNMENT_LEFT, w2 - 20.0, 22, tint)
	# --- کمبو
	if Game.combo_mult > 1 or Game.combo_chain >= 3:
		var font := get_theme_default_font()
		var w := 250.0
		var h := 54.0
		var p := Vector2((sz.x - w) * 0.5, 212.0)
		var sc := 1.0 + _pop * 0.18
		draw_set_transform(p + Vector2(w, h) * 0.5, 0.0, Vector2(sc, sc))
		var r := Rect2(-w * 0.5, -h * 0.5, w, h)
		draw_rect(r, Color(0.08, 0.05, 0.16, 0.72))
		var frac := clampf(Game.combo_time / Game.COMBO_WINDOW, 0.0, 1.0)
		var hot := Color("ffb02e").lerp(Color("ff4d6d"), float(Game.combo_mult - 1) / float(Game.COMBO_MAX - 1))
		draw_rect(Rect2(r.position.x, r.end.y - 8.0, w * frac, 8.0), hot)
		draw_rect(r, Color(hot.r, hot.g, hot.b, 0.9), false, 2.0)
		if font != null:
			draw_string(font, Vector2(-w * 0.5 + 14.0, 12.0), "x%d" % Game.combo_mult, HORIZONTAL_ALIGNMENT_LEFT, -1, 34, hot)
			draw_string(font, Vector2(0.0, 11.0), "کمبو  %d" % Game.combo_chain, HORIZONTAL_ALIGNMENT_RIGHT, w * 0.5 - 14.0, 26, Color.WHITE)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
