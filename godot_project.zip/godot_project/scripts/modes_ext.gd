class_name ModesExt
extends RefCounted
## جهان‌های بیشتر (الهام از فیلم/انیمه/بازی‌ها؛ همه از صفر ساخته شده، بدون برند و اثر واقعی):
##   space  : کهکشان نئونی (سفرِ فضایی)        candy  : سرزمین آب‌نبات (کارخانه‌ی شکلات)
##   shrine : معبد ساکورا (ژاپنِ انیمه‌ای)      pirate : دریای دزدان (کشتی و جزیره)
##   haunted: خانه‌ی ارواح (هالووین)           volcano: دره‌ی آتشفشان (عصر دایناسورها)
##   sky    : جزایر آسمانی (قلعه‌ی روی ابر)    reef   : ریف مرجانی (زیر آب)
## هر جهان: آسمان/جاده/زمین، دکور دو طرف، پس‌زمینه‌ی دور، مانع‌ها (کم/بالاسر/کامل)، سکه و ذرات خودش را دارد.

const Gfx := preload("res://scripts/gfx.gd")
const P := preload("res://scripts/props.gd")

const IDS: Array[String] = ["space", "candy", "shrine", "pirate", "haunted", "volcano", "sky", "reef"]

const DEFS := {
	"space": {
		"name": "کهکشان نئونی", "desc": "جاده‌ی شیشه‌ای میان ستاره‌ها و سیاره‌ها؛ سریع و نئونی.",
		"len": 440.0, "speed": 1.28, "steer": "lane", "tint": Color("7a5cff"),
		"top": Color("02010f"), "hor": Color("4b1f9a"), "gnd": Color("03020a"), "fog": Color("160a3a"), "den": 0.006,
		"amb": Color("8a7cff"), "ambe": 0.8, "lcol": Color("cfd8ff"), "le": 1.0, "road": Color("4a4f86"),
		"ground": Color("04020c"), "sun": Color("7fd0ff"), "sunpos": Vector3(34, 30, -175), "sunsize": 15.0,
		"fx": ["sparkle"],
	},
	"candy": {
		"name": "سرزمین آب‌نبات", "desc": "کوه‌های شکلات، درخت آبنبات و رودخانه‌ی شیرین!",
		"len": 400.0, "speed": 1.05, "steer": "lane", "tint": Color("ff5fb0"),
		"top": Color("ff8fd0"), "hor": Color("fff2fa"), "gnd": Color("ff9ad8"), "fog": Color("ffd2ec"), "den": 0.009,
		"amb": Color("fff0f8"), "ambe": 1.2, "lcol": Color("fff0e0"), "le": 1.2, "road": Color("f5d9b8"),
		"ground": Color("ff9fd2"), "sun": Color("fff27a"), "sunpos": Vector3(-24, 38, -175), "sunsize": 8.0,
		"fx": ["sprinkles"],
	},
	"shrine": {
		"name": "معبد ساکورا", "desc": "غروب ژاپنی با دروازه‌ی تُوری، فانوس و گلبرگ‌های ساکورا.",
		"len": 420.0, "speed": 1.12, "steer": "lane", "tint": Color("ff6f91"),
		"top": Color("5a2f86"), "hor": Color("ffb08a"), "gnd": Color("3a2a4a"), "fog": Color("f2b6b0"), "den": 0.011,
		"amb": Color("ffd2c0"), "ambe": 1.0, "lcol": Color("ffc8a0"), "le": 1.1, "road": Color("9a8a86"),
		"ground": Color("e8b2b8"), "sun": Color("e8342f"), "sunpos": Vector3(0, 24, -175), "sunsize": 16.0,
		"fx": ["sakura"],
	},
	"pirate": {
		"name": "دریای دزدان", "desc": "روی عرشه‌ی چوبی بدو؛ کشتی، بشکه، توپ و جزیره‌ی گنج!",
		"len": 420.0, "speed": 1.1, "steer": "lane", "tint": Color("ffb22e"),
		"top": Color("2478c8"), "hor": Color("cfeeff"), "gnd": Color("1a6aa8"), "fog": Color("a8d8f0"), "den": 0.009,
		"amb": Color("e8f4ff"), "ambe": 1.05, "lcol": Color("fff4d0"), "le": 1.3, "road": Color("a8804e"),
		"ground": Color("1d78b8"), "sun": Color("fff3c0"), "sunpos": Vector3(24, 38, -175), "sunsize": 7.0,
		"fx": ["bubbles"],
	},
	"haunted": {
		"name": "خانه‌ی ارواح", "desc": "قبرستان مه‌آلود، کدوهای چشمک‌زن و روح‌های سبز.",
		"len": 420.0, "speed": 1.15, "steer": "lane", "tint": Color("ff8a1f"),
		"top": Color("070314"), "hor": Color("3d2a62"), "gnd": Color("050a05"), "fog": Color("231a3a"), "den": 0.02,
		"amb": Color("7a6cb8"), "ambe": 0.7, "lcol": Color("b8c8ff"), "le": 0.8, "road": Color("45424e"),
		"ground": Color("0a140a"), "sun": Color("eef4ff"), "sunpos": Vector3(-20, 34, -175), "sunsize": 9.0,
		"fx": ["wisps"],
	},
	"volcano": {
		"name": "دره‌ی آتشفشان", "desc": "عصر دایناسورها: اسکلت، گدازه و کوه‌های آتشین.",
		"len": 420.0, "speed": 1.2, "steer": "lane", "tint": Color("ff5a1f"),
		"top": Color("2a0a06"), "hor": Color("ff7a24"), "gnd": Color("140605"), "fog": Color("5a1c0c"), "den": 0.014,
		"amb": Color("ff9a60"), "ambe": 0.85, "lcol": Color("ffb070"), "le": 1.0, "road": Color("5e4c44"),
		"ground": Color("1c0b08"), "sun": Color("ff6a1a"), "sunpos": Vector3(10, 20, -175), "sunsize": 13.0,
		"fx": ["ash", "lava_embers"],
	},
	"sky": {
		"name": "جزایر آسمانی", "desc": "قلعه‌ی روی ابرها، جزیره‌های شناور و آبشارهای آسمانی.",
		"len": 400.0, "speed": 1.08, "steer": "lane", "tint": Color("5ad0ff"),
		"top": Color("3a98ff"), "hor": Color("ffffff"), "gnd": Color("bcdcff"), "fog": Color("cfe6ff"), "den": 0.005,
		"amb": Color("dfeaff"), "ambe": 0.9, "lcol": Color("fff4d8"), "le": 0.95, "road": Color("8a8fa8"),
		"ground": Color("a9d0f5"), "sun": Color("fff6c0"), "sunpos": Vector3(-26, 44, -175), "sunsize": 8.0,
		"fx": ["sparkle"],
	},
	"reef": {
		"name": "ریف مرجانی", "desc": "زیر دریا: مرجان، حباب، ماهی‌های رنگی و صدف‌های درخشان.",
		"len": 400.0, "speed": 1.0, "steer": "lane", "tint": Color("27e8d0"),
		"top": Color("0a4f9a"), "hor": Color("4ed6e4"), "gnd": Color("062a4a"), "fog": Color("0e6fa0"), "den": 0.022,
		"amb": Color("9ae8ff"), "ambe": 1.0, "lcol": Color("d8ffff"), "le": 1.0, "road": Color("d2c08e"),
		"ground": Color("0c4a6a"), "sun": Color("e8ffff"), "sunpos": Vector3(0, 46, -175), "sunsize": 10.0,
		"fx": ["bubbles"],
	},
}


static func _m(hex: String, emit: float = 0.0, rough: float = 0.6, metal: float = 0.0) -> StandardMaterial3D:
	return P.m(hex, emit, rough, metal)


static func _pick(rng: RandomNumberGenerator, arr: Array) -> Variant:
	return arr[rng.randi() % arr.size()]


# ============================================================
#                      تزئینات کنار جاده
# ============================================================
static func decor(n: Node3D, id: String, rng: RandomNumberGenerator, side: int) -> void:
	match id:
		"space": _decor_space(n, rng, side)
		"candy": _decor_candy(n, rng)
		"shrine": _decor_shrine(n, rng, side)
		"pirate": _decor_pirate(n, rng, side)
		"haunted": _decor_haunted(n, rng, side)
		"volcano": _decor_volcano(n, rng)
		"sky": _decor_sky(n, rng, side)
		"reef": _decor_reef(n, rng)


static func _decor_space(n: Node3D, rng: RandomNumberGenerator, side: int) -> void:
	var r := rng.randi() % 3
	var neon: String = _pick(rng, ["7a5cff", "27e8ff", "ff2d95", "3dff9a"])
	if r == 0:       # برج بلورین شناور
		var h := rng.randf_range(5.0, 14.0)
		Gfx.cyl(n, 0.001, 1.1, h, Vector3(0, 2.0 + h * 0.5, 0), _m(neon, 1.8, 0.2, 0.3), Vector3.ZERO, 5)
		Gfx.cyl(n, 1.1, 0.001, h * 0.4, Vector3(0, 2.0 - h * 0.2, 0), _m(neon, 1.8, 0.2, 0.3), Vector3.ZERO, 5)
		Gfx.glow(n, Vector3(0, 2.0 + h * 0.5, 0), 6.0, Color(1, 1, 1, 0.2))
	elif r == 1:     # سیاره‌ی حلقه‌دار
		var rad := rng.randf_range(1.6, 3.2)
		Gfx.sphere(n, rad, Vector3(0, 7.0 + rad, 0), _m(neon, 0.5, 0.5), 14)
		P.ring(n, rad * 1.7, 0.1, Vector3(0, 7.0 + rad, 0), _m("ffffff", 1.2, 0.3), Vector3(70, 0, 18), 24)
	else:            # ایستگاه / ماهواره
		Gfx.box(n, Vector3(1.4, 1.4, 1.4), Vector3(0, 4.0, 0), _m("c8ccd8", 0.0, 0.3, 0.8))
		Gfx.box(n, Vector3(4.6, 0.08, 1.3), Vector3(0, 4.0, 0), _m("2a5cff", 1.0, 0.3, 0.6))
		Gfx.box(n, Vector3(0.12, 0.12, 0.12), Vector3(0, 5.0, 0), _m("ff2a2a", 3.0))
		Gfx.cyl(n, 0.05, 0.05, 1.4, Vector3(0, 5.6, 0), _m("c8ccd8"), Vector3.ZERO, 5)


static func _decor_candy(n: Node3D, rng: RandomNumberGenerator) -> void:
	var r := rng.randi() % 4
	var cols: Array[String] = ["ff4f9a", "6a5cff", "ffd23f", "3de0c0", "ff7a3a"]
	if r == 0:       # آب‌نبات چوبی غول‌پیکر
		var h := rng.randf_range(4.0, 8.0)
		Gfx.cyl(n, 0.12, 0.12, h, Vector3(0, h * 0.5, 0), _m("ffffff", 0.0, 0.4), Vector3.ZERO, 8)
		var c: String = _pick(rng, cols)
		Gfx.cyl(n, 1.5, 1.5, 0.35, Vector3(0, h + 1.2, 0), _m(c, 0.2, 0.3), Vector3(90, 0, 0), 20)
		Gfx.cyl(n, 1.0, 1.0, 0.4, Vector3(0, h + 1.2, 0), _m("ffffff", 0.1, 0.3), Vector3(90, 0, 0), 20)
		Gfx.cyl(n, 0.5, 0.5, 0.45, Vector3(0, h + 1.2, 0), _m(c, 0.2, 0.3), Vector3(90, 0, 0), 16)
	elif r == 1:     # کیک لایه‌ای با گیلاس
		var layers := rng.randi_range(3, 5)
		for i in layers:
			var rr := 2.6 - i * 0.4
			Gfx.cyl(n, rr, rr, 0.8, Vector3(0, 0.4 + i * 0.85, 0), _m(cols[i % cols.size()], 0.0, 0.5), Vector3.ZERO, 16)
			Gfx.cyl(n, rr + 0.05, rr + 0.05, 0.12, Vector3(0, 0.82 + i * 0.85, 0), _m("fff8f0"), Vector3.ZERO, 16)
		Gfx.sphere(n, 0.3, Vector3(0, layers * 0.85 + 0.25, 0), _m("e8142f", 0.3, 0.2), 10)
	elif r == 2:     # بستنی قیفی وارونه
		Gfx.cyl(n, 1.2, 0.001, 3.0, Vector3(0, 1.5, 0), _m("d9a45a", 0.0, 0.8), Vector3(180, 0, 0), 8)
		Gfx.sphere(n, 1.3, Vector3(0, 3.6, 0), _m(_pick(rng, cols), 0.1, 0.4), 12)
		Gfx.sphere(n, 0.95, Vector3(0, 4.9, 0), _m(_pick(rng, cols), 0.1, 0.4), 12)
	else:            # درخت پنبه‌ی شیرین
		Gfx.cyl(n, 0.2, 0.28, 2.6, Vector3(0, 1.3, 0), _m("8a5a3a"), Vector3.ZERO, 8)
		for i in 4:
			Gfx.sphere(n, 1.1, Vector3(sin(i * 1.6) * 0.7, 3.2 + (i % 2) * 0.5, cos(i * 1.6) * 0.7), _m(_pick(rng, ["ffc2e2", "c2e8ff", "fff0b0"]), 0.15, 0.9), 10)


static func _decor_shrine(n: Node3D, rng: RandomNumberGenerator, side: int) -> void:
	var r := rng.randi() % 4
	var red := _m("d8261f", 0.15, 0.45)
	if r == 0:       # دروازه‌ی تُوری
		for sx in [-1.8, 1.8]:
			Gfx.cyl(n, 0.28, 0.32, 5.6, Vector3(sx, 2.8, 0), red, Vector3.ZERO, 10)
		Gfx.box(n, Vector3(5.6, 0.34, 0.5), Vector3(0, 5.5, 0), _m("1a1a20", 0.0, 0.5), Vector3(0, 0, 0))
		Gfx.box(n, Vector3(4.6, 0.3, 0.4), Vector3(0, 4.8, 0), red)
		Gfx.box(n, Vector3(0.4, 0.5, 0.4), Vector3(0, 5.1, 0), red)
	elif r == 1:     # درخت ساکورا
		Gfx.cyl(n, 0.2, 0.34, 3.2, Vector3(0.2, 1.6, 0), _m("3a2a22", 0.0, 0.95), Vector3(0, 0, 6), 7)
		for i in 5:
			var a := i * 1.3
			Gfx.sphere(n, rng.randf_range(1.2, 1.7), Vector3(sin(a) * 1.4, 3.6 + (i % 3) * 0.6, cos(a) * 1.4), _m(_pick(rng, ["ffb8d0", "ffa0c0", "ffd0e0"]), 0.2, 0.9), 9)
	elif r == 2:     # فانوس سنگی
		Gfx.box(n, Vector3(0.9, 0.3, 0.9), Vector3(0, 0.15, 0), _m("8a8a90", 0.0, 0.95))
		Gfx.cyl(n, 0.2, 0.25, 1.2, Vector3(0, 0.9, 0), _m("8a8a90", 0.0, 0.95), Vector3.ZERO, 8)
		Gfx.box(n, Vector3(0.8, 0.7, 0.8), Vector3(0, 1.85, 0), _m("ffcf70", 1.6, 0.6))
		Gfx.cyl(n, 0.01, 0.85, 0.5, Vector3(0, 2.45, 0), _m("6a6a72", 0.0, 0.95), Vector3.ZERO, 4)
		Gfx.glow(n, Vector3(0, 1.85, 0), 4.0, Color(1.0, 0.75, 0.3, 0.3))
	else:            # پاگودا
		for i in 3:
			var w := 3.4 - i * 0.7
			Gfx.box(n, Vector3(w, 1.1, w), Vector3(0, 0.55 + i * 1.7, 0), _m("f2e4cf", 0.0, 0.8))
			Gfx.box(n, Vector3(w + 1.4, 0.18, w + 1.4), Vector3(0, 1.2 + i * 1.7, 0), _m("2a2a34", 0.0, 0.6), Vector3(0, 45 if i % 2 == 0 else 0, 0))
		Gfx.cyl(n, 0.04, 0.04, 1.4, Vector3(0, 6.2, 0), _m("d8b040", 0.0, 0.3, 0.9), Vector3.ZERO, 5)


static func _decor_pirate(n: Node3D, rng: RandomNumberGenerator, side: int) -> void:
	var r := rng.randi() % 4
	var wood := _m("7a4e28", 0.0, 0.9)
	if r == 0:       # کشتی دزدان
		Gfx.box(n, Vector3(3.0, 1.1, 8.0), Vector3(0, 0.7, 0), wood)
		Gfx.box(n, Vector3(2.6, 0.6, 2.0), Vector3(0, 1.6, 3.0), wood)
		Gfx.cyl(n, 0.14, 0.14, 7.0, Vector3(0, 4.5, -0.5), wood, Vector3.ZERO, 6)
		Gfx.box(n, Vector3(0.05, 3.6, 3.0), Vector3(0, 5.0, -0.5), _m("f6efe0", 0.0, 0.9))
		Gfx.box(n, Vector3(0.05, 0.9, 1.2), Vector3(0, 8.3, -0.2), _m("141414", 0.0, 0.9))
	elif r == 1:     # جزیره‌ی نخل
		Gfx.cyl(n, 2.4, 3.2, 0.8, Vector3(0, 0.4, 0), _m("e8cf8a", 0.0, 0.95), Vector3.ZERO, 12)
		Gfx.cyl(n, 0.2, 0.3, 4.4, Vector3(0, 2.6, 0), _m("8a5a2a", 0.0, 0.9), Vector3(0, 0, 10), 7)
		for i in 6:
			Gfx.box(n, Vector3(0.4, 0.08, 2.4), Vector3(0.6, 4.8, 0), _m("2f9a3a"), Vector3(-20, i * 60.0, 0))
	elif r == 2:     # فانوس دریایی
		Gfx.cyl(n, 0.9, 1.5, 6.0, Vector3(0, 3.0, 0), _m("f2f2f2", 0.0, 0.7), Vector3.ZERO, 12)
		Gfx.cyl(n, 0.95, 1.2, 1.0, Vector3(0, 2.2, 0), _m("d8261f", 0.0, 0.7), Vector3.ZERO, 12)
		Gfx.cyl(n, 0.7, 0.7, 0.9, Vector3(0, 6.5, 0), _m("fff3b0", 2.4, 0.3), Vector3.ZERO, 8)
		Gfx.cyl(n, 0.01, 1.1, 0.7, Vector3(0, 7.3, 0), _m("d8261f", 0.0, 0.6), Vector3.ZERO, 8)
	else:            # بشکه‌ها و صندوق گنج
		for i in 3:
			Gfx.cyl(n, 0.5, 0.5, 1.0, Vector3(i * 0.9 - 0.9, 0.5, rng.randf_range(-0.3, 0.3)), wood, Vector3.ZERO, 10)
			Gfx.cyl(n, 0.52, 0.52, 0.08, Vector3(i * 0.9 - 0.9, 0.3, 0), _m("3a3a40", 0.0, 0.4, 0.8), Vector3.ZERO, 10)
		Gfx.box(n, Vector3(1.3, 0.7, 0.8), Vector3(0, 1.35, 2.0), _m("6a3e1c", 0.0, 0.8))
		Gfx.box(n, Vector3(1.32, 0.18, 0.82), Vector3(0, 1.75, 2.0), _m("ffd23f", 1.0, 0.3, 0.8))


static func _decor_haunted(n: Node3D, rng: RandomNumberGenerator, side: int) -> void:
	var r := rng.randi() % 4
	if r == 0:       # عمارت
		Gfx.box(n, Vector3(5.0, 5.0, 4.0), Vector3(0, 2.5, 0), _m("2a2438", 0.0, 0.9))
		Gfx.box(n, Vector3(5.6, 0.5, 4.6), Vector3(0, 5.2, 0), _m("14101e", 0.0, 0.9))
		Gfx.cyl(n, 0.01, 3.0, 2.4, Vector3(0, 6.7, 0), _m("14101e", 0.0, 0.9), Vector3.ZERO, 4)
		for i in 3:
			Gfx.box(n, Vector3(0.6, 0.9, 0.06), Vector3(-1.6 + i * 1.6, 3.0, 2.04), _m("ffb030" if rng.randf() < 0.7 else "1a1626", 1.8, 0.6))
	elif r == 1:     # درخت بی‌برگ
		Gfx.cyl(n, 0.18, 0.4, 4.2, Vector3(0, 2.1, 0), _m("1c1620", 0.0, 1.0), Vector3(0, 0, rng.randf_range(-8.0, 8.0)), 6)
		for i in 5:
			Gfx.cyl(n, 0.03, 0.12, 2.0, Vector3(0, 3.6, 0), _m("1c1620", 0.0, 1.0), Vector3(0, i * 72.0, 50.0 + rng.randf_range(-10.0, 10.0)), 5)
	elif r == 2:     # کدوی جادویی
		var k := rng.randi_range(1, 3)
		for i in k:
			var px := i * 1.1 - (k - 1) * 0.55
			Gfx.sphere(n, 0.7, Vector3(px, 0.6, rng.randf_range(-0.3, 0.3)), _m("ff7a1a", 0.9, 0.6), 10)
			Gfx.box(n, Vector3(0.25, 0.2, 0.06), Vector3(px - 0.2, 0.7, 0.62), _m("ffe070", 3.0))
			Gfx.box(n, Vector3(0.25, 0.2, 0.06), Vector3(px + 0.2, 0.7, 0.62), _m("ffe070", 3.0))
			Gfx.box(n, Vector3(0.5, 0.1, 0.06), Vector3(px, 0.36, 0.62), _m("ffe070", 3.0))
			Gfx.box(n, Vector3(0.1, 0.25, 0.1), Vector3(px, 1.35, 0), _m("3a6a2a"))
	else:            # سنگ قبر و حصار
		for i in 3:
			var px := i * 1.4 - 1.4
			Gfx.box(n, Vector3(0.9, 1.5 + (i % 2) * 0.4, 0.3), Vector3(px, 0.8, 0), _m("6a6a78", 0.0, 0.95))
			Gfx.cyl(n, 0.45, 0.45, 0.3, Vector3(px, 1.55 + (i % 2) * 0.4, 0), _m("6a6a78", 0.0, 0.95), Vector3(90, 0, 0), 10)
		Gfx.glow(n, Vector3(0, 1.0, 0.3), 5.0, Color(0.4, 1.0, 0.5, 0.18))


static func _decor_volcano(n: Node3D, rng: RandomNumberGenerator) -> void:
	var r := rng.randi() % 4
	if r == 0:       # کوه آتشفشان کوچک
		var h := rng.randf_range(6.0, 12.0)
		Gfx.cyl(n, 0.9, 4.0, h, Vector3(0, h * 0.5, 0), _m("2c2220", 0.0, 0.95), Vector3.ZERO, 9)
		Gfx.cyl(n, 0.85, 0.85, 0.2, Vector3(0, h + 0.05, 0), _m("ff5a14", 3.0, 0.4), Vector3.ZERO, 9)
		Gfx.glow(n, Vector3(0, h + 0.8, 0), 6.0, Color(1.0, 0.4, 0.1, 0.4))
	elif r == 1:     # اسکلت دایناسور
		var bone := _m("e8dfc8", 0.0, 0.8)
		for i in 7:
			Gfx.cyl(n, 0.07, 0.07, 1.4 - abs(i - 3) * 0.14, Vector3(0, 1.4, -1.8 + i * 0.6), bone, Vector3(0, 0, 90), 5)
		Gfx.cyl(n, 0.1, 0.1, 4.4, Vector3(0, 0.7, 0), bone, Vector3(90, 0, 0), 6)
		Gfx.sphere(n, 0.45, Vector3(0, 1.5, -2.6), bone, 8)
		Gfx.box(n, Vector3(0.5, 0.3, 0.8), Vector3(0, 1.4, -3.1), bone)
	elif r == 2:     # رودخانه‌ی گدازه
		Gfx.box(n, Vector3(3.0, 0.12, 8.0), Vector3(0, 0.08, 0), _m("ff5a14", 2.6, 0.4))
		Gfx.glow(n, Vector3(0, 0.6, 0), 8.0, Color(1.0, 0.4, 0.1, 0.35))
		for i in 3:
			Gfx.box(n, Vector3(0.9, 0.5, 0.9), Vector3(rng.randf_range(-1.5, 1.5), 0.2, rng.randf_range(-3.0, 3.0)), _m("1c1412", 0.0, 0.95), Vector3(0, rng.randf_range(0.0, 90.0), 0))
	else:            # سرخس غول‌پیکر
		Gfx.cyl(n, 0.1, 0.16, 2.2, Vector3(0, 1.1, 0), _m("3a5a2a"), Vector3.ZERO, 6)
		for i in 7:
			Gfx.box(n, Vector3(0.5, 0.05, 2.8), Vector3(0, 2.2, 0), _m("2f7a34"), Vector3(-30, i * 51.0, 0))


static func _decor_sky(n: Node3D, rng: RandomNumberGenerator, side: int) -> void:
	var r := rng.randi() % 3
	var y0 := rng.randf_range(-1.5, 3.0)
	if r == 0:       # جزیره‌ی شناور با درخت
		Gfx.cyl(n, 3.0, 0.8, 2.8, Vector3(0, y0 + 1.4, 0), _m("8a6a4a", 0.0, 0.95), Vector3.ZERO, 9)
		Gfx.cyl(n, 3.1, 3.1, 0.35, Vector3(0, y0 + 2.9, 0), _m("5ac04a", 0.0, 0.9), Vector3.ZERO, 12)
		Gfx.cyl(n, 0.2, 0.28, 1.8, Vector3(0.4, y0 + 3.9, 0), _m("7a5030"), Vector3.ZERO, 7)
		Gfx.sphere(n, 1.4, Vector3(0.4, y0 + 5.3, 0), _m("3aa84a", 0.0, 0.9), 10)
	elif r == 1:     # قلعه‌ی کوچک
		Gfx.cyl(n, 2.6, 0.9, 2.2, Vector3(0, y0 + 1.1, 0), _m("8a7a6a", 0.0, 0.95), Vector3.ZERO, 8)
		Gfx.box(n, Vector3(3.2, 2.6, 3.2), Vector3(0, y0 + 3.5, 0), _m("f2eee6", 0.0, 0.8))
		for sx in [-1.5, 1.5]:
			Gfx.cyl(n, 0.5, 0.5, 4.2, Vector3(sx, y0 + 4.2, 0), _m("f2eee6", 0.0, 0.8), Vector3.ZERO, 8)
			Gfx.cyl(n, 0.01, 0.8, 1.2, Vector3(sx, y0 + 6.9, 0), _m("3a78e0", 0.0, 0.5), Vector3.ZERO, 8)
	else:            # بادکنک و ابر
		for i in 4:
			Gfx.sphere(n, rng.randf_range(0.9, 1.5), Vector3(i * 1.2 - 1.8, y0 + 5.0 + (i % 2) * 0.5, rng.randf_range(-0.4, 0.4)), _m("ffffff", 0.35, 0.95), 9)
		Gfx.sphere(n, 0.9, Vector3(0, y0 + 2.0, 0), _m(_pick(rng, ["ff4f6a", "ffd23f", "4f9aff"]), 0.2, 0.4), 10)
		Gfx.box(n, Vector3(0.7, 0.5, 0.7), Vector3(0, y0 + 0.5, 0), _m("8a5a2a"))


static func _decor_reef(n: Node3D, rng: RandomNumberGenerator) -> void:
	var r := rng.randi() % 4
	var cc: String = _pick(rng, ["ff5a8a", "ff8a3a", "b05cff", "ffd23f"])
	if r == 0:       # مرجان شاخه‌ای
		for i in 6:
			Gfx.cyl(n, 0.08, 0.2, 2.6 + (i % 3) * 0.6, Vector3(sin(i * 1.1) * 0.6, 1.4, cos(i * 1.1) * 0.6), _m(cc, 0.4, 0.7), Vector3(sin(i * 1.1) * 18.0, 0, cos(i * 1.1) * 18.0), 6)
	elif r == 1:     # صدف غول‌پیکر با مروارید
		Gfx.sphere(n, 1.6, Vector3(0, 0.9, 0), _m("f2d2e0", 0.1, 0.4), 12)
		Gfx.sphere(n, 0.5, Vector3(0, 1.2, 0), _m("ffffff", 2.0, 0.1), 10)
		Gfx.glow(n, Vector3(0, 1.2, 0), 4.0, Color(1, 1, 1, 0.25))
	elif r == 2:     # جلبک بلند
		for i in 4:
			for j in 5:
				Gfx.box(n, Vector3(0.25, 0.9, 0.06), Vector3(i * 0.5 - 0.75 + sin(j) * 0.25, 0.5 + j * 0.9, 0), _m("2fb85a", 0.2, 0.8), Vector3(0, 0, sin(j + i) * 12.0))
	else:            # ماهی‌ها و حباب
		for i in 3:
			var py := 2.0 + i * 1.2
			Gfx.sphere(n, 0.45, Vector3(i * 1.2 - 1.2, py, 0), _m(_pick(rng, ["ff8a3a", "27e8ff", "ffd23f"]), 0.5, 0.4), 8)
			Gfx.cyl(n, 0.01, 0.35, 0.5, Vector3(i * 1.2 - 1.2, py, 0.45), _m("ff8a3a", 0.5, 0.4), Vector3(90, 0, 0), 4)
		Gfx.sphere(n, 0.2, Vector3(0, 5.5, 0), _m("cfffff", 0.6, 0.1), 6)


# ============================================================
#                        پس‌زمینه‌ی دور (برای همه‌ی جهان‌ها)
# ============================================================
## parent در z=-215 است؛ عرض دید حدود ±160
static func far(parent: Node3D, id: String, rng: RandomNumberGenerator) -> void:
	match id:
		"brick": _far_brick(parent, rng)
		"moto": _far_neon_city(parent, rng)
		"crate": _far_jungle(parent, rng)
		"ring": _far_checker(parent, rng)
		"space": _far_space(parent, rng)
		"candy": _far_candy(parent, rng)
		"shrine": _far_shrine(parent, rng)
		"pirate": _far_sea(parent, rng)
		"haunted": _far_haunted(parent, rng)
		"volcano": _far_volcano(parent, rng)
		"sky": _far_sky(parent, rng)
		"reef": _far_reef(parent, rng)


static func _xs(rng: RandomNumberGenerator, step_min: float, step_max: float) -> Array[float]:
	var out: Array[float] = []
	var x := -170.0
	while x < 170.0:
		out.append(x)
		x += rng.randf_range(step_min, step_max)
	return out


static func _far_brick(p: Node3D, rng: RandomNumberGenerator) -> void:
	var cols: Array[String] = ["e3342f", "2f7fe0", "f6c915", "2faa4a", "f28c1c", "8a4fd0"]
	for x: float in _xs(rng, 10.0, 22.0):
		var h := rng.randf_range(18.0, 60.0)
		var w := rng.randf_range(12.0, 22.0)
		var n := Node3D.new()
		n.position = Vector3(x, 0, rng.randf_range(-10.0, 10.0))
		p.add_child(n)
		var floors := int(h / 8.0)
		for i in floors:
			Gfx.box(n, Vector3(w, 8.0, w), Vector3(0, 4.0 + i * 8.0, 0), _m(_pick(rng, cols), 0.0, 0.5))
		var tc: String = _pick(rng, cols)
		for sx in range(int(w / 4.0)):
			Gfx.cyl(n, 1.2, 1.2, 1.0, Vector3(-w * 0.5 + 2.0 + sx * 4.0, floors * 8.0 + 0.5, 0), _m(tc, 0.0, 0.5), Vector3.ZERO, 8)


static func _far_neon_city(p: Node3D, rng: RandomNumberGenerator) -> void:
	var neon: Array[String] = ["ff2d95", "27e8ff", "9d5cff", "3dff9a"]
	for x: float in _xs(rng, 12.0, 22.0):
		var h := rng.randf_range(35.0, 120.0)
		var w := rng.randf_range(10.0, 20.0)
		Gfx.box(p, Vector3(w, h, w), Vector3(x, h * 0.5, 0), _m("0c0820", 0.0, 0.6, 0.2))
		var c: String = _pick(rng, neon)
		for i in int(h / 7.0):
			if rng.randf() < 0.7:
				Gfx.box(p, Vector3(w * 0.8, 0.6, 0.2), Vector3(x, 3.0 + i * 7.0, w * 0.5 + 0.1), _m(c, 2.4, 0.4))
		Gfx.box(p, Vector3(w + 0.4, 0.8, w + 0.4), Vector3(x, h + 0.2, 0), _m(c, 2.4, 0.4))
	Gfx.cyl(p, 1.0, 1.0, 130.0, Vector3(40, 65, -20), _m("14102a", 0.0, 0.5), Vector3.ZERO, 8)
	Gfx.sphere(p, 7.0, Vector3(40, 128, -20), _m("27e8ff", 2.0, 0.3), 12)


static func _far_jungle(p: Node3D, rng: RandomNumberGenerator) -> void:
	for x: float in _xs(rng, 24.0, 40.0):
		var h := rng.randf_range(20.0, 55.0)
		Gfx.cyl(p, 3.0, rng.randf_range(16.0, 28.0), h, Vector3(x, h * 0.5, 0), _m("3a7a2a", 0.0, 0.95), Vector3.ZERO, 8)
	# معبد پلکانی
	for i in 6:
		Gfx.box(p, Vector3(46.0 - i * 7.0, 5.0, 46.0 - i * 7.0), Vector3(-60, 2.5 + i * 5.0, -30), _m("8a8f98" if i % 2 == 0 else "6f757e", 0.0, 0.95))
	Gfx.box(p, Vector3(10.0, 6.0, 10.0), Vector3(-60, 33.0, -30), _m("c8a04a", 0.6, 0.4, 0.6))


static func _far_checker(p: Node3D, rng: RandomNumberGenerator) -> void:
	for x: float in _xs(rng, 36.0, 55.0):
		var h := rng.randf_range(14.0, 40.0)
		var layers := int(h / 4.0)
		for i in layers:
			Gfx.cyl(p, 18.0 - i * 1.4, 18.5 - i * 1.4, 4.0, Vector3(x, 2.0 + i * 4.0, 0), _m("7a4a22" if i % 2 == 0 else "d9a85a", 0.0, 0.9), Vector3.ZERO, 10)
		Gfx.cyl(p, 18.0 - layers * 1.4, 18.0 - layers * 1.4, 1.0, Vector3(x, layers * 4.0 + 0.5, 0), _m("4aa832", 0.0, 0.9), Vector3.ZERO, 10)
	# لوپ غول‌پیکر
	P.ring(p, 26.0, 2.2, Vector3(50, 28, 15), _m("ffd000", 0.5, 0.3, 0.6), Vector3(0, 0, 0), 32)
	for i in 5:
		Gfx.sphere(p, 3.0, Vector3(-20 + i * 9.0, 54.0 + (i % 2) * 6.0, 10), _m("ffffff", 0.4, 0.9), 8)


static func _far_space(p: Node3D, rng: RandomNumberGenerator) -> void:
	for i in 110:
		var s := rng.randf_range(0.3, 1.0)
		Gfx.sphere(p, s, Vector3(rng.randf_range(-200, 200), rng.randf_range(2, 140), rng.randf_range(-60, 20)), _m("ffffff", 3.0), 4)
	var cols: Array[String] = ["ff5a8a", "5ad0ff", "ffb22e", "9d5cff"]
	for i in 4:
		var rad := rng.randf_range(10.0, 26.0)
		var c: String = cols[i % cols.size()]
		var pos := Vector3(-120 + i * 80.0, rng.randf_range(25.0, 70.0), -25)
		Gfx.sphere(p, rad, pos, _m(c, 0.6, 0.6), 16)
		if i % 2 == 0:
			P.ring(p, rad * 1.9, 0.9, pos, _m("ffffff", 1.0, 0.4), Vector3(72, 0, 14), 28)
	# سحابی
	Gfx.glow(p, Vector3(0, 60, -50), 260.0, Color(0.5, 0.2, 0.9, 0.18))
	Gfx.glow(p, Vector3(-70, 40, -40), 160.0, Color(0.2, 0.7, 1.0, 0.14))


static func _far_candy(p: Node3D, rng: RandomNumberGenerator) -> void:
	var cols: Array[String] = ["ff7ac2", "7a5cff", "ffd23f", "3de0c0", "ff9a5a"]
	for x: float in _xs(rng, 28.0, 44.0):
		var h := rng.randf_range(16.0, 36.0)
		Gfx.cyl(p, 1.0, rng.randf_range(14.0, 22.0), h, Vector3(x, h * 0.5, 0), _m("6a3a22", 0.0, 0.5), Vector3.ZERO, 12)
		Gfx.cyl(p, 6.0, 6.0, 3.0, Vector3(x, h + 0.5, 0), _m("fff8f0", 0.1, 0.5), Vector3.ZERO, 12)
		Gfx.sphere(p, 3.2, Vector3(x, h + 3.0, 0), _m(_pick(rng, cols), 0.3, 0.3), 10)
	# ریسه‌ی ابر پنبه‌ای
	for i in 6:
		Gfx.sphere(p, rng.randf_range(10.0, 18.0), Vector3(-130 + i * 55.0, rng.randf_range(50.0, 80.0), -40), _m(_pick(rng, ["ffc2e2", "c2e8ff", "fff0b0"]), 0.4, 0.95), 10)


static func _far_shrine(p: Node3D, rng: RandomNumberGenerator) -> void:
	# فوجی‌یامای مثلثی با برف
	Gfx.cyl(p, 6.0, 60.0, 80.0, Vector3(30, 40, -30), _m("4a4a8a", 0.0, 0.95), Vector3.ZERO, 10)
	Gfx.cyl(p, 3.0, 17.0, 22.0, Vector3(30, 74.0, -30), _m("fff4f4", 0.2, 0.9), Vector3.ZERO, 10)
	for x: float in _xs(rng, 34.0, 55.0):
		var h := rng.randf_range(16.0, 34.0)
		Gfx.cyl(p, 2.0, rng.randf_range(14.0, 24.0), h, Vector3(x, h * 0.5, 10), _m("3a3a6a", 0.0, 0.95), Vector3.ZERO, 8)
	# قصر ژاپنی دور
	for i in 4:
		var w := 22.0 - i * 4.0
		Gfx.box(p, Vector3(w, 6.0, w * 0.7), Vector3(-70, 3.0 + i * 8.5, -10), _m("f2e4cf", 0.1, 0.8))
		Gfx.box(p, Vector3(w + 8.0, 1.0, w * 0.7 + 8.0), Vector3(-70, 7.0 + i * 8.5, -10), _m("2a2a34", 0.0, 0.6))
	Gfx.glow(p, Vector3(0, 28, -60), 200.0, Color(1.0, 0.5, 0.4, 0.2))


static func _far_sea(p: Node3D, rng: RandomNumberGenerator) -> void:
	for i in 5:
		var px := -120.0 + i * 60.0 + rng.randf_range(-10, 10)
		Gfx.box(p, Vector3(14, 3, 36), Vector3(px, 1.2, 0), _m("5a3a1c", 0.0, 0.9))
		Gfx.cyl(p, 0.5, 0.5, 30.0, Vector3(px, 18.0, -2), _m("5a3a1c", 0.0, 0.9), Vector3.ZERO, 6)
		Gfx.box(p, Vector3(0.3, 18.0, 16.0), Vector3(px, 22.0, -2), _m("f6efe0", 0.1, 0.9))
	# جزیره‌ی آتشفشانی
	Gfx.cyl(p, 2.0, 22.0, 30.0, Vector3(70, 14, -50), _m("4a5a3a", 0.0, 0.95), Vector3.ZERO, 8)
	Gfx.cyl(p, 24.0, 28.0, 2.0, Vector3(70, 1, -50), _m("e8cf8a", 0.0, 0.95), Vector3.ZERO, 12)
	# ابرهای بلند
	for i in 5:
		Gfx.sphere(p, rng.randf_range(10.0, 18.0), Vector3(-130 + i * 60.0, rng.randf_range(55.0, 85.0), -45), _m("ffffff", 0.5, 0.95), 9)


static func _far_haunted(p: Node3D, rng: RandomNumberGenerator) -> void:
	# قلعه‌ی دراکولا روی صخره
	Gfx.cyl(p, 6.0, 26.0, 34.0, Vector3(-30, 17, -20), _m("1a1626", 0.0, 0.95), Vector3.ZERO, 7)
	Gfx.box(p, Vector3(26.0, 18.0, 16.0), Vector3(-30, 43.0, -20), _m("221c32", 0.0, 0.9))
	for sx in [-16.0, 0.0, 16.0]:
		Gfx.cyl(p, 3.0, 3.0, 28.0, Vector3(-30 + sx, 56.0, -20), _m("221c32", 0.0, 0.9), Vector3.ZERO, 8)
		Gfx.cyl(p, 0.01, 4.2, 8.0, Vector3(-30 + sx, 74.0, -20), _m("120e1c", 0.0, 0.9), Vector3.ZERO, 8)
		Gfx.box(p, Vector3(1.4, 2.0, 0.3), Vector3(-30 + sx, 56.0, -11.5), _m("ffb030", 2.2, 0.6))
	for x: float in _xs(rng, 20.0, 32.0):
		var h := rng.randf_range(10.0, 24.0)
		Gfx.cyl(p, 0.2, 1.2, h, Vector3(x, h * 0.5, 14), _m("0c0814", 0.0, 1.0), Vector3(0, 0, rng.randf_range(-6.0, 6.0)), 5)
	# خفاش‌ها
	for i in 14:
		Gfx.box(p, Vector3(2.4, 0.15, 0.7), Vector3(rng.randf_range(-100, 100), rng.randf_range(40, 90), -10), _m("0a0610"), Vector3(0, 0, rng.randf_range(-15, 15)))


static func _far_volcano(p: Node3D, rng: RandomNumberGenerator) -> void:
	for i in 3:
		var px := -90.0 + i * 85.0
		var h := rng.randf_range(50.0, 85.0)
		Gfx.cyl(p, 7.0, 42.0, h, Vector3(px, h * 0.5, -20), _m("2a1e1c", 0.0, 0.95), Vector3.ZERO, 9)
		Gfx.cyl(p, 7.0, 7.0, 1.0, Vector3(px, h + 0.2, -20), _m("ff5a14", 3.0, 0.4), Vector3.ZERO, 9)
		Gfx.glow(p, Vector3(px, h + 6.0, -20), 50.0, Color(1.0, 0.45, 0.1, 0.4))
		for j in 4:
			Gfx.cyl(p, 1.2, 2.4, h * 0.55, Vector3(px + (j - 1.5) * 4.0, h * 0.45, -19 + 20.0), _m("ff5a14", 2.2, 0.4), Vector3(0, 0, (j - 1.5) * 8.0), 5)
	# ابر دود
	for i in 6:
		Gfx.sphere(p, rng.randf_range(12.0, 22.0), Vector3(-120 + i * 52.0, rng.randf_range(70.0, 100.0), -40), _m("3a2824", 0.0, 1.0), 9)


static func _far_sky(p: Node3D, rng: RandomNumberGenerator) -> void:
	for i in 7:
		var px := -140.0 + i * 46.0 + rng.randf_range(-8, 8)
		var py := rng.randf_range(10.0, 50.0)
		var rad := rng.randf_range(10.0, 18.0)
		Gfx.cyl(p, rad, 2.0, rad * 1.3, Vector3(px, py, rng.randf_range(-20, 10)), _m("8a6a4a", 0.0, 0.95), Vector3.ZERO, 9)
		Gfx.cyl(p, rad + 0.5, rad + 0.5, 1.2, Vector3(px, py + rad * 0.65, 0), _m("5ac04a", 0.0, 0.9), Vector3.ZERO, 12)
		if i % 3 == 0:
			Gfx.box(p, Vector3(8.0, 10.0, 8.0), Vector3(px, py + rad * 0.65 + 5.5, 0), _m("f2eee6", 0.1, 0.8))
			Gfx.cyl(p, 0.01, 6.0, 7.0, Vector3(px, py + rad * 0.65 + 14.0, 0), _m("3a78e0", 0.0, 0.5), Vector3.ZERO, 8)
	for i in 9:
		Gfx.sphere(p, rng.randf_range(8.0, 15.0), Vector3(-150 + i * 38.0, rng.randf_range(4.0, 14.0), -30), _m("ffffff", 0.6, 0.95), 9)
	# رنگین‌کمان
	P.ring(p, 90.0, 2.0, Vector3(0, 0, -50), _m("ff6a6a", 1.2, 0.5), Vector3(0, 0, 0), 40)
	P.ring(p, 86.0, 2.0, Vector3(0, 0, -50), _m("ffd23f", 1.2, 0.5), Vector3(0, 0, 0), 40)
	P.ring(p, 82.0, 2.0, Vector3(0, 0, -50), _m("5ad0ff", 1.2, 0.5), Vector3(0, 0, 0), 40)


static func _far_reef(p: Node3D, rng: RandomNumberGenerator) -> void:
	var cols: Array[String] = ["ff5a8a", "ff8a3a", "b05cff", "ffd23f", "3de0c0"]
	for x: float in _xs(rng, 20.0, 34.0):
		var h := rng.randf_range(14.0, 40.0)
		Gfx.cyl(p, 2.0, 6.0, h, Vector3(x, h * 0.5, 0), _m(_pick(rng, cols), 0.4, 0.8), Vector3.ZERO, 7)
	# نهنگ
	Gfx.sphere(p, 14.0, Vector3(40, 50, -30), _m("3a5a9a", 0.1, 0.5), 14)
	Gfx.cyl(p, 0.5, 8.0, 26.0, Vector3(40, 50, -9), _m("3a5a9a", 0.1, 0.5), Vector3(90, 0, 0), 10)
	Gfx.box(p, Vector3(16.0, 1.0, 5.0), Vector3(40, 50, 6), _m("3a5a9a", 0.1, 0.5))
	# پرتوهای نور
	for i in 6:
		Gfx.box(p, Vector3(5.0, 140.0, 0.2), Vector3(-120 + i * 50.0, 70.0, -30), _m("e8ffff", 0.8, 0.5), Vector3(0, 0, -14))


# ============================================================
#                              موانع
# ============================================================
static func obstacle(id: String, kind: int, v: int, e: Object, n: Node3D) -> void:
	match id:
		"space": _obs_space(kind, v, e, n)
		"candy": _obs_candy(kind, v, e, n)
		"shrine": _obs_shrine(kind, v, e, n)
		"pirate": _obs_pirate(kind, v, e, n)
		"haunted": _obs_haunted(kind, v, e, n)
		"volcano": _obs_volcano(kind, v, e, n)
		"sky": _obs_sky(kind, v, e, n)
		"reef": _obs_reef(kind, v, e, n)


static func _dims(e: Object, kind: int) -> void:
	if kind == 2:
		e.y0 = 0.0; e.y1 = 0.9; e.half_d = 0.45
	elif kind == 3:
		e.y0 = 1.0; e.y1 = 6.0; e.half_d = 0.9
	else:
		e.y0 = 0.0; e.y1 = 2.8; e.half_d = 1.3


static func _obs_space(kind: int, v: int, e: Object, n: Node3D) -> void:
	_dims(e, kind)
	var neon: String = ["7a5cff", "27e8ff", "ff2d95", "3dff9a"][v % 4]
	if kind == 2:    # کریستال‌های کوتاه
		for i in 4:
			Gfx.cyl(n, 0.001, 0.32, 0.9 - (i % 2) * 0.2, Vector3(-0.7 + i * 0.47, 0.45, 0), _m(neon, 1.8, 0.2), Vector3.ZERO, 5)
	elif kind == 3:  # دروازه‌ی انرژی
		for sx in [-1.0, 1.0]:
			Gfx.cyl(n, 0.14, 0.18, 3.2, Vector3(sx, 1.6, 0), _m("c8ccd8", 0.0, 0.3, 0.8), Vector3.ZERO, 8)
			Gfx.sphere(n, 0.26, Vector3(sx, 3.3, 0), _m(neon, 3.0), 8)
		Gfx.box(n, Vector3(2.0, 0.22, 0.12), Vector3(0, 2.3, 0), _m(neon, 3.0))
		Gfx.box(n, Vector3(2.0, 0.22, 0.12), Vector3(0, 2.7, 0), _m(neon, 3.0))
	else:            # شهاب‌سنگ
		Gfx.sphere(n, 1.25, Vector3(0, 1.3, 0), _m("4a4458", 0.0, 0.95), 9)
		Gfx.sphere(n, 0.7, Vector3(0.7, 1.9, 0.4), _m("5a5468", 0.0, 0.95), 7)
		Gfx.sphere(n, 0.55, Vector3(-0.8, 0.8, 0.6), _m("3a3448", 0.0, 0.95), 7)
		Gfx.box(n, Vector3(2.2, 0.08, 0.08), Vector3(0, 1.3, 1.2), _m(neon, 2.5), Vector3(0, 0, 25))


static func _obs_candy(kind: int, v: int, e: Object, n: Node3D) -> void:
	_dims(e, kind)
	var cols: Array[String] = ["ff4f9a", "6a5cff", "ffd23f", "3de0c0"]
	var c: String = cols[v % 4]
	if kind == 2:    # پرتقال‌ لقمه‌ای/ژله
		Gfx.sphere(n, 0.5, Vector3(-0.5, 0.4, 0), _m(c, 0.35, 0.2), 10)
		Gfx.sphere(n, 0.5, Vector3(0.5, 0.4, 0), _m(cols[(v + 1) % 4], 0.35, 0.2), 10)
	elif kind == 3:  # طاق عصای آب‌نباتی
		for sx in [-1.0, 1.0]:
			for i in 6:
				Gfx.cyl(n, 0.17, 0.17, 0.55, Vector3(sx, 0.28 + i * 0.5, 0), _m("ffffff" if i % 2 == 0 else "e8142f", 0.1, 0.4), Vector3.ZERO, 8)
		Gfx.box(n, Vector3(2.4, 0.4, 0.6), Vector3(0, 3.2, 0), _m(c, 0.2, 0.4))
	else:            # بلوک ژله‌ای/شکلاتی
		Gfx.box(n, Vector3(1.9, 2.8, 2.3), Vector3(0, 1.4, 0), _m("5a2e18", 0.0, 0.5))
		for i in 4:
			Gfx.box(n, Vector3(1.95, 0.12, 2.35), Vector3(0, 0.3 + i * 0.7, 0), _m(c, 0.2, 0.4))
		Gfx.box(n, Vector3(1.9, 0.2, 2.3), Vector3(0, 2.85, 0), _m("fff8f0", 0.15, 0.6))
		Gfx.sphere(n, 0.28, Vector3(0, 3.1, 0), _m("e8142f", 0.3, 0.2), 8)


static func _obs_shrine(kind: int, v: int, e: Object, n: Node3D) -> void:
	_dims(e, kind)
	var red := _m("d8261f", 0.15, 0.45)
	if kind == 2:    # سنگ‌های باغ ژن
		Gfx.sphere(n, 0.55, Vector3(-0.5, 0.35, 0), _m("7a7a84", 0.0, 0.95), 8)
		Gfx.sphere(n, 0.5, Vector3(0.5, 0.3, 0), _m("8a8a94", 0.0, 0.95), 8)
		Gfx.box(n, Vector3(1.9, 0.12, 0.8), Vector3(0, 0.06, 0), _m("e8dcc8", 0.0, 0.9))
	elif kind == 3:  # تُوریِ کوچک
		for sx in [-1.0, 1.0]:
			Gfx.cyl(n, 0.2, 0.24, 3.2, Vector3(sx, 1.6, 0), red, Vector3.ZERO, 8)
		Gfx.box(n, Vector3(3.0, 0.3, 0.5), Vector3(0, 3.2, 0), _m("1a1a20", 0.0, 0.5))
		Gfx.box(n, Vector3(2.3, 0.22, 0.4), Vector3(0, 2.6, 0), red)
		Gfx.box(n, Vector3(0.1, 0.5, 0.1), Vector3(0, 2.3, 0), _m("ffcf70", 1.5))
	else:            # مجسمه‌ی شیر نگهبان/معبد
		Gfx.box(n, Vector3(1.9, 0.7, 2.3), Vector3(0, 0.35, 0), _m("8a8a94", 0.0, 0.95))
		Gfx.box(n, Vector3(1.4, 1.4, 1.6), Vector3(0, 1.4, 0), _m("a0a0aa", 0.0, 0.9))
		Gfx.sphere(n, 0.7, Vector3(0, 2.4, 0.3), _m("a0a0aa", 0.0, 0.9), 9)
		Gfx.box(n, Vector3(0.18, 0.18, 0.1), Vector3(-0.25, 2.5, 0.95), _m("e8342f", 2.0))
		Gfx.box(n, Vector3(0.18, 0.18, 0.1), Vector3(0.25, 2.5, 0.95), _m("e8342f", 2.0))


static func _obs_pirate(kind: int, v: int, e: Object, n: Node3D) -> void:
	_dims(e, kind)
	var wood := _m("7a4e28", 0.0, 0.9)
	if kind == 2:    # بشکه‌های کوتاه
		for sx in [-0.5, 0.5]:
			Gfx.cyl(n, 0.45, 0.45, 0.85, Vector3(sx, 0.43, 0), wood, Vector3.ZERO, 10)
			Gfx.cyl(n, 0.47, 0.47, 0.08, Vector3(sx, 0.25, 0), _m("3a3a40", 0.0, 0.4, 0.8), Vector3.ZERO, 10)
			Gfx.cyl(n, 0.47, 0.47, 0.08, Vector3(sx, 0.65, 0), _m("3a3a40", 0.0, 0.4, 0.8), Vector3.ZERO, 10)
	elif kind == 3:  # بوم و بادبان
		for sx in [-1.0, 1.0]:
			Gfx.cyl(n, 0.14, 0.18, 3.2, Vector3(sx, 1.6, 0), wood, Vector3.ZERO, 7)
		Gfx.cyl(n, 0.1, 0.1, 2.4, Vector3(0, 3.0, 0), wood, Vector3(0, 0, 90), 6)
		Gfx.box(n, Vector3(2.1, 1.0, 0.05), Vector3(0, 2.4, 0), _m("f6efe0", 0.0, 0.9))
		Gfx.box(n, Vector3(0.7, 0.4, 0.06), Vector3(0, 2.4, 0.03), _m("141414", 0.0, 0.9))
	else:            # توپ‌خانه
		Gfx.box(n, Vector3(1.9, 1.0, 2.3), Vector3(0, 0.5, 0), wood)
		Gfx.cyl(n, 0.4, 0.5, 1.9, Vector3(0, 1.5, 0), _m("23232a", 0.0, 0.4, 0.8), Vector3(90, 0, 0), 10)
		for sx in [-0.8, 0.8]:
			Gfx.cyl(n, 0.5, 0.5, 0.18, Vector3(sx, 0.5, 0.5), _m("4a2e18", 0.0, 0.9), Vector3(0, 0, 90), 12)
		Gfx.sphere(n, 0.3, Vector3(0, 2.1, 0), _m("23232a", 0.0, 0.4, 0.8), 8)


static func _obs_haunted(kind: int, v: int, e: Object, n: Node3D) -> void:
	_dims(e, kind)
	if kind == 2:    # کدو
		for sx in [-0.5, 0.5]:
			Gfx.sphere(n, 0.5, Vector3(sx, 0.4, 0), _m("ff7a1a", 1.0, 0.6), 9)
			Gfx.box(n, Vector3(0.2, 0.16, 0.06), Vector3(sx - 0.15, 0.47, 0.47), _m("ffe070", 3.0))
			Gfx.box(n, Vector3(0.2, 0.16, 0.06), Vector3(sx + 0.15, 0.47, 0.47), _m("ffe070", 3.0))
	elif kind == 3:  # طاق قبرستان با تار عنکبوت
		for sx in [-1.0, 1.0]:
			Gfx.box(n, Vector3(0.4, 3.2, 0.4), Vector3(sx, 1.6, 0), _m("2a2a34", 0.0, 0.95))
		Gfx.box(n, Vector3(2.6, 0.4, 0.5), Vector3(0, 3.0, 0), _m("2a2a34", 0.0, 0.95))
		for i in 4:
			Gfx.box(n, Vector3(0.04, 0.9, 0.04), Vector3(-0.8 + i * 0.55, 2.4, 0), _m("cfd8ff", 1.0), Vector3(0, 0, 0))
		Gfx.sphere(n, 0.22, Vector3(0.2, 1.9, 0), _m("14101e", 0.0, 0.8), 7)
	else:            # روح بزرگ / تابوت
		Gfx.box(n, Vector3(1.9, 1.0, 2.3), Vector3(0, 0.5, 0), _m("3a2a22", 0.0, 0.85))
		Gfx.box(n, Vector3(1.95, 0.2, 2.35), Vector3(0, 1.1, 0), _m("4a3428", 0.0, 0.85))
		Gfx.sphere(n, 0.7, Vector3(0, 2.2, 0), _m("e8fff0", 2.0, 0.3), 10)
		Gfx.cyl(n, 0.7, 0.9, 1.2, Vector3(0, 1.7, 0), _m("e8fff0", 1.8, 0.3), Vector3.ZERO, 10)
		Gfx.sphere(n, 0.12, Vector3(-0.25, 2.3, 0.6), _m("101018"), 6)
		Gfx.sphere(n, 0.12, Vector3(0.25, 2.3, 0.6), _m("101018"), 6)


static func _obs_volcano(kind: int, v: int, e: Object, n: Node3D) -> void:
	_dims(e, kind)
	if kind == 2:    # تخم دایناسور
		for sx in [-0.5, 0.5]:
			Gfx.sphere(n, 0.45, Vector3(sx, 0.45, 0), _m("d8e8b0" if v % 2 == 0 else "e8c8a0", 0.1, 0.7), 9)
		Gfx.box(n, Vector3(1.9, 0.16, 0.8), Vector3(0, 0.08, 0), _m("3a2a22", 0.0, 0.95))
	elif kind == 3:  # طاق استخوان
		var bone := _m("e8dfc8", 0.0, 0.8)
		for sx in [-1.0, 1.0]:
			Gfx.cyl(n, 0.16, 0.2, 3.2, Vector3(sx, 1.6, 0), bone, Vector3.ZERO, 6)
			Gfx.sphere(n, 0.32, Vector3(sx, 0.2, 0), bone, 7)
		Gfx.cyl(n, 0.2, 0.2, 2.4, Vector3(0, 3.0, 0), bone, Vector3(0, 0, 90), 6)
		for i in 5:
			Gfx.cyl(n, 0.02, 0.1, 0.5, Vector3(-0.8 + i * 0.4, 2.75, 0), bone, Vector3.ZERO, 4)
	else:            # صخره‌ی گداخته
		Gfx.box(n, Vector3(1.9, 2.8, 2.3), Vector3(0, 1.4, 0), _m("2a2220", 0.0, 0.95), Vector3(0, 4, 0))
		for i in 4:
			Gfx.box(n, Vector3(0.12, 1.8 - i * 0.2, 0.06), Vector3(-0.7 + i * 0.5, 1.4, 1.16), _m("ff5a14", 3.0), Vector3(0, 0, rng_tilt(i)))
		Gfx.glow(n, Vector3(0, 1.4, 0), 5.0, Color(1, 0.4, 0.1, 0.22))


static func rng_tilt(i: int) -> float:
	return float((i * 37) % 30) - 15.0


static func _obs_sky(kind: int, v: int, e: Object, n: Node3D) -> void:
	_dims(e, kind)
	if kind == 2:    # ابر کوچک
		for i in 4:
			Gfx.sphere(n, 0.42 - (i % 2) * 0.06, Vector3(-0.65 + i * 0.43, 0.4 + (i % 2) * 0.12, 0), _m("ffffff", 0.45, 0.95), 8)
	elif kind == 3:  # طاق رنگین‌کمان
		for sx in [-1.0, 1.0]:
			Gfx.cyl(n, 0.16, 0.2, 3.2, Vector3(sx, 1.6, 0), _m("f2eee6", 0.1, 0.7), Vector3.ZERO, 8)
		var cols: Array[String] = ["ff6a6a", "ffd23f", "5ad0ff"]
		for i in 3:
			Gfx.box(n, Vector3(2.3, 0.2, 0.5), Vector3(0, 2.4 + i * 0.22, 0), _m(cols[i], 1.4, 0.5))
	else:            # برج ابری با پرچم
		Gfx.cyl(n, 1.3, 1.5, 2.8, Vector3(0, 1.4, 0), _m("f2eee6", 0.15, 0.8), Vector3.ZERO, 10)
		Gfx.sphere(n, 1.0, Vector3(0, 3.0, 0), _m("ffffff", 0.5, 0.95), 9)
		Gfx.cyl(n, 0.03, 0.03, 1.2, Vector3(0, 3.9, 0), _m("8a8a90"), Vector3.ZERO, 5)
		Gfx.box(n, Vector3(0.7, 0.4, 0.03), Vector3(0.35, 4.3, 0), _m("ff4f6a", 0.6))


static func _obs_reef(kind: int, v: int, e: Object, n: Node3D) -> void:
	_dims(e, kind)
	var cc: String = ["ff5a8a", "ff8a3a", "b05cff", "ffd23f"][v % 4]
	if kind == 2:    # ستاره‌ی دریایی و مرجان کوتاه
		for sx in [-0.5, 0.5]:
			for i in 5:
				Gfx.box(n, Vector3(0.18, 0.12, 0.55), Vector3(sx, 0.2, 0), _m(cc, 0.5, 0.7), Vector3(0, i * 72.0, 0))
	elif kind == 3:  # طاق نهنگ/دم نهنگ استخوانی ← طاق مرجانی
		for sx in [-1.0, 1.0]:
			Gfx.cyl(n, 0.2, 0.34, 3.2, Vector3(sx, 1.6, 0), _m(cc, 0.5, 0.7), Vector3.ZERO, 7)
			for j in 3:
				Gfx.cyl(n, 0.05, 0.12, 0.9, Vector3(sx + (j - 1) * 0.2, 3.3, 0), _m(cc, 0.5, 0.7), Vector3(0, 0, (j - 1) * 25.0), 5)
		Gfx.cyl(n, 0.2, 0.2, 2.4, Vector3(0, 2.9, 0), _m(cc, 0.5, 0.7), Vector3(0, 0, 90), 7)
	else:            # توده‌ی مرجان بزرگ / ماهی بادکنکی
		for i in 5:
			Gfx.cyl(n, 0.1, 0.35, 2.4 + (i % 3) * 0.2, Vector3(-0.7 + i * 0.35, 1.3, (i % 2) * 0.4 - 0.2), _m(cc, 0.5, 0.7), Vector3(0, 0, (i - 2) * 6.0), 6)
		Gfx.sphere(n, 0.55, Vector3(0, 2.7, 0), _m("ffd23f", 0.5, 0.5), 9)
		for i in 6:
			Gfx.cyl(n, 0.01, 0.05, 0.3, Vector3(sin(i) * 0.55, 2.7 + cos(i) * 0.3, cos(i) * 0.55), _m("ff8a3a"), Vector3(0, 0, i * 60), 4)


# ============================================================
#                              سکه
# ============================================================
static func coin(id: String) -> Node3D:
	var n := Node3D.new()
	match id:
		"space":
			Gfx.cyl(n, 0.001, 0.3, 0.55, Vector3(0, 0.27, 0), _m("7fd0ff", 2.4, 0.2), Vector3.ZERO, 6)
			Gfx.cyl(n, 0.3, 0.001, 0.55, Vector3(0, -0.27, 0), _m("7fd0ff", 2.4, 0.2), Vector3.ZERO, 6)
		"candy":
			Gfx.sphere(n, 0.28, Vector3.ZERO, _m("ff4f9a", 0.4, 0.2), 10)
			Gfx.box(n, Vector3(0.22, 0.2, 0.04), Vector3(0.38, 0, 0), _m("ffffff", 0.4, 0.3), Vector3(0, 0, 45))
			Gfx.box(n, Vector3(0.22, 0.2, 0.04), Vector3(-0.38, 0, 0), _m("ffffff", 0.4, 0.3), Vector3(0, 0, 45))
		"shrine":
			Gfx.cyl(n, 0.38, 0.38, 0.07, Vector3.ZERO, _m("e8b030", 1.2, 0.3, 0.9), Vector3(90, 0, 0), 18)
			Gfx.box(n, Vector3(0.16, 0.16, 0.1), Vector3.ZERO, _m("1a1a20", 0.0, 0.6))
		"pirate":
			Gfx.cyl(n, 0.4, 0.4, 0.09, Vector3.ZERO, _m("ffcf30", 1.3, 0.25, 0.9), Vector3(90, 0, 0), 16)
			Gfx.box(n, Vector3(0.22, 0.06, 0.12), Vector3.ZERO, _m("8a5a10", 0.0, 0.5, 0.6))
		"haunted":
			Gfx.sphere(n, 0.32, Vector3(0, 0.1, 0), _m("b8ffd8", 2.6, 0.2), 9)
			Gfx.cyl(n, 0.32, 0.12, 0.45, Vector3(0, -0.15, 0), _m("b8ffd8", 2.0, 0.2), Vector3.ZERO, 8)
		"volcano":
			Gfx.sphere(n, 0.34, Vector3.ZERO, _m("ff7a1a", 2.2, 0.3), 8)
			Gfx.box(n, Vector3(0.3, 0.3, 0.3), Vector3.ZERO, _m("ffd070", 2.6), Vector3(30, 40, 20))
		"sky":
			Gfx.sphere(n, 0.34, Vector3.ZERO, _m("ffffff", 1.2, 0.8), 9)
			Gfx.box(n, Vector3(0.9, 0.04, 0.3), Vector3(0, 0, 0), _m("ffe9a0", 1.6), Vector3(0, 0, 20))
		"reef":
			Gfx.sphere(n, 0.34, Vector3.ZERO, _m("fff4fa", 2.0, 0.1), 10)
			Gfx.glow(n, Vector3.ZERO, 1.2, Color(1, 1, 1, 0.25))
		_:
			Gfx.sphere(n, 0.3, Vector3.ZERO, _m("ffd23f", 1.0), 8)
	return n


# ============================================================
#                        سنگ فرش جاده‌ی خاص هر جهان
# ============================================================
## نوارهای تزئینی روی جاده (خط‌چین نئونی، گلبرگ و ...)؛ طول ۱۲ واحد، parent = مرکز تایل
static func road_marks(parent: Node3D, id: String, rng: RandomNumberGenerator, half: float) -> void:
	var col := ""
	var emit := 0.0
	match id:
		"space": col = "7fd0ff"; emit = 2.4
		"moto": col = "ff2d95"; emit = 2.0
		"candy": col = "ffffff"; emit = 0.2
		"shrine": col = "c8404a"; emit = 0.1
		"pirate": col = "5a3a1c"; emit = 0.0
		"haunted": col = "5affc0"; emit = 1.6
		"volcano": col = "ff5a14"; emit = 2.4
		"sky": col = "ffffff"; emit = 0.8
		"reef": col = "27e8d0"; emit = 1.6
		_: return
	var mat := _m(col, emit, 0.5)
	for sx in [-half + 0.25, half - 0.25]:
		Gfx.box(parent, Vector3(0.14, 0.03, 12.0), Vector3(sx, 0.03, 0), mat)
	if id in ["pirate"]:
		for i in 6:
			Gfx.box(parent, Vector3(half * 2.0, 0.02, 0.06), Vector3(0, 0.03, -5.5 + i * 2.2), mat)


# ============================================================
#     NPC های کنار جاده: شخصیت‌های «اورجینال» در سبک انیمه / کارتون / پیکسل / فیلم
#     (الهام از سبک‌ها و کهن‌الگوها؛ هیچ شخصیت یا برند واقعی کپی نشده)
# ============================================================
const NPC_KINDS: Array[String] = ["anime_girl", "ninja", "mage", "robot", "bear", "pixel_knight", "ghost", "pirate_cat", "astro", "chef"]
const NPC_NAMES := {
	"anime_girl": "دختر انیمه‌ای", "ninja": "نینجای سایه", "mage": "جادوگر ستاره", "robot": "ربات دوست‌داشتنی",
	"bear": "خرس کارتونی", "pixel_knight": "شوالیه ۱۶ بیتی", "ghost": "روح کوچولو", "pirate_cat": "گربه‌ی دزد دریایی",
	"astro": "فضانورد", "chef": "سرآشپز بامزه",
}


static func _person(n: Node3D, skin: String, top: String, bottom: String, scale_h: float = 1.0) -> Dictionary:
	var parts := {}
	Gfx.box(n, Vector3(0.28, 0.7, 0.3), Vector3(-0.17, 0.35, 0), _m(bottom, 0.0, 0.8))
	Gfx.box(n, Vector3(0.28, 0.7, 0.3), Vector3(0.17, 0.35, 0), _m(bottom, 0.0, 0.8))
	Gfx.box(n, Vector3(0.7, 0.75, 0.38), Vector3(0, 1.08, 0), _m(top, 0.0, 0.7))
	Gfx.box(n, Vector3(0.22, 0.7, 0.24), Vector3(-0.48, 1.0, 0), _m(top, 0.0, 0.7))
	var arm := Node3D.new()
	arm.position = Vector3(0.48, 1.38, 0)
	n.add_child(arm)
	Gfx.box(arm, Vector3(0.22, 0.7, 0.24), Vector3(0, -0.3, 0), _m(top, 0.0, 0.7))
	Gfx.box(arm, Vector3(0.2, 0.2, 0.22), Vector3(0, -0.7, 0), _m(skin, 0.0, 0.8))
	var head := Node3D.new()
	head.position = Vector3(0, 1.8, 0)
	n.add_child(head)
	Gfx.box(head, Vector3(0.62, 0.62, 0.62), Vector3.ZERO, _m(skin, 0.0, 0.8))
	parts["arm"] = arm
	parts["head"] = head
	n.scale = Vector3.ONE * scale_h
	return parts


static func _eyes(head: Node3D, hex: String, big: bool = false) -> void:
	var s := 0.17 if big else 0.1
	for sx in [-0.15, 0.15]:
		Gfx.box(head, Vector3(s, s * (1.5 if big else 1.0), 0.05), Vector3(sx, 0.03, 0.32), _m(hex, 0.6, 0.3))
		if big:
			Gfx.box(head, Vector3(0.05, 0.05, 0.06), Vector3(sx + 0.03, 0.09, 0.34), _m("ffffff", 1.0))


static func npc_build(kind: String, n: Node3D) -> Dictionary:
	var p := {}
	match kind:
		"anime_girl":      # موی صورتی بلند، یونیفورم، چشم درشت
			p = _person(n, "ffe0cc", "f2f2ff", "2a3a8a")
			var h: Node3D = p["head"]
			Gfx.box(h, Vector3(0.72, 0.28, 0.72), Vector3(0, 0.34, -0.02), _m("ff7ab8", 0.2, 0.6))
			Gfx.box(h, Vector3(0.72, 0.9, 0.2), Vector3(0, -0.15, -0.33), _m("ff7ab8", 0.2, 0.6))
			for sx in [-0.42, 0.42]:
				Gfx.box(h, Vector3(0.2, 0.9, 0.3), Vector3(sx, -0.15, 0.0), _m("ff7ab8", 0.2, 0.6))
				Gfx.sphere(h, 0.16, Vector3(sx, 0.35, -0.1), _m("ff4f9a", 0.3, 0.5), 6)
			_eyes(h, "3a8aff", true)
			Gfx.box(n, Vector3(0.74, 0.1, 0.42), Vector3(0, 0.78, 0), _m("c8203a", 0.0, 0.6))
		"ninja":           # ماسک و بند پیشانی، شنل
			p = _person(n, "2a2a38", "1a1a28", "1a1a28")
			var h2: Node3D = p["head"]
			Gfx.box(h2, Vector3(0.66, 0.2, 0.66), Vector3(0, 0.15, 0), _m("e8342f", 0.2, 0.6))
			Gfx.box(h2, Vector3(0.5, 0.14, 0.05), Vector3(0, 0.02, 0.33), _m("ffe8c8", 0.3, 0.5))
			Gfx.box(h2, Vector3(0.1, 0.1, 0.06), Vector3(-0.12, 0.02, 0.34), _m("101018"))
			Gfx.box(h2, Vector3(0.1, 0.1, 0.06), Vector3(0.12, 0.02, 0.34), _m("101018"))
			Gfx.box(n, Vector3(0.9, 1.0, 0.08), Vector3(0, 1.0, -0.26), _m("3a2a6a", 0.1, 0.8), Vector3(8, 0, 0))
		"mage":            # کلاه نوک‌تیز با ستاره، عصا
			p = _person(n, "ffd8b8", "5a3aa8", "3a2a6a")
			var h3: Node3D = p["head"]
			Gfx.cyl(h3, 0.45, 0.45, 0.06, Vector3(0, 0.32, 0), _m("3a2a8a", 0.1, 0.6), Vector3.ZERO, 10)
			Gfx.cyl(h3, 0.01, 0.3, 0.9, Vector3(0, 0.82, 0), _m("3a2a8a", 0.1, 0.6), Vector3.ZERO, 8)
			Gfx.sphere(h3, 0.1, Vector3(0, 1.28, 0), _m("ffe070", 3.0), 6)
			Gfx.box(h3, Vector3(0.5, 0.45, 0.2), Vector3(0, -0.45, 0.2), _m("f2f2f2", 0.1, 0.9))
			_eyes(h3, "202030")
			Gfx.cyl(n, 0.04, 0.04, 2.0, Vector3(-0.7, 1.0, 0.1), _m("7a4e28"), Vector3.ZERO, 5)
			Gfx.sphere(n, 0.14, Vector3(-0.7, 2.05, 0.1), _m("7fe8ff", 3.0), 7)
		"robot":           # بدنه‌ی فلزی، چشم LED، آنتن
			p = _person(n, "c8d0dc", "9aa6b8", "6a7488")
			var h4: Node3D = p["head"]
			Gfx.box(h4, Vector3(0.5, 0.18, 0.05), Vector3(0, 0.02, 0.32), _m("0a0a14"))
			Gfx.box(h4, Vector3(0.1, 0.1, 0.06), Vector3(-0.12, 0.02, 0.34), _m("27ffa0", 3.0))
			Gfx.box(h4, Vector3(0.1, 0.1, 0.06), Vector3(0.12, 0.02, 0.34), _m("27ffa0", 3.0))
			Gfx.cyl(h4, 0.02, 0.02, 0.4, Vector3(0, 0.5, 0), _m("6a7488"), Vector3.ZERO, 5)
			Gfx.sphere(h4, 0.07, Vector3(0, 0.72, 0), _m("ff4040", 3.0), 6)
			Gfx.box(n, Vector3(0.3, 0.3, 0.05), Vector3(0, 1.1, 0.2), _m("27e8ff", 2.0))
		"bear":            # کارتونی گرد با گوش
			p = _person(n, "8a5a32", "e8342f", "2f7fe0", 1.1)
			var h5: Node3D = p["head"]
			for sx in [-0.3, 0.3]:
				Gfx.sphere(h5, 0.16, Vector3(sx, 0.34, 0), _m("8a5a32"), 7)
				Gfx.sphere(h5, 0.08, Vector3(sx, 0.34, 0.1), _m("d8a070"), 6)
			Gfx.box(h5, Vector3(0.3, 0.22, 0.12), Vector3(0, -0.1, 0.34), _m("d8a070"))
			Gfx.box(h5, Vector3(0.1, 0.08, 0.06), Vector3(0, -0.04, 0.42), _m("101018"))
			_eyes(h5, "101018")
		"pixel_knight":    # زره مکعبی ۱۶ بیتی
			p = _person(n, "e8c8a0", "c8d0dc", "6a7488")
			var h6: Node3D = p["head"]
			Gfx.box(h6, Vector3(0.7, 0.4, 0.7), Vector3(0, 0.22, 0), _m("c8d0dc", 0.0, 0.3, 0.7))
			Gfx.box(h6, Vector3(0.12, 0.35, 0.12), Vector3(0, 0.62, 0), _m("e8342f", 0.4))
			Gfx.box(h6, Vector3(0.5, 0.08, 0.05), Vector3(0, 0.0, 0.34), _m("101018"))
			Gfx.box(n, Vector3(0.1, 1.4, 0.2), Vector3(-0.72, 1.0, 0.2), _m("e8f0ff", 0.4, 0.2, 0.8))
			Gfx.box(n, Vector3(0.55, 0.65, 0.08), Vector3(-0.6, 1.0, 0.42), _m("2f7fe0", 0.1, 0.5, 0.4))
		"ghost":           # روح سفید شناور
			Gfx.cyl(n, 0.5, 0.65, 1.3, Vector3(0, 1.0, 0), _m("f4f8ff", 1.2, 0.5), Vector3.ZERO, 10)
			Gfx.sphere(n, 0.5, Vector3(0, 1.65, 0), _m("f4f8ff", 1.2, 0.5), 10)
			var arm_g := Node3D.new()
			arm_g.position = Vector3(0.55, 1.3, 0.1)
			n.add_child(arm_g)
			Gfx.sphere(arm_g, 0.18, Vector3(0.1, -0.1, 0), _m("f4f8ff", 1.2, 0.5), 6)
			Gfx.box(n, Vector3(0.12, 0.2, 0.06), Vector3(-0.17, 1.7, 0.46), _m("101018"))
			Gfx.box(n, Vector3(0.12, 0.2, 0.06), Vector3(0.17, 1.7, 0.46), _m("101018"))
			Gfx.glow(n, Vector3(0, 1.3, 0), 3.5, Color(0.7, 1.0, 0.9, 0.2))
			p = {"arm": arm_g, "head": n}
		"pirate_cat":      # گربه با کلاه دزدان و چشم‌بند
			p = _person(n, "e8a050", "b8202a", "3a2a1a", 0.95)
			var h7: Node3D = p["head"]
			for sx in [-0.22, 0.22]:
				Gfx.cyl(h7, 0.01, 0.13, 0.28, Vector3(sx, 0.42, 0), _m("e8a050"), Vector3.ZERO, 4)
			Gfx.box(h7, Vector3(0.78, 0.14, 0.78), Vector3(0, 0.34, 0), _m("141414"))
			Gfx.box(h7, Vector3(0.3, 0.1, 0.06), Vector3(0, 0.34, 0.4), _m("f2f2f2"))
			Gfx.box(h7, Vector3(0.18, 0.18, 0.06), Vector3(-0.15, 0.03, 0.33), _m("101018"))
			Gfx.box(h7, Vector3(0.1, 0.1, 0.06), Vector3(0.15, 0.03, 0.33), _m("7fe8a0", 1.0))
			Gfx.box(n, Vector3(0.1, 0.1, 0.9), Vector3(0, 0.55, -0.5), _m("e8a050"), Vector3(-40, 0, 0))
		"astro":           # کلاه شیشه‌ای و کوله
			p = _person(n, "ffd8b8", "f2f2f8", "e0e4ee")
			var h8: Node3D = p["head"]
			Gfx.sphere(h8, 0.55, Vector3.ZERO, _m("9ad8ff", 0.3, 0.1), 12)
			Gfx.box(n, Vector3(0.55, 0.75, 0.3), Vector3(0, 1.1, -0.35), _m("c8ccd8", 0.0, 0.5, 0.5))
			Gfx.box(n, Vector3(0.2, 0.14, 0.05), Vector3(0, 1.2, 0.2), _m("ff6a2a", 1.6))
			_eyes(h8, "202030")
		_:                 # سرآشپز
			p = _person(n, "ffd8b8", "f6f6f6", "3a3a46")
			var h9: Node3D = p["head"]
			Gfx.cyl(h9, 0.3, 0.3, 0.5, Vector3(0, 0.56, 0), _m("ffffff", 0.2, 0.9), Vector3.ZERO, 8)
			Gfx.sphere(h9, 0.38, Vector3(0, 0.9, 0), _m("ffffff", 0.2, 0.9), 9)
			Gfx.box(h9, Vector3(0.44, 0.1, 0.05), Vector3(0, -0.12, 0.33), _m("5a3a1c"))
			_eyes(h9, "202030")
	return p


## یک NPC کنار جاده می‌گذارد و دست‌تکان‌دادن/جَستن ساده را به آن می‌دهد (parent باید داخل درخت باشد)
static func npc_spawn(parent: Node3D, side: int, z: float, road_half: float, shoulder: float, rng: RandomNumberGenerator, kind: String = "") -> void:
	if kind == "":
		kind = NPC_KINDS[rng.randi() % NPC_KINDS.size()]
	var n := Node3D.new()
	n.position = Vector3(float(side) * (road_half + shoulder + 1.6), 0.0, z)
	n.rotation_degrees.y = -90.0 * float(side) + rng.randf_range(-15.0, 15.0)
	parent.add_child(n)
	var p := npc_build(kind, n)
	n.name = "npc_" + kind
	n.set_meta("npc", kind)
	if p.has("arm"):
		var arm: Node3D = p["arm"]
		var tw := n.create_tween().set_loops()
		tw.tween_property(arm, "rotation_degrees:z", 150.0, 0.35 + rng.randf() * 0.2)
		tw.tween_property(arm, "rotation_degrees:z", 110.0, 0.35 + rng.randf() * 0.2)
	var tb := n.create_tween().set_loops()
	tb.tween_property(n, "position:y", 0.18, 0.5 + rng.randf() * 0.2).set_trans(Tween.TRANS_SINE)
	tb.tween_property(n, "position:y", 0.0, 0.5 + rng.randf() * 0.2).set_trans(Tween.TRANS_SINE)
