extends RefCounted
## هنرِ رابط کاربری که با کد ساخته می‌شود: دکمه‌های براق با گرادیان، پنل شیشه‌ای، اسلایدر، پرتوهای نورانی.
## هیچ فایل تصویری لازم نیست؛ همه‌چیز یک‌بار ساخته و در حافظه نگه‌داری می‌شود.

static var _cache := {}
## سبک دکمه‌ها: classic | glass | flat | neon | candy | outline  (از «ظاهر» در ویرایشگر محتوا تنظیم می‌شود)
static var style := "classic"
const STYLES := [["classic", "کلاسیک"], ["glass", "شیشه‌ای (آیفونی)"], ["flat", "تخت"], ["neon", "نئون"], ["candy", "آبنبات"], ["outline", "خطی"]]


## فاصله‌ی علامت‌گذاری با لبه‌ی مستطیل گرد (منفی = داخل)
static func _sdf(x: int, y: int, w: int, h: int, inset: float, r: float) -> float:
	var hx := float(w) * 0.5 - inset - r
	var hy := float(h) * 0.5 - inset - r
	var px := absf(float(x) + 0.5 - float(w) * 0.5) - hx
	var py := absf(float(y) + 0.5 - float(h) * 0.5) - hy
	return Vector2(maxf(px, 0.0), maxf(py, 0.0)).length() + minf(maxf(px, py), 0.0) - r


static func _alt_tex(base: Color, shine: float) -> ImageTexture:
	var W := 96
	var H := 96
	var img := Image.create(W, H, false, Image.FORMAT_RGBA8)
	for y in H:
		var t := float(y) / float(H - 1)
		for x in W:
			var c := Color(0, 0, 0, 0)
			match style:
				"glass":
					var d := _sdf(x, y, W, H, 1.0, 30.0)
					var a := clampf(0.5 - d, 0.0, 1.0)
					if a > 0.0:
						c = base.lightened(0.15)
						c.a = lerpf(0.62, 0.42, t)
						if t < 0.55:
							c = c.lerp(Color.WHITE, (1.0 - t / 0.55) * 0.34 * shine)
							c.a = maxf(c.a, 0.30)
						var ring := clampf(1.0 - absf(d + 1.6) / 1.6, 0.0, 1.0)
						c = c.lerp(Color(1, 1, 1, lerpf(0.85, 0.3, t)), ring * 0.9)
						c.a *= a
				"flat":
					var d2 := _sdf(x, y, W, H, 1.0, 26.0)
					var a2 := clampf(0.5 - d2, 0.0, 1.0)
					if a2 > 0.0:
						c = base
						c.a = a2
				"neon":
					var d3 := _sdf(x, y, W, H, 9.0, 28.0)
					var core := clampf(0.5 - d3, 0.0, 1.0)
					var ring3 := clampf(1.0 - absf(d3 + 1.5) / 2.0, 0.0, 1.0)
					var glow := 0.0
					if d3 > 0.0:
						glow = 0.55 * exp(-d3 / 3.5)
					var neon := base.lightened(0.25)
					if core > 0.0:
						c = base.darkened(0.82)
						c.a = 0.88
						c = c.lerp(neon, ring3)
						c.a = maxf(c.a, ring3)
					elif glow > 0.02:
						c = neon
						c.a = glow
				"outline":
					var d4 := _sdf(x, y, W, H, 1.0, 28.0)
					var core4 := clampf(0.5 - d4, 0.0, 1.0)
					var ring4 := clampf(1.0 - absf(d4 + 2.2) / 2.2, 0.0, 1.0)
					if core4 > 0.0:
						c = base.darkened(0.72)
						c.a = 0.62
						c = c.lerp(base.lightened(0.3), ring4)
						c.a = maxf(c.a, ring4) * core4
			img.set_pixel(x, y, c)
	return ImageTexture.create_from_image(img)


static func _rr_alpha(x: int, y: int, w: int, h: int, r: float) -> float:
	# پوشش لبه‌ی نرم مستطیل گرد (۰..۱)
	var cx := clampf(float(x) + 0.5, r, float(w) - r)
	var cy := clampf(float(y) + 0.5, r, float(h) - r)
	var d := Vector2(float(x) + 0.5 - cx, float(y) + 0.5 - cy).length()
	return clampf(r - d + 0.5, 0.0, 1.0)


## دکمه‌ی براق: رنگ پایه، ارتفاع «لبه‌ی ۳بعدی» پایین، میزان برق
static func button_tex(base: Color, lip: int = 8, shine: float = 1.0) -> ImageTexture:
	var key := "btn|%s|%s|%d|%.2f" % [style, base.to_html(), lip, shine]
	if _cache.has(key):
		return _cache[key]
	if style in ["glass", "flat", "neon", "outline"]:
		var at := _alt_tex(base, shine)
		_cache[key] = at
		return at
	var W := 96
	var H := 96
	var R := 36.0 if style == "candy" else 32.0
	if style == "candy":
		shine *= 1.7
	var img := Image.create(W, H, false, Image.FORMAT_RGBA8)
	var top := base.lightened(0.28)
	var bot := base.darkened(0.12)
	var lip_col := base.darkened(0.42)
	var body_h := H - lip
	for y in H:
		for x in W:
			var a := _rr_alpha(x, y, W, H, R)
			if a <= 0.0:
				continue
			var c: Color
			if y >= body_h:
				c = lip_col
			else:
				var t := float(y) / float(body_h)
				c = top.lerp(bot, t)
				# برق نیمه‌ی بالایی
				if t < 0.5:
					var g := (1.0 - t / 0.5) * 0.20 * shine
					c = c.lerp(Color.WHITE, g)
				# حاشیه‌ی روشن بالا
				if y < 3:
					c = c.lerp(Color.WHITE, 0.4 * shine)
			# لبه‌ی تیره‌ی بیرونی
			var edge := 1.0 - _rr_alpha(x, y, W, H, R - 2.0)
			if edge > 0.0:
				c = c.lerp(base.darkened(0.55), edge * 0.7)
			c.a = a
			img.set_pixel(x, y, c)
	var t2 := ImageTexture.create_from_image(img)
	_cache[key] = t2
	return t2


## دکمه با «ناحیه‌ی گوشه»‌ی خودکار: اگر دکمه کوتاه‌تر از گوشه‌ها باشد گوشه‌ها متناسب کوچک می‌شوند
## (قبلاً روی دکمه‌های کوچک گوشه‌ها روی هم می‌افتادند و شکل دکمه به‌هم می‌ریخت).
class AdaptiveStyle extends StyleBox:
	var tex: Texture2D
	var m := 34          # حاشیه‌ی گوشه در تصویر اصلی
	var lip := 0         # لبه‌ی سه‌بعدی پایین

	func _draw(ci: RID, rect: Rect2) -> void:
		if tex == null or rect.size.x < 2.0 or rect.size.y < 2.0:
			return
		var tw := float(tex.get_width())
		var th := float(tex.get_height())
		var sl := float(m)
		var st := float(m)
		var sb := float(m + lip)
		var k := minf(1.0, minf(rect.size.y / (st + sb), rect.size.x / (2.0 * sl)))
		var dl := sl * k
		var dt := st * k
		var db := sb * k
		var x0 := rect.position.x
		var y0 := rect.position.y
		var dx := [x0, x0 + dl, x0 + rect.size.x - dl, x0 + rect.size.x]
		var dy := [y0, y0 + dt, y0 + rect.size.y - db, y0 + rect.size.y]
		var sx := [0.0, sl, tw - sl, tw]
		var sy := [0.0, st, th - sb, th]
		var rid := tex.get_rid()
		for j in 3:
			for i in 3:
				var dr := Rect2(dx[i], dy[j], dx[i + 1] - dx[i], dy[j + 1] - dy[j])
				if dr.size.x <= 0.0 or dr.size.y <= 0.0:
					continue
				RenderingServer.canvas_item_add_texture_rect_region(ci, dr, rid, Rect2(sx[i], sy[j], sx[i + 1] - sx[i], sy[j + 1] - sy[j]))


static func button_style(base: Color, lip: int = 8, shine: float = 1.0) -> StyleBox:
	var sb := AdaptiveStyle.new()
	sb.tex = button_tex(base, lip, shine)
	var alt: bool = style in ["glass", "flat", "neon", "outline"]
	if alt:
		lip = 0
	sb.m = 38 if style == "candy" else (40 if style == "neon" else (32 if style in ["glass", "outline"] else (30 if style == "flat" else 34)))
	sb.lip = lip
	sb.content_margin_left = 24
	sb.content_margin_right = 24
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10 + lip
	return sb


## تیک‌باکس: مربع گرد؛ روشن = طلایی با تیک
static func check_tex(on: bool, size: int = 48) -> ImageTexture:
	var key := "chk|%s|%d|%s" % [on, size, style]
	if _cache.has(key):
		return _cache[key]
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	var r := float(size) * 0.22
	var tick_a := Vector2(size * 0.24, size * 0.54)
	var tick_b := Vector2(size * 0.43, size * 0.72)
	var tick_c := Vector2(size * 0.78, size * 0.30)
	for y in size:
		for x in size:
			var d := _sdf(x, y, size, size, 2.0, r)
			var cover := clampf(0.5 - d, 0.0, 1.0)
			if cover <= 0.0:
				continue
			var ring := clampf(1.0 - absf(d + 2.0) / 2.0, 0.0, 1.0)
			var c: Color
			if on:
				c = Color("ffb02e").lerp(Color("ffd46a"), 1.0 - float(y) / float(size))
				c = c.lerp(Color("7a4300"), ring * 0.5)
				var p := Vector2(x + 0.5, y + 0.5)
				var dd := minf(_seg_dist(p, tick_a, tick_b), _seg_dist(p, tick_b, tick_c))
				var t := clampf(1.0 - (dd - float(size) * 0.055) / 1.4, 0.0, 1.0)
				c = c.lerp(Color("3a1d00"), t)
			else:
				c = Color(0.06, 0.02, 0.13, 0.85)
				c = c.lerp(Color(1, 1, 1, 0.75), ring)
			c.a *= cover
			img.set_pixel(x, y, c)
	var t2 := ImageTexture.create_from_image(img)
	_cache[key] = t2
	return t2


static func _seg_dist(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	var t := clampf((p - a).dot(ab) / maxf(ab.length_squared(), 0.0001), 0.0, 1.0)
	return p.distance_to(a + ab * t)


## پنل شیشه‌ای تیره با حاشیه‌ی روشن
static func panel_style(tint: Color = Color(0.12, 0.04, 0.22, 0.78), border: Color = Color(1, 1, 1, 0.22)) -> StyleBoxTexture:
	var key := "pnl|%s|%s" % [tint.to_html(), border.to_html()]
	var tex: ImageTexture
	if _cache.has(key):
		tex = _cache[key]
	else:
		var S := 64
		var R := 22.0
		var img := Image.create(S, S, false, Image.FORMAT_RGBA8)
		for y in S:
			for x in S:
				var a := _rr_alpha(x, y, S, S, R)
				if a <= 0.0:
					continue
				var t := float(y) / float(S)
				var c := tint.lightened(0.10 * (1.0 - t)).darkened(0.12 * t)
				var inner := _rr_alpha(x, y, S, S, R - 2.5)
				var edge := a - inner * a
				if edge > 0.0:
					c = c.lerp(Color(border.r, border.g, border.b, 1.0), border.a * 2.5 * edge)
				if y < 12 and a > 0.5:
					c = c.lerp(Color.WHITE, 0.07 * (1.0 - float(y) / 12.0))
				c.a = tint.a * a if edge <= 0.0 else clampf(tint.a + 0.2, 0.0, 1.0) * a
				img.set_pixel(x, y, c)
		tex = ImageTexture.create_from_image(img)
		_cache[key] = tex
	var sb := StyleBoxTexture.new()
	sb.texture = tex
	sb.texture_margin_left = 26
	sb.texture_margin_right = 26
	sb.texture_margin_top = 26
	sb.texture_margin_bottom = 26
	sb.content_margin_left = 18
	sb.content_margin_right = 18
	sb.content_margin_top = 14
	sb.content_margin_bottom = 14
	return sb


## دستگیره‌ی گرد اسلایدر (طلایی)
static func knob_tex(col: Color) -> ImageTexture:
	var key := "knob|" + col.to_html()
	if _cache.has(key):
		return _cache[key]
	var S := 48
	var img := Image.create(S, S, false, Image.FORMAT_RGBA8)
	for y in S:
		for x in S:
			var d := Vector2(float(x) + 0.5 - 24.0, float(y) + 0.5 - 24.0).length()
			var a := clampf(22.0 - d + 0.5, 0.0, 1.0)
			if a <= 0.0:
				continue
			var t := float(y) / float(S)
			var c := col.lightened(0.35).lerp(col.darkened(0.2), t)
			var rim := clampf(d - 17.0, 0.0, 1.0)
			c = c.lerp(col.darkened(0.55), rim * 0.8)
			var hl := Vector2(float(x) - 18.0, float(y) - 15.0).length()
			c = c.lerp(Color.WHITE, clampf(1.0 - hl / 9.0, 0.0, 1.0) * 0.6)
			c.a = a
			img.set_pixel(x, y, c)
	var tex := ImageTexture.create_from_image(img)
	_cache[key] = tex
	return tex


static func track_style(col: Color, height: int = 14) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.set_corner_radius_all(height)
	sb.content_margin_top = float(height) * 0.5
	sb.content_margin_bottom = float(height) * 0.5
	sb.border_width_top = 2
	sb.border_color = Color(0, 0, 0, 0.35)
	return sb


## پرتوهای نورانی پشت عنوان (برای چرخاندن آهسته)
static func rays_tex(col: Color, rays: int = 14) -> ImageTexture:
	var key := "rays|%s|%d" % [col.to_html(), rays]
	if _cache.has(key):
		return _cache[key]
	var S := 384
	var img := Image.create(S, S, false, Image.FORMAT_RGBA8)
	var half := float(S) * 0.5
	for y in S:
		for x in S:
			var p := Vector2(float(x) + 0.5 - half, float(y) + 0.5 - half)
			var r := p.length() / half
			if r >= 1.0:
				continue
			var a := fposmod(atan2(p.y, p.x), TAU / float(rays)) / (TAU / float(rays))
			var wedge := 1.0 if a < 0.5 else 0.0
			var fade := (1.0 - r) * clampf(r * 4.0, 0.0, 1.0)
			img.set_pixel(x, y, Color(col.r, col.g, col.b, wedge * fade * col.a))
	var tex := ImageTexture.create_from_image(img)
	_cache[key] = tex
	return tex


## تیرگی لبه‌های صفحه (وینیت) برای حس سینمایی
static func vignette_tex() -> ImageTexture:
	if _cache.has("vig"):
		return _cache["vig"]
	var S := 128
	var img := Image.create(S, S, false, Image.FORMAT_RGBA8)
	var half := float(S) * 0.5
	for y in S:
		for x in S:
			var p := Vector2(float(x) + 0.5 - half, float(y) + 0.5 - half) / half
			var d := clampf((p.length() - 0.55) / 0.85, 0.0, 1.0)
			img.set_pixel(x, y, Color(0.08, 0.0, 0.14, d * d * 0.7))
	var tex := ImageTexture.create_from_image(img)
	_cache["vig"] = tex
	return tex
