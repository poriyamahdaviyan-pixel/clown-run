class_name AnimPack
extends RefCounted
## انیمیشن قرضی: یک کلیپ را از فایل مدلِ «کاراکتر الف» بیرون می‌کشد و روی «کاراکتر ب» اجرا می‌کند.
## ذخیره به‌صورت JSON ساده (نه فایل منبع Godot) تا فایل دانلودی هرگز کد اجرا نکند.
## روی اسکلت‌های هم‌نام (مثلاً Mixamo یا VRM) درست کار می‌کند؛ استخوانی که در کاراکتر ب نباشد نادیده گرفته می‌شود.

const DIR := "user://anim_packs"
const VERSION := 1


static func clips_of_model(path: String) -> Array:
	var out: Array = []
	var sc := _load_scene(path)
	if sc == null:
		return out
	for p in sc.find_children("*", "AnimationPlayer", true, false):
		for nm in (p as AnimationPlayer).get_animation_list():
			if String(nm) != "RESET" and not out.has(String(nm)):
				out.append(String(nm))
	sc.free()
	return out


static func _load_scene(path: String) -> Node3D:
	var doc := GLTFDocument.new()
	var st := GLTFState.new()
	if doc.append_from_file(path, st) != OK:
		return null
	var n := doc.generate_scene(st)
	return n as Node3D if n is Node3D else null


## کلیپ‌های خواسته‌شده را از فایل مدل به JSON تبدیل می‌کند (کلید = نام کلیپ). ارتفاع لگن هم ثبت می‌شود.
static func extract(path: String, clips: Array) -> Dictionary:
	var res := {}
	var sc := _load_scene(path)
	if sc == null:
		return res
	var skel: Skeleton3D = null
	var sks := sc.find_children("*", "Skeleton3D", true, false)
	if not sks.is_empty():
		skel = sks[0] as Skeleton3D
	var hip := _hip_bone(skel)
	var hip_y := 0.0
	if skel != null and hip >= 0:
		hip_y = absf(skel.get_bone_global_rest(hip).origin.y)
	for p in sc.find_children("*", "AnimationPlayer", true, false):
		var ap := p as AnimationPlayer
		for cn in clips:
			if not ap.has_animation(String(cn)) or res.has(String(cn)):
				continue
			var a := ap.get_animation(String(cn))
			var tr: Array = []
			for i in a.get_track_count():
				var tt := a.track_get_type(i)
				var kind := ""
				match tt:
					Animation.TYPE_ROTATION_3D: kind = "r"
					Animation.TYPE_POSITION_3D: kind = "p"
					Animation.TYPE_SCALE_3D: kind = "s"
				if kind == "":
					continue
				var np := a.track_get_path(i)
				if np.get_subname_count() == 0:
					continue
				var bone := String(np.get_subname(0))
				var times: Array = []
				var vals: Array = []
				for k in a.track_get_key_count(i):
					times.append(snappedf(a.track_get_key_time(i, k), 0.0001))
					var v = a.track_get_key_value(i, k)
					if v is Quaternion:
						vals.append_array([snappedf(v.x, 0.00001), snappedf(v.y, 0.00001), snappedf(v.z, 0.00001), snappedf(v.w, 0.00001)])
					elif v is Vector3:
						vals.append_array([snappedf(v.x, 0.00001), snappedf(v.y, 0.00001), snappedf(v.z, 0.00001)])
				tr.append({"k": kind, "b": bone, "t": times, "v": vals})
			res[String(cn)] = {"v": VERSION, "len": a.length, "loop": a.loop_mode != Animation.LOOP_NONE,
				"hip": String(skel.get_bone_name(hip)) if (skel != null and hip >= 0) else "", "hip_y": hip_y, "tracks": tr}
	sc.free()
	return res


static func _hip_bone(skel: Skeleton3D) -> int:
	if skel == null:
		return -1
	for i in skel.get_bone_count():
		var n := skel.get_bone_name(i).to_lower()
		if n.contains("hip") or n.contains("pelvis"):
			return i
	for i in skel.get_bone_count():
		if skel.get_bone_parent(i) < 0:
			return i
	return -1


## JSON ← → Animation روی اسکلت مقصد. anim_root = نودی که مسیر ترک‌ها نسبت به آن است
static func build(clip: Dictionary, anim_root: Node, skel: Skeleton3D) -> Animation:
	if skel == null or anim_root == null or not clip.has("tracks"):
		return null
	var a := Animation.new()
	a.length = maxf(0.1, float(clip.get("len", 1.0)))
	a.loop_mode = Animation.LOOP_LINEAR if bool(clip.get("loop", false)) else Animation.LOOP_NONE
	var base := String(anim_root.get_path_to(skel))
	var hip := String(clip.get("hip", ""))
	var thip := _hip_bone(skel)
	var ratio := 1.0
	if thip >= 0 and float(clip.get("hip_y", 0.0)) > 0.0001:
		ratio = absf(skel.get_bone_global_rest(thip).origin.y) / float(clip.hip_y)
	var made := 0
	for t in clip.tracks:
		var bone := String(t.b)
		var bi := skel.find_bone(bone)
		if bi < 0:
			continue
		var k := String(t.k)
		var is_hip := bone == hip
		if k == "p" and not is_hip:
			continue                      # فقط حرکت لگن؛ طول استخوان‌های دیگر مال خود کاراکتر است
		var ti := -1
		match k:
			"r": ti = a.add_track(Animation.TYPE_ROTATION_3D)
			"p": ti = a.add_track(Animation.TYPE_POSITION_3D)
			"s": ti = a.add_track(Animation.TYPE_SCALE_3D)
		if ti < 0:
			continue
		a.track_set_path(ti, NodePath("%s:%s" % [base, bone]))
		var times: Array = t.t
		var vals: Array = t.v
		var first_xz := Vector2.ZERO
		for i in times.size():
			var tm := float(times[i])
			if k == "r":
				if i * 4 + 3 >= vals.size():
					break
				a.rotation_track_insert_key(ti, tm, Quaternion(float(vals[i * 4]), float(vals[i * 4 + 1]), float(vals[i * 4 + 2]), float(vals[i * 4 + 3])).normalized())
			elif k == "p":
				if i * 3 + 2 >= vals.size():
					break
				var v := Vector3(float(vals[i * 3]), float(vals[i * 3 + 1]), float(vals[i * 3 + 2]))
				if i == 0:
					first_xz = Vector2(v.x, v.z)
				v = Vector3(first_xz.x, v.y, first_xz.y) * ratio     # بدون حرکت به جلو (فقط بالا/پایین)
				a.position_track_insert_key(ti, tm, v)
			else:
				if i * 3 + 2 >= vals.size():
					break
				a.scale_track_insert_key(ti, tm, Vector3(float(vals[i * 3]), float(vals[i * 3 + 1]), float(vals[i * 3 + 2])))
		made += 1
	return a if made > 0 else null


# ------------------------- ذخیره‌ی بسته‌های نصب‌شده -------------------------
static func path_of(id: String) -> String:
	return "%s/%s.json" % [DIR, id]


static func save(id: String, clip: Dictionary) -> void:
	DirAccess.make_dir_recursive_absolute(DIR)
	var f := FileAccess.open(path_of(id), FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(clip))
		f.close()


static func load_pack(id: String) -> Dictionary:
	if not FileAccess.file_exists(path_of(id)):
		return {}
	var d = JSON.parse_string(FileAccess.get_file_as_string(path_of(id)))
	return d if d is Dictionary else {}


## متن JSON بسته‌ی خارج‌شده از فروشگاه را بررسی و نگه می‌دارد
static func parse(text: String) -> Dictionary:
	var d = JSON.parse_string(text)
	if not d is Dictionary or not d.get("tracks") is Array or int(d.get("v", 0)) != VERSION:
		return {}
	return d
