class_name MiniCraft
extends MiniBase
## «جهان مکعبی» (سبک ماین‌کرفت): زمین مکعبی با کوه، آب، ماسه و درخت. با آنالوگ بگرد، سنگ‌های الماس و طلا را بردار
## و از کریپرها فرار کن؛ کریپر نزدیک که شود منفجر می‌شود و زمان کم می‌کند. پله‌های یک‌بلوکی خودکار بالا می‌روند.

const N := 44            # ابعاد زمین (ستون)
const WATER := 2
const REACH := 1.5

var heights := []        # N*N
var pl: Node3D
var pp := Vector2(N * 0.5, N * 0.5)
var py := 6.0
var vy := 0.0
var face := 0.0
var _ores: Array[Dictionary] = []
var _creepers: Array[Dictionary] = []
var _rng := RandomNumberGenerator.new()
var _shake := 0.0
var _bob := 0.0
var _walk := 0.0
var _limbs: Array[Node3D] = []
var _flash: ColorRect


func _ready() -> void:
	title = "جهان مکعبی"
	hint = "آنالوگ: حرکت\nالماس و طلا بردار، از کریپرها فرار کن!"
	accent = Color("5be26a")
	duration = 50.0
	_rng.seed = 777
	var env := make_env(Color("4a98ff"), Color("cfe9ff"), Color("cfe9ff"), 0.003, Color("c8d8ff"), 0.5)
	add_sun(Color("fff6d8"), 1.05, Vector3(-55, -40, 0))
	_gen_terrain()
	_build_voxels()
	_build_water()
	_build_trees()
	_build_player()
	_build_ores()
	_build_creepers()
	_build_base(env)
	_flash = ColorRect.new()
	_flash.color = Color(1, 1, 1, 0)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	_hud.add_child(_flash)
	_update_camera(1.0)


func _m(hex: String, emit: float = 0.0, rough: float = 0.9) -> StandardMaterial3D:
	return Modes.P.m(hex, emit, rough, 0.0)


# ------------------------------------------------------------ زمین
func _gen_terrain() -> void:
	var noise := FastNoiseLite.new()
	noise.seed = 31
	noise.frequency = 0.045
	noise.fractal_octaves = 3
	heights.resize(N * N)
	for x in N:
		for z in N:
			var v := noise.get_noise_2d(x, z) * 0.5 + 0.5       # 0..1
			var edge := minf(minf(x, N - 1 - x), minf(z, N - 1 - z))
			var h := int(round(1.0 + v * 7.0))
			if edge < 3:
				h = maxi(h, 4)       # دیوار کوه دور زمین
			heights[x * N + z] = clampi(h, 1, 9)
	# جای شروع صاف
	for dx in range(-2, 3):
		for dz in range(-2, 3):
			heights[(N / 2 + dx) * N + (N / 2 + dz)] = 4


func hgt(x: int, z: int) -> int:
	if x < 0 or z < 0 or x >= N or z >= N:
		return 99
	return heights[x * N + z]


func _build_voxels() -> void:
	var inst: Array[Transform3D] = []
	var cols: Array[Color] = []
	for x in N:
		for z in N:
			var h: int = heights[x * N + z]
			for y in range(maxi(0, h - 3), h):
				var top := y == h - 1
				var c: Color
				if top:
					if h <= WATER + 1:
						c = Color("e6d28f")
					elif h >= 8:
						c = Color("f4f8ff")
					elif h >= 7:
						c = Color("8d9199")
					else:
						c = Color("5fb24a")
				else:
					c = Color("8a5a36") if h < 7 else Color("7a7e86")
				var j := _rng.randf_range(-0.05, 0.05)
				c = Color(clampf(c.r + j, 0, 1), clampf(c.g + j, 0, 1), clampf(c.b + j, 0, 1))
				inst.append(Transform3D(Basis(), Vector3(x + 0.5, y + 0.5, z + 0.5)))
				cols.append(c)
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var bm := BoxMesh.new()
	bm.size = Vector3(1, 1, 1)
	mm.mesh = bm
	mm.instance_count = inst.size()
	for i in inst.size():
		mm.set_instance_transform(i, inst[i])
		mm.set_instance_color(i, cols[i])
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.95
	mi.material_override = mat
	add_child(mi)


func _build_water() -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.2, 0.5, 0.95, 0.62)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 0.1
	mat.metallic = 0.3
	var pm := PlaneMesh.new()
	pm.size = Vector2(N + 40, N + 40)
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	mi.material_override = mat
	mi.position = Vector3(N * 0.5, WATER + 0.55, N * 0.5)
	add_child(mi)


var _trees: Array[Node3D] = []


## درخت‌های بین دوربین و بازیکن پنهان می‌شوند تا بازیکن همیشه دیده شود
func _hide_trees_near() -> void:
	for tn in _trees:
		var p: Vector2 = tn.get_meta("p")
		var dx := absf(p.x - pp.x)
		var dz := p.y - pp.y
		tn.visible = not ((dx < 3.6 and dz > -2.0 and dz < 14.0) or (dx < 2.5 and absf(dz) < 3.0))


func _build_trees() -> void:
	var leaf := _m("2f8f3a")
	var wood := _m("6a4526")
	for i in 70:
		var x := _rng.randi_range(4, N - 5)
		var z := _rng.randi_range(4, N - 5)
		var h := hgt(x, z)
		if h <= WATER + 1 or h >= 7 or absf(x - N * 0.5) < 4 and absf(z - N * 0.5) < 4:
			continue
		var base := Vector3(x + 0.5, h, z + 0.5)
		var tn := Node3D.new()
		add_child(tn)
		tn.set_meta("p", Vector2(base.x, base.z))
		_trees.append(tn)
		for t in 3:
			Modes.Gfx.box(tn, Vector3(0.9, 1.0, 0.9), base + Vector3(0, 0.5 + t, 0), wood)
		for lx in range(-1, 2):
			for lz in range(-1, 2):
				Modes.Gfx.box(tn, Vector3(1, 1, 1), base + Vector3(lx, 3.5, lz), leaf)
		Modes.Gfx.box(tn, Vector3(1, 1, 1), base + Vector3(0, 4.5, 0), leaf)


# ------------------------------------------------------------ بازیکن و دشمن
func _make_blocky(skin: String, shirt: String, pants: String, limbs: Array) -> Node3D:
	var n := Node3D.new()
	var head := Modes.Gfx.box(n, Vector3(0.6, 0.6, 0.6), Vector3(0, 1.85, 0), _m(skin))
	Modes.Gfx.box(n, Vector3(0.62, 0.2, 0.62), Vector3(0, 2.08, 0), _m("4a2e18"))
	Modes.Gfx.box(n, Vector3(0.1, 0.1, 0.02), Vector3(-0.15, 1.88, -0.31), _m("1a1a2a"))
	Modes.Gfx.box(n, Vector3(0.1, 0.1, 0.02), Vector3(0.15, 1.88, -0.31), _m("1a1a2a"))
	Modes.Gfx.box(n, Vector3(0.6, 0.8, 0.34), Vector3(0, 1.2, 0), _m(shirt))
	for sx in [-0.39, 0.39]:
		var arm := Node3D.new()
		arm.position = Vector3(sx, 1.55, 0)
		Modes.Gfx.box(arm, Vector3(0.2, 0.75, 0.24), Vector3(0, -0.35, 0), _m(skin))
		n.add_child(arm)
		limbs.append(arm)
	for sx in [-0.15, 0.15]:
		var leg := Node3D.new()
		leg.position = Vector3(sx, 0.8, 0)
		Modes.Gfx.box(leg, Vector3(0.28, 0.8, 0.3), Vector3(0, -0.4, 0), _m(pants))
		n.add_child(leg)
		limbs.append(leg)
	return n


func _build_player() -> void:
	pl = _make_blocky("e0b080", "27a6c8", "2a3a8a", _limbs)
	add_child(pl)
	py = float(hgt(int(pp.x), int(pp.y))) + 0.0


func _build_ores() -> void:
	for i in 18:
		var gold := i % 3 == 0
		var p := _free_cell()
		var h := hgt(int(p.x), int(p.y))
		var node := Node3D.new()
		node.position = Vector3(p.x, h + 0.55, p.y)
		var col := "ffd23f" if gold else "37e8e0"
		Modes.Gfx.box(node, Vector3(0.7, 0.7, 0.7), Vector3.ZERO, _m(col, 1.8, 0.2))
		Modes.Gfx.box(node, Vector3(0.78, 0.2, 0.78), Vector3(0, -0.25, 0), _m("5a5f68"))
		Modes.Gfx.glow(node, Vector3.ZERO, 2.2, Color(1.0, 0.85, 0.3, 0.3) if gold else Color(0.2, 1.0, 0.95, 0.3))
		add_child(node)
		_ores.append({"node": node, "pos": p, "val": 4 if gold else 3, "gold": gold})


func _free_cell() -> Vector2:
	for k in 60:
		var x := _rng.randi_range(4, N - 5)
		var z := _rng.randi_range(4, N - 5)
		var h := hgt(x, z)
		if h > WATER + 1 and h < 8 and Vector2(x, z).distance_to(Vector2(N * 0.5, N * 0.5)) > 6.0:
			return Vector2(x + 0.5, z + 0.5)
	return Vector2(N * 0.5 + 8, N * 0.5 + 8)


func _build_creepers() -> void:
	for i in 6:
		var p := _free_cell()
		var node := Node3D.new()
		var cl: Array = []
		Modes.Gfx.box(node, Vector3(0.6, 0.6, 0.6), Vector3(0, 1.45, 0), _m("4cbf3c"))
		Modes.Gfx.box(node, Vector3(0.6, 0.95, 0.38), Vector3(0, 0.8, 0), _m("3da82f"))
		Modes.Gfx.box(node, Vector3(0.14, 0.14, 0.02), Vector3(-0.14, 1.52, -0.31), _m("0a0a0a"))
		Modes.Gfx.box(node, Vector3(0.14, 0.14, 0.02), Vector3(0.14, 1.52, -0.31), _m("0a0a0a"))
		Modes.Gfx.box(node, Vector3(0.2, 0.22, 0.02), Vector3(0, 1.3, -0.31), _m("0a0a0a"))
		for sx in [-0.17, 0.17]:
			for sz in [-0.2, 0.2]:
				Modes.Gfx.box(node, Vector3(0.24, 0.35, 0.24), Vector3(sx, 0.18, sz), _m("2f8f26"))
		add_child(node)
		_creepers.append({"node": node, "pos": p, "fuse": 0.0, "dir": Vector2.RIGHT.rotated(_rng.randf() * TAU), "wait": 0.0})


# ------------------------------------------------------------ منطق
func _ground(x: float, z: float) -> float:
	return float(hgt(int(floor(x)), int(floor(z))))


func _tick(delta: float) -> void:
	var s := stick.get_vector()
	var spd := 5.2
	var mv := Vector2(s.x, s.y) * spd
	if mv.length() > 0.1:
		face = lerp_angle(face, atan2(-mv.x, -mv.y), 1.0 - exp(-14.0 * delta))
	# حرکت با پله‌ی خودکار: تا یک بلوک بالا می‌رود، بیشتر مانع است
	var np := pp + mv * delta
	var cur_h := _ground(pp.x, pp.y)
	var try_x := Vector2(np.x, pp.y)
	var try_z := Vector2(pp.x, np.y)
	if _ground(try_x.x, try_x.y) - py <= 1.05:
		pp.x = clampf(np.x, 1.0, N - 1.0)
	if _ground(try_z.x, try_z.y) - py <= 1.05:
		pp.y = clampf(np.y, 1.0, N - 1.0)
	var gh := _ground(pp.x, pp.y)
	if gh > py:
		vy = 6.0 if gh - py > 0.1 else 0.0       # پرش خودکار روی پله
	vy -= 22.0 * delta
	py += vy * delta
	if py <= gh:
		py = gh
		vy = 0.0
	pl.position = Vector3(pp.x, py, pp.y)
	pl.rotation.y = face
	_walk += mv.length() * delta * 2.0
	for i in _limbs.size():
		var sgn := 1.0 if i % 2 == 0 else -1.0
		_limbs[i].rotation.x = sin(_walk * 1.6) * 0.8 * sgn * clampf(mv.length() / spd, 0.0, 1.0)
	# آب: کندتر نمی‌کنیم ولی صدا/اثری لازم نیست
	for o in _ores:
		if o.node.visible:
			o.node.rotation.y += delta * 2.2
			o.node.position.y = _ground(o.pos.x, o.pos.y) + 0.65 + sin(time_left * 3.0 + o.pos.x) * 0.1
			if pp.distance_to(o.pos) < REACH and absf(py - _ground(o.pos.x, o.pos.y)) < 1.6:
				o.node.visible = false
				add_coins(int(o.val))
				say(("طلا! +%d" if o.gold else "الماس! +%d") % int(o.val), 0.7)
	for c in _creepers:
		_creeper_tick(c, delta)
	_shake = maxf(0.0, _shake - delta * 2.0)
	if _flash != null and _flash.color.a > 0.0:
		_flash.color.a = maxf(0.0, _flash.color.a - delta * 2.0)
	_update_camera(delta)


func _creeper_tick(c: Dictionary, delta: float) -> void:
	var node: Node3D = c.node
	if not node.visible:
		c.wait -= delta
		if c.wait <= 0.0:
			var q := _free_cell()
			c.pos = q
			c.fuse = 0.0
			node.visible = true
		return
	var to: Vector2 = pp - c.pos
	var d := to.length()
	var v := Vector2.ZERO
	if d < 11.0:
		v = to.normalized() * 3.3
		if d < 2.4:
			c.fuse += delta
		else:
			c.fuse = maxf(0.0, c.fuse - delta)
	else:
		c.wait -= delta
		if c.wait <= 0.0:
			c.dir = Vector2.RIGHT.rotated(_rng.randf() * TAU)
			c.wait = _rng.randf_range(1.0, 2.5)
		v = c.dir * 1.2
	var np: Vector2 = c.pos + v * delta
	if absf(_ground(np.x, np.y) - _ground(c.pos.x, c.pos.y)) <= 1.05 and _ground(np.x, np.y) > WATER:
		c.pos = Vector2(clampf(np.x, 1.0, N - 1.0), clampf(np.y, 1.0, N - 1.0))
	else:
		c.dir = c.dir.rotated(1.7)
	node.position = Vector3(c.pos.x, _ground(c.pos.x, c.pos.y), c.pos.y)
	if v.length() > 0.1:
		node.rotation.y = atan2(-v.x, -v.y)
	var pulse := 1.0 + clampf(c.fuse, 0.0, 1.5) * 0.25 * (1.0 + sin(time_left * 40.0))
	node.scale = Vector3.ONE * pulse
	if c.fuse >= 1.2:
		# انفجار: زمان کم می‌شود و بازیکن پرت می‌شود
		c.fuse = 0.0
		node.visible = false
		c.wait = 4.0
		time_left = maxf(time_left - 4.0, 0.0)
		_shake = 1.0
		_flash.color = Color(1, 0.9, 0.6, 0.8)
		var away: Vector2 = (pp - c.pos).normalized()
		pp += away * 2.0
		pp = Vector2(clampf(pp.x, 1.0, N - 1.0), clampf(pp.y, 1.0, N - 1.0))
		vy = 7.0
		say("بوووم! -۴ ثانیه", 0.9)


func _update_camera(delta: float) -> void:
	var target := Vector3(pp.x, py + 1.0, pp.y)
	var want := target + Vector3(0, 15.0, 12.0)
	var off := Vector3(randf() - 0.5, randf() - 0.5, 0.0) * _shake * 0.6
	cam.position = want if cam.position == Vector3.ZERO else cam.position.lerp(want, 1.0 - exp(-7.0 * delta))
	cam.position += off
	cam.look_at(target, Vector3.UP)
	_hide_trees_near()
