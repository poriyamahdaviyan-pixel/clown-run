extends Node3D
## کاراکتر سه‌بعدی از فایل GLB (مثلاً Mixamo / Sketchfab / Ready Player Me / Blender).
##  • اندازه و مکان خودکار تنظیم می‌شود (قد ۱٫۹ متر، پا روی زمین، پشت به دوربین).
##  • انیمیشن‌های لازم هر حالت: ایستادن، دویدن، پرش، سُرخوردن، برخورد/لیز خوردن، پرواز (جت‌پک)، فرود.
##    ۱) اگر فایل خودش انیمیشنِ همان حالت را دارد (نام شامل run / jump / slide ...) همان پخش می‌شود
##       (در تنظیمات هر حالت را می‌شود دستی به یک کلیپ وصل کرد)
##    ۲) وگرنه اگر مدل اسکلت انسانی دارد (نام استخوان‌ها: Mixamo / Rigify / VRM / ...) حرکت‌ها با کد
##       روی استخوان‌ها ساخته می‌شود (تاب پا و دست، خم‌شدن زانو، آرنج، خم‌شدن بدن، سر ...)
##    ۳) وگرنه کل بدن حرکت ساده‌ی دویدن/پرش/سُرخوردن می‌گیرد.
## رابط کلاس با CharacterModel سازگار است (arms/legs/set_skin/pose_idle).

const TARGET_HEIGHT := 1.9
const MAX_BYTES := 4 * 1024 * 1024 * 1024    # عملاً بدون محدودیت؛ فقط حافظه‌ی گوشی
const STATES: Array[String] = ["idle", "run", "jump", "slide", "hit", "fly", "land"]
const STATE_TITLES := {"idle": "ایستادن", "run": "دویدن", "jump": "پرش", "slide": "سُرخوردن", "hit": "برخورد", "fly": "پرواز (جت‌پک)", "land": "فرود"}
const KEYWORDS := {
	"idle": ["idle", "stand", "breath", "wait"],
	"run": ["run", "jog", "sprint", "walk"],
	"jump": ["jump", "leap", "air", "fall"],
	"slide": ["slide", "slid", "roll", "crouch", "duck"],
	"hit": ["hit", "stumble", "damage", "hurt", "trip", "death", "die", "break"],
	"fly": ["fly", "float", "hover", "glide", "swim"],
	"land": ["land"],
}
const DEFAULT_CFG := {"scale": 1.0, "off_y": 0.0, "speed": 1.0, "swing": 1.0, "lean": 1.0, "proc": true, "map": {}}
const FINGERS: Array[String] = ["thumb", "index", "middle", "ring", "pinky", "little", "finger"]

var arms: Array[Node3D] = []     # برای سازگاری؛ خالی است
var legs: Array[Node3D] = []
var head: Node3D
var is_glb := true
var load_error := ""
var height_m := 0.0
var cfg: Dictionary = DEFAULT_CFG.duplicate(true)
var preview_state := ""          # در پیش‌نمایش تنظیمات: حالت اجباری
var clip_names: Array[String] = []
var rig_info := ""               # توضیح اسکلت تشخیص‌داده‌شده
var has_rig := false

var _holder: Node3D
var _scene: Node3D
var _anim: AnimationPlayer
var _skel: Skeleton3D
var _foot_idx: Array[int] = []
var _ankle_clear := -1.0       # فاصله‌ی مچ تا کف کفش در حالت ایستاده (فضای والد)
var _plant := 0.0              # اصلاح ارتفاعی که پا را روی زمین می‌نشاند
var _roles := {}                 # "thigh_-1" → اندیس استخوان
var _role_of := {}               # اندیس استخوان → {role, side}
var _axis := Vector3.RIGHT       # محور خم‌شدن (چپ‌وراست مدل) در فضای اسکلت
var _order: Array[int] = []      # استخوان‌های هدایت‌شونده به ترتیب سلسله‌مراتب
var _cur_ang := {}               # اندیس استخوان → زاویه‌ی فعلی
var _cur_clip := ""
var _cur_state := ""
var _yaw_q := 0
var _t := 0.0
var _state_time := 0.0


## باید بعد از اضافه‌شدن به درخت فراخوانی شود. true اگر بارگذاری موفق بود
func load_from_file(path: String, yaw_quarter_turns: int = 0) -> bool:
	_clear()
	load_error = ""
	if not FileAccess.file_exists(path):
		load_error = "فایل پیدا نشد"
		return false
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		load_error = "فایل باز نشد"
		return false
	var size := f.get_length()
	f.close()
	if size > MAX_BYTES:
		load_error = "فایل بیش از حد بزرگ است"
		return false
	var doc := GLTFDocument.new()
	var st := GLTFState.new()
	var err := doc.append_from_file(path, st)
	if err != OK:
		load_error = "فایل مدل معتبر نیست (یا حافظه‌ی گوشی برای این مدل کم است)"
		return false
	var node := doc.generate_scene(st)
	if node == null or not (node is Node3D):
		if node != null:
			node.queue_free()
		load_error = "مدلی در فایل پیدا نشد"
		return false
	_scene = node as Node3D
	_holder = Node3D.new()
	add_child(_holder)
	_holder.add_child(_scene)
	if _find_meshes(_scene).is_empty():
		load_error = "این فایل مش (شکل سه‌بعدی) ندارد"
		_clear()
		return false
	_yaw_q = yaw_quarter_turns
	_normalize()
	_setup_clips()
	_setup_rig()
	apply_config(cfg)
	return true


func _clear() -> void:
	for c in get_children():
		remove_child(c)
		c.queue_free()
	_holder = null
	_scene = null
	_anim = null
	_skel = null
	_roles.clear()
	_role_of.clear()
	_order.clear()
	_cur_ang.clear()
	clip_names.clear()
	_cur_clip = ""
	_cur_state = ""
	has_rig = false
	rig_info = ""


func _find_meshes(n: Node) -> Array[MeshInstance3D]:
	var out: Array[MeshInstance3D] = []
	for c in n.find_children("*", "MeshInstance3D", true, false):
		out.append(c as MeshInstance3D)
	return out


func _normalize() -> void:
	# glTF رو به +Z است؛ بازی رو به −Z (دوربین از پشت می‌بیند) ← ۱۸۰ درجه + چرخش کاربر
	_holder.rotation_degrees = Vector3(0.0, 180.0 + 90.0 * float(_yaw_q), 0.0)
	var box := AABB()
	var first := true
	var inv := _holder.global_transform.affine_inverse() if _holder.is_inside_tree() else Transform3D.IDENTITY
	for mi in _find_meshes(_scene):
		if mi.mesh == null:
			continue
		var gt := mi.global_transform if mi.is_inside_tree() else mi.transform
		var local_box: AABB = (inv * gt) * mi.get_aabb()
		if first:
			box = local_box
			first = false
		else:
			box = box.merge(local_box)
	if first or box.size.y < 0.0001:
		return
	var s := TARGET_HEIGHT / box.size.y
	height_m = box.size.y * s
	_scene.scale = _scene.scale * s
	var c := box.get_center() * s
	var bottom := box.position.y * s
	_scene.position = _scene.position - Vector3(c.x, bottom, c.z)


# ------------------------- کلیپ‌ها -------------------------
func _setup_clips() -> void:
	var players := _scene.find_children("*", "AnimationPlayer", true, false)
	if players.is_empty():
		return
	_anim = players[0] as AnimationPlayer
	for nm in _anim.get_animation_list():
		if String(nm) != "RESET":
			clip_names.append(String(nm))


func clip_for(state: String) -> String:
	var map: Dictionary = cfg.get("map", {})
	var chosen := String(map.get(state, ""))
	if chosen == "-":
		return ""            # اجبار به حرکت ساختگی
	if chosen != "" and clip_names.has(chosen):
		return chosen
	if _anim == null:
		return ""
	var used := {}
	for nm in clip_names:
		used[nm] = true
	for kw in KEYWORDS[state]:
		for nm in clip_names:
			if _kw_match(String(nm), kw):
				return nm
	# کلیپ‌هایی که اسمشان هیچ حالتی را نمی‌رساند («Action»، «Take 001»، «mixamo.com» ...)
	if state == "run" or (state == "idle" and _unnamed_clips().size() > 1):
		var un := _unnamed_clips()
		if not un.is_empty():
			return un[0] if state == "run" else un[1]
	return ""


func _kw_match(clip: String, kw: String) -> bool:
	var n := clip.to_lower()
	var cut := maxi(n.rfind("|"), n.rfind(":"))
	if cut >= 0:
		n = n.substr(cut + 1)
	var idx := n.find(kw)
	while idx >= 0:
		# «hair» نباید «air» حساب شود: قبل از کلمه حرف نباشد (جدا یا camelCase قبول)
		var ok := idx == 0 or not _is_letter(n[idx - 1])
		if ok:
			return true
		idx = n.find(kw, idx + 1)
	return false


func _is_letter(ch: String) -> bool:
	var c := ch.unicode_at(0)
	return (c >= 97 and c <= 122)


func _unnamed_clips() -> Array[String]:
	var out: Array[String] = []
	for nm in clip_names:
		var hit := false
		for st in KEYWORDS:
			for kw in KEYWORDS[st]:
				if _kw_match(String(nm), kw):
					hit = true
		if not hit:
			out.append(nm)
	return out


# ------------------------- اسکلت انسانی -------------------------
func _classify(raw: String) -> Dictionary:
	var n := raw.to_lower()
	var cut := maxi(n.rfind(":"), n.rfind("|"))
	if cut >= 0:
		n = n.substr(cut + 1)
	if n.contains("armature") or n.contains("end") or n.contains("nub") or n.contains("twist") or n.contains("roll"):
		return {}
	for fw in FINGERS:
		if n.contains(fw):
			return {}
	var side := 0
	if n.contains("left") or n.begins_with("l_") or n.begins_with("l.") or n.ends_with("_l") or n.ends_with(".l") or n.ends_with("-l") or n.contains("_l_") or n.contains(".l."):
		side = -1
	elif n.contains("right") or n.begins_with("r_") or n.begins_with("r.") or n.ends_with("_r") or n.ends_with(".r") or n.ends_with("-r") or n.contains("_r_") or n.contains(".r."):
		side = 1
	if n.contains("hips") or n.contains("pelvis"):
		return {"role": "hips", "side": 0}
	if n.contains("spine") or n.contains("chest"):
		return {"role": "spine", "side": 0}
	if n.contains("neck"):
		return {"role": "neck", "side": 0}
	if n.contains("head"):
		return {"role": "head", "side": 0}
	if n.contains("toe") or n.contains("hand") or n.contains("shoulder") or n.contains("clavicle"):
		return {}
	if side == 0:
		return {}
	if n.contains("upleg") or n.contains("upperleg") or n.contains("thigh") or n.contains("upper_leg"):
		return {"role": "thigh", "side": side}
	if n.contains("foot") or n.contains("ankle"):
		return {"role": "foot", "side": side}
	if n.contains("leg") or n.contains("shin") or n.contains("calf"):
		return {"role": "shin", "side": side}
	if n.contains("forearm") or n.contains("lowerarm") or n.contains("lower_arm") or n.contains("elbow"):
		return {"role": "fore", "side": side}
	if n.contains("upperarm") or n.contains("upper_arm") or n.contains("arm"):
		return {"role": "arm", "side": side}
	return {}


func _depth(sk: Skeleton3D, i: int) -> int:
	var d := 0
	var p := sk.get_bone_parent(i)
	while p >= 0 and d < 64:
		d += 1
		p = sk.get_bone_parent(p)
	return d


func _setup_rig() -> void:
	var best: Skeleton3D = null
	for c in _scene.find_children("*", "Skeleton3D", true, false):
		var sk := c as Skeleton3D
		if best == null or sk.get_bone_count() > best.get_bone_count():
			best = sk
	if best == null:
		rig_info = "اسکلت ندارد — حرکت ساده‌ی کل بدن"
		return
	_skel = best
	var found := {}
	for i in _skel.get_bone_count():
		var r := _classify(_skel.get_bone_name(i))
		if r.is_empty():
			continue
		var key := "%s_%d" % [r["role"], r["side"]]
		if r["role"] == "spine":
			key = "spine_%d" % _roles.size()
			# فقط ۳ ستون فقرات اول
			var cnt := 0
			for k in _roles:
				if String(k).begins_with("spine"):
					cnt += 1
			if cnt >= 3:
				continue
		if _roles.has(key):
			continue
		_roles[key] = i
		_role_of[i] = r
		found[r["role"]] = true
	_foot_idx.clear()
	_ankle_clear = -1.0
	_plant = 0.0
	var legs_ok := _roles.has("thigh_-1") and _roles.has("thigh_1")
	var arms_ok := _roles.has("arm_-1") and _roles.has("arm_1")
	var by_shape := false
	if not legs_ok and not arms_ok:
		# اسم استخوان‌ها شناخته نشد؛ از روی شکل و جای استخوان‌ها حدس می‌زنیم
		by_shape = _guess_by_shape()
		legs_ok = _roles.has("thigh_-1") and _roles.has("thigh_1")
		arms_ok = _roles.has("arm_-1") and _roles.has("arm_1")
	has_rig = legs_ok or arms_ok
	for sd in [-1, 1]:
		if _roles.has("foot_%d" % sd):
			_foot_idx.append(int(_roles["foot_%d" % sd]))
	if has_rig:
		var idxs: Array[int] = []
		for k in _roles:
			idxs.append(int(_roles[k]))
		idxs.sort_custom(func(a: int, b: int) -> bool: return _depth(_skel, a) < _depth(_skel, b))
		_order = idxs
		rig_info = "اسکلت انسانی تشخیص داده شد%s (%d استخوان هدایت‌شونده)" % [" از روی شکل (نام‌ها ناشناخته)" if by_shape else "", _order.size()]
	else:
		rig_info = "اسکلت پیدا شد ولی نام استخوان‌ها شناخته نشد (%d استخوان) — حرکت ساده‌ی کل بدن" % _skel.get_bone_count()


## فضای مرجع: مختصات استخوان‌ها نسبت به مدل (چپ‌وراست = X، بالا = Y)
func _bone_pos(i: int) -> Vector3:
	# استخوان در فضای اسکلت ← فضای «والدِ نگهدارنده»
	var g := _skel.global_transform
	var pg: Transform3D = Transform3D.IDENTITY
	if _holder.get_parent() is Node3D:
		pg = (_holder.get_parent() as Node3D).global_transform
	var rel: Transform3D = pg.affine_inverse() * g
	return rel * _skel.get_bone_global_rest(i).origin


func _children_of(i: int) -> Array[int]:
	var out: Array[int] = []
	for c in _skel.get_bone_children(i):
		out.append(int(c))
	return out


func _chain_down(start: int, lateral: bool, cx: float) -> Array[int]:
	# زنجیره‌ای از استخوان‌ها: پا ← فرزند پایین‌ترین؛ دست ← فرزندی که از بدن دورتر می‌شود
	var chain: Array[int] = [start]
	var cur := start
	for _k in 6:
		var kids := _children_of(cur)
		if kids.is_empty():
			break
		var best := -1
		var bs := -1e9
		for k in kids:
			var p := _bone_pos(k)
			var score := (absf(p.x - cx) * 1.0 - p.y * 0.3) if lateral else -p.y
			if score > bs:
				bs = score
				best = k
		chain.append(best)
		cur = best
	return chain


func _guess_by_shape() -> bool:
	var n := _skel.get_bone_count()
	if n < 8:
		return false
	var ymin := 1e9
	var ymax := -1e9
	var cx := 0.0
	for i in n:
		var p := _bone_pos(i)
		ymin = minf(ymin, p.y)
		ymax = maxf(ymax, p.y)
		cx += p.x
	cx /= float(n)
	var H := ymax - ymin
	if H < 0.0001:
		return false
	# پا: استخوانی که میان‌تنه است، کنارِ مرکز، و پدرش تقریباً وسط بدن
	var legs := {}
	var arms := {}
	for i in n:
		var p := _bone_pos(i)
		var par := _skel.get_bone_parent(i)
		if par < 0:
			continue
		var pp := _bone_pos(par)
		var hy := (p.y - ymin) / H
		var side := 0
		if p.x - cx > 0.015 * H:
			side = 1
		elif p.x - cx < -0.015 * H:
			side = -1
		if side == 0:
			continue
		var pcentral := absf(pp.x - cx) < 0.045 * H
		if pcentral and hy > 0.35 and hy < 0.62 and pp.y - p.y > -0.02 * H:
			var ch := _chain_down(i, false, cx)
			if ch.size() >= 3 and not legs.has(side):
				legs[side] = ch
		elif hy > 0.6 and (absf(p.x - cx) - absf(pp.x - cx)) > 0.01 * H and pcentral and not arms.has(side):
			var ch2 := _chain_down(i, true, cx)
			if ch2.size() >= 3:
				arms[side] = ch2
	if legs.size() < 2:
		return false
	for side in legs:
		var ch: Array = legs[side]
		_set_role("thigh", side, ch[0])
		_set_role("shin", side, ch[1])
		_set_role("foot", side, ch[2])
	for side in arms:
		var ch: Array = arms[side]
		# با ترقوه: [ترقوه، بازو، ساعد، دست]؛ بدون ترقوه: [بازو، ساعد، دست]
		var o := 1 if ch.size() >= 4 else 0
		_set_role("arm", side, ch[o])
		_set_role("fore", side, ch[o + 1])
	return true


func _set_role(role: String, side: int, bone: int) -> void:
	_roles["%s_%d" % [role, side]] = bone
	_role_of[bone] = {"role": role, "side": side}


## آیا الان یک کلیپ واقعی پخش می‌شود؟ (آن‌وقت بازی خودش مدل را کج/بالا نمی‌برد)
func uses_clip() -> bool:
	return _cur_clip != ""


## نقش‌هایی که پیدا شده‌اند (برای نمایش در تنظیمات)
func rig_roles() -> Array[String]:
	var out: Array[String] = []
	for k in _roles:
		out.append("%s ← %s" % [k, _skel.get_bone_name(int(_roles[k]))])
	out.sort()
	return out


# ------------------------- تنظیمات -------------------------
func apply_config(c: Dictionary) -> void:
	cfg = DEFAULT_CFG.duplicate(true)
	for k in c:
		cfg[k] = c[k]
	if _holder == null:
		return
	_holder.scale = Vector3.ONE * float(cfg["scale"])
	_cur_state = ""     # انتخاب کلیپ دوباره انجام شود


func _bone_angle_target(role: String, side: int, state: String, st: Dictionary) -> float:
	var sw := float(cfg["swing"])
	var ln := float(cfg["lean"])
	var ph: float = st["phase"]
	var t: float = st["t"]
	var s := sin(ph + (0.0 if side < 0 else PI))
	var c := cos(ph + (0.0 if side < 0 else PI))
	match state:
		"run":
			match role:
				"thigh": return -0.85 * s * sw
				"shin": return 0.12 + 0.95 * maxf(0.0, c) * sw
				"foot": return 0.15 * s
				"arm": return 0.85 * s * sw
				"fore": return -1.15 - 0.25 * c
				"spine": return 0.16 * ln
				"head": return -0.10 * ln
				"neck": return -0.05 * ln
		"jump":
			var up := clampf(float(st["vy"]) * 0.2 + 0.5, 0.0, 1.0)   # ۱ = در حال بالا رفتن
			match role:
				"thigh": return lerpf(-0.45 if side < 0 else 0.15, -1.1 if side < 0 else -0.25, up) * sw
				"shin": return lerpf(0.3, 1.4 if side < 0 else 0.55, up)
				"foot": return 0.2
				"arm": return lerpf(-1.5, -2.3, up)
				"fore": return -0.35
				"spine": return 0.06 * ln
				"head": return -0.1 * ln
		"slide":
			match role:
				"thigh": return -0.18
				"shin": return 0.05
				"arm": return 0.35
				"fore": return -0.2
				"spine": return -0.12 * ln
				"head": return -0.25 * ln
		"hit":
			var flail := sin(t * 22.0 + (0.0 if side < 0 else PI))
			match role:
				"thigh": return (-0.35 if side < 0 else 0.25) * sw
				"shin": return 0.7 if side < 0 else 0.25
				"arm": return -0.5 + 0.8 * flail
				"fore": return -0.9
				"spine": return 0.5 * ln + 0.08 * sin(t * 26.0)
				"head": return 0.35 * ln
				"neck": return 0.15 * ln
		"fly":
			var flutter := sin(t * 14.0 + (0.0 if side < 0 else PI)) * 0.14
			match role:
				"thigh": return 0.08 + flutter
				"shin": return 0.25
				"arm": return -3.0
				"fore": return -0.08
				"spine": return 0.04 * ln
				"head": return -0.3 * ln
		"land":
			match role:
				"thigh": return -1.0
				"shin": return 1.5
				"foot": return -0.3
				"arm": return -0.8
				"fore": return -0.5
				"spine": return 0.55 * ln
				"head": return -0.2 * ln
		_:   # idle
			match role:
				"spine": return 0.02 + 0.025 * sin(t * 2.0)
				"arm": return 0.06 + 0.03 * sin(t * 2.0 + float(side))
				"fore": return -0.12
				"head": return 0.03 * sin(t * 1.1)
	return 0.0


func _apply_rig(state: String, st: Dictionary, delta: float) -> void:
	_skel.reset_bone_poses()
	var k := 1.0 - exp(-16.0 * delta)
	# محور خم‌شدن = چپ‌وراست مدل، در فضای خود اسکلت (چرخش/مقیاس گره‌ی اسکلت مهم نیست)
	var parent_b := Basis.IDENTITY
	if _holder.get_parent() is Node3D:
		parent_b = (_holder.get_parent() as Node3D).global_transform.basis.orthonormalized()
	var sk_b := _skel.global_transform.basis.orthonormalized()
	var axis := (sk_b.inverse() * (parent_b * Vector3.RIGHT)).normalized()
	if axis.length() < 0.5:
		axis = Vector3.RIGHT
	var dir := 1.0
	for i in _order:
		var info: Dictionary = _role_of.get(i, {})
		if info.is_empty():
			continue
		var tgt := _bone_angle_target(String(info["role"]), int(info["side"]), state, st)
		var cur := float(_cur_ang.get(i, 0.0))
		cur = lerpf(cur, tgt, k)
		_cur_ang[i] = cur
		var par := _skel.get_bone_parent(i)
		var pg := Basis.IDENTITY
		if par >= 0:
			pg = _skel.get_bone_global_pose(par).basis.orthonormalized()
		var rest_g := _skel.get_bone_global_rest(i).basis.orthonormalized()
		var gd := Basis(axis, cur * dir) * rest_g
		_skel.set_bone_pose_rotation(i, (pg.inverse() * gd).get_rotation_quaternion())


# ------------------------- سازگاری با CharacterModel -------------------------
func set_skin(_tex: Texture2D, _slim: bool, _smooth: bool) -> void:
	pass


## پیش‌نمایش (صفحه‌ی کاراکتر / تنظیمات): هر فریم صدا زده می‌شود
func pose_idle(t: float) -> void:
	var st := preview_state if preview_state != "" else "idle"
	var d := 1.0 / 60.0
	var s := {
		"moving": st == "run", "speed": 14.0, "phase": t * 13.7, "airborne": st == "jump",
		"sliding": st == "slide", "flying": st == "fly", "hit": st == "hit", "landing": st == "land",
		"vy": cos(t * 3.0) * 3.0, "t": t,
	}
	animate_state(s, d)


## هر فریم از بازیکن. st: moving, speed, phase, airborne, sliding, flying, hit, landing, vy, t
var _once_clip := ""
var _once_t := 0.0


func clip_list() -> PackedStringArray:
	return _anim.get_animation_list() if _anim != null else PackedStringArray()


## یک کلیپ دلخواه را یک‌بار پخش می‌کند (برای قانون‌های انیمیشن)
func play_clip_once(clip: String, dur: float) -> void:
	if clip.begins_with("pack:"):
		_ensure_pack(clip)
		clip = clip.replace(":", "_")      # نام انیمیشن در Godot نباید «:» داشته باشد
	if _anim == null or not _anim.has_animation(clip):
		return
	_once_clip = clip
	_once_t = maxf(dur, 0.3)
	_anim.play(clip)
	_anim.speed_scale = 1.0


## انیمیشن قرضی (AnimPack) را روی اسکلت همین مدل می‌سازد و به پخش‌کننده اضافه می‌کند
func _ensure_pack(clip: String) -> void:
	if _skel == null or _scene == null:
		return
	var key := clip.replace(":", "_")
	if _anim != null and _anim.has_animation(key):
		return
	var data := AnimPack.load_pack(clip.substr(5))
	if data.is_empty():
		return
	if _anim == null:
		_anim = AnimationPlayer.new()
		_scene.add_child(_anim)
		_anim.root_node = NodePath("..")
	var root := _anim.get_node_or_null(_anim.root_node)
	var a := AnimPack.build(data, root if root != null else _scene, _skel)
	if a == null:
		return
	var lib: AnimationLibrary
	if _anim.has_animation_library(""):
		lib = _anim.get_animation_library("")
	else:
		lib = AnimationLibrary.new()
		_anim.add_animation_library("", lib)
	lib.add_animation(key, a)


func animate_state(st: Dictionary, delta: float) -> void:
	if _holder == null:
		return
	if _once_t > 0.0:
		_once_t -= delta
		if _once_t <= 0.0:
			_cur_state = ""      # بعد از پایان دوباره حالت عادی شروع شود
		return
	_t = float(st.get("t", _t + delta))
	var state := "idle"
	if bool(st.get("flying", false)):
		state = "fly"
	elif bool(st.get("hit", false)):
		state = "hit"
	elif bool(st.get("sliding", false)):
		state = "slide"
	elif bool(st.get("airborne", false)):
		state = "jump"
	elif bool(st.get("landing", false)):
		state = "land"
	elif bool(st.get("moving", false)):
		state = "run"
	if state != _cur_state:
		_cur_state = state
		_state_time = 0.0
		_start_state(state)
	_state_time += delta
	var base_y := float(cfg["off_y"])
	_holder.position = Vector3(0.0, base_y + _plant, 0.0)
	_holder.rotation.z = 0.0
	if _cur_clip != "":
		var sp := float(cfg["speed"])
		if state == "run":
			sp *= clampf(0.7 + float(st.get("speed", 11.0)) * 0.035, 0.8, 1.8)
		elif state == "jump" or state == "hit" or state == "land":
			var want := {"jump": 0.75, "hit": 0.7, "land": 0.3}[state] as float
			var ca := _anim.get_animation(_cur_clip)
			var len_s := ca.length - float(_offsets.get(ca.get_instance_id(), 0.0))
			if len_s > 0.05:
				sp *= clampf(len_s / want, 0.5, 3.0)
		_anim.speed_scale = sp
		_plant_feet(state, base_y, delta)
		return
	if has_rig and bool(cfg["proc"]):
		_apply_rig(state, st, delta)
		_plant_feet(state, base_y, delta)
		return
	_plant = 0.0
	_apply_body_only(state, st)


## پا را روی زمین می‌نشاند: هیچ‌وقت فرو نمی‌رود و هنگام دویدن/ایستادن هم معلق نمی‌ماند
func _plant_feet(state: String, base_y: float, delta: float) -> void:
	if _skel == null or _holder == null or not _holder.is_inside_tree() or _foot_idx.is_empty():
		return
	var par := _holder.get_parent() as Node3D
	if par == null:
		return
	var lowest := 1e9
	for i in _foot_idx:
		var wp := _skel.to_global(_skel.get_bone_global_pose(i).origin)
		lowest = minf(lowest, par.to_local(wp).y)
	if _ankle_clear < 0.0:
		# اولین بار: فاصله‌ی مچ تا زمین را از حالت استراحت بگیر (مدل روی زمین نرمال شده است)
		var rest_low := 1e9
		for i in _foot_idx:
			var wr := _skel.to_global(_skel.get_bone_global_rest(i).origin)
			rest_low = minf(rest_low, par.to_local(wr).y - _holder.position.y)
		_ankle_clear = clampf(rest_low, 0.0, 0.5)
		return
	var sole := lowest - _ankle_clear - _plant
	var corr := base_y - sole
	var grounded := state == "run" or state == "idle" or state == "slide" or state == "land"
	if not grounded:
		corr = maxf(corr, 0.0)       # در هوا فقط از فرورفتن جلوگیری کن
	corr = clampf(corr, -0.25, 0.25) if grounded else clampf(corr, 0.0, 0.25)
	_plant = lerpf(_plant, corr, 1.0 - exp(-16.0 * delta))


func _start_state(state: String) -> void:
	_cur_clip = ""
	var clip := clip_for(state)
	if _anim != null and clip != "":
		var a := _anim.get_animation(clip)
		_strip_root_motion(a, state)
		a.loop_mode = Animation.LOOP_LINEAR if (state == "run" or state == "idle" or state == "fly") else Animation.LOOP_NONE
		_cur_clip = clip
		_anim.play(clip, 0.0 if _offsets.get(a.get_instance_id(), 0.0) > 0.0 else 0.12)
		var off := float(_offsets.get(a.get_instance_id(), 0.0))
		if off > 0.0:
			_anim.seek(off, true)
	else:
		if _anim != null:
			_anim.stop()
		if _skel != null:
			_skel.reset_bone_poses()
			_cur_ang.clear()


## حرکت ریشه‌ی کلیپ را «درجا» می‌کند: جلو/عقب و ارتفاع پرش را خود بازی تعیین می‌کند.
##  • x و z لگن روی حالت ایستاده قفل می‌شود.
##  • پرش و فرود: لگن هرگز بالاتر از قد ایستاده نمی‌رود (کلیپ فرود معمولاً از ۵ متری بالا شروع می‌شود!)
##    و بخش بی‌فایده‌ی ابتدای کلیپ (خم‌شدن قبل از پرش / سقوط قبل از فرود) رد می‌شود.
##  • سُرخوردن: لگن از یک حدی پایین‌تر نمی‌رود تا بدن در زمین فرو نرود.
var _stripped := {}
var _offsets := {}     # شناسه‌ی کلیپ → زمان شروع پخش

func _strip_root_motion(a: Animation, state: String) -> void:
	var id := a.get_instance_id()
	if _stripped.has(id):
		return
	_stripped[id] = true
	var rest := Vector3.ZERO
	var rest_found := false
	for ti in a.get_track_count():
		if a.track_get_type(ti) != Animation.TYPE_POSITION_3D:
			continue
		var path := a.track_get_path(ti)
		var rootish := false
		if path.get_subname_count() == 0:
			rootish = true
		elif _skel != null:
			var bi := _skel.find_bone(String(path.get_subname(0)))
			if bi >= 0:
				var nm := _skel.get_bone_name(bi).to_lower()
				rootish = _depth(_skel, bi) <= 1 or nm.contains("hips") or nm.contains("pelvis") or nm.contains("root")
				if rootish:
					rest = _skel.get_bone_rest(bi).origin
					rest_found = true
		if not rootish:
			continue
		var n := a.track_get_key_count(ti)
		if n == 0:
			continue
		var base := rest if rest_found else (a.track_get_key_value(ti, n - 1) as Vector3)
		var rest_y := base.y
		var offset := 0.0
		if state == "land":
			for k in n:
				if (a.track_get_key_value(ti, k) as Vector3).y <= rest_y * 1.05:
					offset = a.track_get_key_time(ti, k)
					break
		elif state == "jump":
			var lowest := 1e9
			var low_t := 0.0
			for k in n:
				var yy := (a.track_get_key_value(ti, k) as Vector3).y
				if yy < lowest:
					lowest = yy
					low_t = a.track_get_key_time(ti, k)
				if low_t > 0.0 or k > n / 2:
					pass
			# اگر ابتدای کلیپ خم‌شدن است، از لحظه‌ی برگشتن به قد ایستاده شروع کن
			var v0 := (a.track_get_key_value(ti, 0) as Vector3).y
			if v0 < rest_y * 0.85:
				for k in n:
					if (a.track_get_key_value(ti, k) as Vector3).y >= rest_y * 0.95:
						offset = a.track_get_key_time(ti, k)
						break
		_offsets[id] = offset
		for k in n:
			var v: Vector3 = a.track_get_key_value(ti, k)
			var y := v.y
			if state == "jump" or state == "land":
				y = minf(y, rest_y)
			elif state == "slide":
				y = maxf(y, rest_y * 0.24)
			a.track_set_key_value(ti, k, Vector3(base.x, y, base.z))


## بدون اسکلت و بدون کلیپ: حرکت ساده‌ی کل بدن
func _apply_body_only(state: String, st: Dictionary) -> void:
	var ph := float(st["phase"])
	var sw := float(cfg["swing"])
	var ln := float(cfg["lean"])
	var sn := sin(ph)
	_holder.rotation.x = 0.0
	match state:
		"run":
			_holder.position.y += absf(sn) * 0.09 * sw
			_holder.rotation.z = sn * 0.09 * sw
			_holder.rotation.x = (0.16 + absf(cos(ph)) * 0.04) * ln
		"jump":
			_holder.rotation.x = (-0.18 if float(st["vy"]) > 0.0 else 0.12) * ln
		"slide":
			_holder.rotation.x = -0.1 * ln
		"hit":
			_holder.rotation.x = 0.4 * ln
			_holder.rotation.z = sin(_t * 24.0) * 0.12
		"fly":
			_holder.rotation.x = -0.1 * ln
			_holder.rotation.z = sin(_t * 12.0) * 0.05
		"land":
			_holder.scale = Vector3(1.0, 0.86, 1.0) * float(cfg["scale"])
			return
		_:
			_holder.position.y += sin(_t * 2.0) * 0.012
			_holder.rotation.z = sin(_t * 1.1) * 0.02
	_holder.scale = Vector3.ONE * float(cfg["scale"])
