class_name MiniSpace
extends MiniBase
## «نبرد فضایی» (سبک تیراندازی فضایی): با آنالوگ سفینه را در صفحه حرکت بده؛ شلیک خودکار است.
## شهاب‌سنگ‌ها و سفینه‌های دشمن را بزن، ستاره‌ها را بردار؛ برخورد ۴ ثانیه از زمان کم می‌کند.

const Gfx := preload("res://scripts/gfx.gd")
const AX := 6.5
const AY := 3.6

var ship: Node3D
var _flame: MeshInstance3D
var _ents: Array[Dictionary] = []
var _bullets: Array[Dictionary] = []
var _rng := RandomNumberGenerator.new()
var _spawn_t := 0.5
var _fire_t := 0.0
var _shake := 0.0
var _flash: ColorRect
var _t := 0.0
var _kills := 0


func _ready() -> void:
	title = "نبرد فضایی"
	hint = "آنالوگ: حرکت سفینه (شلیک خودکار)\nدشمن‌ها را بزن و ستاره‌ها را بردار!"
	accent = Color("7a5cff")
	duration = 45.0
	_rng.randomize()
	var env := make_env(Color("02010f"), Color("2a1260"), Color("0a0620"), 0.004, Color("8a7cff"), 0.7)
	add_sun(Color("cfd8ff"), 1.1, Vector3(-40, 30, 0))
	_build_scenery()
	_build_ship()
	_build_base(env)
	cam.position = Vector3(0, 1.2, 9.5)
	cam.rotation_degrees = Vector3(-4, 0, 0)
	_flash = ColorRect.new()
	_flash.color = Color(1, 0.2, 0.2, 0)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	_hud.add_child(_flash)


func _m(hex: String, emit: float = 0.0, rough: float = 0.5, metal: float = 0.0) -> StandardMaterial3D:
	return Modes.P.m(hex, emit, rough, metal)


func _build_scenery() -> void:
	Gfx.glow(self, Vector3(-40, 20, -140), 220.0, Color(0.5, 0.2, 0.9, 0.22))
	Gfx.glow(self, Vector3(50, -10, -150), 180.0, Color(0.1, 0.6, 1.0, 0.18))
	Gfx.sphere(self, 26.0, Vector3(60, 24, -170), _m("ff5a8a", 0.5, 0.6), 16)
	Gfx.sphere(self, 12.0, Vector3(-70, -14, -140), _m("5ad0ff", 0.6, 0.6), 14)
	Modes.P.ring(self, 22.0, 0.7, Vector3(-70, -14, -140), _m("ffffff", 1.0, 0.4), Vector3(74, 0, 12), 28)
	var sm := SphereMesh.new()
	sm.radius = 0.06
	sm.height = 0.12
	sm.radial_segments = 5
	sm.rings = 3
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(1, 1, 1)
	sm.material = mat
	var p := CPUParticles3D.new()
	p.amount = 140
	p.lifetime = 2.4
	p.preprocess = 2.4
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(30, 18, 2)
	p.mesh = sm
	p.direction = Vector3(0, 0, 1)
	p.spread = 0.0
	p.initial_velocity_min = 35.0
	p.initial_velocity_max = 55.0
	p.gravity = Vector3.ZERO
	p.position = Vector3(0, 0, -90)
	p.visibility_aabb = AABB(Vector3(-40, -30, -10), Vector3(80, 60, 120))
	add_child(p)


func _build_ship() -> void:
	ship = Node3D.new()
	add_child(ship)
	Gfx.box(ship, Vector3(0.7, 0.35, 2.0), Vector3(0, 0, 0), _m("e8eef8", 0.0, 0.25, 0.7))
	Gfx.cyl(ship, 0.001, 0.35, 1.0, Vector3(0, 0, -1.4), _m("e8eef8", 0.0, 0.25, 0.7), Vector3(-90, 0, 0), 8)
	Gfx.box(ship, Vector3(3.0, 0.1, 0.9), Vector3(0, -0.05, 0.4), _m("7a5cff", 0.4, 0.3, 0.6), Vector3(0, 0, 0))
	Gfx.box(ship, Vector3(0.1, 0.5, 0.7), Vector3(0, 0.35, 0.7), _m("ff2d95", 0.8))
	Gfx.sphere(ship, 0.3, Vector3(0, 0.25, -0.2), _m("27e8ff", 1.6, 0.1), 8)
	_flame = Gfx.cyl(ship, 0.001, 0.22, 1.0, Vector3(0, 0, 1.5), _m("ffb030", 3.0), Vector3(90, 0, 0), 6)
	Gfx.glow(ship, Vector3(0, 0, 1.6), 2.6, Color(1.0, 0.6, 0.2, 0.4))


func _spawn() -> void:
	var r := _rng.randf()
	var n := Node3D.new()
	var d := {"node": n, "kind": 0, "hp": 2, "vz": 26.0 + _t * 0.5, "spin": Vector3(_rng.randf_range(-2, 2), _rng.randf_range(-2, 2), 0)}
	n.position = Vector3(_rng.randf_range(-AX, AX), _rng.randf_range(-AY, AY), -95.0)
	if r < 0.18:     # ستاره
		d["kind"] = 2
		d["hp"] = 1
		Gfx.cyl(n, 0.001, 0.5, 0.9, Vector3(0, 0.45, 0), _m("ffe070", 2.6), Vector3.ZERO, 5)
		Gfx.cyl(n, 0.5, 0.001, 0.9, Vector3(0, -0.45, 0), _m("ffe070", 2.6), Vector3.ZERO, 5)
		Gfx.glow(n, Vector3.ZERO, 3.0, Color(1, 0.85, 0.3, 0.4))
	elif r < 0.5:    # سفینه‌ی دشمن
		d["kind"] = 1
		d["hp"] = 1
		d["vz"] = 34.0 + _t * 0.5
		Gfx.box(n, Vector3(1.2, 0.4, 1.6), Vector3.ZERO, _m("c8203a", 0.3, 0.3, 0.5))
		Gfx.box(n, Vector3(2.4, 0.08, 0.7), Vector3.ZERO, _m("5a0a1a", 0.0, 0.4, 0.6))
		Gfx.sphere(n, 0.28, Vector3(0, 0.25, 0.3), _m("ff4040", 2.4), 7)
		n.rotation_degrees = Vector3(0, 180, 0)
	else:            # شهاب‌سنگ
		var s := _rng.randf_range(0.9, 1.6)
		Gfx.sphere(n, s, Vector3.ZERO, _m("5a5468", 0.0, 0.95), 8)
		Gfx.sphere(n, s * 0.5, Vector3(s * 0.6, s * 0.4, s * 0.3), _m("6a6478", 0.0, 0.95), 6)
		Gfx.sphere(n, s * 0.4, Vector3(-s * 0.5, -s * 0.3, s * 0.5), _m("463f58", 0.0, 0.95), 6)
		d["r"] = s
	add_child(n)
	_ents.append(d)


func _tick(delta: float) -> void:
	_t += delta
	var v := stick.get_vector()
	ship.position.x = clampf(ship.position.x + v.x * 13.0 * delta, -AX, AX)
	ship.position.y = clampf(ship.position.y - v.y * 9.0 * delta, -AY, AY)
	ship.rotation_degrees.z = lerpf(ship.rotation_degrees.z, -v.x * 28.0, 0.2)
	ship.rotation_degrees.x = lerpf(ship.rotation_degrees.x, -v.y * 12.0, 0.2)
	_flame.scale = Vector3(1, 0.8 + 0.5 * sin(_t * 40.0), 1)
	cam.position.x = lerpf(cam.position.x, ship.position.x * 0.5, 0.1)
	cam.position.y = lerpf(cam.position.y, 1.2 + ship.position.y * 0.4, 0.1)
	if _shake > 0.0:
		_shake -= delta
		cam.position += Vector3(_rng.randf_range(-0.2, 0.2), _rng.randf_range(-0.2, 0.2), 0) * (_shake * 4.0)
		_flash.color.a = clampf(_shake * 1.2, 0.0, 0.4)
	else:
		_flash.color.a = 0.0
	# شلیک
	_fire_t -= delta
	if _fire_t <= 0.0:
		_fire_t = 0.17
		for sx in [-0.9, 0.9]:
			var b := Node3D.new()
			Gfx.box(b, Vector3(0.12, 0.12, 1.1), Vector3.ZERO, _m("7fe8ff", 3.0))
			b.position = ship.position + Vector3(sx, -0.05, -0.8)
			add_child(b)
			_bullets.append({"node": b})
	# ساخت دشمن
	_spawn_t -= delta
	if _spawn_t <= 0.0:
		_spawn_t = maxf(0.28, 0.6 - _t * 0.006)
		_spawn()
	# گلوله‌ها
	for i in range(_bullets.size() - 1, -1, -1):
		var b: Node3D = _bullets[i]["node"]
		b.position.z -= 110.0 * delta
		var hit := false
		for j in range(_ents.size() - 1, -1, -1):
			var e: Dictionary = _ents[j]
			if int(e["kind"]) == 2:
				continue
			var en: Node3D = e["node"]
			var rad: float = float(e.get("r", 1.1)) + 0.3
			if absf(en.position.z - b.position.z) < 1.4 and Vector2(en.position.x - b.position.x, en.position.y - b.position.y).length() < rad:
				e["hp"] = int(e["hp"]) - 1
				hit = true
				if int(e["hp"]) <= 0:
					_destroy(j, true)
				break
		if hit or b.position.z < -100.0:
			b.queue_free()
			_bullets.remove_at(i)
	# دشمن‌ها
	for j in range(_ents.size() - 1, -1, -1):
		var e: Dictionary = _ents[j]
		var en: Node3D = e["node"]
		en.position.z += float(e["vz"]) * delta
		en.rotation += (e["spin"] as Vector3) * delta
		var near := absf(en.position.z - ship.position.z) < 1.5 and Vector2(en.position.x - ship.position.x, en.position.y - ship.position.y).length() < float(e.get("r", 0.9)) + 0.9
		if near:
			if int(e["kind"]) == 2:
				add_coins(3)
				say("+۳ ستاره", 0.5)
				_destroy(j, false)
			else:
				time_left -= 4.0
				_shake = 0.35
				say("برخورد! −۴ ثانیه", 0.8)
				_destroy(j, false)
		elif en.position.z > 14.0:
			en.queue_free()
			_ents.remove_at(j)


func _destroy(j: int, scored: bool) -> void:
	var e: Dictionary = _ents[j]
	var en: Node3D = e["node"]
	var pos := en.position
	if scored:
		_kills += 1
		var k := int(e["kind"])
		add_coins(4 if k == 1 else 2)
		if _kills % 10 == 0:
			bonus += 10
			say("۱۰ نابودی! پاداش +۱۰", 0.9)
	# انفجار
	var g := Gfx.glow(self, pos, 5.0, Color(1.0, 0.7, 0.3, 0.7))
	var tw := create_tween()
	tw.tween_property(g, "scale", Vector3.ONE * 2.2, 0.25)
	tw.parallel().tween_property(g, "transparency", 1.0, 0.25)
	tw.tween_callback(g.queue_free)
	en.queue_free()
	_ents.remove_at(j)
