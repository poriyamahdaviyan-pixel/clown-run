extends Node
## صفحه‌های آنلاین: حساب (ورود/ثبت‌نام)، جدول امتیاز، فروشگاه آنلاین با پیش‌نمایش و قفل.

const UiArt := preload("res://scripts/ui_art.gd")
const StoreFx := preload("res://scripts/store_fx.gd")
const COL_TEXT := Color("fff1de")
const COL_GOLD := Color("ffb02e")
const RARITY_NAMES := {"common": "معمولی", "rare": "کمیاب", "epic": "حماسی", "legendary": "افسانه‌ای"}
const RARITY_COLORS := {"common": Color("b8b8c8"), "rare": Color("4aa3ff"), "epic": Color("c15bff"), "legendary": Color("ffb02e")}
const KIND_NAMES := {"skin": "اسکین", "glb": "مدل سه‌بعدی", "coin": "طرح سکه", "voice": "صدا", "anim": "انیمیشن", "anim_clip": "انیمیشن کاراکتر", "police": "ظاهر تعقیب‌کننده", "music": "آهنگ پس‌زمینه", "chaser_voice": "صدای تعقیب‌کننده", "chaser_anim": "انیمیشن تعقیب‌کننده"}

var ui                       # ui.gd
var account: Control
var board: Control
var store: Control
var _acc_box: VBoxContainer
var _user_edit: LineEdit
var _pass_edit: LineEdit
var _acc_msg: Label
var challenge: Control
var _ch_list: VBoxContainer
var _ch_room := 0
var _ch_code: LineEdit
var _ch_title: Label
var _board_list: VBoxContainer
var _board_period := "all"
var _store_grid: GridContainer
var store_filter := ""
var _store_tabs: HBoxContainer
var char_shop
var studio
var store_admin
var release_admin
var competitive
var _store_admin_row: HFlowContainer
var _store_coins: Label
var _store_msg: Label
var _detail: Control
var _spinners: Array = []
var _t := 0.0


func build(p_ui, root: Control) -> void:
	ui = p_ui
	account = _screen(root, "حساب من", Color("1f1238"))
	board = _screen(root, "جدول امتیاز", Color("1b1038"))
	store = _screen(root, "فروشگاه آنلاین", Color("2a1248"))
	var bd := StoreFx.new()
	bd.mode = "backdrop"
	ui._add_full(store, bd)
	store.move_child(bd, 1)
	_build_account()
	challenge = _screen(root, "رقابت", Color("231040"))
	_build_board()
	_build_challenge()
	_build_store()
	char_shop = preload("res://scripts/char_shop.gd").new()
	ui.add_child(char_shop)
	char_shop.setup(ui, self)
	studio = preload("res://scripts/store_studio.gd").new()
	ui.add_child(studio)
	studio.setup(ui, self, char_shop)
	store_admin = preload("res://scripts/store_admin.gd").new()
	ui.add_child(store_admin)
	store_admin.setup(ui, self)
	release_admin = preload("res://scripts/release_admin.gd").new()
	ui.add_child(release_admin)
	release_admin.setup(ui)
	Online.auth_changed.connect(_on_auth)
	Online.connection_changed.connect(func(_o: bool): _on_auth())
	Online.profile_changed.connect(_on_profile)
	Online.items_changed.connect(func(): if store.visible: refresh_store())
	Content.changed.connect(func(): if store.visible: refresh_store())


func _process(delta: float) -> void:
	_t += delta
	for s in _spinners:
		if is_instance_valid(s) and s.has_meta("shine"):
			var ph: float = fmod(_t * 0.45 + float(s.get_meta("shine")), 3.0)
			s.position = Vector2(-80.0 + ph * 200.0, -60.0)
		elif is_instance_valid(s):
			var k := 1.0 + 0.035 * sin(_t * 1.8 + float(s.get_meta("ph", 0.0)))
			s.scale = Vector2(k, k)          # تپش ملایم (چرخش واقعیِ ۳۶۰° در صفحه‌ی جزئیات است)
			s.pivot_offset = s.size * 0.5
	_spinners = _spinners.filter(func(s): return is_instance_valid(s))


# ------------------------- ساختار کلی -------------------------
func _screen(root: Control, title: String, bg_color: Color) -> Control:
	var c := Control.new()
	ui._add_full(root, c)
	var bg := ColorRect.new()
	bg.color = bg_color
	ui._add_full(c, bg)
	var m := MarginContainer.new()
	ui._add_full(c, m)
	for k in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + k, 28)
	m.add_theme_constant_override("margin_top", 56)
	var col := VBoxContainer.new()
	col.name = "Col"
	col.add_theme_constant_override("separation", 14)
	m.add_child(col)
	col.add_child(ui._label(title, 54, Color.WHITE))
	c.visible = false
	return c


func _col(c: Control) -> VBoxContainer:
	for ch in c.get_children():
		if ch is MarginContainer:
			return ch.get_child(0)
	return null


var _acc_back: Button


func _back_button(col: VBoxContainer) -> Button:
	var b: Button = ui._button("بازگشت", func(): ui._set_screen(ui.Screen.START), Vector2(540, 88), 36, "Dark")
	col.add_child(b)
	return b


func toast(t: String) -> void:
	Game.toast.emit(t)


# ------------------------- حساب -------------------------
func _build_account() -> void:
	var col := _col(account)
	_acc_box = VBoxContainer.new()
	_acc_box.add_theme_constant_override("separation", 14)
	_acc_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(_acc_box)
	_acc_back = _back_button(col)


func refresh_account() -> void:
	for c in _acc_box.get_children():
		c.queue_free()
	if _acc_back != null:
		_acc_back.visible = Online.gate_open()
	if not Online.enabled():
		_acc_box.add_child(_note("این بازی کاملاً آنلاین است ولی به سرور وصل نیست.\nفایل online.cfg با آدرس و کلید Supabase پر نشده یا در برنامه نیامده."))
		return
	if Online.restoring:
		_acc_box.add_child(_note("در حال اتصال به حساب…"))
		return
	if Online.offline:
		_acc_box.add_child(_note("اینترنت در دسترس نیست. برای بازی کردن باید آنلاین باشی."))
		_acc_box.add_child(ui._button("تلاش دوباره", func(): Online.check_connection(), Vector2(540, 92), 36, "Gold"))
		return
	if Online.maintenance:
		_acc_box.add_child(_note("بخش آنلاین موقتاً در حال تعمیر است."))
	if Online.logged_in():
		_acc_box.add_child(ui._label("سلام %s" % Online.username, 48, COL_GOLD))
		var card := _card()
		var v := card.get_child(0) as VBoxContainer
		v.add_child(ui._label("سکه: %d" % Game.coins, 40, Color.WHITE))
		v.add_child(_note("هر سکه‌ای که در بازی جمع می‌کنی بعد از پایان دور به حساب آنلاین اضافه می‌شود و برای خرید از فروشگاه آنلاین خرج می‌شود."))
		_acc_box.add_child(card)
		var daily = ui._button("جایزه‌ی روزانه", func(): _claim_daily(), Vector2(540, 92), 36, "Gold")
		daily.disabled = not Online.daily_ready
		if not Online.daily_ready:
			daily.text = "جایزه‌ی امروز را گرفته‌ای ✓"
		_acc_box.add_child(daily)
		if Online.is_admin:
			_acc_box.add_child(_note("(مدیر) تو مدیر هستی. برای افزودن کاراکتر/سکه و تغییر تنظیمات، فایل admin/index.html را در مرورگر باز کن."))
		if Online.is_admin:
			_acc_box.add_child(ui._button("نسخه‌ها و بروزرسانی (لینک APK، وصله)", func(): release_admin.open(), Vector2(540, 84), 28, "Teal"))
		_acc_box.add_child(ui._button("خروج از حساب", func(): Online.sign_out(), Vector2(540, 84), 32, "Red"))
		return
	_acc_box.add_child(_note("برای بازی باید وارد حساب شوی. سکه‌ها، ارتقاها، ماموریت‌ها و امتیازت روی حسابت ذخیره می‌شود و با هر گوشی‌ای می‌توانی ادامه بدهی."))
	_user_edit = LineEdit.new()
	_user_edit.placeholder_text = "نام کاربری (انگلیسی/عدد، ۳ تا ۲۰)"
	_user_edit.custom_minimum_size = Vector2(540, 84)
	_user_edit.add_theme_font_size_override("font_size", 32)
	_user_edit.max_length = 20
	_user_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_DEFAULT
	_acc_box.add_child(_user_edit)
	_pass_edit = LineEdit.new()
	_pass_edit.placeholder_text = "رمز (حداقل ۶ کاراکتر)"
	_pass_edit.secret = true
	_pass_edit.custom_minimum_size = Vector2(540, 84)
	_pass_edit.add_theme_font_size_override("font_size", 32)
	_acc_box.add_child(_pass_edit)
	_acc_msg = ui._label("", 28, Color("ff7a8a"))
	_acc_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_acc_msg.custom_minimum_size = Vector2(600, 0)
	_acc_box.add_child(_acc_msg)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(ui._button("ورود", func(): _do_auth(false), Vector2(262, 96), 38, "Gold"))
	row.add_child(ui._button("ثبت‌نام", func(): _do_auth(true), Vector2(262, 96), 38, "Teal"))
	_acc_box.add_child(row)


func _do_auth(sign_up: bool) -> void:
	_acc_msg.text = "…"
	var u := _user_edit.text.strip_edges()
	var r: Dictionary
	if sign_up:
		r = await Online.sign_up(u, _pass_edit.text)
	else:
		r = await Online.sign_in(u, _pass_edit.text)
	if not r.ok:
		if is_instance_valid(_acc_msg):
			_acc_msg.text = String(r.error)
	else:
		toast("خوش آمدی %s!" % Online.username)
		ui._set_screen(ui.Screen.START)


func _claim_daily() -> void:
	var r := await Online.claim_daily()
	if r.get("ok", false):
		toast("جایزه‌ی روزانه: +%d سکه (روز %d)" % [int(r.reward), int(r.streak)])
	else:
		toast("امروز را قبلاً گرفته‌ای")
	refresh_account()


func _claim_local() -> void:
	var r := await Online.claim_local_coins()
	if r.get("ok", false):
		toast("%d سکه به حساب آنلاین منتقل شد" % int(r.added))
	else:
		toast("انتقال ممکن نیست (قبلاً انجام شده)")
	refresh_account()


func _on_auth() -> void:
	if account.visible:
		refresh_account()
	ui._refresh_all()


func _on_profile() -> void:
	if account.visible:
		refresh_account()
	if store.visible and _store_coins:
		_store_coins.text = "سکه: %d" % Game.coins
	ui._refresh_all()


# ------------------------- جدول امتیاز -------------------------
func _build_board() -> void:
	var col := _col(board)
	var tabs := HBoxContainer.new()
	tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	tabs.add_theme_constant_override("separation", 10)
	for t in [["day", "امروز"], ["week", "این هفته"], ["all", "همیشه"]]:
		var key: String = t[0]
		tabs.add_child(ui._button(t[1], func(): _board_period = key; refresh_board(), Vector2(180, 78), 32, "Teal"))
	col.add_child(tabs)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(sc)
	_board_list = VBoxContainer.new()
	_board_list.add_theme_constant_override("separation", 8)
	_board_list.custom_minimum_size = Vector2(640, 0)
	sc.add_child(_board_list)
	_back_button(col)


func refresh_board() -> void:
	for c in _board_list.get_children():
		c.queue_free()
	if not Online.enabled():
		_board_list.add_child(_note("بخش آنلاین هنوز به سرور وصل نیست."))
		return
	_board_list.add_child(_note("در حال دریافت…"))
	var rows: Array = await Online.leaderboard(_board_period)
	for c in _board_list.get_children():
		c.queue_free()
	if rows.is_empty():
		_board_list.add_child(_note("هنوز امتیازی ثبت نشده. اولین نفر باش!"))
		return
	var medals := ["۱", "۲", "۳"]
	for r: Dictionary in rows:
		var rank := int(r.get("rank", 0))
		var mine := Online.s(r.get("username", "")) == Online.username
		var p := PanelContainer.new()
		p.add_theme_stylebox_override("panel", UiArt.panel_style(Color(0.9, 0.55, 0.1, 0.4) if mine else Color(0.1, 0.04, 0.22, 0.7)))
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 12)
		p.add_child(h)
		var rl = ui._label(medals[rank - 1] if rank <= 3 else str(rank), 38 if rank <= 3 else 32, [Color("ffd24a"), Color("d6dbe6"), Color("e0925a")][rank - 1] if rank <= 3 else COL_GOLD)
		rl.custom_minimum_size = Vector2(70, 0)
		h.add_child(rl)
		var nl = ui._label(Online.s(r.get("username", "")), 32, Color.WHITE)
		nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		h.add_child(nl)
		h.add_child(ui._label("%d  (%d م)" % [int(r.get("score", 0)), int(r.get("distance", 0))], 30, COL_TEXT))
		_board_list.add_child(p)


# ------------------------- رقابت (چندنفره، لیگ، رویداد) -------------------------
func _build_challenge() -> void:
	competitive = Competitive.new()
	ui.add_child(competitive)
	competitive.setup(ui, self)
	competitive.build(_col(challenge))


func refresh_challenge() -> void:
	competitive.refresh()


# ------------------------- فروشگاه آنلاین -------------------------
var _store_search: LineEdit
var _store_flt_row: HFlowContainer
var _store_hero: Control
var store_flt := "all"          # all | mine | free | sale | limited
var store_sort := "new"         # new | cheap | pricey | rare
const FLT_NAMES := [["all", "همه"], ["mine", "مال من"], ["free", "رایگان"], ["sale", "تخفیف"], ["limited", "محدود"]]
const SORT_NAMES := {"new": "جدیدترین", "cheap": "ارزان‌ترین", "pricey": "گران‌ترین", "rare": "نادرترین"}
var _store_scroll: ScrollContainer


func _build_store() -> void:
	var col := _col(store)
	var old_title := col.get_child(0)
	var ban := StoreFx.new()
	ban.mode = "banner"
	ban.custom_minimum_size = Vector2(0, 132)
	col.add_child(ban)
	col.move_child(ban, 0)
	var bt: Label = ui._label("فروشگاه", 60, Color.WHITE)
	bt.add_theme_color_override("font_outline_color", Color(0.25, 0.02, 0.3))
	bt.add_theme_constant_override("outline_size", 10)
	bt.set_meta(ui.FIT_META, true)
	bt.autowrap_mode = TextServer.AUTOWRAP_OFF
	bt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	ui._add_full(ban, bt)
	old_title.visible = false
	# سربرگ: سکه + جست‌وجو
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 10)
	col.add_child(head)
	var pill := PanelContainer.new()
	var psb := StyleBoxFlat.new()
	psb.bg_color = Color(0.25, 0.14, 0.02, 0.95)
	psb.set_corner_radius_all(30)
	psb.set_border_width_all(3)
	psb.border_color = COL_GOLD
	psb.set_content_margin_all(10)
	psb.content_margin_left = 20
	psb.content_margin_right = 20
	pill.add_theme_stylebox_override("panel", psb)
	_store_coins = ui._label("", 30, COL_GOLD)
	pill.add_child(_store_coins)
	head.add_child(pill)
	_store_search = LineEdit.new()
	_store_search.placeholder_text = "جست‌وجو در فروشگاه…"
	_store_search.clear_button_enabled = true
	_store_search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_store_search.custom_minimum_size = Vector2(0, 64)
	_store_search.add_theme_font_size_override("font_size", 26)
	_store_search.text_changed.connect(func(_t): refresh_store())
	head.add_child(_store_search)
	# تب بخش‌ها: یک ردیف که با کشیدن انگشت به چپ/راست می‌رود
	var tab_sc := ScrollContainer.new()
	tab_sc.custom_minimum_size = Vector2(0, 84)
	tab_sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	tab_sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	col.add_child(tab_sc)
	_store_tabs = HBoxContainer.new()
	_store_tabs.add_theme_constant_override("separation", 8)
	tab_sc.add_child(_store_tabs)
	# فیلتر و ترتیب
	_store_flt_row = HFlowContainer.new()
	_store_flt_row.add_theme_constant_override("h_separation", 8)
	_store_flt_row.add_theme_constant_override("v_separation", 6)
	col.add_child(_store_flt_row)
	_store_admin_row = HFlowContainer.new()
	_store_admin_row.alignment = FlowContainer.ALIGNMENT_CENTER
	_store_admin_row.add_theme_constant_override("h_separation", 8)
	_store_admin_row.add_theme_constant_override("v_separation", 8)
	col.add_child(_store_admin_row)
	_store_msg = ui._label("", 26, Color("ffd27a"))
	_store_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_store_msg.custom_minimum_size = Vector2(10, 0)
	col.add_child(_store_msg)
	_store_scroll = ScrollContainer.new()
	_store_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_store_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(_store_scroll)
	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 14)
	_store_scroll.add_child(inner)
	_store_hero = VBoxContainer.new()
	_store_hero.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_child(_store_hero)
	_store_grid = GridContainer.new()
	_store_grid.columns = 2
	_store_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_store_grid.add_theme_constant_override("h_separation", 14)
	_store_grid.add_theme_constant_override("v_separation", 14)
	inner.add_child(_store_grid)
	_back_button(col)


func _rebuild_filters() -> void:
	for c in _store_flt_row.get_children():
		c.queue_free()
	var show := store_filter != "@chars" and Online.enabled()
	_store_flt_row.visible = show
	_store_search.visible = true
	if not show:
		return
	for f in FLT_NAMES:
		var fid: String = f[0]
		var on := fid == store_flt
		_store_flt_row.add_child(ui._button(String(f[1]), func(): store_flt = fid; refresh_store(), Vector2(0, 54), 21, "Gold" if on else "Dark"))
	_store_flt_row.add_child(ui._button("ترتیب: " + String(SORT_NAMES[store_sort]), func():
		var ks: Array = SORT_NAMES.keys()
		store_sort = ks[(ks.find(store_sort) + 1) % ks.size()]
		refresh_store(), Vector2(0, 54), 21, "Teal"))
	Content.apply_tree.call_deferred(_store_flt_row)


func open_store() -> void:
	refresh_store()
	await Online.refresh_profile()
	await Online.load_items()


func _rebuild_store_tabs() -> void:
	for c in _store_tabs.get_children():
		c.queue_free()
	var secs := Content.store_visible()
	var kinds: Array = []
	for sec: Dictionary in secs:
		kinds.append(String(sec.kind))
	if not store_filter in kinds:
		store_filter = ""
	if secs.size() > 1:           # با یک بخش، نوار تب لازم نیست
		for sec: Dictionary in secs:
			var key := String(sec.kind)
			var b: Button = ui._button(String(sec.text), func(): store_filter = key; refresh_store(), Vector2(132, 72), 28, "Teal")
			b.modulate = Color.WHITE if key == store_filter else Color(1, 1, 1, 0.6)
			_store_tabs.add_child(b)
	Content.apply_tree.call_deferred(_store_tabs)


func _rebuild_admin_row() -> void:
	for c in _store_admin_row.get_children():
		c.queue_free()
	_store_admin_row.visible = Online.is_admin and store_filter != "@chars"
	if not _store_admin_row.visible:
		return
	_store_admin_row.add_child(ui._button("+ آیتم جدید", func(): store_admin.open_form_for(store_filter, {}), Vector2(250, 66), 24, "Gold"))
	_store_admin_row.add_child(ui._button("مدیریت این بخش", func(): store_admin.open_manager(store_filter), Vector2(300, 66), 24, "Teal"))
	_store_admin_row.add_child(ui._button("ساخت خودکار پیش‌نمایش‌های خالی", func(): store_admin.backfill_previews(), Vector2(0, 66), 22, "Dark"))


func refresh_store() -> void:
	studio.detach()
	_rebuild_store_tabs()
	_rebuild_filters()
	_rebuild_admin_row()
	for c in _store_grid.get_children():
		c.queue_free()
	_spinners.clear()
	_store_coins.text = "سکه: %d" % Game.coins if Online.logged_in() else "برای خرید وارد حساب شو"
	if not Online.enabled():
		_store_msg.text = "بخش آنلاین هنوز به سرور وصل نیست."
		return
	if Online.maintenance:
		_store_msg.text = "فروشگاه موقتاً در حال تعمیر است."
		return
	for c in _store_hero.get_children():
		c.queue_free()
	if store_filter == "@chars":
		_store_msg.text = ""
		studio.fill_grid(_store_grid)
		return
	_store_grid.columns = 2
	var list: Array = _filtered_items()
	for c in _store_hero.get_children():
		c.queue_free()
	var q := _store_search.text.strip_edges() if _store_search != null else ""
	if q == "" and store_flt == "all" and store_filter != "all_chars":
		var feat := list.filter(func(i): return bool(i.get("featured", false)))
		if not feat.is_empty():
			_store_hero.add_child(_hero_card(feat[0]))
	for it: Dictionary in list:
		_store_grid.add_child(_item_card(it))
	_store_msg.text = "" if list.size() > 0 else ("چیزی با این جست‌وجو پیدا نشد." if (q != "" or store_flt != "all") else "هنوز آیتمی در فروشگاه نیست.")
	if Online.logged_in() and list.size() > 0:
		_store_msg.text = "%d آیتم" % list.size()


func _filtered_items() -> Array:
	var out: Array = []
	var q := _store_search.text.strip_edges().to_lower() if _store_search != null else ""
	for it: Dictionary in Online.items:
		if store_filter != "" and String(it.kind) != store_filter:
			continue
		if not Content.store_shows_kind(String(it.kind)):
			continue
		if Online.is_char_item(it) and store_filter != "all_chars":
			continue                # آیتم‌های مخصوص یک کاراکتر فقط داخل استودیوی همان کاراکتر
		var state := Online.item_state(it)
		match store_flt:
			"mine":
				if state != "owned": continue
			"free":
				if Online.price_of(it) != 0 or state == "owned": continue
			"sale":
				if int(it.get("discount_percent", 0)) <= 0: continue
			"limited":
				if it.get("stock") == null and Online.s(it.get("ends_at", "")) == "": continue
		if q != "":
			var hay := ("%s %s %s" % [Online.s(it.get("name", "")), Online.s(it.get("description", "")), _kind_name(String(it.kind))]).to_lower()
			if q not in hay:
				continue
		out.append(it)
	match store_sort:
		"cheap": out.sort_custom(func(a, b): return Online.price_of(a) < Online.price_of(b))
		"pricey": out.sort_custom(func(a, b): return Online.price_of(a) > Online.price_of(b))
		"rare": out.sort_custom(func(a, b): return RARITY_NAMES.keys().find(Online.s(a.get("rarity", "common"))) > RARITY_NAMES.keys().find(Online.s(b.get("rarity", "common"))))
	return out


func _frame(rarity: String) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.04, 0.2, 0.9)
	sb.set_corner_radius_all(18)
	sb.set_border_width_all(4 if rarity != "common" else 2)
	sb.border_color = RARITY_COLORS.get(rarity, RARITY_COLORS.common)
	if rarity == "legendary" or rarity == "epic":
		sb.shadow_color = Color(sb.border_color, 0.55)
		sb.shadow_size = 12
	sb.set_content_margin_all(10)
	return sb


const KIND_HINT := {"glb": "۳۶۰° مدل", "police": "۳۶۰° مدل", "skin": "۳۶۰° اسکین", "coin": "۳۶۰° سکه", "voice": "▶ صدا + پرش", "chaser_voice": "▶ صدا", "music": "▶ آهنگ", "anim_clip": "▶ حرکت", "anim": "▶ حرکت", "chaser_anim": "▶ حرکت"}


func _chip(text: String, color: Color, fg: Color = Color.WHITE) -> Control:
	var pc := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 10
	sb.content_margin_right = 10
	sb.content_margin_top = 2
	sb.content_margin_bottom = 2
	pc.add_theme_stylebox_override("panel", sb)
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l: Label = ui._label(text, 19, fg)
	l.set_meta("ct_skip", true)
	l.set_meta(ui.FIT_META, true)          # چیپ هرگز نباید حرف‌به‌حرف بشکند
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	pc.add_child(l)
	return pc


func _price_text(it: Dictionary, state: String) -> String:
	if state == "owned":
		return "✓ مال تو"
	if state == "sold_out" or state == "expired":
		return "ناموجود"
	return "رایگان" if Online.price_of(it) == 0 else "%d سکه" % Online.price_of(it)


func _item_card(it: Dictionary) -> Control:
	var rarity := Online.s(it.get("rarity", "common"))
	var state := Online.item_state(it)
	var rc: Color = RARITY_COLORS.get(rarity, Color.WHITE)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(250, 0)
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.add_theme_stylebox_override("panel", StoreFx.card_style(rarity))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	card.add_child(v)
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, 210)
	holder.clip_contents = true
	v.add_child(holder)
	var glow := TextureRect.new()
	glow.texture = StoreFx.gradient_tex(Color(rc.r, rc.g, rc.b, 0.55), Color(rc.r, rc.g, rc.b, 0.0), true, true)
	glow.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	glow.stretch_mode = TextureRect.STRETCH_SCALE
	glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui._add_full(holder, glow)
	var sh := ColorRect.new()
	sh.color = Color(1, 1, 1, 0.13)
	sh.size = Vector2(36, 420)
	sh.rotation = 0.35
	sh.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sh.set_meta("shine", randf() * 4.0)
	holder.add_child(sh)
	_spinners.append(sh)
	var tr := TextureRect.new()
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if String(it.kind) == "skin" else CanvasItem.TEXTURE_FILTER_LINEAR
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui._add_full(holder, tr)
	tr.set_meta("ph", randf() * 6.0)
	_spinners.append(tr)
	_load_preview(tr, it)
	_glyph(holder, it)
	if state == "locked" or state == "sold_out" or state == "expired":
		var shade := ColorRect.new()
		shade.color = Color(0, 0, 0, 0.28)
		shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
		ui._add_full(holder, shade)
	# نشان‌ها
	var tags := HBoxContainer.new()
	tags.add_theme_constant_override("separation", 6)
	tags.position = Vector2(8, 8)
	tags.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(tags)
	if bool(it.get("featured", false)):
		tags.add_child(_chip("★ ویژه", Color(0.55, 0.36, 0.0, 0.92), COL_GOLD))
	if int(it.get("discount_percent", 0)) > 0:
		tags.add_child(_chip("%d٪ تخفیف" % int(it.discount_percent), Color(0.05, 0.4, 0.15, 0.92), Color("9dffb4")))
	var created := Online.s(it.get("created_at", ""))
	if created != "":
		var age := Time.get_unix_time_from_system() - Time.get_unix_time_from_datetime_string(created.substr(0, 19))
		if age >= 0.0 and age < 3.0 * 86400.0:
			tags.add_child(_chip("جدید", Color(0.5, 0.05, 0.3, 0.92), Color("ffb0e0")))
	var hint := String(KIND_HINT.get(String(it.kind), ""))
	if hint != "":
		var hc := _chip(hint, Color(0.08, 0.03, 0.2, 0.85), Color("d6c4ff"))
		hc.position = Vector2(8, 170)
		holder.add_child(hc)
	var pl = it.get("payload", {})
	if pl is Dictionary and String(pl.get("char_name", "")) != "":
		var ch := _chip("برای: " + String(pl.char_name), Color(0.1, 0.1, 0.3, 0.9), Color("a9c6ff"))
		ch.position = Vector2(8, 140)
		holder.add_child(ch)
	v.add_child(_wrap_label(ui._label(String(it.name), 30, Color.WHITE)))
	var meta = ui._label("%s • %s" % [_kind_name(String(it.kind)), RARITY_NAMES.get(rarity, "")], 22, rc)
	v.add_child(_wrap_label(meta))
	var extra := _extra_text(it)
	if extra != "":
		v.add_child(_wrap_label(ui._label(extra, 20, Color("ffd27a"))))
	if Online.is_admin:
		var eb: Button = ui._button("ویرایش (مدیر)", func(): store_admin.open_form_for(store_filter, it), Vector2(0, 50), 19, "Dark")
		eb.clip_text = true
		v.add_child(eb)
	var kind := "Gold"
	match state:
		"owned": kind = "Teal"
		"sold_out", "expired": kind = "Dark"
	var txt := _price_text(it, state)
	if int(it.get("discount_percent", 0)) > 0 and state == "locked":
		txt += "  (قبلاً %d)" % int(it.get("price", 0))
	var b: Button = ui._button(txt, func(): _open_detail(it), Vector2(0, 72), 27, kind)
	b.clip_text = true
	v.add_child(b)
	return card


## کارت بزرگ بالای فروشگاه برای آیتم ویژه
func _hero_card(it: Dictionary) -> Control:
	var rarity := Online.s(it.get("rarity", "common"))
	var rc: Color = RARITY_COLORS.get(rarity, Color.WHITE)
	var state := Online.item_state(it)
	var card := PanelContainer.new()
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.add_theme_stylebox_override("panel", _frame("legendary"))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	card.add_child(h)
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(250, 250)
	holder.clip_contents = true
	h.add_child(holder)
	var tr := TextureRect.new()
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui._add_full(holder, tr)
	tr.set_meta("ph", 0.0)
	_spinners.append(tr)
	_load_preview(tr, it)
	_glyph(holder, it)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 8)
	h.add_child(v)
	v.add_child(_wrap_label(ui._label("★ پیشنهاد ویژه", 24, COL_GOLD)))
	v.add_child(_wrap_label(ui._label(String(it.name), 38, Color.WHITE)))
	v.add_child(_wrap_label(ui._label("%s • %s" % [_kind_name(String(it.kind)), RARITY_NAMES.get(rarity, "")], 22, rc)))
	var d := Online.s(it.get("description", ""))
	if d != "":
		v.add_child(_wrap_label(ui._label(d, 21, Color(1, 1, 1, 0.75))))
	var ex := _extra_text(it)
	if ex != "":
		v.add_child(_wrap_label(ui._label(ex, 20, Color("ffd27a"))))
	var b: Button = ui._button(_price_text(it, state) + "  —  مشاهده", func(): _open_detail(it), Vector2(0, 70), 26, "Gold")
	b.clip_text = true
	v.add_child(b)
	return card


## برچسبی که با پهنای کارت می‌شکند و پهنای کارت را زیاد نمی‌کند
func _wrap_label(l: Label) -> Label:
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(10, 0)
	return l


func _kind_name(kind: String) -> String:
	if KIND_NAMES.has(kind):
		return KIND_NAMES[kind]
	for sec: Dictionary in Content.store_all():
		if String(sec.kind) == kind:
			return String(sec.text)
	return kind


const ITEM_PREVIEW_KINDS := ["glb", "police", "voice", "chaser_voice", "music", "anim_clip", "anim", "chaser_anim"]
const KIND_GLYPH := {"voice": "صدا", "anim": "انیمیشن", "anim_clip": "انیمیشن", "police": "ظاهر"}


## آیتم‌هایی که تصویر ندارند (صدا، انیمیشن…) یک نماد بزرگ می‌گیرند
func _glyph(holder: Control, it: Dictionary) -> void:
	if Online.s(it.get("preview_path", "")) != "":
		return
	var l: Label = ui._label(String(KIND_GLYPH.get(String(it.kind), "ویژه")), 38, Color.WHITE)
	l.set_meta("ct_skip", true)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	ui._add_full(holder, l)


func _extra_text(it: Dictionary) -> String:
	var parts: Array[String] = []
	if it.get("stock") != null:
		parts.append("نسخه‌ی محدود: %d عدد مانده" % int(it.stock))
	var ends := Online.s(it.get("ends_at", ""))
	if ends != "":
		var et := preload("res://scripts/store_admin.gd").ends_text(ends)
		if et != "تمام شده":
			parts.append("⏳ پایان فروش: %s دیگر" % et)
	return "  •  ".join(parts)


func _load_preview(tr: TextureRect, it: Dictionary) -> void:
	var t: Texture2D = await Online.preview(it)
	if is_instance_valid(tr):
		tr.texture = t


# ------------------------- جزئیات، پیش‌نمایش و خرید -------------------------
func _open_detail(it: Dictionary) -> void:
	if _detail and is_instance_valid(_detail):
		_detail.queue_free()
	_detail = Control.new()
	ui._add_full(store, _detail)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0, 0.06, 0.88)
	ui._add_full(_detail, dim)
	var m := MarginContainer.new()
	ui._add_full(_detail, m)
	for k in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + k, 18)
	m.add_theme_constant_override("margin_top", 44)
	var sc := ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	m.add_child(sc)
	var rarity := Online.s(it.get("rarity", "common"))
	var rc: Color = RARITY_COLORS.get(rarity, Color.WHITE)
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", _frame(rarity))
	sc.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	panel.add_child(v)
	# پیش‌نمایشِ متناسب با نوع آیتم (مدل/سکه/اسکین: ۳۶۰°؛ صدا: کاراکتر می‌پرد؛ انیمیشن: روی کاراکتر؛ آهنگ؛ تصویر؛ متن…)
	var pl = it.get("payload", {})
	var payload: Dictionary = pl if pl is Dictionary else {}
	var ipv: Node = preload("res://scripts/item_preview.gd").new()
	v.add_child(ipv)
	ipv.setup(ui, it)
	# پیش‌نمایش روی کاراکتر دلخواه برای انیمیشن/صدای عمومی
	if String(it.kind) in ["anim_clip", "anim", "chaser_anim", "voice", "chaser_voice"] and String(payload.get("char", "")) == "":
		var ob := OptionButton.new()
		ob.add_theme_font_size_override("font_size", 22)
		ob.custom_minimum_size = Vector2(0, 58)
		ob.add_item("پیش‌نمایش روی: کاراکتر فعلی", 0)
		var keys: Array = [""]
		for e: Dictionary in Skins.entries:
			keys.append(Skins.char_key(e))
			ob.add_item("پیش‌نمایش روی: " + String(e.get("name", "")), keys.size() - 1)
		ob.item_selected.connect(func(i: int):
			var it2 := it.duplicate(true)
			var p2: Dictionary = it2.get("payload", {}) if it2.get("payload") is Dictionary else {}
			p2["char"] = keys[i]
			it2["payload"] = p2
			it2["_keep_payload_char"] = true
			_open_detail(it2))
		v.add_child(ob)
	# سربرگ اطلاعات
	var nm: Label = ui._label(String(it.name), 44, Color.WHITE)
	nm.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nm.custom_minimum_size = Vector2(10, 0)
	v.add_child(nm)
	var chips := HFlowContainer.new()
	chips.add_theme_constant_override("h_separation", 8)
	chips.add_theme_constant_override("v_separation", 6)
	v.add_child(chips)
	chips.add_child(_chip(_kind_name(String(it.kind)), Color(0.12, 0.06, 0.3, 0.95), Color("d6c4ff")))
	chips.add_child(_chip(String(RARITY_NAMES.get(rarity, "")), Color(rc.r * 0.35, rc.g * 0.35, rc.b * 0.35, 0.95), rc))
	if String(KIND_HINT.get(String(it.kind), "")) != "":
		chips.add_child(_chip(String(KIND_HINT[String(it.kind)]), Color(0.05, 0.2, 0.3, 0.95), Color("8fe9ff")))
	if String(payload.get("char_name", "")) != "":
		chips.add_child(_chip("مخصوص: " + String(payload.char_name), Color(0.1, 0.1, 0.35, 0.95), Color("a9c6ff")))
	if String(payload.get("event", "")) != "":
		chips.add_child(_chip("رویداد: " + Rules.event_name(String(payload.event)), Color(0.3, 0.1, 0.1, 0.95), Color("ffb4a0")))
	var desc := Online.s(it.get("description", ""))
	if desc != "":
		var dl = ui._label(desc, 26, COL_TEXT)
		dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		dl.custom_minimum_size = Vector2(10, 0)
		v.add_child(dl)
	var ex := _extra_text(it)
	if ex != "":
		v.add_child(_wrap_label(ui._label(ex, 24, Color("ffd27a"))))
	var msg = ui._label("", 26, Color("ffd27a"))
	msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	msg.custom_minimum_size = Vector2(10, 0)
	var state := Online.item_state(it)
	var main_btn: Button
	if it.has("_local"):
		main_btn = ui._button("فقط پیش‌نمایش (هنوز منتشر نشده)", func(): pass, Vector2(0, 90), 28, "Dark")
		main_btn.disabled = true
	elif state == "owned":
		main_btn = ui._button("نصب و انتخاب", func(): _do_install(it, msg), Vector2(0, 90), 36, "Teal")
	elif state == "locked":
		var txt := "رایگان بگیر" if Online.price_of(it) == 0 else "بخر: %d سکه" % Online.price_of(it)
		if int(it.get("discount_percent", 0)) > 0:
			txt += "   (%d٪ تخفیف از %d)" % [int(it.discount_percent), int(it.get("price", 0))]
		if not Online.logged_in():
			txt = "برای خرید وارد شو"
		main_btn = ui._button(txt, func(): _do_buy(it, msg), Vector2(0, 90), 32, "Gold")
	else:
		main_btn = ui._button("ناموجود", func(): pass, Vector2(0, 90), 36, "Dark")
		main_btn.disabled = true
	v.add_child(main_btn)
	v.add_child(msg)
	# میان‌بُر به استودیو برای آیتم‌های مخصوص یک کاراکتر
	if Online.is_char_item(it) and String(payload.get("char", "")) != "" and not it.has("_local"):
		v.add_child(ui._button("باز کردن در استودیو (روی همان کاراکتر)", func():
			studio.sel_key = String(payload.char)
			studio.tab = {"voice": "voice", "chaser_voice": "voice", "music": "music"}.get(String(it.kind), "anim")
			store_filter = "@chars"
			_detail.queue_free()
			refresh_store(), Vector2(0, 70), 24, "Teal"))
	if Online.is_admin and not it.has("_local"):
		var ar := HFlowContainer.new()
		ar.add_theme_constant_override("h_separation", 8)
		v.add_child(ar)
		ar.add_child(ui._button("ویرایش کامل (مدیر)", func(): _detail.queue_free(); store_admin.open_form_for(String(it.kind), it), Vector2(0, 62), 22, "Dark"))
	v.add_child(ui._button("بستن", func(): _detail.queue_free(), Vector2(0, 76), 32, "Dark"))
	Content.apply_tree.call_deferred(_detail)


func _do_buy(it: Dictionary, msg: Label) -> void:
	if not Online.logged_in():
		_detail.queue_free()
		ui._set_screen(ui.Screen.ACCOUNT)
		return
	msg.text = "…"
	var r := await Online.buy(it)
	if r.get("ok", false):
		toast("خریدی! «%s»" % String(it.name))
		if is_instance_valid(_detail):
			_detail.queue_free()
		refresh_store()
		_open_detail(it)
	elif is_instance_valid(msg):
		msg.text = Online.error_text(Online.s(r.get("error", "")), int(r.get("need", 0)))


func _do_install(it: Dictionary, msg: Label) -> void:
	msg.text = "در حال دانلود…"
	var r := await Online.install(it)
	if r.get("ok", false):
		toast(String(r.message))
		if is_instance_valid(_detail):
			_detail.queue_free()
	elif is_instance_valid(msg):
		msg.text = Online.s(r.get("error", "خطا"))


# ------------------------- کمکی‌ها -------------------------
func _note(t: String) -> Label:
	var l = ui._label(t, 28, Color(1, 1, 1, 0.85))
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(620, 0)
	return l


func _card() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiArt.panel_style(Color(0.2, 0.07, 0.3, 0.8)))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)
	return p
