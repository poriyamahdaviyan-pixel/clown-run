extends Node
## «استودیوی آیتم‌ها» (مالک): هر نوع آیتم را اینجا می‌سازی و به‌صورت پیش‌نویس ذخیره می‌کنی؛
## بعد هنگام افزودن به فروشگاه همان پیش‌نویس‌ها را انتخاب می‌کنی (بدون انتخاب دوباره‌ی فایل).
## انواع: سکه، اسکین، کاراکتر (مدل)، ظاهر تعقیب‌کننده، صدا، آهنگ، انیمیشن (از فایل مدلِ یک کاراکتر).
## پیش‌نویس‌ها فقط روی همین گوشی‌اند: user://item_studio/

const DIR := "user://item_studio"
const FILES := "user://item_studio/files"
const INDEX := "user://item_studio/index.json"
const RARITIES := [["common", "معمولی"], ["rare", "کمیاب"], ["epic", "حماسی"], ["legendary", "افسانه‌ای"]]
const KINDS := [
	["coin", "سکه", "x2"], ["skin", "اسکین", "bolt"], ["glb", "کاراکتر", "ghost"], ["police", "تعقیب‌کننده", "shield"],
	["voice", "صدا", "magnet"], ["music", "آهنگ", "heart"], ["anim_clip", "انیمیشن", "rocket"],
]
const CTYPES := {
	"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "webp": "image/webp", "glb": "model/gltf-binary",
	"gltf": "model/gltf+json", "ogg": "audio/ogg", "mp3": "audio/mpeg", "wav": "audio/wav", "zip": "application/zip",
}
const CHAR_KINDS := ["voice", "anim_clip"]       # آیتم‌هایی که برای یک کاراکتر مشخص‌اند

var ui
var scr                       # online_screens.gd
var _over: Control
var _body: VBoxContainer
var _note: Label
var _filter := ""
var _drafts: Array = []
var _open_id := ""            # پیش‌نویسِ بازشده برای ویرایش


func setup(owner_ui, screens) -> void:
	ui = owner_ui
	scr = screens
	_load()


# ------------------------- ذخیره‌سازی -------------------------
func _load() -> void:
	_drafts = []
	if FileAccess.file_exists(INDEX):
		var d = JSON.parse_string(FileAccess.get_file_as_string(INDEX))
		if d is Array:
			for x in d:
				if x is Dictionary and x.has("id") and x.has("kind"):
					_drafts.append(x)


func _save() -> void:
	DirAccess.make_dir_recursive_absolute(DIR)
	var f := FileAccess.open(INDEX, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(_drafts))
		f.close()


func drafts_of(kind: String) -> Array:
	_load()
	var out: Array = []
	for d: Dictionary in _drafts:
		if String(d.kind) == kind:
			out.append(d)
	return out


func get_draft(id: String) -> Dictionary:
	for d: Dictionary in _drafts:
		if String(d.id) == id:
			return d
	return {}


func _new_id() -> String:
	return "d%d%d" % [Time.get_unix_time_from_system(), randi() % 10000]


## فایل را داخل پوشه‌ی استودیو کپی می‌کند و پیش‌نویس می‌سازد
func add_draft(kind: String, name: String, src_path: String, payload: Dictionary = {}) -> Dictionary:
	DirAccess.make_dir_recursive_absolute(FILES)
	var id := _new_id()
	var file := ""
	if src_path != "":
		var bytes := FileAccess.get_file_as_bytes(src_path)
		if bytes.is_empty():
			return {}
		var ext := src_path.get_extension().to_lower()
		file = "%s/%s.%s" % [FILES, id, ext if ext != "" else "dat"]
		var f := FileAccess.open(file, FileAccess.WRITE)
		if f == null:
			return {}
		f.store_buffer(bytes)
		f.close()
	var d := {"id": id, "kind": kind, "name": name, "desc": "", "price": 100, "rarity": "common", "file": file,
		"payload": payload, "created": int(Time.get_unix_time_from_system())}
	_drafts.push_front(d)
	_save()
	return d


func add_image_draft(kind: String, name: String, img: Image) -> Dictionary:
	DirAccess.make_dir_recursive_absolute(FILES)
	var tmp := "%s/_tmp_%d.png" % [DIR, randi()]
	if img == null or img.is_empty() or img.save_png(tmp) != OK:
		return {}
	var d := add_draft(kind, name, tmp)
	DirAccess.remove_absolute(tmp)
	return d


func remove_draft(id: String) -> void:
	for i in _drafts.size():
		if String(_drafts[i].id) == id:
			var f := String(_drafts[i].get("file", ""))
			if f != "" and FileAccess.file_exists(f):
				DirAccess.remove_absolute(f)
			_drafts.remove_at(i)
			break
	_save()


# ------------------------- صفحه -------------------------
func say(t: String) -> void:
	if _note != null and is_instance_valid(_note):
		_note.text = t


func close() -> void:
	if _over != null and is_instance_valid(_over):
		_over.queue_free()
	_over = null


func open() -> void:
	_load()
	if _over != null and is_instance_valid(_over):
		_over.queue_free()
	_over = Control.new()
	ui._add_full(scr.store, _over)
	var bg := ColorRect.new()
	bg.color = Color("160a2c")
	ui._add_full(_over, bg)
	var m := MarginContainer.new()
	ui._add_full(_over, m)
	for k in ["left", "right", "bottom"]:
		m.add_theme_constant_override("margin_" + k, 22)
	m.add_theme_constant_override("margin_top", 56)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	m.add_child(col)
	var t: Label = ui._label("استودیوی آیتم‌ها", 44, Color("ffb02e"))
	t.set_meta("ct_skip", true)
	col.add_child(t)
	var tip: Label = ui._label("هر آیتم را اینجا بساز و ذخیره کن؛ بعداً موقع افزودن به فروشگاه از همین‌ها انتخاب می‌کنی. پیش‌نویس‌ها فقط روی همین گوشی می‌مانند.", 20, Color("c9d6e6"))
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.custom_minimum_size = Vector2(560, 0)
	col.add_child(tip)
	_note = ui._label("", 22, Color("ffd27a"))
	_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_note.custom_minimum_size = Vector2(560, 0)
	col.add_child(_note)
	var top := HFlowContainer.new()
	top.add_theme_constant_override("h_separation", 8)
	top.add_theme_constant_override("v_separation", 8)
	col.add_child(top)
	top.add_child(ui._button("بستن", func(): close(); scr.refresh_store(), Vector2(150, 60), 24, "Dark"))
	_body = ui.make_scroll_view(col)
	_render()


func _render() -> void:
	if _body == null or not is_instance_valid(_body):
		return
	for c in _body.get_children():
		c.queue_free()
	var B := _body
	B.add_child(ui._label("ساخت آیتم تازه", 32, Color("ffb02e")))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	B.add_child(grid)
	for k in KINDS:
		var kind: String = k[0]
		var cell := PanelContainer.new()
		cell.add_theme_stylebox_override("panel", scr._frame("rare"))
		cell.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 6)
		cell.add_child(v)
		var cc := CenterContainer.new()
		cc.add_child(BoostIcon.make(String(k[2]), Color("ffc21a"), 70))
		v.add_child(cc)
		var nm: Label = ui._label(String(k[1]), 26, Color.WHITE)
		nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(nm)
		v.add_child(ui._button("ساخت", func(): _new_menu(kind), Vector2(0, 56), 22, "Gold"))
		grid.add_child(cell)
	B.add_child(ui._label("پیش‌نویس‌ها", 32, Color("ffb02e")))
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 8)
	fl.add_theme_constant_override("v_separation", 8)
	B.add_child(fl)
	var opts: Array = [["", "همه"]]
	for k in KINDS:
		opts.append([k[0], k[1]])
	for o in opts:
		var key := String(o[0])
		fl.add_child(ui._button(String(o[1]), func(): _filter = key; _render(), Vector2(0, 52), 20, "Gold" if _filter == key else "Dark"))
	var shown := 0
	for d: Dictionary in _drafts:
		if _filter != "" and String(d.kind) != _filter:
			continue
		shown += 1
		B.add_child(_draft_card(d))
	if shown == 0:
		var e: Label = ui._label("هنوز پیش‌نویسی نیست. از بالا یک نوع را انتخاب کن.", 24, Color("c9d6e6"))
		B.add_child(e)
	Content.apply_tree.call_deferred(B)


# ------------------------- ساخت (منبع‌ها) -------------------------
func _new_menu(kind: String) -> void:
	say("")
	match kind:
		"coin":
			var im: Image = CoinSkin.cutout_image() if CoinSkin.has_method("cutout_image") else null
			var opts := _sheet("سکه از کجا؟")
			if im != null:
				opts.add_child(ui._button("پیش‌نویس فعلیِ طراح سکه", func(): _from_image("coin", "سکه‌ی طراح", im), Vector2(0, 66), 24, "Gold"))
			if CoinSkin.face_tex != null:
				opts.add_child(ui._button("سکه‌ی فعلی بازی", func(): _from_image("coin", "سکه‌ی فعلی", CoinSkin.face_tex.get_image()), Vector2(0, 66), 24, "Teal"))
			opts.add_child(ui._button("از فایل عکس", func(): _from_file("coin"), Vector2(0, 66), 24, "Dark"))
		"skin":
			var opts2 := _sheet("اسکین از کجا؟")
			var e: Dictionary = Skins.current_entry()
			if not Skins.is_glb(e):
				opts2.add_child(ui._button("اسکین فعلی من (%s)" % String(e.name), func():
					var res: Dictionary = Skins.result_for(e)
					_from_image("skin", String(e.name), res["image"]), Vector2(0, 66), 24, "Gold"))
			opts2.add_child(ui._button("از فایل عکس", func(): _from_file("skin"), Vector2(0, 66), 24, "Dark"))
		"glb", "police":
			var opts3 := _sheet("مدل از کجا؟")
			opts3.add_child(ui._button("از فایل (glb، gltf، vrm، fbx، obj یا zip)", func(): _from_file(kind), Vector2(0, 66), 24, "Gold"))
		"voice":
			_voice_source()
		"music":
			_from_file("music")
		"anim_clip":
			_anim_source()


func _sheet(title: String) -> VBoxContainer:
	_body_clear()
	var B := _body
	B.add_child(ui._label(title, 32, Color("ffb02e")))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	B.add_child(v)
	B.add_child(ui._button("بازگشت", func(): _render(), Vector2(0, 60), 22, "Dark"))
	return v


func _body_clear() -> void:
	for c in _body.get_children():
		c.queue_free()


func _from_image(kind: String, name: String, img: Image) -> void:
	var d := add_image_draft(kind, name, img)
	_after_add(d)


func _from_file(kind: String) -> void:
	var target := "item_file"
	ui.pick_file(target, func(p: String):
		var nm := String(p).get_file().get_basename()
		var d := add_draft(kind, nm, String(p))
		_after_add(d))


func _after_add(d: Dictionary) -> void:
	if d.is_empty():
		say("ساخته نشد؛ فایل خوانده نشد.")
		_render()
		return
	_open_id = String(d.id)
	say("پیش‌نویس ذخیره شد ✓")
	_render()


func _voice_source() -> void:
	var v := _sheet("صدا از کجا؟")
	v.add_child(ui._button("از فایل (ogg، mp3، wav)", func():
		ui.pick_file("item_file", func(p: String):
			var d := add_draft("voice", String(p).get_file().get_basename(), String(p), {"event": "jump"})
			_after_add(d)), Vector2(0, 66), 24, "Gold"))


func _anim_source() -> void:
	var v := _sheet("انیمیشن از فایل کدام کاراکتر؟")
	var any := false
	for e: Dictionary in Skins.entries:
		if not Skins.is_glb(e):
			continue
		any = true
		var key := Skins.char_key(e)
		var nm := String(e.name)
		v.add_child(ui._button(nm, func(): _anim_clips(e, key, nm), Vector2(0, 62), 22, "Teal"))
	if not any:
		v.add_child(ui._label("هنوز کاراکتر سه‌بعدی (GLB) نداری. اول یکی را در «کاراکتر» اضافه کن.", 22, Color("ff9a9a")))


func _anim_clips(e: Dictionary, key: String, nm: String) -> void:
	var v := _sheet("انیمیشن‌های «%s»" % nm)
	var clips: Array = AnimPack.clips_of_model(String(e.glb))
	if clips.is_empty():
		v.add_child(ui._label("این فایل انیمیشن ندارد.", 22, Color("ff9a9a")))
	for c in clips:
		var clip := String(c)
		v.add_child(ui._button(clip, func():
			var d := add_draft("anim_clip", clip, "", {"char": key, "char_name": nm, "clip": clip, "event": Content.cat_of(key, clip) if Content.cat_of(key, clip) != "" else "jump"})
			_after_add(d), Vector2(0, 60), 22, "Dark"))


# ------------------------- کارت پیش‌نویس -------------------------
func _kind_name(kind: String) -> String:
	for k in KINDS:
		if k[0] == kind:
			return String(k[1])
	return kind


func _event_option(cur: String, cb: Callable) -> OptionButton:
	var o := OptionButton.new()
	o.add_theme_font_size_override("font_size", 22)
	o.custom_minimum_size = Vector2(0, 58)
	var ids: Array = []
	for ev in Rules.SLOT_EVENTS:
		ids.append(String(ev))
		o.add_item("کاربرد: " + Rules.event_name(String(ev)), ids.size() - 1)
	ids.append("")
	o.add_item("کاربرد: سایر", ids.size() - 1)
	o.select(maxi(ids.find(cur), 0))
	o.item_selected.connect(func(k: int): cb.call(String(ids[k])))
	return o


func _char_option(cur: String, glb_only: bool, cb: Callable) -> OptionButton:
	var o := OptionButton.new()
	o.add_theme_font_size_override("font_size", 22)
	o.custom_minimum_size = Vector2(0, 58)
	var keys: Array = []
	for e: Dictionary in Skins.entries:
		if glb_only and not Skins.is_glb(e):
			continue
		keys.append([Skins.char_key(e), String(e.name)])
	var sel := 0
	for i in keys.size():
		o.add_item("برای کاراکتر: " + String(keys[i][1]), i)
		if String(keys[i][0]) == cur:
			sel = i
	if keys.is_empty():
		o.add_item("کاراکتری نیست", 0)
	o.select(sel)
	o.item_selected.connect(func(k: int):
		if k < keys.size():
			cb.call(String(keys[k][0]), String(keys[k][1])))
	return o


func _draft_card(d: Dictionary) -> Control:
	var id := String(d.id)
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel", scr._frame(String(d.get("rarity", "common"))))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	card.add_child(v)
	var head: Label = ui._label("%s  —  %s" % [String(d.name), _kind_name(String(d.kind))], 28, Color.WHITE)
	head.set_meta("ct_skip", true)
	v.add_child(head)
	var kind := String(d.kind)
	var file := String(d.get("file", ""))
	if file != "" and FileAccess.file_exists(file):
		v.add_child(LocalPreview.make(ui, file))
	elif kind == "anim_clip":
		var pl: Dictionary = d.get("payload", {})
		var l: Label = ui._label("انیمیشن «%s» از فایل «%s»" % [String(pl.get("clip", "")), String(pl.get("char_name", ""))], 22, Color("c9d6e6"))
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(540, 0)
		v.add_child(l)
	var ne := LineEdit.new()
	ne.text = String(d.name)
	ne.placeholder_text = "نام آیتم"
	ne.custom_minimum_size = Vector2(0, 62)
	ne.add_theme_font_size_override("font_size", 26)
	ne.text_changed.connect(func(t: String): d["name"] = t; _save())
	v.add_child(ne)
	var de := LineEdit.new()
	de.text = String(d.get("desc", ""))
	de.placeholder_text = "توضیح کوتاه (اختیاری)"
	de.custom_minimum_size = Vector2(0, 58)
	de.add_theme_font_size_override("font_size", 24)
	de.text_changed.connect(func(t: String): d["desc"] = t; _save())
	v.add_child(de)
	var pe := LineEdit.new()
	pe.text = str(int(d.get("price", 100)))
	pe.placeholder_text = "قیمت پیش‌فرض (سکه)"
	pe.custom_minimum_size = Vector2(0, 58)
	pe.add_theme_font_size_override("font_size", 24)
	pe.text_changed.connect(func(t: String): d["price"] = maxi(0, int(t)); _save())
	v.add_child(pe)
	var rf := HFlowContainer.new()
	rf.add_theme_constant_override("h_separation", 6)
	rf.add_theme_constant_override("v_separation", 6)
	v.add_child(rf)
	for r in RARITIES:
		var rk: String = r[0]
		rf.add_child(ui._button(String(r[1]), func(): d["rarity"] = rk; _save(); _render(), Vector2(0, 50), 20, "Gold" if String(d.get("rarity", "common")) == rk else "Dark"))
	if kind in CHAR_KINDS:
		var pl2: Dictionary = d.get("payload", {})
		v.add_child(_event_option(String(pl2.get("event", "")), func(ev: String): pl2["event"] = ev; d["payload"] = pl2; _save()))
		if kind == "voice":
			v.add_child(_char_option(String(pl2.get("char", "")), false, func(k: String, n: String): pl2["char"] = k; pl2["char_name"] = n; d["payload"] = pl2; _save()))
			if String(pl2.get("char", "")) == "":
				var e0: Dictionary = Skins.current_entry()
				pl2["char"] = Skins.char_key(e0)
				pl2["char_name"] = String(e0.name)
				d["payload"] = pl2
				_save()
	var act := HFlowContainer.new()
	act.add_theme_constant_override("h_separation", 6)
	act.add_theme_constant_override("v_separation", 6)
	v.add_child(act)
	act.add_child(ui._button("افزودن به فروشگاه", func(): _send(d), Vector2(0, 60), 22, "Gold"))
	act.add_child(ui._button("حذف", func(): remove_draft(id); _render(), Vector2(0, 60), 22, "Red"))
	return card


# ------------------------- ارسال به فروشگاه -------------------------
func _send(d: Dictionary) -> void:
	if not Online.is_admin:
		say("برای افزودن به فروشگاه باید با حساب مدیر وارد شوی (بخش حساب من).")
		return
	var kind := String(d.kind)
	if kind in CHAR_KINDS:
		await _publish_char_item(d)
	else:
		close()
		scr.store_admin.open_form_with_draft(d)


## صدا و انیمیشن مخصوص یک کاراکتر مستقیم منتشر می‌شوند (در «کاراکتر من» دیده می‌شوند)
func _publish_char_item(d: Dictionary) -> void:
	var kind := String(d.kind)
	var pl: Dictionary = (d.get("payload", {}) as Dictionary).duplicate()
	if String(pl.get("char", "")) == "":
		say("اول کاراکتر مقصد را انتخاب کن.")
		return
	say("در حال ارسال…")
	var id := "%08x-%04x-4%03x-a%03x-%012x" % [randi(), randi() & 0xffff, randi() & 0xfff, randi() & 0xfff, (randi() << 8) ^ randi()]
	var item := {"id": id, "kind": kind, "name": String(d.name), "description": String(d.get("desc", "")), "price": int(d.get("price", 0)),
		"rarity": String(d.get("rarity", "common")), "status": "approved", "payload": pl}
	var file := String(d.get("file", ""))
	if kind == "voice":
		var bytes := FileAccess.get_file_as_bytes(file)
		if bytes.is_empty():
			say("فایل صدا خوانده نشد.")
			return
		var ext := file.get_extension().to_lower()
		var ct := String(CTYPES.get(ext, "audio/ogg"))
		var path := "voice/%s.%s" % [id, ext]
		var pvp := "pv/%s.%s" % [id, ext]
		var up: Dictionary = await Online.admin_upload(path, bytes, ct)
		if up.ok:
			up = await Online.admin_upload(pvp, bytes, ct, "previews")
		if not up.ok:
			say("خطا: " + String(up.error))
			return
		item["file_path"] = path
		pl["pv"] = pvp
		item["payload"] = pl
	var r: Dictionary = await Online.admin_save_item(item)
	if not r.ok:
		say("خطا: " + String(r.error))
		return
	await Online.load_items()
	say("به فروشگاه اضافه شد ✓ (در «کاراکتر من» برای همان کاراکتر دیده می‌شود)")


# ------------------------- انتخاب‌گر داخل فرم فروشگاه -------------------------
## لیست فشرده‌ی پیش‌نویس‌های یک نوع؛ با انتخاب، cb(draft) صدا زده می‌شود
func picker(kind: String, cb: Callable) -> Control:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	var list := drafts_of(kind)
	var head: Label = ui._label("انتخاب از استودیو (%d پیش‌نویس)" % list.size(), 26, Color("ffb02e"))
	box.add_child(head)
	if list.is_empty():
		var e: Label = ui._label("پیش‌نویسی از این نوع نداری؛ از «استودیوی آیتم‌ها» بساز.", 20, Color("c9d6e6"))
		e.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		e.custom_minimum_size = Vector2(540, 0)
		box.add_child(e)
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 8)
	fl.add_theme_constant_override("v_separation", 8)
	box.add_child(fl)
	for d: Dictionary in list:
		fl.add_child(ui._button(String(d.name), func(): cb.call(d), Vector2(0, 58), 22, "Purple"))
	return box
