extends Node
## «استودیو» فروشگاه: یک کاراکتر را انتخاب کن؛ او روی صحنه‌ی زنده (۳۶۰°) می‌ایستد
## و هر انیمیشن، صدا یا آهنگ را همان‌جا روی خودش می‌بینی/می‌شنوی، می‌خری و به رویداد دلخواه می‌سپاری.
## انیمیشن‌ها از روی «خودِ فایل مدل» خوانده می‌شوند. مالک همه‌چیز را همین‌جا کنترل می‌کند.
const GlbModel := preload("res://scripts/glb_model.gd")
const CharacterModel := preload("res://scripts/character_model.gd")
const ItemPreview := preload("res://scripts/item_preview.gd")
const SoundPanel := preload("res://scripts/sound_panel.gd")
const KEY := "studio"
const MAX_PLAY := 25.0
const TABS := [["anim", "انیمیشن", "anim_clip", "store_anim"], ["voice", "صدا", "voice", "store_voice"],
	["music", "آهنگ", "music", "store_music"], ["slots", "نصب‌شده", "", ""]]

var ui
var scr
var shop                       # char_shop.gd (مدیریت مالک)
var sel_key := ""
var tab := "anim"
var owner_mode := false
var show_perms := false
var _list: VBoxContainer
var _msg: Label
var _stage_name: Label
var _audio: AudioStreamPlayer
var _col: VBoxContainer
var _clip_cache := {}
var _strip: HBoxContainer
var _tabs_box: HFlowContainer


func setup(owner_ui, screens, char_shop) -> void:
	ui = owner_ui
	scr = screens
	shop = char_shop
	shop.clips_override = _clips_of
	Online.items_changed.connect(func(): if _list != null and is_instance_valid(_list): _fill())


func _is_chaser() -> bool:
	return sel_key == Rules.CHASER


func _entry_of(key: String) -> Dictionary:
	if key == Rules.CHASER and Content.chaser_studio_on():
		return {"id": Rules.CHASER, "name": "تعقیب‌کننده", "chaser": true}
	for e: Dictionary in Skins.entries:
		if Skins.char_key(e) == key:
			return e
	return {}


func _gold() -> Color:
	return Color("ffb02e")


func _lab(t: String, size: int = 22, color: Color = Color("c9d6e6")) -> Label:
	var l: Label = ui._label(t, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(10, 0)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func _say(t: String) -> void:
	if _msg != null and is_instance_valid(_msg):
		_msg.text = t


# ------------------------- ساخت صفحه -------------------------
## صحنه‌ی سه‌بعدی گران است و با هر تازه‌سازی فروشگاه نباید از نو ساخته شود؛ پس صفحه نگه داشته و دوباره پیوست می‌شود
func detach() -> void:
	if _col != null and is_instance_valid(_col) and _col.get_parent() != null:
		_col.get_parent().remove_child(_col)


func fill_grid(grid: GridContainer) -> void:
	grid.columns = 1
	if _col != null and is_instance_valid(_col):
		detach()
		grid.add_child(_col)
		var ee := _entry_of(sel_key)
		if ee.is_empty():
			sel_key = Skins.char_key(Skins.current_entry())
			ee = _entry_of(sel_key)
		ui._sync_preview_model(KEY, Skins.current_entry() if _is_chaser() else ee)
		_stage_name.text = String(ee.get("name", ""))
		_fill_strip()
		_build_tabs()
		_fill()
		return
	if _entry_of(sel_key).is_empty():
		sel_key = Skins.char_key(Skins.current_entry())
	var e := _entry_of(sel_key)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	grid.add_child(_col)
	if e.is_empty():
		_col.add_child(_lab("کاراکتری پیدا نشد."))
		return
	_col.add_child(ui._label("استودیوی شخصی‌سازی", 40, _gold()))
	# صحنه‌ی زنده
	var stage_panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.02, 0.15, 0.95)
	sb.set_corner_radius_all(26)
	sb.set_border_width_all(3)
	sb.border_color = Color("7a3cff")
	sb.shadow_color = Color(0.48, 0.24, 1.0, 0.45)
	sb.shadow_size = 14
	sb.set_content_margin_all(4)
	stage_panel.add_theme_stylebox_override("panel", sb)
	_col.add_child(stage_panel)
	var pv: Control = ui._make_preview(KEY, 460, CharacterModel.new(), false)
	stage_panel.add_child(pv)
	ui._sync_preview_model(KEY, e)
	ui.preview_toolbar(KEY)
	_stage_name = ui._label(String(e.name), 30, Color.WHITE)
	_stage_name.set_meta("ct_skip", true)
	_stage_name.set_meta(ui.FIT_META, true)
	_stage_name.autowrap_mode = TextServer.AUTOWRAP_OFF
	_stage_name.position = Vector2(16, 10)
	pv.add_child(_stage_name)
	# انتخاب کاراکتر
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 150)
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_col.add_child(sc)
	_strip = HBoxContainer.new()
	_strip.add_theme_constant_override("separation", 8)
	sc.add_child(_strip)
	_fill_strip()
	_col.add_child(ui._button("بازی با این کاراکتر", func():
		if _is_chaser():
			return
		Skins.select(String(_entry_of(sel_key).get("id", "")))
		_say("«%s» کاراکتر بازی شد" % String(_entry_of(sel_key).get("name", ""))), Vector2(0, 62), 24, "Teal"))
	# تب‌ها (جدا ساخته می‌شوند تا با هر تغییر، صحنه‌ی ۳بعدی از نو ساخته نشود)
	_tabs_box = HFlowContainer.new()
	_tabs_box.add_theme_constant_override("h_separation", 8)
	_tabs_box.add_theme_constant_override("v_separation", 8)
	_col.add_child(_tabs_box)
	_build_tabs()
	_msg = ui._label("", 24, Color("ffd27a"))
	_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_msg.custom_minimum_size = Vector2(10, 0)
	_col.add_child(_msg)
	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 10)
	_col.add_child(_list)
	_fill()


func _build_tabs() -> void:
	if _tabs_box == null or not is_instance_valid(_tabs_box):
		return
	for c in _tabs_box.get_children():
		c.queue_free()
	var shown := _visible_tabs()
	if not tab in shown:
		tab = shown[0] if not shown.is_empty() else "slots"
	for t in TABS:
		var tid: String = t[0]
		if not tid in shown:
			continue
		var on := tid == tab
		_tabs_box.add_child(ui._button(String(t[1]), func(): tab = tid; show_perms = false; _refresh_local(), Vector2(150, 64), 24, "Gold" if on else "Dark"))
	if Edition.is_owner():
		_tabs_box.add_child(ui._button("مالک: " + ("روشن" if owner_mode else "خاموش"), func(): _toggle_owner(), Vector2(190, 64), 22, "Gold" if owner_mode else "Teal"))
		_tabs_box.add_child(ui._button("دسترسی بازیکن", func(): show_perms = not show_perms; _refresh_local(), Vector2(210, 64), 22, "Gold" if show_perms else "Teal"))
	Content.apply_tree.call_deferred(_tabs_box)


func _refresh_local() -> void:
	_build_tabs()
	_fill()


func _visible_tabs() -> Array:
	var out: Array = []
	for t in TABS:
		if _is_chaser() and String(t[0]) == "music":
			continue
		if String(t[3]) == "" or Content.can(String(t[3])) or Edition.is_owner():
			out.append(String(t[0]))
	return out


func _fill_strip() -> void:
	for c in _strip.get_children():
		c.queue_free()
	var all_entries: Array = Skins.entries.duplicate()
	if Content.chaser_studio_on():
		all_entries.append({"id": Rules.CHASER, "name": "تعقیب‌کننده", "chaser": true})
	for ce: Dictionary in all_entries:
		var k := Rules.CHASER if bool(ce.get("chaser", false)) else Skins.char_key(ce)
		var on := k == sel_key
		var tile := PanelContainer.new()
		tile.add_theme_stylebox_override("panel", scr._frame("legendary" if on else "common"))
		tile.custom_minimum_size = Vector2(130, 0)
		var tv := VBoxContainer.new()
		tv.add_theme_constant_override("separation", 2)
		tile.add_child(tv)
		var tr := TextureRect.new()
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.custom_minimum_size = Vector2(0, 76)
		tr.texture = null if bool(ce.get("chaser", false)) else Skins.thumbnail(ce)
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tv.add_child(tr)
		if bool(ce.get("chaser", false)):
			var cc := CenterContainer.new()
			cc.add_child(BoostIcon.make("shield", Color("4aa3ff"), 70))
			tr.add_child(cc)
			ui._add_full(tr, cc)
		var nm: Label = ui._label(String(ce.name), 20, Color.WHITE)
		nm.set_meta("ct_skip", true)
		nm.clip_text = true
		nm.custom_minimum_size = Vector2(10, 0)
		nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		tv.add_child(nm)
		var pick: Button = ui._button("✓" if on else "انتخاب", func(): _select(k), Vector2(0, 44), 18, "Gold" if on else "Dark")
		tv.add_child(pick)
		_strip.add_child(tile)


func _select(key: String) -> void:
	sel_key = key
	var e := _entry_of(key)
	ui._sync_preview_model(KEY, Skins.current_entry() if key == Rules.CHASER else e)
	if _stage_name != null:
		_stage_name.text = String(e.get("name", ""))
	_clip_cache.clear()
	_fill_strip()
	if owner_mode:
		_toggle_owner(true)
	else:
		_fill()


func _toggle_owner(keep: bool = false) -> void:
	if not keep:
		owner_mode = not owner_mode
	if owner_mode and not Online.is_admin:
		owner_mode = false
		_say("برای مدیریتِ قیمت/فایل‌ها باید با حساب مدیر وارد شوی (حساب من).")
		_refresh_local()
		return
	if owner_mode and not _is_chaser():
		_say("در حال دریافت…")
		shop._mgr_items = await Online.admin_load_char_items(sel_key)
		_say("")
	if keep:
		_fill()
	else:
		_refresh_local()


# ------------------------- محتوای تب -------------------------
func _fill() -> void:
	if _list == null or not is_instance_valid(_list):
		return
	for c in _list.get_children():
		c.queue_free()
	var e := _entry_of(sel_key)
	if e.is_empty():
		return
	if show_perms and Edition.is_owner():
		SoundPanel.build_perms(ui, _list, _say)
		Content.apply_tree.call_deferred(_list)
		return
	if _is_chaser():
		_fill_chaser()
		Content.apply_tree.call_deferred(_list)
		return
	if not Skins.is_glb(e) and String(e.get("id", "")) != Skins.current_id:
		_list.add_child(_lab("این کاراکتر بلوکی است؛ ظاهرش را وقتی نشان می‌دهم که کاراکتر فعلی باشد («بازی با این کاراکتر» را بزن).", 19, Color(1, 1, 1, 0.6)))
	if owner_mode and tab != "slots" and not _is_chaser():
		shop._body = _list
		shop._entry = e
		shop._tab = tab
		shop._mgr = true
		shop._busy_note = _msg
		shop._render_manager(sel_key)
		Content.apply_tree.call_deferred(_list)
		return
	match tab:
		"anim": _fill_anim(e)
		"voice": _fill_voice(e)
		"music": _fill_music(e)
		_: _fill_slots(e)
	Content.apply_tree.call_deferred(_list)


func _row(title: String, badge: String, badge_color: Color, edge: Color = Color("5a2a9a")) -> VBoxContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.12, 0.05, 0.24, 0.92)
	sb.set_corner_radius_all(16)
	sb.set_border_width_all(2)
	sb.border_color = edge
	sb.set_content_margin_all(10)
	p.add_theme_stylebox_override("panel", sb)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	var h := HBoxContainer.new()
	v.add_child(h)
	var nm: Label = _lab(title, 26, Color.WHITE)
	nm.set_meta("ct_skip", true)
	h.add_child(nm)
	if badge != "":
		var bl: Label = ui._label(badge, 21, badge_color)
		bl.set_meta("ct_skip", true)
		bl.set_meta(ui.FIT_META, true)
		bl.autowrap_mode = TextServer.AUTOWRAP_OFF
		h.add_child(bl)
	_list.add_child(p)
	return v


func _btn_row(parent: Control) -> HFlowContainer:
	var h := HFlowContainer.new()
	h.add_theme_constant_override("h_separation", 8)
	h.add_theme_constant_override("v_separation", 8)
	parent.add_child(h)
	return h


func _act(h: Control, text: String, cb: Callable, kind: String = "Teal", w: int = 150) -> Button:
	var b: Button = ui._button(text, cb, Vector2(w, 58), 22, kind)
	h.add_child(b)
	return b


func _events_allowed() -> Array:
	if _is_chaser():
		return Rules.CHASER_SLOT_EVENTS.duplicate()
	return Rules.SLOT_EVENTS.filter(func(x): return Content.perm_event_ok(String(x)))


## منوی «اختصاص به رویداد» برای یک منبع (clip:…، شناسه‌ی کتابخانه) و عمل (anim | sound)
func _slot_option(parent: Control, src: String, action: String) -> void:
	if not (Content.can("chooser") or Edition.is_owner()):
		return
	var eid := String(_entry_of(sel_key).get("id", ""))
	var evs := _events_allowed()
	var o := OptionButton.new()
	o.add_theme_font_size_override("font_size", 22)
	o.custom_minimum_size = Vector2(0, 58)
	o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	o.add_item("اختصاص به رویداد…", 0)
	for ev in evs:
		o.add_item("هنگام: " + Rules.event_name(String(ev)), o.item_count)
	var cur := Rules.slot_event_of(eid, src, action)
	var idx := evs.find(cur) + 1 if cur != "" else 0
	if cur != "" and idx == 0:
		o.add_item("فعلی: " + Rules.event_name(cur), o.item_count)
		idx = o.item_count - 1
	o.select(idx)
	o.item_selected.connect(func(k: int):
		var old := Rules.slot_event_of(eid, src, action)
		if old != "":
			Rules.set_slot(eid, old, action, "")
		if k > 0 and k <= evs.size():
			var ev := String(evs[k - 1])
			if Rules.set_slot(eid, ev, action, src):
				_say("برای «%s» روی «%s» نصب شد ✓" % [String(_entry_of(sel_key).get("name", "")), Rules.event_name(ev)])
				_preview_event(ev, action, src)
			else:
				_say("نصب نشد؛ اول آیتم را نصب کن.")
		else:
			_say("برداشته شد.")
		_fill())
	parent.add_child(o)


func _preview_event(ev: String, action: String, src: String) -> void:
	if action == "anim":
		var s := src
		if not s.begins_with("clip:"):
			for le in Rules.library:
				if String(le.get("id", "")) == src and String(le.get("clip", "")) != "":
					s = "clip:" + String(le.clip)
		if s.begins_with("clip:"):
			_stage_act(s)
	else:
		for le in Rules.library:
			if String(le.get("id", "")) == src:
				Sfx.play_any(String(le.get("arg", "")))
		_stage_act(_action_for(ev))


func _action_for(ev: String) -> String:
	match ev:
		"slide": return "slide"
		"hit", "crash", "gameover": return "hit"
		"coin", "score": return "bounce"
		_: return "jump"


func _stage_act(act: String, dur: float = 2.6) -> void:
	if not ui._pv.has(KEY):
		return
	var d: Dictionary = ui._pv[KEY]
	if not is_instance_valid(d["pivot"]) or not is_instance_valid(d["content"]):
		return
	ItemPreview.play_action(self, d["content"], d["pivot"], act, dur)


# ------------------------- انیمیشن‌ها (از روی خودِ مدل) -------------------------
func _clips_of(e: Dictionary) -> Array:
	var ck := "%s|%d" % [str(e.get("glb", "")), FileAccess.get_modified_time(str(e.get("glb", "")))]
	if not _clip_cache.has(ck):
		var list: Array = []
		var d: Dictionary = ui._pv.get(KEY, {})
		var c = d.get("content")
		if Skins.char_key(e) == sel_key and c != null and is_instance_valid(c) and c.get("is_glb") == true:
			for n in c.clip_list():       # از خودِ مدلِ روی صحنه، بدون ساختن مدل دوم
				list.append(String(n))
		else:
			list = shop.load_clips(e)
		_clip_cache[ck] = list
	return _clip_cache[ck]


var cat_filter := "all"


## ردیف دسته‌ها (همه / پرش / سر خوردن / …) بالای فهرست
func _cat_bar() -> void:
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 8)
	fl.add_theme_constant_override("v_separation", 8)
	_list.add_child(fl)
	var opts: Array = [["all", "همه"]]
	for ev in _events_allowed():
		opts.append([String(ev), Rules.event_name(String(ev))])
	opts.append(["", "سایر"])
	for o in opts:
		var key := String(o[0])
		var b: Button = ui._button(String(o[1]), func():
			cat_filter = key
			_fill(), Vector2(0, 56), 22, "Gold" if cat_filter == key else "Dark")
		fl.add_child(b)


func _cat_ok(c: String) -> bool:
	return cat_filter == "all" or c == cat_filter


## مالک: انتخاب دسته‌ی یک مورد
func _cat_pick(parent: Control, name: String, cur: String) -> void:
	if not Edition.is_owner():
		return
	var o := OptionButton.new()
	o.custom_minimum_size = Vector2(0, 52)
	o.add_item("دسته: " + (Rules.event_name(cur) if cur != "" else "سایر"), 0)
	var evs: Array = Rules.SLOT_EVENTS
	for i in evs.size():
		o.add_item(Rules.event_name(String(evs[i])), i + 1)
	o.add_item("سایر", 99)
	o.item_selected.connect(func(idx: int):
		var id := o.get_item_id(idx)
		if id == 0:
			return
		Content.set_cat(sel_key, name, "" if id == 99 else String(evs[id - 1]))
		_fill())
	parent.add_child(o)


func _fill_anim(e: Dictionary) -> void:
	_cat_bar()
	var defs := Content.char_defaults(sel_key)
	var clips := _clips_of(e)
	var sale := Online.items_of_char(sel_key, "anim_clip")
	var by_clip := {}
	for it: Dictionary in sale:
		var p = it.get("payload", {})
		if p is Dictionary and String(p.get("clip", "")) != "":
			by_clip[String(p.clip)] = it
	var count := 0
	if not Skins.is_glb(e):
		_list.add_child(_lab("این کاراکتر مدل سه‌بعدی (GLB) نیست؛ انیمیشن‌های خودِ فایل ندارد. فقط انیمیشن‌های فروشیِ آماده برایش هست.", 20))
	for clip in clips:
		var c := String(clip)
		var cc := Content.cat_of(sel_key, c)
		if not _cat_ok(cc):
			continue
		if c in defs:
			count += 1
			var v := _row(c, "رایگان", Color("7dff9a"))
			var h := _btn_row(v)
			_act(h, "نمایش", func(): _stage_act("clip:" + c), "Teal", 120)
			_cat_pick(v, c, cc)
			_slot_option(v, "clip:" + c, "anim")
		elif by_clip.has(c):
			count += 1
			_store_item_row(by_clip[c], "anim", "clip:" + c)
	for it: Dictionary in sale:
		var p2 = it.get("payload", {})
		if p2 is Dictionary and String(p2.get("clip", "")) in clips:
			continue
		var pe := String(p2.get("event", "")) if p2 is Dictionary else ""
		if not _cat_ok(pe if pe != "" else Content.cat_of(sel_key, String(it.name))):
			continue
		count += 1
		_store_item_row(it, "anim", "")
	if count == 0:
		_list.add_child(_lab("هنوز انیمیشنی برای این کاراکتر عرضه نشده."))
	if not Edition.is_owner() and not Content.can("chooser"):
		_list.add_child(_lab("برای سپردن انیمیشن به رویدادها باید بخش انتخاب برای تو باز باشد.", 19, Color(1, 1, 1, 0.55)))


## یک آیتم فروشی: وضعیت، نمایش روی کاراکتر، خرید، نصب، رویداد
func _store_item_row(it: Dictionary, action: String, own_clip_src: String) -> void:
	var state := Online.item_state(it)
	var price := Online.price_of(it)
	var rar := Online.s(it.get("rarity", "common"))
	var badge := "✓ مال تو" if state == "owned" else ("رایگان" if price == 0 else "%d سکه" % price)
	if state == "sold_out" or state == "expired":
		badge = "ناموجود"
	if int(it.get("discount_percent", 0)) > 0 and state == "locked":
		badge += "  (%d٪ تخفیف)" % int(it.discount_percent)
	var pl = it.get("payload", {})
	var ev := String(pl.get("event", "")) if pl is Dictionary else ""
	var title := String(it.name) + ("  • %s" % Rules.event_name(ev) if ev != "" else "")
	var v := _row(title, badge, Color("7dff9a") if state == "owned" else Color("ffd24a"), scr.RARITY_COLORS.get(rar, Color("5a2a9a")))
	var d := Online.s(it.get("description", ""))
	if d != "":
		v.add_child(_lab(d, 19, Color(1, 1, 1, 0.65)))
	var h := _btn_row(v)
	var kind := String(it.kind)
	_act(h, "نمایش روی کاراکتر", func(): _preview_item(it, kind, own_clip_src), "Teal", 220)
	var lib_id := String(it.id)
	var installed := false
	for le in Rules.library:
		if String(le.get("id", "")) == lib_id:
			installed = true
	if state == "locked":
		_act(h, "رایگان بگیر" if price == 0 else "بخر: %d" % price, func(): _buy(it), "Gold", 170)
	elif state == "owned" and not installed and kind != "music":
		_act(h, "نصب", func(): _install(it), "Gold", 120)
	elif state == "owned" and kind == "music":
		_act(h, "نصب / انتخاب", func(): _install(it), "Gold", 190)
	_act(h, "جزئیات", func(): scr._open_detail(it), "Dark", 130)
	if Edition.is_owner() and Online.is_admin:
		_act(h, "ویرایش", func(): scr.store_admin.open_form_for(kind, it), "Dark", 120)
	if state == "owned" and installed and action != "":
		_slot_option(v, lib_id, action)
		if action == "sound" and Content.perm_b("snd_store_tune"):
			SoundPanel.sound_row(ui, v, "بلندی", String(_lib_arg(lib_id)))


func _lib_arg(id: String) -> String:
	for le in Rules.library:
		if String(le.get("id", "")) == id:
			return String(le.get("arg", ""))
	return ""


func _buy(it: Dictionary) -> void:
	if not Online.logged_in():
		ui._set_screen(ui.Screen.ACCOUNT)
		return
	_say("…")
	var r: Dictionary = await Online.buy(it)
	if r.get("ok", false):
		scr.toast("خریدی! «%s»" % String(it.name))
		_say("خریدی ✓ حالا نصبش کن")
		await _install(it)
	else:
		_say(Online.error_text(Online.s(r.get("error", "")), int(r.get("need", 0))))


func _install(it: Dictionary) -> void:
	_say("در حال دریافت…")
	var r: Dictionary = await Online.install(it)
	_say(String(r.get("message", "")) if r.get("ok", false) else Online.s(r.get("error", "خطا")))
	_refresh_local()


## نمایش آیتم روی کاراکتر انتخاب‌شده در صحنه‌ی بالا
func _preview_item(it: Dictionary, kind: String, own_clip_src: String) -> void:
	_stop_audio()
	if own_clip_src.begins_with("clip:"):
		_stage_act(own_clip_src)
		return
	var pl = it.get("payload", {})
	var p: Dictionary = pl if pl is Dictionary else {}
	if kind == "anim_clip":
		if String(p.get("clip", "")) != "":
			_stage_act("clip:" + String(p.clip))
		else:
			scr._open_detail(it)
		return
	_say("در حال دریافت پیش‌نمایش…")
	var path: String = await Online.preview_file(it)
	_say("")
	if path == "":
		_say("برای این آیتم فایل پیش‌نمایش ثبت نشده؛ «جزئیات» را بزن.")
		return
	var st: AudioStream = Rules.stream_from_path(path)
	if st == null:
		scr._open_detail(it)
		return
	if kind == "music" and st.has_method("set_loop"):
		st.set_loop(true)
	_play_stream(st)
	if kind in ["voice", "chaser_voice"]:
		_stage_act(_action_for(String(p.get("event", ""))), 1.0)


func _play_stream(st: AudioStream) -> void:
	if _audio == null or not is_instance_valid(_audio):
		_audio = AudioStreamPlayer.new()
		add_child(_audio)
	Music.hold = true
	_audio.stream = st
	_audio.volume_db = linear_to_db(maxf(float(Game.vol.get("master", 1.0)) * float(Game.vol.get("world", 1.0)), 0.3))
	_audio.play()
	get_tree().create_timer(MAX_PLAY).timeout.connect(func():
		if is_instance_valid(_audio) and _audio.playing:
			_audio.stop())


func _stop_audio() -> void:
	if _audio != null and is_instance_valid(_audio) and _audio.playing:
		_audio.stop()
	Music.hold = false


# ------------------------- صداها -------------------------
func _fill_voice(e: Dictionary) -> void:
	_cat_bar()
	var v := _row("صدای اصلی کاراکتر", "همیشه هست", Color("7dff9a"))
	var h := _btn_row(v)
	_act(h, "بشنو + بپر", func():
		Sfx.voice("jump")
		_stage_act("jump", 1.0), "Teal", 170)
	_act(h, "سُر", func():
		Sfx.voice("slide")
		_stage_act("slide", 1.0), "Teal", 100)
	var shown := {}
	for it: Dictionary in Online.items_of_char(sel_key, "voice"):
		shown[String(it.id)] = true
		var pl0 = it.get("payload", {})
		var ev0 := String(pl0.get("event", "")) if pl0 is Dictionary else ""
		if not _cat_ok(ev0 if ev0 != "" else Content.cat_of(sel_key, String(it.name))):
			continue
		_store_item_row(it, "sound", "")
	for le in Rules.library_of("voice", false, sel_key):
		if shown.has(String(le.id)):
			continue
		var lev := String(le.get("hint", ""))
		if not _cat_ok(lev if lev != "" else Content.cat_of(sel_key, String(le.name))):
			continue
		var v2 := _row(String(le.name), "نصب‌شده", Color("7dff9a"))
		var h2 := _btn_row(v2)
		var arg := String(le.get("arg", ""))
		_act(h2, "بشنو", func(): Sfx.play_any(arg); _stage_act(_action_for(String(le.get("hint", ""))), 1.0), "Teal", 120)
		_slot_option(v2, String(le.id), "sound")
		if Content.perm_b("snd_store_tune"):
			SoundPanel.sound_row(ui, v2, "بلندی", arg)
	if Online.items_of_char(sel_key, "voice").is_empty() and Rules.library_of("voice", false, sel_key).is_empty():
		_list.add_child(_lab("هنوز صدای اضافه‌ای برای این کاراکتر عرضه نشده."))


# ------------------------- آهنگ -------------------------
## تعقیب‌کننده: صدا/انیمیشن‌های مخصوص او (همان آیتم‌های chaser_voice و chaser_anim) و نصب‌شده‌ها
func _fill_chaser() -> void:
	if tab == "slots":
		_fill_slots(_entry_of(Rules.CHASER))
		return
	var kind := "chaser_voice" if tab == "voice" else "chaser_anim"
	var action := "sound" if tab == "voice" else "anim"
	_list.add_child(_lab("این‌ها فقط برای تعقیب‌کننده‌اند؛ بخر، نصب کن و به رویداد او (نزدیک شدن، رسیدن، گرفتن، دور شدن) بسپار.", 20))
	if owner_mode and Online.is_admin:
		_list.add_child(ui._button("+ افزودن آیتم جدید", func(): scr.store_admin.open_form_for(kind, {}), Vector2(0, 66), 24, "Gold"))
	var n := 0
	for it: Dictionary in Online.items:
		if String(it.kind) != kind:
			continue
		if not owner_mode and not Edition.is_owner() and String(it.get("status", "approved")) != "approved":
			continue
		n += 1
		_store_item_row(it, action, "")
	for le in Rules.library_of("voice" if tab == "voice" else "anim", true):
		var already := false
		for it2: Dictionary in Online.items:
			if String(it2.id) == String(le.id):
				already = true
		if already:
			continue
		n += 1
		var v := _row(String(le.name), "نصب‌شده", Color("7dff9a"))
		if tab == "voice":
			var arg := String(le.get("arg", ""))
			_act(_btn_row(v), "بشنو", func(): Sfx.play_any(arg, 0.0, Rules.CHASER), "Teal", 120)
		_slot_option(v, String(le.id), action)
	if n == 0:
		_list.add_child(_lab("هنوز چیزی برای تعقیب‌کننده عرضه نشده."))


func _fill_music(_e: Dictionary) -> void:
	if Content.perm_b("snd_music_char"):
		var v := _row("آهنگ این کاراکتر هنگام بازی", "", Color.WHITE)
		var o := OptionButton.new()
		o.add_theme_font_size_override("font_size", 22)
		o.custom_minimum_size = Vector2(0, 58)
		var tracks := Music.all_tracks()
		var cur := Music.char_choice(sel_key)
		o.add_item("پیش‌فرض (آهنگ بازی)", 0)
		var sel := 0
		for t in tracks:
			o.add_item(String(t.name), o.item_count)
			if String(t.id) == cur:
				sel = o.item_count - 1
		o.select(sel)
		o.item_selected.connect(func(k: int):
			Music.set_char_choice(sel_key, "" if k == 0 else String(tracks[k - 1].id))
			if k > 0:
				Music.preview(String(tracks[k - 1].id))
			_say("ذخیره شد ✓"))
		v.add_child(o)
	var list := Online.items_of_char(sel_key, "music")
	for it: Dictionary in list:
		_store_item_row(it, "", "")
	if list.is_empty():
		_list.add_child(_lab("هنوز آهنگی برای این کاراکتر عرضه نشده."))


# ------------------------- نصب‌شده: خلاصه‌ی همه‌ی رویدادها -------------------------
func _src_name(src: String) -> String:
	if src == "":
		return "—"
	if src.begins_with("clip:"):
		return src.substr(5)
	if src.begins_with("builtin:") or src.begins_with("trick:"):
		return src.substr(src.find(":") + 1)
	for le in Rules.library:
		if String(le.get("id", "")) == src:
			return String(le.get("name", src))
	return src


func _fill_slots(e: Dictionary) -> void:
	var eid := String(e.get("id", ""))
	_list.add_child(_lab("هر رویداد بازی چه صدا و حرکتی دارد (فقط برای «%s»). با ▶ همین‌جا روی صحنه امتحان کن؛ برای عوض‌کردن، از تب انیمیشن یا صدا اختصاص بده." % String(e.get("name", "")), 20))
	var any := false
	for evv in _events_allowed():
		var ev := String(evv)
		var snd := Rules.slot_of(eid, ev, "sound")
		var anm := Rules.slot_of(eid, ev, "anim")
		if snd == "" and anm == "":
			continue
		any = true
		var v := _row(Rules.event_name(ev), "", Color.WHITE)
		v.add_child(_lab("صدا: %s   |   حرکت: %s" % [_src_name(snd), _src_name(anm)], 21))
		var h := _btn_row(v)
		_act(h, "امتحان", func():
			if snd != "":
				_preview_event(ev, "sound", snd)
			if anm != "":
				_preview_event(ev, "anim", anm), "Teal", 130)
		if snd != "":
			_act(h, "برداشتن صدا", func(): Rules.set_slot(eid, ev, "sound", ""); _fill(), "Dark", 170)
		if anm != "":
			_act(h, "برداشتن حرکت", func(): Rules.set_slot(eid, ev, "anim", ""); _fill(), "Dark", 170)
	if not any:
		_list.add_child(_lab("هنوز چیزی روی رویدادها نصب نکرده‌ای."))
