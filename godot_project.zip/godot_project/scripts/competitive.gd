class_name Competitive
extends Node
const UiArt := preload("res://scripts/ui_art.gd")
## بخش رقابتی و چندنفره: چالش روزانه با «قانون روز»، رویدادهای محدود، اتاق‌های دوئل (دوستانه و باز)،
## لیگ و جام، فصل، جدول‌ها، قوانین، و پنل مدیر با اختیار کامل.
## منطق جدول‌ها، لیگ‌ها و قانون‌ها به‌صورت static است تا بدون صفحه هم آزمایش شود.

const DEFAULT_LEAGUES := [
	{"name": "برنز", "min": 0, "color": "cd7f32"}, {"name": "نقره", "min": 200, "color": "c0c8d4"},
	{"name": "طلا", "min": 500, "color": "ffd24a"}, {"name": "پلاتین", "min": 1000, "color": "5fe0d0"},
	{"name": "الماس", "min": 1800, "color": "6ab8ff"}, {"name": "افسانه‌ای", "min": 3000, "color": "ff6bd6"}]
const DEFAULT_MODS := [
	{"id": "fast", "name": "سرعت‌ساز", "desc": "شروع و سقف سرعت بیشتر؛ سریع‌تر تصمیم بگیر", "mult": {"START_SPEED": 1.25, "MAX_SPEED": 1.2, "SPEED_PER_SECOND": 1.3}},
	{"id": "rich", "name": "سکه‌باران", "desc": "هر سکه سه برابر امتیاز می‌دهد", "mult": {"COIN_SCORE": 3}},
	{"id": "hard", "name": "بدون بخشش", "desc": "زمین‌خوردن و تعقیب‌کننده طولانی‌تر می‌ماند", "mult": {"STUMBLE_TIME": 1.6, "HEAT_TIME": 1.6}},
	{"id": "near", "name": "لبه‌ی تیغ", "desc": "رد شدن از نزدیکی موانع چهار برابر امتیاز دارد", "mult": {"NEAR_BONUS": 4}},
	{"id": "marathon", "name": "ماراتن", "desc": "سرعت آرام‌تر زیاد می‌شود؛ دوام بیاور", "mult": {"SPEED_PER_SECOND": 0.4, "MAX_SPEED": 0.85}},
	{"id": "turbo", "name": "توربو", "desc": "سرعت و سکه هر دو بالا", "mult": {"START_SPEED": 1.4, "MAX_SPEED": 1.3, "COIN_SCORE": 2}}]
## مقدار پیش‌فرض تنظیمات (همان پیش‌فرض‌های سرور)
const CFG_DEFAULTS := {
	"enabled": true, "daily_enabled": true, "events_enabled": true, "player_rooms": true,
	"daily_reward": 40, "streak_bonus": 5, "daily_tries": 0, "participation_trophies": 5,
	"rank_rewards": [150, 100, 60, 40, 30, 20, 20, 10, 10, 10], "rank_trophies": [40, 30, 20, 15, 10, 10, 5, 5, 5, 5],
	"duel_win_trophies": 25, "duel_lose_trophies": 10, "duel_rake_percent": 10, "create_room_fee": 20, "entry_fee_max": 500,
	"max_room_hours": 72, "max_open_rooms": 20, "season_days": 30, "season_keep_percent": 50, "season_coins_per_100": 10, "max_score_mult": 3,
	"daily_mode": "auto", "modifier_pool": [], "rules_text": "", "banner": ""}
const TABS := [["today", "امروز"], ["events", "رویدادها"], ["rooms", "اتاق‌ها"], ["league", "لیگ"], ["rules", "قوانین"]]

var ui
var scr
var _col: VBoxContainer
var _head: PanelContainer
var _tabs_row: HFlowContainer
var _content: VBoxContainer
var _tab := "today"
var _state: Dictionary = {}
var _gen := 0                        # برای نادیده گرفتن پاسخ‌های دیر رسیده
var _f := {"title": "", "mod": "", "hours": 24, "fee": "0", "public": true, "code": "", "ev_title": "", "ev_mod": "", "ev_hours": 24, "ev_fee": "0",
	"ev_tries": "0", "ev_prizes": "200,100,50", "ev_troph": "50,30,15", "ev_public": true, "ev_delay": "0",
	"m_user": "", "m_room": "", "m_amount": "100"}
var _edit_vals := {}


# ------------------------- منطق (static) -------------------------
static func cfg() -> Dictionary:
	var d: Dictionary = CFG_DEFAULTS.duplicate(true)
	for k in Online.comp_cfg.keys():
		d[k] = Online.comp_cfg[k]
	return d


static func leagues(c: Dictionary) -> Array:
	var out: Array = []
	if c.get("leagues") is Array:
		for x in c.leagues:
			if x is Dictionary and x.has("name"):
				out.append({"name": String(x.name), "min": int(x.get("min", 0)), "color": String(x.get("color", "ffffff"))})
	if out.is_empty():
		out = DEFAULT_LEAGUES.duplicate(true)
	out.sort_custom(func(a, b): return int(a.min) < int(b.min))
	return out


## {name, color, idx, min, next_min (-1 اگر آخرین)، next_name}
static func league_of(trophies: int, c: Dictionary) -> Dictionary:
	var ls := leagues(c)
	var idx := 0
	for i in ls.size():
		if trophies >= int(ls[i].min):
			idx = i
	var nxt: Dictionary = ls[idx + 1] if idx + 1 < ls.size() else {}
	return {"name": ls[idx].name, "color": Color(String(ls[idx].color)), "idx": idx, "min": int(ls[idx].min),
		"next_min": int(nxt.get("min", -1)) if not nxt.is_empty() else -1, "next_name": String(nxt.get("name", ""))}


static func modifiers(c: Dictionary) -> Array:
	var out: Array = DEFAULT_MODS.duplicate(true)
	if c.get("modifiers") is Array:
		for m in c.modifiers:
			if not (m is Dictionary) or String(m.get("id", "")) == "":
				continue
			var found := false
			for i in out.size():
				if String(out[i].id) == String(m.id):
					out[i] = m
					found = true
			if not found:
				out.append(m)
	return out


static func modifier(id: String, c: Dictionary) -> Dictionary:
	if id == "":
		return {}
	for m in modifiers(c):
		if String(m.id) == id:
			return m
	return {}


static func daily_modifier(c: Dictionary, room: int) -> Dictionary:
	var mode := String(c.get("daily_mode", "auto"))
	if mode == "none" or mode == "":
		return {}
	if mode != "auto":
		return modifier(mode, c)
	var pool: Array = []
	var ids: Array = c.get("modifier_pool", []) if c.get("modifier_pool") is Array else []
	for m in modifiers(c):
		if ids.is_empty() or ids.has(String(m.id)):
			pool.append(m)
	return pool[room % pool.size()] if not pool.is_empty() else {}


static func parse_time(iso: String) -> int:
	if iso.length() < 19:
		return 0
	return int(Time.get_unix_time_from_datetime_string(iso.substr(0, 19)))


static func now_utc() -> int:
	return int(Time.get_unix_time_from_system())


static func fmt_left(secs: int) -> String:
	if secs <= 0:
		return "تمام شد"
	var d := secs / 86400
	var h := (secs % 86400) / 3600
	var m := (secs % 3600) / 60
	if d > 0:
		return "%d روز و %d ساعت" % [d, h]
	if h > 0:
		return "%d ساعت و %d دقیقه" % [h, m]
	return "%d دقیقه" % maxi(m, 1)


static func secs_to_day_end() -> int:
	return 86400 - (now_utc() % 86400)


static func parse_int_list(text: String) -> Array:
	var out: Array = []
	for p in text.replace("،", ",").replace(" ", "").split(",", false):
		if String(p).is_valid_int():
			out.append(int(p))
	return out


## «نام:حداقل[:رنگ]» با ویرگول یا خط جدید ← فهرست لیگ‌ها
static func parse_leagues_text(text: String) -> Array:
	var out: Array = []
	var pal := ["cd7f32", "c0c8d4", "ffd24a", "5fe0d0", "6ab8ff", "ff6bd6", "ff8a3d", "9cff6b"]
	for line in text.replace("،", ",").replace("\n", ",").split(",", false):
		var p := String(line).split(":")
		if p.size() >= 2 and String(p[1]).strip_edges().is_valid_int():
			out.append({"name": String(p[0]).strip_edges(), "min": int(p[1]), "color": String(p[2]).strip_edges() if p.size() > 2 else pal[out.size() % pal.size()]})
	out.sort_custom(func(a, b): return int(a.min) < int(b.min))
	return out


static func leagues_to_text(ls: Array) -> String:
	var parts: Array = []
	for l in ls:
		parts.append("%s:%d:%s" % [l.name, int(l.min), l.color])
	return "\n".join(parts)


## «شناسه|نام|توضیح|متغیر=ضریب,متغیر=ضریب» در هر خط ← قانون‌های سفارشی
static func parse_mods_text(text: String) -> Array:
	var out: Array = []
	for line in text.split("\n", false):
		var p := String(line).split("|")
		if p.size() < 4 or String(p[0]).strip_edges() == "":
			continue
		var mult := {}
		for kv in String(p[3]).split(",", false):
			var q := String(kv).split("=")
			if q.size() == 2 and Game.REMOTE_LIMITS.has(String(q[0]).strip_edges()) and String(q[1]).strip_edges().is_valid_float():
				mult[String(q[0]).strip_edges()] = float(q[1])
		out.append({"id": String(p[0]).strip_edges(), "name": String(p[1]).strip_edges(), "desc": String(p[2]).strip_edges(), "mult": mult})
	return out


static func mods_to_text(ms: Array) -> String:
	var lines: Array = []
	for m in ms:
		var kv: Array = []
		for k in m.get("mult", {}).keys():
			kv.append("%s=%s" % [k, str(m.mult[k])])
		lines.append("%s|%s|%s|%s" % [m.id, m.name, m.get("desc", ""), ",".join(kv)])
	return "\n".join(lines)


# ------------------------- ساخت صفحه -------------------------
func setup(owner_ui, screens) -> void:
	ui = owner_ui
	scr = screens


func build(col: VBoxContainer) -> void:
	_col = col
	_head = PanelContainer.new()
	col.add_child(_head)
	_tabs_row = HFlowContainer.new()
	_tabs_row.add_theme_constant_override("h_separation", 8)
	_tabs_row.add_theme_constant_override("v_separation", 8)
	_tabs_row.alignment = FlowContainer.ALIGNMENT_CENTER
	col.add_child(_tabs_row)
	_content = ui.make_scroll_view(col)
	_content.custom_minimum_size = Vector2(620, 0)
	scr._back_button(col)


func refresh() -> void:
	_gen += 1
	_render_tabs()
	_render_head()
	_open_tab(_tab)
	if Online.enabled() and Online.logged_in():
		var g := _gen
		var st: Dictionary = await Online.comp_state()
		if g != _gen or st.is_empty():
			return
		_state = st
		if st.get("cfg") is Dictionary:
			for k in (st.cfg as Dictionary).keys():
				if not Online.comp_cfg.has(k):
					pass
		_render_head()
		var roll: Dictionary = st.get("season_roll", {}) if st.get("season_roll") is Dictionary else {}
		if bool(roll.get("rolled", false)):
			scr.toast("فصل تازه شروع شد! جام‌هایت کم شد و %d سکه جایزه‌ی فصل گرفتی" % int(roll.get("reward", 0)))
		if _tab == "today":
			_open_tab("today")


func _render_tabs() -> void:
	for c in _tabs_row.get_children():
		c.queue_free()
	var items: Array = TABS.duplicate()
	if Online.is_admin:
		items.append(["admin", "مدیریت"])
	for t in items:
		var on: bool = _tab == String(t[0])
		_tabs_row.add_child(ui._button(String(t[1]), func(): _open_tab(String(t[0])), Vector2(0, 70), 28, "Gold" if on else "Dark"))


func _clear() -> void:
	for c in _content.get_children():
		c.queue_free()


func _card(tint: Color = Color(0.2, 0.07, 0.3, 0.85), border: Color = Color(1, 1, 1, 0.2)) -> VBoxContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiArt.panel_style(tint, border))
	p.custom_minimum_size = Vector2(600, 0)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	_content.add_child(p)
	return v


func _lbl(parent: Control, t: String, size: int = 26, color: Color = Color(1, 1, 1, 0.9)) -> Label:
	var l: Label = ui._label(t, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(560, 0)
	parent.add_child(l)
	return l


func _btn(parent: Control, t: String, cb: Callable, kind: String = "Dark", h: int = 70, size: int = 28) -> Button:
	var b: Button = ui._button(t, cb, Vector2(0, h), size, kind)
	parent.add_child(b)
	return b


func _open_tab(t: String) -> void:
	_tab = t
	_gen += 1
	_render_tabs()
	_clear()
	if not Online.enabled() or not Online.logged_in():
		var v := _card()
		_lbl(v, "برای رقابت و جدول‌ها باید وارد حساب آنلاین شوی. بازی بدون آن هم کار می‌کند.", 28)
		_btn(v, "ورود / ساخت حساب", func(): ui._set_screen(ui.Screen.ACCOUNT), "Gold")
		return
	if not bool(cfg().get("enabled", true)) and not Online.is_admin:
		_lbl(_card(), "بخش رقابت فعلاً توسط مدیر غیرفعال شده است.", 28)
		return
	var b := String(cfg().get("banner", ""))
	if b != "":
		_lbl(_card(Color(0.35, 0.22, 0.05, 0.9), Color("ffb02e")), b, 26, Color("ffe7b0"))
	match t:
		"today": _tab_today()
		"events": _tab_events()
		"rooms": _tab_rooms()
		"league": _tab_league()
		"rules": _tab_rules()
		"admin": _tab_admin()


# ------------------------- سربرگ: لیگ و جام -------------------------
func _render_head() -> void:
	for c in _head.get_children():
		c.queue_free()
	var tr := int(_state.get("trophies", Online.comp_state_cache.get("trophies", 0)))
	var c := cfg()
	var lg := league_of(tr, c)
	_head.add_theme_stylebox_override("panel", UiArt.panel_style(Color(lg.color).darkened(0.62), Color(lg.color)))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	_head.add_child(v)
	var top: Label = ui._label("لیگ %s  •  %d جام" % [lg.name, tr], 38, lg.color)
	v.add_child(top)
	var bar := Control.new()
	bar.custom_minimum_size = Vector2(560, 22)
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.45)
	ui._add_full(bar, bg)
	var frac := 1.0
	if int(lg.next_min) > 0:
		frac = clampf(float(tr - int(lg.min)) / float(int(lg.next_min) - int(lg.min)), 0.0, 1.0)
	var fill := ColorRect.new()
	fill.color = lg.color
	bar.add_child(fill)
	fill.anchor_right = frac
	fill.anchor_bottom = 1.0
	v.add_child(bar)
	var sub := "به بالاترین لیگ رسیده‌ای" if int(lg.next_min) < 0 else "%d جام تا لیگ %s" % [int(lg.next_min) - tr, lg.next_name]
	var l2: Label = ui._label(sub, 24, Color(1, 1, 1, 0.85))
	v.add_child(l2)
	if not _state.is_empty():
		var info := "پشت‌سرهم: %d روز  •  برد: %d  •  بازی: %d  •  رتبه‌ی فصل: %d" % [int(_state.get("streak", 0)), int(_state.get("wins", 0)), int(_state.get("games", 0)), int(_state.get("season_rank", 0))]
		var l3: Label = ui._label(info, 22, Color(1, 1, 1, 0.8))
		l3.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l3.custom_minimum_size = Vector2(560, 0)
		v.add_child(l3)


# ------------------------- تب امروز -------------------------
func _tab_today() -> void:
	var c := cfg()
	var room := Online.daily_room()
	var mod := daily_modifier(c, room)
	var v := _card(Color(0.28, 0.1, 0.12, 0.88), Color("ffb02e"))
	_lbl(v, "چالش امروز", 38, Color("ffb02e"))
	if not bool(c.get("daily_enabled", true)):
		_lbl(v, "چالش روزانه فعلاً غیرفعال است.", 26)
		return
	_lbl(v, "مسیر امروز برای همه‌ی بازیکنان یکسان است. تا پایان امروز: %s" % fmt_left(secs_to_day_end()), 24)
	if mod.is_empty():
		_lbl(v, "قانون ویژه‌ای برای امروز نیست.", 24)
	else:
		_lbl(v, "قانون امروز: %s" % mod.name, 32, Color("7dff9a"))
		_lbl(v, String(mod.get("desc", "")), 24, Color("c8ffd6"))
	var lim := int(c.get("daily_tries", 0))
	var used := int(_state.get("tries_used", 0))
	if lim > 0:
		_lbl(v, "تلاش‌های امروز: %d از %d" % [used, lim], 26, Color("ffd27a") if used < lim else Color("ff8a8a"))
	var rw := "جایزه‌ی اولین شرکت: %d سکه + %d جام + پاداش پشت‌سرهم (هر روز %d سکه، تا ۷ روز)" % [int(c.daily_reward), int(c.participation_trophies), int(c.streak_bonus)]
	_lbl(v, rw, 22, Color(1, 1, 1, 0.8))
	if lim > 0 and used >= lim:
		_lbl(v, "تلاش‌هایت تمام شد؛ فردا دوباره.", 26, Color("ff8a8a"))
	else:
		_btn(v, "شروع چالش امروز", func(): _play(room, mod), "Gold", 96, 36)
	# جایزه‌ی دیروز
	if _state.get("claim") is Dictionary:
		var cl: Dictionary = _state.claim
		var cv := _card(Color(0.1, 0.3, 0.18, 0.9), Color("7dff9a"))
		_lbl(cv, "جایزه‌ی دیروز: رتبه‌ی %d از %d" % [int(cl.rank), int(cl.count)], 30, Color("b9ffcb"))
		_lbl(cv, "%d سکه و %d جام" % [int(cl.coins), int(cl.trophies)], 26)
		_btn(cv, "دریافت جایزه", func(): _claim(), "Gold", 80, 32)
	var hdr := _card(Color(0, 0, 0, 0.0), Color(0, 0, 0, 0))
	_lbl(hdr, "جدول امروز", 32, Color("ffb02e"))
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	hdr.add_child(box)
	_load_board(room, box)


func _claim() -> void:
	var r: Dictionary = await Online.comp_claim_yesterday()
	if r.ok:
		scr.toast("%d سکه و %d جام گرفتی" % [int(r.data.coins_gained), int(r.data.trophies_gained)])
	else:
		scr.toast(Online.error_text(String(r.error)))
	await Online.comp_state()
	_state = Online.comp_state_cache
	_render_head()
	_open_tab("today")


func _play(room: int, mod: Dictionary) -> void:
	scr._ch_room = room
	Game.start_challenge(room, mod)


# ------------------------- جدول و سکو -------------------------
func _load_board(room: int, box: VBoxContainer) -> void:
	var g := _gen
	var l: Label = ui._label("در حال دریافت…", 24, Color(1, 1, 1, 0.6))
	box.add_child(l)
	var rows: Array = await Online.challenge_board(room, 30)
	if g != _gen or not is_instance_valid(box):
		return
	for c in box.get_children():
		c.queue_free()
	_board_widget(rows, box, room)


func _board_widget(rows: Array, box: VBoxContainer, room: int) -> void:
	if rows.is_empty():
		var l: Label = ui._label("هنوز کسی امتیاز نگرفته؛ اولین نفر باش!", 26, Color(1, 1, 1, 0.8))
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(560, 0)
		box.add_child(l)
		return
	# سکوی سه نفر اول
	var pod := HBoxContainer.new()
	pod.add_theme_constant_override("separation", 8)
	pod.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_child(pod)
	var order := [1, 0, 2]
	var heights := [150, 190, 120]
	var cols := [Color("c0c8d4"), Color("ffd24a"), Color("cd7f32")]
	for k in 3:
		var idx: int = order[k]
		var col := VBoxContainer.new()
		col.alignment = BoxContainer.ALIGNMENT_END
		col.custom_minimum_size = Vector2(190, 200)
		pod.add_child(col)
		if idx >= rows.size():
			continue
		var r: Dictionary = rows[idx]
		var pn := PanelContainer.new()
		pn.custom_minimum_size = Vector2(190, heights[k])
		pn.add_theme_stylebox_override("panel", UiArt.panel_style(Color(cols[idx]).darkened(0.55), cols[idx]))
		var iv := VBoxContainer.new()
		iv.alignment = BoxContainer.ALIGNMENT_CENTER
		pn.add_child(iv)
		var rn: Label = ui._label(str(idx + 1), 44, cols[idx])
		iv.add_child(rn)
		var nm: Label = ui._label(Online.s(r.get("username", "")), 24, Color.WHITE)
		nm.clip_text = true
		nm.custom_minimum_size = Vector2(170, 0)
		iv.add_child(nm)
		iv.add_child(ui._label(str(int(r.get("score", 0))), 28, cols[idx]))
		col.add_child(pn)
	for r: Dictionary in rows:
		if int(r.get("rank", 0)) <= 3:
			continue
		_board_row(box, r, room)
	if rows.size() >= 1 and Online.is_admin:
		for r: Dictionary in rows.slice(0, 3):
			pass
	# مدیر روی هر ردیف دکمه‌ی «اختیار» دارد
	if Online.is_admin:
		var fl := HFlowContainer.new()
		fl.add_theme_constant_override("h_separation", 6)
		fl.add_theme_constant_override("v_separation", 6)
		box.add_child(fl)
		for r: Dictionary in rows.slice(0, 12):
			var nm := Online.s(r.get("username", ""))
			fl.add_child(ui._button("اختیار: " + nm, func(): _f["m_user"] = nm; _f["m_room"] = str(room); _open_tab("admin"), Vector2(0, 56), 20, "Red"))


func _board_row(box: VBoxContainer, r: Dictionary, room: int) -> void:
	var mine := Online.s(r.get("username", "")) == Online.username
	var t := "%d.  %s   %d  (%d م)" % [int(r.get("rank", 0)), Online.s(r.get("username", "")), int(r.get("score", 0)), int(r.get("distance", 0))]
	var l: Label = ui._label(t, 26, Color("ffd24a") if mine else Color.WHITE)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(560, 0)
	box.add_child(l)


func _show_board(room: int, title: String, mod: Dictionary, can_play: bool) -> void:
	_gen += 1
	_clear()
	var v := _card()
	_lbl(v, title, 34, Color("ffb02e"))
	if not mod.is_empty():
		_lbl(v, "قانون: %s — %s" % [mod.name, mod.get("desc", "")], 22, Color("7dff9a"))
	if can_play:
		_btn(v, "بازی در این رقابت", func(): _play(room, mod), "Gold", 84, 32)
	_btn(v, "بازگشت", func(): _open_tab(_tab), "Dark", 64, 26)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	v.add_child(box)
	_load_board(room, box)


# ------------------------- تب رویدادها -------------------------
func _tab_events() -> void:
	var c := cfg()
	if not bool(c.get("events_enabled", true)):
		_lbl(_card(), "رویدادها فعلاً غیرفعال است.", 28)
		return
	var holder := _card(Color(0, 0, 0, 0), Color(0, 0, 0, 0))
	_lbl(holder, "رویدادهای ویژه", 36, Color("ffb02e"))
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	holder.add_child(box)
	_load_events(box, "event")


func _load_events(box: VBoxContainer, kind: String) -> void:
	var g := _gen
	box.add_child(ui._label("در حال دریافت…", 24, Color(1, 1, 1, 0.6)))
	var rows: Array = await Online.comp_events_list()
	if g != _gen or not is_instance_valid(box):
		return
	for ch in box.get_children():
		ch.queue_free()
	var shown := 0
	for e: Dictionary in rows:
		if String(e.get("kind", "")) != kind:
			continue
		shown += 1
		_event_card(box, e)
	if shown == 0:
		var l: Label = ui._label("فعلاً رویداد فعالی نیست." if kind == "event" else "اتاق بازی در دسترس نیست؛ خودت یکی بساز!", 26, Color(1, 1, 1, 0.8))
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(560, 0)
		box.add_child(l)


func _event_card(box: VBoxContainer, e: Dictionary) -> void:
	var c := cfg()
	var mod := modifier(String(e.get("modifier", "")), c)
	var room := int(e.id)
	var started := parse_time(String(e.get("starts_at", ""))) <= now_utc()
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiArt.panel_style(Color(0.16, 0.1, 0.34, 0.9), Color("b78bff") if String(e.kind) == "event" else Color("5fe0d0")))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	p.add_child(v)
	box.add_child(p)
	_lbl(v, Online.s(e.get("title", "")), 32, Color.WHITE)
	var left := parse_time(String(e.get("ends_at", ""))) - now_utc()
	var meta := "%s  •  %d بازیکن" % [("زمان باقی‌مانده: " + fmt_left(left)) if started else "هنوز شروع نشده", int(e.get("players", 0))]
	if String(e.kind) == "duel" and Online.s(e.get("creator", "")) != "":
		meta += "  •  ساخته‌ی " + Online.s(e.creator)
	_lbl(v, meta, 22, Color(1, 1, 1, 0.8))
	if not mod.is_empty():
		_lbl(v, "قانون: %s — %s" % [mod.name, mod.get("desc", "")], 22, Color("7dff9a"))
	var bits: Array = []
	if int(e.get("entry_fee", 0)) > 0:
		bits.append("ورودی %d سکه" % int(e.entry_fee))
	if int(e.get("max_tries", 0)) > 0:
		bits.append("%d تلاش" % int(e.max_tries))
	if String(e.kind) == "event":
		var pr: Array = e.get("prizes", []) if e.get("prizes") is Array else []
		var tr: Array = e.get("trophy_rewards", []) if e.get("trophy_rewards") is Array else []
		for i in mini(3, maxi(pr.size(), tr.size())):
			bits.append("رتبه %d: %d سکه، %d جام" % [i + 1, int(pr[i]) if i < pr.size() else 0, int(tr[i]) if i < tr.size() else 0])
	else:
		bits.append("جمع جایزه: %d سکه (برنده %d%% می‌برد)" % [int(e.get("pool", 0)), 100 - int(c.get("duel_rake_percent", 10))])
	if not bits.is_empty():
		_lbl(v, "  •  ".join(bits), 21, Color("ffd27a"))
	if e.get("my_score") != null:
		_lbl(v, "بهترین امتیاز تو: %d" % int(e.my_score), 24, Color("7dff9a"))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	var pb: Button = ui._button("بازی", func(): _play(room, mod), Vector2(0, 70), 28, "Gold")
	pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pb.disabled = not started
	row.add_child(pb)
	var bb: Button = ui._button("جدول", func(): _show_board(room, Online.s(e.get("title", "")), mod, started), Vector2(0, 70), 28, "Teal")
	bb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(bb)
	if Online.is_admin:
		var ar := HFlowContainer.new()
		ar.add_theme_constant_override("h_separation", 6)
		v.add_child(ar)
		ar.add_child(ui._button("پایان و پرداخت جایزه", func(): _adm("end_room", {"room": room}, "پایان یافت"), Vector2(0, 52), 20, "Gold"))
		ar.add_child(ui._button("پاک‌کردن جدول", func(): _adm("reset_board", {"room": room}, "جدول پاک شد"), Vector2(0, 52), 20, "Dark"))
		ar.add_child(ui._button("حذف اتاق", func(): _adm("delete_room", {"room": room}, "حذف شد"), Vector2(0, 52), 20, "Red"))


# ------------------------- تب اتاق‌ها -------------------------
func _edit(parent: Control, key: String, hint: String, numeric: bool = false) -> LineEdit:
	var e := LineEdit.new()
	e.text = String(_f[key])
	e.placeholder_text = hint
	e.add_theme_font_size_override("font_size", 26)
	e.custom_minimum_size = Vector2(0, 64)
	e.alignment = HORIZONTAL_ALIGNMENT_CENTER
	if numeric:
		e.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	e.text_changed.connect(func(t: String): _f[key] = t)
	parent.add_child(e)
	return e


func _chips(parent: Control, options: Array, key: String, rerender: Callable) -> void:
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 6)
	fl.add_theme_constant_override("v_separation", 6)
	parent.add_child(fl)
	for o in options:
		var on := str(_f[key]) == str(o[0])
		fl.add_child(ui._button(("✓ " if on else "") + String(o[1]), func(): _f[key] = o[0]; rerender.call(), Vector2(0, 56), 22, "Gold" if on else "Dark"))


func _mod_options(c: Dictionary) -> Array:
	var o: Array = [["", "بدون قانون"]]
	for m in modifiers(c):
		o.append([String(m.id), String(m.name)])
	return o


func _tab_rooms() -> void:
	var c := cfg()
	var v := _card()
	_lbl(v, "دوئل با دوستان", 34, Color("ffb02e"))
	_lbl(v, "یک کد ۴ تا ۷ رقمی بساز و برای دوستت بفرست؛ هر دو همان مسیر را می‌دوید و امتیازها کنار هم می‌آید.", 22)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	var ce := _edit(row, "code", "کد اتاق", true)
	ce.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var rnd: Button = ui._button("کد تصادفی", func(): _f["code"] = str(randi_range(10000, 99999)); _open_tab("rooms"), Vector2(0, 64), 24, "Teal")
	row.add_child(rnd)
	var jr := HBoxContainer.new()
	jr.add_theme_constant_override("separation", 8)
	v.add_child(jr)
	var play_b: Button = ui._button("ورود و بازی", func():
		var code := int(String(_f.code))
		if code < 1000 or code > 9999999:
			scr.toast("کد باید عدد ۴ تا ۷ رقمی باشد")
			return
		_play(code, {}), Vector2(0, 70), 28, "Purple")
	play_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	jr.add_child(play_b)
	var brd_b: Button = ui._button("جدول اتاق", func():
		var code := int(String(_f.code))
		if code < 1000 or code > 9999999:
			scr.toast("کد باید عدد ۴ تا ۷ رقمی باشد")
			return
		_show_board(code, "اتاق %d" % code, {}, true), Vector2(0, 70), 28, "Teal")
	brd_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	jr.add_child(brd_b)
	# ساخت اتاق باز
	if bool(c.get("player_rooms", true)):
		var nv := _card(Color(0.1, 0.22, 0.3, 0.9), Color("5fe0d0"))
		_lbl(nv, "ساخت اتاق باز", 34, Color("5fe0d0"))
		_lbl(nv, "هزینه‌ی ساخت %d سکه. هر کس ورودی بدهد به جایزه اضافه می‌شود و برنده بعد از پایان زمان جایزه و جام می‌گیرد." % int(c.create_room_fee), 21)
		_edit(nv, "title", "نام اتاق (اختیاری)")
		_lbl(nv, "قانون", 22, Color(1, 1, 1, 0.7))
		_chips(nv, _mod_options(c), "mod", func(): _open_tab("rooms"))
		_lbl(nv, "مدت", 22, Color(1, 1, 1, 0.7))
		var hrs: Array = []
		for h in [1, 6, 24, 72]:
			if h <= int(c.max_room_hours):
				hrs.append([h, "%d ساعت" % h])
		_chips(nv, hrs, "hours", func(): _open_tab("rooms"))
		_edit(nv, "fee", "ورودی هر بازیکن (سکه؛ حداکثر %d)" % int(c.entry_fee_max), true)
		var pc := CheckBox.new()
		pc.text = "اتاق عمومی (در فهرست همه دیده شود)"
		pc.button_pressed = bool(_f.public)
		pc.add_theme_font_size_override("font_size", 24)
		pc.toggled.connect(func(on: bool): _f["public"] = on)
		nv.add_child(pc)
		_btn(nv, "ساخت اتاق", func(): _create_room(), "Gold", 80, 30)
	var lv := _card(Color(0, 0, 0, 0), Color(0, 0, 0, 0))
	_lbl(lv, "اتاق‌های باز", 34, Color("ffb02e"))
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	lv.add_child(box)
	_load_events(box, "duel")


func _create_room() -> void:
	var c := cfg()
	var r: Dictionary = await Online.comp_create_room(String(_f.title), String(_f.mod), int(_f.hours), clampi(int(String(_f.fee)), 0, int(c.entry_fee_max)), bool(_f.public))
	if r.ok:
		scr.toast("اتاق ساخته شد")
		_f["title"] = ""
		_open_tab("rooms")
	else:
		scr.toast(Online.error_text(String(r.error), int(r.get("need", 0))))


# ------------------------- تب لیگ -------------------------
func _tab_league() -> void:
	var c := cfg()
	var tr := int(_state.get("trophies", 0))
	var v := _card()
	_lbl(v, "فصل %d" % int(_state.get("season", 0)), 34, Color("ffb02e"))
	_lbl(v, "پایان فصل: %d روز دیگر. در پایان، %d%% جام‌هایت می‌ماند و به ازای هر ۱۰۰ جام، %d سکه جایزه می‌گیری." % [int(_state.get("season_days_left", 0)), int(c.season_keep_percent), int(c.season_coins_per_100)], 22)
	var cur := league_of(tr, c)
	for i in leagues(c).size():
		var l: Dictionary = leagues(c)[i]
		var mine: bool = int(cur.idx) == i
		_lbl(v, "%s%s  —  از %d جام" % ["◄ " if mine else "", l.name, int(l.min)], 28 if mine else 24, Color(String(l.color)) if mine else Color(1, 1, 1, 0.65))
	var bv := _card(Color(0, 0, 0, 0), Color(0, 0, 0, 0))
	_lbl(bv, "برترین‌های فصل", 34, Color("ffb02e"))
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	bv.add_child(box)
	_load_season(box)


func _load_season(box: VBoxContainer) -> void:
	var g := _gen
	box.add_child(ui._label("در حال دریافت…", 24, Color(1, 1, 1, 0.6)))
	var rows: Array = await Online.comp_season_board(50)
	if g != _gen or not is_instance_valid(box):
		return
	for ch in box.get_children():
		ch.queue_free()
	if rows.is_empty():
		box.add_child(ui._label("هنوز کسی جام نگرفته.", 26, Color(1, 1, 1, 0.8)))
	var c := cfg()
	for r: Dictionary in rows:
		var mine := Online.s(r.get("username", "")) == Online.username
		var lg := league_of(int(r.get("trophies", 0)), c)
		var l: Label = ui._label("%d.  %s   %d جام  (%s)" % [int(r.get("rank", 0)), Online.s(r.get("username", "")), int(r.get("trophies", 0)), lg.name], 26, Color("ffd24a") if mine else lg.color)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(560, 0)
		box.add_child(l)


# ------------------------- تب قوانین -------------------------
func _tab_rules() -> void:
	var c := cfg()
	var v := _card()
	_lbl(v, "قوانین و ویژگی‌ها", 36, Color("ffb02e"))
	if String(c.get("rules_text", "")) != "":
		_lbl(v, String(c.rules_text), 24)
	var rr: Array = c.rank_rewards
	var rt: Array = c.rank_trophies
	var lines: Array = [
		"چالش روزانه: مسیر یکسان برای همه؛ هر روز یک «قانون روز» دارد. اولین شرکت هر روز %d سکه و %d جام می‌دهد." % [int(c.daily_reward), int(c.participation_trophies)],
		"پشت‌سرهم بازی کنی هر روز %d سکه‌ی اضافه می‌گیری (تا ۷ روز)." % int(c.streak_bonus),
		"جایزه‌ی رتبه‌ی روز قبل را از تب «امروز» می‌گیری: نفر اول %d سکه و %d جام، دوم %d و %d، سوم %d و %d." % [int(rr[0]) if rr.size() > 0 else 0, int(rt[0]) if rt.size() > 0 else 0, int(rr[1]) if rr.size() > 1 else 0, int(rt[1]) if rt.size() > 1 else 0, int(rr[2]) if rr.size() > 2 else 0, int(rt[2]) if rt.size() > 2 else 0],
		"رویدادها زمان‌دارند و جایزه‌ی سکه و جام به رتبه‌های برتر می‌رسد؛ بعضی ورودی یا محدودیت تلاش دارند.",
		"دوئل: برنده %d جام می‌گیرد، بازنده %d جام از دست می‌دهد و جایزه‌ی اتاق (جمع ورودی‌ها منهای %d%%) به برنده می‌رسد." % [int(c.duel_win_trophies), int(c.duel_lose_trophies), int(c.duel_rake_percent)],
		"فصل هر %d روز تمام می‌شود؛ %d%% جام‌ها می‌ماند و جایزه‌ی سکه‌ی فصل می‌گیری." % [int(c.season_days), int(c.season_keep_percent)],
		"امتیازِ غیرعادی یا تقلب ثبت نمی‌شود و مدیر می‌تواند امتیاز را حذف یا کم کند و حساب را از رقابت کنار بگذارد."]
	if int(c.daily_tries) > 0:
		lines.append("در چالش روزانه روزی %d تلاش داری." % int(c.daily_tries))
	for t in lines:
		_lbl(v, "• " + String(t), 22)
	var mv := _card()
	_lbl(mv, "قانون‌های روز", 32, Color("ffb02e"))
	for m in modifiers(c):
		_lbl(mv, "%s: %s" % [m.name, m.get("desc", "")], 22)


# ------------------------- تب مدیریت (دست مدیر کاملاً باز) -------------------------
func _adm(action: String, args: Dictionary, ok_text: String) -> bool:
	var r: Dictionary = await Online.comp_admin(action, args)
	if r.ok:
		scr.toast(ok_text)
		if _tab == "admin" or _tab == "events" or _tab == "rooms":
			_open_tab(_tab)
		return true
	scr.toast("انجام نشد: " + Online.error_text(String(r.error)))
	return false


const SETTINGS_SPEC := [
	["بخش‌ها", "head"],
	["enabled", "کل رقابت روشن", "bool"], ["daily_enabled", "چالش روزانه روشن", "bool"], ["events_enabled", "رویدادها روشن", "bool"], ["player_rooms", "بازیکنان بتوانند اتاق بسازند", "bool"],
	["چالش روزانه", "head"],
	["daily_reward", "سکه‌ی اولین شرکت هر روز", "int"], ["streak_bonus", "سکه‌ی پاداش هر روزِ پشت‌سرهم (تا ۷ روز)", "int"], ["daily_tries", "حداکثر تلاش روزانه (۰ = نامحدود)", "int"],
	["participation_trophies", "جام شرکت در چالش روز", "int"], ["rank_rewards", "سکه‌ی رتبه‌ها (۱ تا ۱۰، با ویرگول)", "ints"], ["rank_trophies", "جام رتبه‌ها (با ویرگول)", "ints"],
	["daily_mode", "قانون روز: auto یا none یا شناسه‌ی قانون", "text"], ["modifier_pool", "قانون‌های مجاز برای خودکار (شناسه‌ها با ویرگول؛ خالی = همه)", "idlist"],
	["دوئل و اتاق‌ها", "head"],
	["duel_win_trophies", "جام برنده‌ی دوئل", "int"], ["duel_lose_trophies", "جام‌های از دست رفته‌ی بازنده", "int"], ["duel_rake_percent", "سهم برنامه از جایزه‌ی اتاق (درصد)", "int"],
	["create_room_fee", "هزینه‌ی ساخت اتاق (سکه)", "int"], ["entry_fee_max", "سقف ورودی اتاق (سکه)", "int"], ["max_room_hours", "حداکثر مدت اتاق (ساعت)", "int"], ["max_open_rooms", "حداکثر اتاق باز هم‌زمان", "int"],
	["فصل و امنیت", "head"],
	["season_days", "طول فصل (روز)", "int"], ["season_keep_percent", "درصد جامی که از فصل قبل می‌ماند", "int"], ["season_coins_per_100", "سکه‌ی پایان فصل به ازای هر ۱۰۰ جام", "int"],
	["max_score_mult", "سقف امتیاز قابل‌قبول (ضریب؛ با قانون‌های پرامتیاز بالاتر ببر)", "int"],
	["متن‌ها", "head"],
	["banner", "اعلان بالای صفحه‌ی رقابت", "text"], ["rules_text", "متن قوانین", "text"],
]


func _tab_admin() -> void:
	var c := cfg()
	_edit_vals = {}
	# --- تنظیمات
	var sv := _card(Color(0.3, 0.1, 0.1, 0.9), Color("ff8a8a"))
	_lbl(sv, "تنظیمات رقابت (برای همه‌ی بازیکنان)", 32, Color("ffb7b7"))
	for sp in SETTINGS_SPEC:
		if String(sp[1]) == "head":
			_lbl(sv, String(sp[0]), 28, Color("ffb02e"))
			continue
		var key := String(sp[0])
		var kind := String(sp[2])
		_lbl(sv, String(sp[1]), 20, Color(1, 1, 1, 0.75))
		if kind == "bool":
			var cb := CheckBox.new()
			cb.text = "روشن"
			cb.button_pressed = bool(c.get(key, true))
			cb.add_theme_font_size_override("font_size", 24)
			sv.add_child(cb)
			_edit_vals[key] = cb
		else:
			var le := LineEdit.new()
			le.add_theme_font_size_override("font_size", 24)
			le.custom_minimum_size = Vector2(0, 58)
			if kind == "ints":
				var a: Array = c.get(key, [])
				le.text = ",".join(a.map(func(x): return str(int(x))))
			elif kind == "idlist":
				var a2: Array = c.get(key, [])
				le.text = ",".join(a2.map(func(x): return str(x)))
			else:
				le.text = str(c.get(key, ""))
			if kind == "int":
				le.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
			sv.add_child(le)
			_edit_vals[key] = le
	_lbl(sv, "لیگ‌ها (هر خط: نام:حداقل جام:رنگ هگز)", 24, Color("ffb02e"))
	var le_l := TextEdit.new()
	le_l.custom_minimum_size = Vector2(0, 230)
	le_l.add_theme_font_size_override("font_size", 22)
	le_l.text = leagues_to_text(leagues(c))
	sv.add_child(le_l)
	_edit_vals["_leagues"] = le_l
	_lbl(sv, "قانون‌های سفارشی (هر خط: شناسه|نام|توضیح|متغیر=ضریب,متغیر=ضریب). متغیرها: " + ", ".join(Game.REMOTE_LIMITS.keys().filter(func(k): return k not in ["REVIVE_PRICE", "UPGRADE_BASE_PRICE"])), 20, Color("ffb02e"))
	var le_m := TextEdit.new()
	le_m.custom_minimum_size = Vector2(0, 260)
	le_m.add_theme_font_size_override("font_size", 20)
	le_m.text = mods_to_text(modifiers(c))
	sv.add_child(le_m)
	_edit_vals["_mods"] = le_m
	_btn(sv, "ذخیره و انتشار برای همه", func(): _save_settings(), "Gold", 84, 30)
	_btn(sv, "بازگشت به پیش‌فرض", func(): _reset_settings(), "Dark", 64, 24)
	# --- رویداد تازه
	var ev := _card(Color(0.16, 0.1, 0.34, 0.9), Color("b78bff"))
	_lbl(ev, "ساخت رویداد", 32, Color("d9c2ff"))
	_edit(ev, "ev_title", "نام رویداد")
	_lbl(ev, "قانون", 20)
	_chips(ev, _mod_options(c), "ev_mod", func(): _open_tab("admin"))
	_lbl(ev, "مدت (ساعت)", 20)
	_chips(ev, [[6, "۶"], [24, "۲۴"], [72, "۷۲"], [168, "۱۶۸"], [720, "۷۲۰"]], "ev_hours", func(): _open_tab("admin"))
	_edit(ev, "ev_delay", "شروع بعد از چند ساعت (۰ = همین الان)", true)
	_edit(ev, "ev_fee", "ورودی (سکه)", true)
	_edit(ev, "ev_tries", "حداکثر تلاش (۰ = نامحدود)", true)
	_edit(ev, "ev_prizes", "جایزه‌ی سکه‌ی رتبه‌ها (با ویرگول)")
	_edit(ev, "ev_troph", "جام رتبه‌ها (با ویرگول)")
	var pc := CheckBox.new()
	pc.text = "عمومی"
	pc.button_pressed = bool(_f.ev_public)
	pc.add_theme_font_size_override("font_size", 24)
	pc.toggled.connect(func(on: bool): _f["ev_public"] = on)
	ev.add_child(pc)
	_btn(ev, "ساخت رویداد", func(): _create_event(), "Gold", 80, 30)
	# --- بازیکن
	var pv := _card(Color(0.3, 0.1, 0.1, 0.9), Color("ff8a8a"))
	_lbl(pv, "مدیریت بازیکن و امتیاز", 32, Color("ffb7b7"))
	_edit(pv, "m_user", "نام کاربری بازیکن")
	_edit(pv, "m_room", "کد اتاق (خالی = چالش امروز)", true)
	_edit(pv, "m_amount", "مقدار", true)
	var g1 := HFlowContainer.new()
	g1.add_theme_constant_override("h_separation", 6)
	g1.add_theme_constant_override("v_separation", 6)
	pv.add_child(g1)
	var acts := [
		["حذف امتیاز از اتاق", "remove_score", "امتیاز حذف شد", "Red"], ["کم‌کردن امتیاز", "reduce_score", "امتیاز کم شد", "Red"],
		["اضافه‌کردن جام", "trophies+", "جام اضافه شد", "Teal"], ["کم‌کردن جام", "trophies-", "جام کم شد", "Red"],
		["اضافه‌کردن سکه", "coins+", "سکه اضافه شد", "Teal"], ["کم‌کردن سکه", "coins-", "سکه کم شد", "Red"],
		["کنار گذاشتن از رقابت", "ban+", "از رقابت کنار رفت", "Red"], ["برگرداندن به رقابت", "ban-", "برگشت", "Teal"]]
	for a in acts:
		g1.add_child(ui._button(String(a[0]), func(): _player_action(String(a[1]), String(a[2])), Vector2(0, 60), 22, String(a[3])))
	# --- جدول امروز و فصل
	var tv := _card(Color(0.1, 0.18, 0.3, 0.9), Color("6ab8ff"))
	_lbl(tv, "جدول و فصل", 32, Color("b9d8ff"))
	_btn(tv, "پاک‌کردن جدول امروز", func(): _adm("reset_board", {"room": Online.daily_room()}, "جدول امروز پاک شد"), "Red", 64, 24)
	_btn(tv, "شروع فصل تازه برای همه (جام‌ها کم می‌شود و جایزه می‌دهد)", func(): _adm("new_season", {}, "فصل تازه شروع شد"), "Red", 64, 22)
	_btn(tv, "مشاهده‌ی جدول امروز", func(): _show_board(Online.daily_room(), "جدول امروز", daily_modifier(c, Online.daily_room()), false), "Teal", 64, 24)


func _save_settings() -> void:
	var d: Dictionary = Online.comp_cfg.duplicate(true)
	for sp in SETTINGS_SPEC:
		if String(sp[1]) == "head":
			continue
		var key := String(sp[0])
		var kind := String(sp[2])
		var w = _edit_vals.get(key)
		if w == null:
			continue
		match kind:
			"bool": d[key] = (w as CheckBox).button_pressed
			"int": d[key] = int(String((w as LineEdit).text))
			"ints": d[key] = parse_int_list((w as LineEdit).text)
			"idlist":
				var ids: Array = []
				for p in (w as LineEdit).text.replace("،", ",").split(",", false):
					ids.append(String(p).strip_edges())
				d[key] = ids
			_: d[key] = (w as LineEdit).text
	var ls := parse_leagues_text((_edit_vals["_leagues"] as TextEdit).text)
	if ls.size() >= 2:
		d["leagues"] = ls
	var ms := parse_mods_text((_edit_vals["_mods"] as TextEdit).text)
	d["modifiers"] = ms
	d["season_days"] = clampi(int(d.get("season_days", 30)), 1, 365)
	d["season_keep_percent"] = clampi(int(d.get("season_keep_percent", 50)), 0, 100)
	d["duel_rake_percent"] = clampi(int(d.get("duel_rake_percent", 10)), 0, 100)
	d["max_score_mult"] = clampi(int(d.get("max_score_mult", 3)), 1, 50)
	var r: Dictionary = await Online.push_comp_config(d)
	scr.toast("تنظیمات رقابت برای همه منتشر شد" if r.ok else "ذخیره نشد: " + String(r.error))
	if r.ok:
		_open_tab("admin")


func _reset_settings() -> void:
	var keep := {}
	if Online.comp_cfg.has("season_offset"):
		keep["season_offset"] = Online.comp_cfg.season_offset      # شماره‌ی فصل را عوض نکن
	var r: Dictionary = await Online.push_comp_config(keep)
	scr.toast("به پیش‌فرض برگشت" if r.ok else "انجام نشد")
	if r.ok:
		_open_tab("admin")


func _create_event() -> void:
	var title := String(_f.ev_title).strip_edges()
	if title == "":
		scr.toast("برای رویداد یک نام بنویس")
		return
	var start := now_utc() + int(String(_f.ev_delay)) * 3600
	var args := {"title": title, "modifier": String(_f.ev_mod), "starts_at": Time.get_datetime_string_from_unix_time(start) + "Z",
		"ends_at": Time.get_datetime_string_from_unix_time(start + int(_f.ev_hours) * 3600) + "Z", "entry_fee": int(String(_f.ev_fee)),
		"prizes": parse_int_list(String(_f.ev_prizes)), "trophy_rewards": parse_int_list(String(_f.ev_troph)),
		"max_tries": int(String(_f.ev_tries)), "is_public": bool(_f.ev_public)}
	if await _adm("create_event", args, "رویداد ساخته شد"):
		_f["ev_title"] = ""


func _player_action(act: String, ok_text: String) -> void:
	var user := String(_f.m_user).strip_edges()
	if user == "":
		scr.toast("نام کاربری را بنویس")
		return
	var room := int(String(_f.m_room)) if String(_f.m_room) != "" else Online.daily_room()
	var amt := int(String(_f.m_amount))
	match act:
		"remove_score": await _adm("remove_score", {"username": user, "room": room}, ok_text)
		"reduce_score": await _adm("reduce_score", {"username": user, "room": room, "amount": amt}, ok_text)
		"trophies+": await _adm("trophies", {"username": user, "delta": absi(amt)}, ok_text)
		"trophies-": await _adm("trophies", {"username": user, "delta": -absi(amt)}, ok_text)
		"coins+": await _adm("coins", {"username": user, "delta": absi(amt)}, ok_text)
		"coins-": await _adm("coins", {"username": user, "delta": -absi(amt)}, ok_text)
		"ban+": await _adm("ban", {"username": user, "banned": true}, ok_text)
		"ban-": await _adm("ban", {"username": user, "banned": false}, ok_text)
