extends RefCounted
## «فروشگاه قدرت‌ها»: ارتقای قدرت‌های روی مسیر + ابزارهای مصرفی (اول یا وسط بازی) + ابزارهای همراه.
## نمادها با BoostIcon (کدکشی) و پس‌زمینه با StoreFx ساخته می‌شوند.

const StoreFx := preload("res://scripts/store_fx.gd")
const POWER_KIND := ["magnet", "shield", "x2", "jet", "spring", "slow"]
const POWER_DESC := ["سکه‌های اطراف را می‌کشد", "یک برخورد را می‌گیرد", "هر سکه دو برابر", "پرواز و شکست‌ناپذیری", "پرش‌های بلندتر", "دنیا کندتر می‌شود"]
const COL_GOLD := Color("ffc21a")

var ui
var root: Control
var coins_lbl: Label
var best_lbl: Label
var _tab := "boost"
var _loadout_box: VBoxContainer
var _body: VBoxContainer
var _tabs_row: HBoxContainer
var _msg: Label


func build(owner_ui, holder: Control) -> void:
	ui = owner_ui
	root = holder
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color("3a1668"), Color("0b0420")])
	grad.offsets = PackedFloat32Array([0.0, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	gt.width = 8
	gt.height = 256
	var bg := TextureRect.new()
	bg.texture = gt
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	ui._add_full(root, bg)
	var fx := StoreFx.new()
	fx.mode = "backdrop"
	ui._add_full(root, fx)

	var scroll := ScrollContainer.new()
	ui._add_full(root, scroll)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 26)
	margin.add_theme_constant_override("margin_right", 26)
	margin.add_theme_constant_override("margin_top", 64)
	margin.add_theme_constant_override("margin_bottom", 40)
	scroll.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 16)
	margin.add_child(col)

	var ban := StoreFx.new()
	ban.mode = "banner"
	ban.custom_minimum_size = Vector2(0, 124)
	col.add_child(ban)
	var bt: Label = ui._label("فروشگاه قدرت‌ها", 56, Color.WHITE)
	bt.add_theme_color_override("font_outline_color", Color(0.25, 0.02, 0.3))
	bt.add_theme_constant_override("outline_size", 10)
	bt.set_meta(ui.FIT_META, true)
	bt.autowrap_mode = TextServer.AUTOWRAP_OFF
	bt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	ui._add_full(ban, bt)

	coins_lbl = ui._label("", 36, COL_GOLD)
	best_lbl = ui._label("", 24, Color("c9d6e6"))
	var cr := HBoxContainer.new()
	cr.alignment = BoxContainer.ALIGNMENT_CENTER
	cr.add_theme_constant_override("separation", 10)
	var ci := BoostIcon.make("coin", COL_GOLD, 52, false)
	cr.add_child(ci)
	cr.add_child(coins_lbl)
	col.add_child(cr)
	col.add_child(best_lbl)

	_loadout_box = VBoxContainer.new()
	_loadout_box.add_theme_constant_override("separation", 10)
	col.add_child(_loadout_box)

	_tabs_row = HBoxContainer.new()
	_tabs_row.add_theme_constant_override("separation", 10)
	col.add_child(_tabs_row)
	_body = VBoxContainer.new()
	_body.add_theme_constant_override("separation", 14)
	col.add_child(_body)

	_msg = ui._label("", 22, Color("ffd27a"))
	_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_msg.custom_minimum_size = Vector2(560, 0)
	col.add_child(_msg)
	var rv: Label = ui._label("زنده‌شدن دوباره بعد از باخت: %d سکه یا یک «بلیت زندگی» (یک بار در هر بازی)" % Game.REVIVE_PRICE, 22, Color("ff9a4a"))
	rv.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rv.custom_minimum_size = Vector2(560, 0)
	col.add_child(rv)
	col.add_child(ui._button("بازگشت", func(): ui._set_screen(ui.Screen.START), Vector2(540, 96), 38, "Dark"))
	Game.boosts_changed.connect(refresh)
	refresh()


func say(t: String) -> void:
	if _msg != null:
		_msg.text = t


func refresh() -> void:
	if root == null or not is_instance_valid(root):
		return
	coins_lbl.text = "%d" % Game.coins
	best_lbl.text = "بیشترین امتیاز: %d" % Game.high_score
	_build_loadout()
	_build_tabs()
	_build_body()


# ------------------------- ابزارهای همراه -------------------------
func _build_loadout() -> void:
	for c in _loadout_box.get_children():
		c.queue_free()
	var head: Label = ui._label("ابزارهای همراه (حداکثر %d)" % Game.LOADOUT_SLOTS, 30, COL_GOLD)
	_loadout_box.add_child(head)
	var tip: Label = ui._label("هرچه اینجا بگذاری، حین بازی دکمه‌اش پایین صفحه می‌آید. با «شروع خودکار» همان اول بازی مصرف می‌شود.", 20, Color("c9d6e6"))
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.custom_minimum_size = Vector2(560, 0)
	_loadout_box.add_child(tip)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	_loadout_box.add_child(row)
	for i in Game.LOADOUT_SLOTS:
		row.add_child(_slot(i))


func _slot(i: int) -> Control:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	box.custom_minimum_size = Vector2(200, 0)
	var pc := PanelContainer.new()
	var sb := StoreFx.card_style("common")
	var filled := i < Game.loadout.size()
	var id := String(Game.loadout[i]) if filled else ""
	var d := Game.boost_def(id) if filled else {}
	if filled:
		sb = StoreFx.card_style("rare")
	pc.add_theme_stylebox_override("panel", sb)
	box.add_child(pc)
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 4)
	pc.add_child(v)
	if filled:
		var ic := BoostIcon.make(String(d.icon), Color(String(d.color)), 92)
		ic.dim = Game.boost_count(id) <= 0
		var cc := CenterContainer.new()
		cc.add_child(ic)
		v.add_child(cc)
		var nm: Label = ui._label(String(d.name), 22, Color.WHITE)
		nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		nm.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		nm.custom_minimum_size = Vector2(150, 0)
		v.add_child(nm)
		var cnt: Label = ui._label("× %d" % Game.boost_count(id), 26, COL_GOLD if Game.boost_count(id) > 0 else Color("ff7a7a"))
		cnt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(cnt)
		if id != "life":
			var on := bool(Game.auto_start.get(id, false))
			box.add_child(ui._button(("✓ شروع خودکار" if on else "شروع خودکار"), func(): Game.toggle_auto_start(id), Vector2(0, 52), 20, "Gold" if on else "Dark"))
		box.add_child(ui._button("برداشتن", func(): Game.set_loadout(id, false), Vector2(0, 52), 20, "Dark"))
	else:
		var cc2 := CenterContainer.new()
		var plus: Label = ui._label("+", 80, Color(1, 1, 1, 0.35))
		cc2.add_child(plus)
		cc2.custom_minimum_size = Vector2(0, 150)
		v.add_child(cc2)
		var em: Label = ui._label("خالی", 20, Color(1, 1, 1, 0.5))
		em.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(em)
	return box


# ------------------------- تب‌ها -------------------------
func _build_tabs() -> void:
	for c in _tabs_row.get_children():
		c.queue_free()
	for t in [["boost", "ابزارها"], ["upgrade", "ارتقای قدرت‌ها"]]:
		var key: String = t[0]
		var b: Button = ui._button(String(t[1]), func(): _tab = key; refresh(), Vector2(0, 76), 28, "Gold" if _tab == key else "Dark")
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_tabs_row.add_child(b)


func _build_body() -> void:
	for c in _body.get_children():
		c.queue_free()
	if _tab == "boost":
		var any := false
		for d: Dictionary in Game.shown_boosts():
			any = true
			_body.add_child(_boost_card(d))
		if not any:
			var e: Label = ui._label("فعلاً ابزاری عرضه نمی‌شود.", 26, Color("c9d6e6"))
			_body.add_child(e)
	else:
		for i in Game.POWER_NAMES.size():
			_body.add_child(_upgrade_card(i))


func _card(tint: Color, rarity: String = "common") -> PanelContainer:
	var pc := PanelContainer.new()
	var sb := StoreFx.card_style(rarity)
	sb.border_color = Color(tint.r, tint.g, tint.b, 0.95)
	sb.shadow_color = Color(tint.r, tint.g, tint.b, 0.4)
	sb.shadow_size = 12
	pc.add_theme_stylebox_override("panel", sb)
	return pc


func _pill(text: String, col: Color) -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 6)
	h.add_child(BoostIcon.make("coin", COL_GOLD, 34, false))
	var l: Label = ui._label(text, 24, col)
	h.add_child(l)
	return h


func _boost_card(d: Dictionary) -> Control:
	var id := String(d.id)
	var tint := Color(String(d.color))
	var card := _card(tint, "epic" if id in ["ghost", "life"] else "rare")
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	card.add_child(row)
	var ic := BoostIcon.make(String(d.icon), tint, 104)
	row.add_child(ic)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_theme_constant_override("separation", 4)
	row.add_child(info)
	var top := HBoxContainer.new()
	info.add_child(top)
	var nm: Label = ui._label(String(d.name), 30, Color.WHITE)
	nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(nm)
	var have := Game.boost_count(id)
	var bd: Label = ui._label("× %d" % have, 28, COL_GOLD if have > 0 else Color(1, 1, 1, 0.45))
	top.add_child(bd)
	var ds: Label = ui._label("%s%s" % [String(d.desc), ("" if float(d.dur) <= 0.0 else "  (%d ثانیه)" % int(Game.boost_dur(id)))], 20, Color("c9d6e6"))
	ds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ds.custom_minimum_size = Vector2(240, 0)
	info.add_child(ds)
	var pr := Game.boost_price(id)
	var br := HFlowContainer.new()
	br.add_theme_constant_override("h_separation", 8)
	br.add_theme_constant_override("v_separation", 8)
	info.add_child(br)
	if Game.boost_on(id):
		br.add_child(ui._button("خرید  %d سکه" % pr, func(): _buy(id, 1), Vector2(0, 60), 22, "Gold"))
		br.add_child(ui._button("×۵  %d" % (pr * 5), func(): _buy(id, 5), Vector2(0, 60), 22, "Teal"))
	else:
		br.add_child(ui._label("فعلاً عرضه نمی‌شود", 20, Color("ff9a9a")))
	var eq := Game.in_loadout(id)
	var full := Game.loadout.size() >= Game.LOADOUT_SLOTS and not eq
	var lb: Button = ui._button("✓ همراه" if eq else "همراه کن", func():
		if full:
			say("جای ابزار همراه پر است؛ اول یکی را بردار.")
			return
		Game.set_loadout(id, not eq), Vector2(0, 60), 22, "Purple" if eq else "Dark")
	br.add_child(lb)
	return card


func _buy(id: String, qty: int) -> void:
	say("")
	await Game.buy_boost(id, qty)
	refresh()


func _upgrade_card(i: int) -> Control:
	var tint: Color = ui.POWER_UI_COLORS[i]
	var card := _card(tint)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	card.add_child(row)
	row.add_child(BoostIcon.make(POWER_KIND[i], tint, 104))
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_theme_constant_override("separation", 4)
	row.add_child(info)
	var nm: Label = ui._label(Game.POWER_NAMES[i], 30, Color.WHITE)
	info.add_child(nm)
	var ds: Label = ui._label(POWER_DESC[i], 20, Color("c9d6e6"))
	ds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ds.custom_minimum_size = Vector2(240, 0)
	info.add_child(ds)
	var lv: int = Game.levels[i]
	var pips := HBoxContainer.new()
	pips.add_theme_constant_override("separation", 6)
	for k in Game.MAX_LEVEL:
		var p := ColorRect.new()
		p.custom_minimum_size = Vector2(34, 12)
		p.color = tint if k < lv else Color(1, 1, 1, 0.18)
		pips.add_child(p)
	info.add_child(pips)
	var cur := int(Game.power_duration(i))
	var t: Label
	if lv >= Game.MAX_LEVEL:
		t = ui._label("%d ثانیه  •  حداکثر سطح" % cur, 22, Color("7dff9a"))
		info.add_child(t)
	else:
		var nxt := int(Game.POWER_BASE[i] + Game.POWER_STEP[i] * float(lv + 1))
		t = ui._label("%d ثانیه ← %d ثانیه" % [cur, nxt], 22, Color("ffd27a"))
		info.add_child(t)
		var b: Button = ui._button("ارتقا  %d سکه" % Game.upgrade_price(i), func():
			await Game.buy_upgrade(i)
			refresh(), Vector2(0, 62), 24, "Gold")
		info.add_child(b)
	return card
