class_name MiniStack
extends MiniBase
## «برج‌چینی» (سبک استک): بلوک روی برج می‌لغزد؛ با لمس رهایش کن. هرچه دقیق‌تر بیفتد بهتر؛ لبه‌ی اضافه می‌افتد.
## افتادن کامل بلوک بازی را تمام می‌کند. فاصله‌ی دقیق (کمتر از ۰٫۱) = «عالی» و کمبو.

const Gfx := preload("res://scripts/gfx.gd")
const H := 0.5

var _rng := RandomNumberGenerator.new()
var _tower: Array[Dictionary] = []     # {node, cx, cz, w, d}
var _cur: Node3D
var _cw := 3.0
var _cd := 3.0
var _ax := 0           # 0: روی x می‌لغزد، 1: روی z
var _pos := 0.0
var _dir := 1.0
var _speed := 3.2
var _cam_y := 4.0
var _floors := 0
var _perfects := 0
var _debris: Array[Dictionary] = []
var _combo := 0


func _ready() -> void:
	title = "برج‌چینی"
	hint = "لمس = رها کردن بلوک\nدقیق بیفتد، کمبو می‌گیری!"
	accent = Color("ff7a1f")
	duration = 60.0
	_rng.randomize()
	var env := make_env(Color("ff9a5a"), Color("ffe8c8"), Color("ffe0c0"), 0.006, Color("fff0e0"), 0.9)
	add_sun(Color("fff2d8"), 1.1, Vector3(-50, -35, 0))
	_build_base(env)
	stick.enabled = false
	cam.fov = 45.0
	Gfx.glow(self, Vector3(0, 8, -40), 160.0, Color(1, 0.8, 0.5, 0.2))
	_env = env
	_build_scenery()
	_add_block(0.0, 0.0, 3.0, 3.0, 0, false)
	_new_slider()
	_update_cam(1.0)


var _env: Environment
var _clouds: Array[Node3D] = []
var _stars: Array[Node3D] = []
var _hue := 0.07


## ستون پایه + ابرهای شناور + ستاره‌ها (با بالا رفتن برج آسمان تیره‌تر و پرستاره می‌شود)
func _build_scenery() -> void:
	# پایه‌ی سنگی زیر برج
	Gfx.box(self, Vector3(4.6, 40.0, 4.6), Vector3(0, -20.0 - H * 0.5, 0), Modes.P.m("4a3a5a", 0.0, 0.8, 0.0))
	Gfx.box(self, Vector3(5.2, 0.5, 5.2), Vector3(0, -H * 0.5 - 0.25, 0), Modes.P.m("6a5a7a", 0.0, 0.7, 0.0))
	var wm := Modes.P.m("ffffff", 0.35, 0.9, 0.0)
	for i in 26:
		var c := Node3D.new()
		var a := deg_to_rad(225.0 + _rng.randf_range(-85.0, 85.0))
		var rad := _rng.randf_range(10.0, 26.0)
		c.set_meta("dy", _rng.randf_range(-7.0, 9.0))
		c.position = Vector3(cos(a) * rad, 0.0, sin(a) * rad)
		for k in 3:
			Gfx.sphere(c, _rng.randf_range(1.2, 2.2), Vector3(k * 1.6 - 1.6, _rng.randf_range(-0.2, 0.3), 0), wm, 8).scale = Vector3(1.4, 0.7, 1.0)
		add_child(c)
		_clouds.append(c)
	var sm := Modes.P.m("ffffff", 3.0, 0.5, 0.0)
	for i in 70:
		var a2 := deg_to_rad(225.0 + _rng.randf_range(-70.0, 70.0))
		var rad2 := _rng.randf_range(24.0, 40.0)
		var st := Gfx.sphere(self, 0.12, Vector3(cos(a2) * rad2, 0.0, sin(a2) * rad2), sm, 4)
		st.set_meta("dy", _rng.randf_range(2.0, 16.0))
		_stars.append(st)


func _m(hex: String) -> StandardMaterial3D:
	return Modes.P.m(hex, 0.12, 0.4, 0.0)


func _col(i: int) -> String:
	return Color.from_hsv(fmod(0.02 + i * 0.045, 1.0), 0.55, 0.98).to_html(false)


func _add_block(cx: float, cz: float, w: float, d: float, idx: int, add_to_tower: bool = true) -> Node3D:
	var n := Node3D.new()
	var mi := Gfx.box(n, Vector3(w, H, d), Vector3.ZERO, _m(_col(idx)))
	mi.name = "b"
	n.position = Vector3(cx, idx * H, cz)
	add_child(n)
	if add_to_tower:
		_tower.append({"node": n, "cx": cx, "cz": cz, "w": w, "d": d})
	else:
		_tower.append({"node": n, "cx": cx, "cz": cz, "w": w, "d": d})
	return n


func _new_slider() -> void:
	var top: Dictionary = _tower[_tower.size() - 1]
	_cw = float(top["w"])
	_cd = float(top["d"])
	_cur = Node3D.new()
	Gfx.box(_cur, Vector3(_cw, H, _cd), Vector3.ZERO, _m(_col(_tower.size())))
	_pos = -5.0
	_dir = 1.0
	_ax = _tower.size() % 2
	add_child(_cur)
	_place_cur()


func _place_cur() -> void:
	var top: Dictionary = _tower[_tower.size() - 1]
	var y := float(_tower.size()) * H
	if _ax == 0:
		_cur.position = Vector3(float(top["cx"]) + _pos, y, float(top["cz"]))
	else:
		_cur.position = Vector3(float(top["cx"]), y, float(top["cz"]) + _pos)


func _input(event: InputEvent) -> void:
	if not running or _cur == null:
		return
	var press := false
	if event is InputEventScreenTouch and event.pressed:
		press = true
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		press = true
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_SPACE:
		press = true
	if press:
		_drop()


func _drop() -> void:
	var top: Dictionary = _tower[_tower.size() - 1]
	var delta_off := _pos
	var size_along := _cw if _ax == 0 else _cd
	var overlap := size_along - absf(delta_off)
	if overlap <= 0.0:
		# کامل از دست رفت
		_spawn_debris(_cur.position, Vector3(_cw, H, _cd), _col(_tower.size()))
		_cur.queue_free()
		_cur = null
		say("برج افتاد! %d طبقه" % _floors, 1.2)
		finish()
		return
	var perfect := absf(delta_off) < 0.1
	var cx := float(top["cx"])
	var cz := float(top["cz"])
	var nw := _cw
	var nd := _cd
	if perfect:
		_perfects += 1
		_combo += 1
		say("عالی! ×%d" % _combo, 0.6)
		add_coins(1 + mini(_combo, 4))
	else:
		_combo = 0
		if _ax == 0:
			nw = overlap
			cx = float(top["cx"]) + delta_off * 0.5
			var cut_w := absf(delta_off)
			_spawn_debris(Vector3(float(top["cx"]) + delta_off * 0.5 + signf(delta_off) * (overlap * 0.5 + cut_w * 0.5), _cur.position.y, cz), Vector3(cut_w, H, _cd), _col(_tower.size()))
		else:
			nd = overlap
			cz = float(top["cz"]) + delta_off * 0.5
			var cut_d := absf(delta_off)
			_spawn_debris(Vector3(cx, _cur.position.y, float(top["cz"]) + delta_off * 0.5 + signf(delta_off) * (overlap * 0.5 + cut_d * 0.5)), Vector3(_cw, H, cut_d), _col(_tower.size()))
		add_coins(1)
	_cur.queue_free()
	_cur = null
	_floors += 1
	_add_block(cx, cz, nw, nd, _tower.size())
	_speed = minf(3.2 + _floors * 0.14, 8.5)
	if _floors == 15:
		bonus += 20
		say("۱۵ طبقه! پاداش +۲۰", 1.0)
	_new_slider()


func _spawn_debris(pos: Vector3, size: Vector3, hex: String) -> void:
	var n := Node3D.new()
	Gfx.box(n, size, Vector3.ZERO, _m(hex))
	n.position = pos
	add_child(n)
	_debris.append({"node": n, "vy": 0.0, "life": 1.6})


func _update_cam(k: float) -> void:
	var ty := 4.0 + float(_tower.size()) * H
	_cam_y = lerpf(_cam_y, ty, k)
	cam.position = Vector3(9.0, _cam_y + 5.5, 9.0)
	cam.look_at(Vector3(0, _cam_y - 1.0, 0), Vector3.UP)


func _tick(delta: float) -> void:
	for c in _clouds:
		c.position.x += delta * 0.8
		if c.position.x > 26.0:
			c.position.x = -26.0
		c.position.y = _cam_y + float(c.get_meta("dy"))
	for st in _stars:
		st.position.y = _cam_y + float(st.get_meta("dy"))
	if _env != null and _env.sky != null:
		var f := clampf(float(_floors) / 40.0, 0.0, 1.0)
		var sm: ProceduralSkyMaterial = _env.sky.sky_material
		sm.sky_top_color = Color("ff9a5a").lerp(Color("120a3a"), f)
		sm.sky_horizon_color = Color("ffe8c8").lerp(Color("6a3a9a"), f)
		sm.ground_horizon_color = sm.sky_horizon_color
		_env.fog_light_color = Color("ffe0c0").lerp(Color("3a1f6a"), f)
	if _cur != null:
		var top: Dictionary = _tower[_tower.size() - 1]
		var lim := 4.6
		_pos += _dir * _speed * delta
		if _pos > lim:
			_pos = lim
			_dir = -1.0
		elif _pos < -lim:
			_pos = -lim
			_dir = 1.0
		_place_cur()
		if top.is_empty():
			return
	for i in range(_debris.size() - 1, -1, -1):
		var d: Dictionary = _debris[i]
		var n: Node3D = d["node"]
		d["vy"] = float(d["vy"]) - 22.0 * delta
		n.position.y += float(d["vy"]) * delta
		n.rotation_degrees.z += 90.0 * delta
		d["life"] = float(d["life"]) - delta
		if float(d["life"]) <= 0.0:
			n.queue_free()
			_debris.remove_at(i)
	_update_cam(1.0 - exp(-3.0 * delta))
