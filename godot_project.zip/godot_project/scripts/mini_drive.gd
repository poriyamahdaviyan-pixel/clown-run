class_name MiniDrive
extends MiniBase
## «رانندگی شهر باز»: یک شهر کوچک آزاد؛ با آنالوگ رانندگی کن، سکه و جعبه جمع کن، نیترو بگیر و به ترافیک نخور.
## آنالوگ: بالا = گاز، پایین = ترمز/دنده‌عقب، چپ/راست = فرمان (دریفت دارد).

const P := 42.0           # دوره‌ی شبکه‌ی خیابان
const HALF := 100.0       # مرز شهر
const MAX_SPEED := 30.0

var car: Node3D
var pos := Vector2(21, 50)
var yaw := 0.0
var vel := Vector2.ZERO
var nitro := 0.0
var shake := 0.0
var _rects: Array[Rect2] = []
var _coins: Array[Dictionary] = []
var _crates: Array[Dictionary] = []
var _pads: Array[Vector2] = []
var _npcs: Array[Dictionary] = []
var _rng := RandomNumberGenerator.new()
var _smoke: CPUParticles3D
var _cam_yaw := 0.0
var _hit_cd := 0.0


func _ready() -> void:
	title = "رانندگی شهر باز"
	hint = "آنالوگ: گاز/ترمز و فرمان\nسکه و جعبه بگیر، به ماشین‌ها نخور!"
	accent = Color("27e8ff")
	duration = 45.0
	_rng.seed = 4242
	var env := make_env(Color("1a2b6b"), Color("ff9f6b"), Color("f2b88a"), 0.006, Color("9aa6e8"), 0.55)
	add_sun(Color("fff0d0"), 1.0, Vector3(-50, -35, 0))
	_build_city()
	_build_car()
	_build_collectibles()
	_build_npcs()
	_build_base(env)
	_build_radar()
	_update_camera(1.0)


func _m(hex: String, emit: float = 0.0, rough: float = 0.6, metal: float = 0.0) -> StandardMaterial3D:
	return Modes.P.m(hex, emit, rough, metal)


func _box(parent: Node3D, size: Vector3, p: Vector3, mat: Material) -> MeshInstance3D:
	return Modes.Gfx.box(parent, size, p, mat)


# ------------------------------------------------------------ ساخت شهر
func _build_city() -> void:
	var ground := _box(self, Vector3(300, 0.2, 300), Vector3(0, -0.1, 0), _m("2b2e38", 0.0, 0.9))
	ground.name = "ground"
	var cols: Array[String] = ["3c4a6b", "5a3c6b", "6b4a3c", "3c6b5a", "4a4a5e", "6b3c4a"]
	for ix in range(-2, 3):
		for iz in range(-2, 3):
			var c := Vector3(ix * P, 0, iz * P)
			var kind := _rng.randi() % 6
			_box(self, Vector3(30, 0.3, 30), Vector3(c.x, 0.05, c.z), _m("7a7f8c", 0.0, 0.9))
			if kind == 0:
				# پارک
				_box(self, Vector3(28, 0.32, 28), Vector3(c.x, 0.06, c.z), _m("3f9a4a", 0.0, 0.9))
				for k in 7:
					var tp := Vector3(c.x + _rng.randf_range(-12, 12), 0, c.z + _rng.randf_range(-12, 12))
					Modes.Gfx.cyl(self, 0.3, 0.4, 3.0, tp + Vector3(0, 1.5, 0), _m("7a4a22"), Vector3.ZERO, 6)
					Modes.Gfx.sphere(self, 1.7, tp + Vector3(0, 3.8, 0), _m("2f9a3a"), 8)
					_rects.append(Rect2(tp.x - 0.5, tp.z - 0.5, 1.0, 1.0))
			elif kind == 1:
				# میدان با فواره و پله
				_box(self, Vector3(12, 0.5, 12), Vector3(c.x, 0.25, c.z), _m("9aa0ad", 0.0, 0.8))
				Modes.Gfx.cyl(self, 2.0, 2.0, 1.2, Vector3(c.x, 1.0, c.z), _m("27e8ff", 1.2, 0.2), Vector3.ZERO, 14)
				_rects.append(Rect2(c.x - 2.2, c.z - 2.2, 4.4, 4.4))
			else:
				# چهار ساختمان
				for sx in [-1, 1]:
					for sz in [-1, 1]:
						var w := _rng.randf_range(10.0, 13.0)
						var d := _rng.randf_range(10.0, 13.0)
						var h := _rng.randf_range(8.0, 30.0)
						var bp := Vector3(c.x + sx * 7.5, h * 0.5, c.z + sz * 7.5)
						var bc: String = cols[_rng.randi() % cols.size()]
						_box(self, Vector3(w, h, d), bp, _m(bc, 0.0, 0.6, 0.15))
						var neon: String = ["ff2d95", "27e8ff", "ffd23f", "3dff9a"][_rng.randi() % 4]
						for f in int(h / 4.0):
							_box(self, Vector3(w + 0.05, 0.25, d + 0.05), Vector3(bp.x, 2.0 + f * 4.0, bp.z), _m(neon, 1.4, 0.4))
						_box(self, Vector3(w + 0.3, 0.4, d + 0.3), Vector3(bp.x, h + 0.2, bp.z), _m("1a1c26"))
						_rects.append(Rect2(bp.x - w * 0.5, bp.z - d * 0.5, w, d))
	# خط‌های وسط خیابان
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var bm := BoxMesh.new()
	bm.size = Vector3(0.35, 0.02, 3.0)
	mm.mesh = bm
	var lines: Array[Transform3D] = []
	for r in range(-2, 2):
		var line := (float(r) + 0.5) * P
		var t := -HALF
		while t < HALF:
			lines.append(Transform3D(Basis(), Vector3(line, 0.02, t)))
			lines.append(Transform3D(Basis(Vector3.UP, PI * 0.5), Vector3(t, 0.02, line)))
			t += 6.0
	mm.instance_count = lines.size()
	for i in lines.size():
		mm.set_instance_transform(i, lines[i])
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = _m("f4e9a0", 0.6)
	add_child(mi)
	# پدهای نیترو
	for k in 6:
		var rp := _road_point()
		_pads.append(rp)
		_box(self, Vector3(3.0, 0.05, 5.0), Vector3(rp.x, 0.05, rp.y), _m("27e8ff", 2.2, 0.3))
		_box(self, Vector3(2.2, 0.06, 0.5), Vector3(rp.x, 0.08, rp.y - 1.0), _m("ffffff", 2.4))


## نقطه‌ی تصادفی روی یکی از خیابان‌ها
func _road_point() -> Vector2:
	var line := (float(_rng.randi_range(-2, 1)) + 0.5) * P
	var along := _rng.randf_range(-HALF + 8.0, HALF - 8.0)
	if _rng.randf() < 0.5:
		return Vector2(line + _rng.randf_range(-3.0, 3.0), along)
	return Vector2(along, line + _rng.randf_range(-3.0, 3.0))


func _build_car() -> void:
	car = _make_car("ff2d95", true)
	add_child(car)
	_smoke = CPUParticles3D.new()
	_smoke.amount = 40
	_smoke.lifetime = 0.7
	_smoke.emitting = false
	_smoke.direction = Vector3(0, 1, 0)
	_smoke.spread = 40.0
	_smoke.initial_velocity_min = 0.5
	_smoke.initial_velocity_max = 2.0
	_smoke.scale_amount_min = 0.3
	_smoke.scale_amount_max = 0.9
	var sm := SphereMesh.new()
	sm.radius = 0.3
	sm.height = 0.6
	sm.radial_segments = 6
	sm.rings = 3
	_smoke.mesh = sm
	_smoke.material_override = _m("dcdce6", 0.0, 1.0)
	_smoke.position = Vector3(0, 0.3, 1.5)
	car.add_child(_smoke)


func _make_car(col: String, hero: bool) -> Node3D:
	var n := Node3D.new()
	_box(n, Vector3(1.9, 0.6, 4.0), Vector3(0, 0.62, 0), _m(col, 0.0, 0.25, 0.5))
	_box(n, Vector3(1.6, 0.55, 2.0), Vector3(0, 1.17, 0.2), _m("10131c", 0.0, 0.15, 0.3))
	_box(n, Vector3(1.5, 0.08, 0.1), Vector3(0, 0.82, -2.0), _m("fff6c8", 3.0))
	_box(n, Vector3(1.5, 0.08, 0.1), Vector3(0, 0.82, 2.0), _m("ff2a2a", 3.0))
	for sx in [-0.98, 0.98]:
		for sz in [-1.3, 1.3]:
			Modes.Gfx.cyl(n, 0.4, 0.4, 0.3, Vector3(sx, 0.4, sz), _m("0c0c0e", 0.0, 0.9), Vector3(0, 0, 90), 10)
	if hero:
		_box(n, Vector3(1.92, 0.06, 3.8), Vector3(0, 0.1, 0), _m("27e8ff", 1.6))
		_box(n, Vector3(0.12, 0.35, 1.2), Vector3(-0.7, 1.15, 1.8), _m("1a1a22"))
		_box(n, Vector3(0.12, 0.35, 1.2), Vector3(0.7, 1.15, 1.8), _m("1a1a22"))
		_box(n, Vector3(1.7, 0.08, 0.5), Vector3(0, 1.38, 1.9), _m("ff2d95", 0.6))
	return n


func _build_collectibles() -> void:
	for i in 70:
		var p := _road_point()
		var big := i % 11 == 0
		var node := Node3D.new()
		node.position = Vector3(p.x, 1.4 if not big else 1.8, p.y)
		var r := 0.6 if not big else 1.0
		Modes.Gfx.cyl(node, r, r, 0.14, Vector3.ZERO, _m("ffcf2e" if not big else "ff4d6d", 1.4, 0.25, 0.7), Vector3(90, 0, 0), 14)
		Modes.Gfx.cyl(node, r * 0.55, r * 0.55, 0.16, Vector3.ZERO, _m("fff3b0", 1.0), Vector3(90, 0, 0), 12)
		add_child(node)
		_coins.append({"node": node, "pos": p, "val": 5 if big else 1})
	for i in 14:
		var p := _road_point()
		var node := Node3D.new()
		node.position = Vector3(p.x, 0, p.y)
		_box(node, Vector3(1.8, 1.8, 1.8), Vector3(0, 0.9, 0), _m("c8873a", 0.0, 0.8))
		_box(node, Vector3(1.9, 0.18, 1.9), Vector3(0, 0.09, 0), _m("7a4a1c"))
		_box(node, Vector3(1.9, 0.18, 1.9), Vector3(0, 1.71, 0), _m("7a4a1c"))
		add_child(node)
		_crates.append({"node": node, "pos": p})


func _build_npcs() -> void:
	var cols: Array[String] = ["e3342f", "2f7fe0", "f6c915", "20c8c0", "ffffff", "8a4fd0"]
	for i in 12:
		var line := (float(_rng.randi_range(-2, 1)) + 0.5) * P
		var horiz := i % 2 == 0
		var dir := 1.0 if _rng.randf() < 0.5 else -1.0
		var off := 3.0 * dir
		var n := _make_car(cols[i % cols.size()], false)
		add_child(n)
		_npcs.append({"node": n, "line": line, "horiz": horiz, "dir": dir, "off": off, "t": _rng.randf_range(-HALF, HALF), "spd": _rng.randf_range(7.0, 13.0)})


func _build_radar() -> void:
	_radar = Control.new()
	_radar.custom_minimum_size = Vector2(150, 150)
	_radar.size = Vector2(150, 150)
	_radar.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	_radar.position = Vector2(-170, -190)
	_radar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_radar.draw.connect(_draw_radar)
	_hud.add_child(_radar)


func _draw_radar() -> void:
	var c := Vector2(75, 75)
	_radar.draw_circle(c, 74.0, Color(0.03, 0.03, 0.1, 0.65))
	_radar.draw_arc(c, 74.0, 0, TAU, 40, accent, 3.0)
	var k := 0.55
	for cd in _coins:
		if not is_instance_valid(cd.node) or not cd.node.visible:
			continue
		var d: Vector2 = (cd.pos as Vector2) - pos
		d = d.rotated(yaw)      # بالا = جلوی ماشین
		d *= k
		if d.length() < 70.0:
			_radar.draw_circle(c + d, 3.0 if cd.val == 1 else 5.0, Color("ffd23f") if cd.val == 1 else Color("ff4d6d"))
	for n in _npcs:
		var d2: Vector2 = Vector2(n.node.position.x, n.node.position.z) - pos
		d2 = d2.rotated(yaw) * k
		if d2.length() < 70.0:
			_radar.draw_circle(c + d2, 3.5, Color("ff5050"))
	_radar.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -8), c + Vector2(6, 6), c + Vector2(-6, 6)]), Color.WHITE)


# ------------------------------------------------------------ منطق
func _tick(delta: float) -> void:
	var s := stick.get_vector()
	var f := Vector2(-sin(yaw), -cos(yaw))
	var r := Vector2(-f.y, f.x)   # راست ماشین
	var speed := vel.dot(f)
	var lat := vel.dot(r)
	var throttle := clampf(-s.y * 1.25, -0.7, 1.0)
	var steer := clampf(s.x * 1.3, -1.0, 1.0)
	var top := MAX_SPEED + (14.0 if nitro > 0.0 else 0.0)
	if throttle > 0.0:
		speed += throttle * (30.0 + (30.0 if nitro > 0.0 else 0.0)) * delta
	elif throttle < 0.0:
		speed += throttle * (46.0 if speed > 0.5 else 14.0) * delta
	else:
		speed = move_toward(speed, 0.0, 9.0 * delta)
	speed = clampf(speed, -9.0, top)
	var turn := steer * 2.3 * clampf(absf(speed) / 9.0, 0.0, 1.0) * (1.0 if speed >= 0.0 else -1.0)
	yaw -= turn * delta
	f = Vector2(-sin(yaw), -cos(yaw))
	r = Vector2(-f.y, f.x)
	lat = lerpf(lat, 0.0, 1.0 - exp(-4.5 * delta))
	vel = f * speed + r * lat
	pos += vel * delta
	nitro = maxf(0.0, nitro - delta)
	_hit_cd = maxf(0.0, _hit_cd - delta)
	shake = maxf(0.0, shake - delta * 2.5)
	_collide_world()
	_collect()
	_move_npcs(delta)
	car.position = Vector3(pos.x, 0.0, pos.y)
	car.rotation.y = yaw
	car.rotation.z = clampf(-lat * 0.02, -0.15, 0.15)
	_smoke.emitting = absf(lat) > 3.0 and absf(speed) > 8.0
	_update_camera(delta)


func _collide_world() -> void:
	for rc in _rects:
		var cx := clampf(pos.x, rc.position.x, rc.end.x)
		var cz := clampf(pos.y, rc.position.y, rc.end.y)
		var d := pos - Vector2(cx, cz)
		var dist := d.length()
		if dist < 1.5:
			var n := d.normalized() if dist > 0.001 else Vector2(0, 1)
			pos += n * (1.5 - dist)
			var vn := vel.dot(n)
			if vn < 0.0:
				if vn < -8.0:
					shake = 0.6
					say("بوم!", 0.5)
				vel -= n * vn * 1.4
				vel *= 0.85
	if absf(pos.x) > HALF:
		pos.x = clampf(pos.x, -HALF, HALF)
		vel.x *= -0.4
	if absf(pos.y) > HALF:
		pos.y = clampf(pos.y, -HALF, HALF)
		vel.y *= -0.4


func _collect() -> void:
	for cd in _coins:
		if cd.node.visible and pos.distance_to(cd.pos) < 2.4:
			cd.node.visible = false
			add_coins(int(cd.val))
	for cr in _crates:
		if cr.node.visible and pos.distance_to(cr.pos) < 2.3:
			cr.node.visible = false
			var spd := vel.length()
			add_coins(3)
			bonus += 40
			say("جعبه شکست! +3", 0.7)
			shake = maxf(shake, 0.25)
			vel *= 0.92
	for pd in _pads:
		if pos.distance_to(pd) < 3.4 and nitro < 0.5:
			nitro = 2.5
			say("نیترو!", 0.8)


func _move_npcs(delta: float) -> void:
	for n in _npcs:
		n.t += float(n.dir) * float(n.spd) * delta
		if n.t > HALF:
			n.t = -HALF
		elif n.t < -HALF:
			n.t = HALF
		var p: Vector2 = Vector2(n.line + n.off, n.t) if not n.horiz else Vector2(n.t, n.line + n.off)
		var node: Node3D = n.node
		node.position = Vector3(p.x, 0.0, p.y)
		node.rotation.y = (PI if n.dir > 0.0 else 0.0) if not n.horiz else (PI * 0.5 if n.dir > 0.0 else -PI * 0.5)
		if _hit_cd <= 0.0 and p.distance_to(pos) < 2.7:
			_hit_cd = 1.0
			var away := (pos - p).normalized()
			vel = away * maxf(vel.length(), 8.0) * 0.8
			shake = 0.8
			time_left = maxf(time_left - 2.0, 0.0)
			say("تصادف! -۲ ثانیه", 0.9)


func _update_camera(delta: float) -> void:
	_cam_yaw = lerp_angle(_cam_yaw, yaw, 1.0 - exp(-4.0 * delta))
	var back := Vector3(sin(_cam_yaw), 0, cos(_cam_yaw))
	var sp := vel.length()
	var dist := 12.0 + sp * 0.14
	var target := Vector3(pos.x, 0.0, pos.y)
	var want := target + back * dist + Vector3(0, 6.8 + sp * 0.04, 0)
	var off := Vector3(randf() - 0.5, randf() - 0.5, 0.0) * shake * 0.5
	cam.position = cam.position.lerp(want, 1.0 - exp(-8.0 * delta)) if cam.position != Vector3.ZERO else want
	cam.position += off
	cam.look_at(target + Vector3(0, 1.2, 0) - back * 6.0, Vector3.UP)
	cam.fov = lerpf(cam.fov, 62.0 + clampf(sp, 0.0, 44.0) * 0.55 + (8.0 if nitro > 0.0 else 0.0), 1.0 - exp(-4.0 * delta))
