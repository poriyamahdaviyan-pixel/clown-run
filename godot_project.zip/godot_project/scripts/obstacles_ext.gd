extends RefCounted
## موانع تکمیلی (واقع‌گرایانه‌تر) برای هر شش محیط. ابعاد با Track هماهنگ است:
##   LOW  : پرش لازم، ارتفاع ≤ ۰٫۹، عرض ≈ ۱٫۹        OVER : سُرخوردن لازم، زیر ۱٫۰ باز
##   FULL : تا ۲٫۸ متر، عمق ≈ ۲٫۶ (باید لِین عوض کرد یا پرید)
## محیط‌ها: 0 شهر، 1 صحرا، 2 جنگل، 3 کوهستان برفی، 4 بندر شبانه، 5 آتشفشان

const Gfx := preload("res://scripts/gfx.gd")
const P := preload("res://scripts/props.gd")

static var _rng := RandomNumberGenerator.new()


static func _box(n: Node3D, s: Vector3, p: Vector3, m: Material, r: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	return Gfx.box(n, s, p, m, r)


static func _cyl(n: Node3D, rt: float, rb: float, h: float, p: Vector3, m: Material, r: Vector3 = Vector3.ZERO, seg: int = 12) -> MeshInstance3D:
	return Gfx.cyl(n, rt, rb, h, p, m, r, seg)


static func _sph(n: Node3D, r: float, p: Vector3, m: Material, scale: Vector3 = Vector3.ONE, seg: int = 10) -> MeshInstance3D:
	var s := Gfx.sphere(n, r, p, m, seg)
	s.scale = scale
	return s


static func _cone(n: Node3D, r: float, h: float, p: Vector3, m: Material, seg: int = 8) -> MeshInstance3D:
	return Gfx.cyl(n, 0.001, r, h, p + Vector3(0, h * 0.5, 0), m, Vector3.ZERO, seg)


static func _wheels(n: Node3D, xs: Array, zs: Array, r: float) -> void:
	var rub := P.m("151517", 0.0, 0.9)
	var rim := P.m("b5bcc4", 0.0, 0.3, 0.9)
	for sx in xs:
		for sz in zs:
			_cyl(n, r, r, 0.26, Vector3(sx, r, sz), rub, Vector3(0, 0, 90), 14)
			_cyl(n, r * 0.52, r * 0.52, 0.28, Vector3(sx, r, sz), rim, Vector3(0, 0, 90), 8)


# =============================================================
#                          LOW  (پرش)
# =============================================================
static func low(zone: int, v: int, n: Node3D) -> void:
	_rng.randomize()
	match zone:
		0:
			if v == 4: _tires(n)
			else: _pallet_sacks(n)
		1:
			if v == 4: _barrels(n, "9a4a22")
			else: _sandbags(n, "c9a56a")
		2:
			if v == 4: _stone_blocks(n)
			else: _stump(n)
		3:
			match v % 6:
				0: _snow_mound(n)
				1: _ice_blocks(n)
				2: _sled(n)
				3: _snow_fence(n)
				4: _snow_crates(n)
				_: _snowman(n)
		4:
			match v % 6:
				0: _bollard(n)
				1: _pallet_sacks(n)
				2: _tires(n)
				3: _buoys(n)
				4: _fish_crates(n)
				_: _barrels(n, "2a6fb0")
		_:
			match v % 6:
				0: _lava_rocks(n, 4)
				1: _obsidian_shards(n)
				2: _steam_vent(n)
				3: _charred_logs(n)
				4: _lava_rocks(n, 6)
				_: _cracked_slab(n)


static func _tires(n: Node3D) -> void:
	var rub := P.m("1a1a1c", 0.0, 0.95)
	var wall := P.m("3a3a3e", 0.0, 0.9)
	for sx in [-0.5, 0.5]:
		for i in 3:
			P.torus(n, 0.42, 0.2, Vector3(sx + (0.04 if i == 1 else 0.0), 0.12 + i * 0.25, 0.0), rub if i % 2 == 0 else wall, Vector3.ZERO, 14)
	_box(n, Vector3(0.9, 0.1, 0.5), Vector3(0.0, 0.05, 0.0), P.m("5a3a1c"))
	_box(n, Vector3(0.7, 0.04, 0.04), Vector3(0, 0.82, 0.3), P.m("f2c200", 0.6))


static func _pallet_sacks(n: Node3D) -> void:
	var wood := P.m("a97a3e", 0.0, 0.9)
	var sack := P.m("d8c9a0", 0.0, 0.95)
	for k in 2:
		var y := 0.08 + k * 0.5
		_box(n, Vector3(1.8, 0.07, 0.9), Vector3(0, y, 0), wood)
		for sx in [-0.8, 0.0, 0.8]:
			_box(n, Vector3(0.2, 0.12, 0.9), Vector3(sx, y - 0.08, 0), wood)
	for i in 3:
		_sph(n, 0.34, Vector3(-0.58 + i * 0.58, 0.32, 0.0), sack, Vector3(1.0, 0.7, 1.15), 8)
	for i in 2:
		_sph(n, 0.34, Vector3(-0.3 + i * 0.6, 0.72, 0.0), sack, Vector3(1.0, 0.65, 1.1), 8)
	_box(n, Vector3(0.3, 0.1, 0.02), Vector3(-0.3, 0.74, 0.37), P.m("c0392b"))


static func _barrels(n: Node3D, hex: String) -> void:
	var body := P.m(hex, 0.0, 0.55, 0.5)
	var band := P.m("2e2a28", 0.0, 0.6, 0.6)
	for i in 2:
		var x := -0.5 + i * 1.0
		_cyl(n, 0.3, 0.3, 0.85, Vector3(x, 0.43, 0.0), body, Vector3.ZERO, 14)
		for by in [0.15, 0.42, 0.7]:
			_cyl(n, 0.31, 0.31, 0.05, Vector3(x, by, 0.0), band, Vector3.ZERO, 14)
		_cyl(n, 0.26, 0.26, 0.03, Vector3(x, 0.86, 0.0), band, Vector3.ZERO, 14)
	_box(n, Vector3(0.9, 0.05, 0.05), Vector3(0, 0.55, 0.34), P.m("f5c518", 0.5))


static func _sandbags(n: Node3D, hex: String) -> void:
	var m := P.m(hex, 0.0, 0.95)
	var m2 := P.m("b8935a", 0.0, 0.95)
	for row in 3:
		var cnt := 3 if row < 2 else 2
		for i in cnt:
			var x := -0.62 + i * 0.62 + (0.31 if row % 2 == 1 and row < 2 else 0.0) + (0.15 if row == 2 else 0.0)
			_sph(n, 0.32, Vector3(x, 0.15 + row * 0.24, 0.0), m if (i + row) % 2 == 0 else m2, Vector3(1.0, 0.55, 0.9), 8)


static func _stone_blocks(n: Node3D) -> void:
	var st := P.m("8c9183", 0.0, 0.95)
	var moss := P.m("4f7d3c", 0.0, 1.0)
	_box(n, Vector3(1.0, 0.55, 0.8), Vector3(-0.45, 0.28, 0.0), st, Vector3(0, 4, 0))
	_box(n, Vector3(0.9, 0.5, 0.8), Vector3(0.5, 0.25, 0.1), st, Vector3(0, -6, 0))
	_box(n, Vector3(0.8, 0.4, 0.7), Vector3(0.05, 0.72, 0.0), st, Vector3(0, 12, 0))
	_sph(n, 0.45, Vector3(-0.5, 0.58, 0.0), moss, Vector3(1.0, 0.25, 0.8), 8)
	_box(n, Vector3(0.04, 0.3, 0.3), Vector3(0.05, 0.72, 0.36), P.m("5a6a52"))


static func _stump(n: Node3D) -> void:
	var bark := P.m("5a3d22", 0.0, 1.0)
	var cut := P.m("c99a5e", 0.0, 0.9)
	_cyl(n, 0.5, 0.62, 0.8, Vector3(0, 0.4, 0), bark, Vector3.ZERO, 12)
	_cyl(n, 0.46, 0.46, 0.03, Vector3(0, 0.81, 0), cut, Vector3.ZERO, 12)
	for k in 4:
		var a := k * TAU / 4.0 + 0.4
		_box(n, Vector3(0.2, 0.18, 0.7), Vector3(cos(a) * 0.55, 0.1, sin(a) * 0.4), bark, Vector3(0, -rad_to_deg(a), 0))
	_sph(n, 0.4, Vector3(0.3, 0.8, 0.0), P.m("4f8d3a", 0.0, 1.0), Vector3(1.2, 0.35, 0.8), 8)


static func _snow_mound(n: Node3D) -> void:
	var snow := P.m("f2f7ff", 0.1, 0.95)
	_sph(n, 0.7, Vector3(-0.35, 0.2, 0), snow, Vector3(1.3, 0.8, 0.8), 10)
	_sph(n, 0.6, Vector3(0.45, 0.15, 0.05), snow, Vector3(1.2, 0.75, 0.8), 10)
	for k in 3:
		_cyl(n, 0.012, 0.02, 0.5, Vector3(-0.2 + k * 0.25, 0.7, 0.0), P.m("4a3220"), Vector3(0, 0, -15 + k * 15), 5)


static func _ice_blocks(n: Node3D) -> void:
	var ice := P.m("9edcff", 0.35, 0.12, 0.15)
	var ice2 := P.m("c6efff", 0.3, 0.1, 0.1)
	_box(n, Vector3(0.9, 0.7, 0.7), Vector3(-0.45, 0.35, 0), ice, Vector3(0, 10, 4))
	_box(n, Vector3(0.7, 0.85, 0.6), Vector3(0.5, 0.42, 0.05), ice2, Vector3(0, -14, -5))
	_box(n, Vector3(0.5, 0.4, 0.5), Vector3(0.0, 0.9, 0.0), ice, Vector3(20, 25, 10))
	Gfx.glow(n, Vector3(0, 0.6, 0.4), 1.5, Color(0.6, 0.9, 1.0, 0.25))


static func _sled(n: Node3D) -> void:
	var wood := P.m("9a6a38", 0.0, 0.85)
	var iron := P.m("3a3f46", 0.0, 0.4, 0.8)
	_box(n, Vector3(1.4, 0.07, 0.8), Vector3(0, 0.42, 0), wood, Vector3(0, 0, 18))
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.06, 0.07, 1.3), Vector3(s * 0.4, 0.12, 0), iron)
		_box(n, Vector3(0.06, 0.45, 0.06), Vector3(s * 0.4, 0.3, -0.5), iron)
		_box(n, Vector3(0.06, 0.45, 0.06), Vector3(s * 0.4, 0.3, 0.5), iron)
	_box(n, Vector3(1.5, 0.12, 0.35), Vector3(0, 0.5, 0.0), P.m("f2f7ff", 0.1, 0.95))


static func _snow_fence(n: Node3D) -> void:
	var wood := P.m("8a6a44", 0.0, 0.9)
	var snow := P.m("f2f7ff", 0.1, 0.95)
	for x in [-0.85, 0.0, 0.85]:
		_box(n, Vector3(0.12, 0.85, 0.12), Vector3(x, 0.42, 0), wood)
		_box(n, Vector3(0.16, 0.06, 0.16), Vector3(x, 0.86, 0), snow)
	for y in [0.3, 0.62]:
		_box(n, Vector3(1.9, 0.1, 0.06), Vector3(0, y, 0), wood)
		_box(n, Vector3(1.9, 0.05, 0.08), Vector3(0, y + 0.07, 0), snow)
	_box(n, Vector3(0.5, 0.25, 0.03), Vector3(0.0, 0.47, 0.09), P.m("d93a2f", 0.2))


static func _snow_crates(n: Node3D) -> void:
	var crate := Gfx.mat(Color.WHITE, 0.0, Gfx.crate_tex(), 0.85)
	var snow := P.m("f2f7ff", 0.1, 0.95)
	_box(n, Vector3(0.85, 0.85, 0.8), Vector3(-0.5, 0.42, 0), crate)
	_box(n, Vector3(0.85, 0.85, 0.8), Vector3(0.5, 0.42, 0), crate, Vector3(0, 7, 0))
	_sph(n, 0.5, Vector3(-0.5, 0.86, 0), snow, Vector3(1.0, 0.25, 0.9), 8)
	_sph(n, 0.5, Vector3(0.5, 0.86, 0), snow, Vector3(1.0, 0.25, 0.9), 8)


static func _snowman(n: Node3D) -> void:
	var snow := P.m("f7faff", 0.1, 0.95)
	var coal := P.m("1a1a1a", 0.0, 0.9)
	var h := Node3D.new()
	h.scale = Vector3.ONE * 0.62
	n.add_child(h)
	_sph(h, 0.55, Vector3(0, 0.5, 0), snow, Vector3.ONE, 12)
	_sph(h, 0.4, Vector3(0, 1.2, 0), snow, Vector3.ONE, 12)
	_sph(h, 0.28, Vector3(0, 1.75, 0), snow, Vector3.ONE, 12)
	_cone(h, 0.05, 0.3, Vector3(0, 1.74, 0.27), P.m("ff7a1a"), 6).rotation_degrees = Vector3(90, 0, 0)
	for s in [-1.0, 1.0]:
		_sph(h, 0.035, Vector3(s * 0.1, 1.82, 0.24), coal, Vector3.ONE, 5)
		_cyl(h, 0.015, 0.015, 0.6, Vector3(s * 0.55, 1.15, 0), P.m("4a3220"), Vector3(0, 0, s * -60), 5)
	for k in 3:
		_sph(h, 0.04, Vector3(0, 1.3 - k * 0.22, 0.38), coal, Vector3.ONE, 5)
	_cyl(h, 0.18, 0.18, 0.2, Vector3(0, 2.08, 0), coal, Vector3.ZERO, 10)
	_cyl(h, 0.3, 0.3, 0.03, Vector3(0, 1.98, 0), coal, Vector3.ZERO, 10)
	_box(n, Vector3(1.0, 0.14, 0.2), Vector3(0, 0.07, 0.2), P.m("e8f1ff", 0.1))


static func _bollard(n: Node3D) -> void:
	var steel := P.m("ffcc00", 0.0, 0.45, 0.4)
	var rope := P.m("c9b27a", 0.0, 0.95)
	for x in [-0.8, 0.8]:
		_cyl(n, 0.18, 0.24, 0.6, Vector3(x, 0.3, 0), steel, Vector3.ZERO, 10)
		_sph(n, 0.2, Vector3(x, 0.62, 0), steel, Vector3(1, 0.7, 1), 10)
		_box(n, Vector3(0.5, 0.05, 0.5), Vector3(x, 0.03, 0), P.m("4a4d52"))
	for k in 6:
		var t := float(k) / 5.0
		_cyl(n, 0.045, 0.045, 0.45, Vector3(lerpf(-0.8, 0.8, t), 0.55 - sin(t * PI) * 0.22, 0.0), rope, Vector3(0, 0, 90), 6)
	_box(n, Vector3(0.5, 0.2, 0.04), Vector3(0, 0.75, 0.0), P.m("d93a2f", 0.3))


static func _buoys(n: Node3D) -> void:
	var red := P.m("e03a2a", 0.0, 0.5)
	var white := P.m("f2f2ee", 0.0, 0.5)
	for i in 3:
		var x := -0.62 + i * 0.62
		_sph(n, 0.3, Vector3(x, 0.32, 0.0), red if i != 1 else white, Vector3(1, 1.05, 1), 12)
		_cyl(n, 0.31, 0.31, 0.07, Vector3(x, 0.32, 0.0), white if i != 1 else red, Vector3.ZERO, 12)
		_cyl(n, 0.02, 0.02, 0.3, Vector3(x, 0.72, 0.0), P.m("3a3f46"), Vector3.ZERO, 5)
		_sph(n, 0.045, Vector3(x, 0.88, 0.0), P.m("ff8a00", 2.5), Vector3.ONE, 6)
	_box(n, Vector3(1.9, 0.02, 0.04), Vector3(0, 0.25, 0.25), P.m("c9b27a"))


static func _fish_crates(n: Node3D) -> void:
	var blue := P.m("2a7fc0", 0.0, 0.5)
	var ice := P.m("dff4ff", 0.1, 0.4)
	for i in 2:
		var x := -0.5 + i * 1.0
		_box(n, Vector3(0.86, 0.5, 0.7), Vector3(x, 0.25, 0), blue)
		_box(n, Vector3(0.88, 0.05, 0.72), Vector3(x, 0.52, 0), P.m("1f5f94"))
		_sph(n, 0.42, Vector3(x, 0.56, 0), ice, Vector3(1, 0.3, 0.8), 8)
		_box(n, Vector3(0.24, 0.06, 0.06), Vector3(x + 0.1, 0.62, 0.1), P.m("b8c4cc", 0.0, 0.3, 0.8), Vector3(0, 20, 8))
	_box(n, Vector3(0.7, 0.4, 0.7), Vector3(0, 0.7, 0), blue, Vector3(0, 12, 0))


static func _lava_rocks(n: Node3D, count: int) -> void:
	var rock := P.m("26232a", 0.0, 0.95)
	var lava := P.m("ff5a14", 2.6, 0.5)
	for i in count:
		var x := -0.75 + (i % 3) * 0.75 + _rng.randf_range(-0.1, 0.1)
		var z := (-0.15 if i < 3 else 0.2)
		var s := _rng.randf_range(0.38, 0.55)
		_sph(n, s, Vector3(x, s * 0.55, z), rock, Vector3(1.0, 0.8, 0.9), 7)
		_box(n, Vector3(s * 1.1, 0.04, 0.04), Vector3(x, s * 0.8, z + s * 0.5), lava, Vector3(0, _rng.randf_range(-30, 30), _rng.randf_range(-20, 20)))
	Gfx.glow(n, Vector3(0, 0.4, 0.2), 2.0, Color(1.0, 0.45, 0.1, 0.35))


static func _obsidian_shards(n: Node3D) -> void:
	var obs := P.m("15121a", 0.25, 0.15, 0.4)
	for i in 5:
		var x := -0.8 + i * 0.4
		var h := _rng.randf_range(0.5, 0.9)
		var c := _cone(n, _rng.randf_range(0.14, 0.22), h, Vector3(x, 0, _rng.randf_range(-0.2, 0.2)), obs, 5)
		c.rotation_degrees = Vector3(_rng.randf_range(-10, 10), 0, _rng.randf_range(-14, 14))
	Gfx.glow(n, Vector3(0, 0.3, 0.2), 1.6, Color(0.8, 0.3, 0.6, 0.2))


static func _steam_vent(n: Node3D) -> void:
	var rock := P.m("2c2a30", 0.0, 0.95)
	for k in 8:
		var a := TAU * k / 8.0
		_sph(n, 0.2, Vector3(cos(a) * 0.62, 0.17, sin(a) * 0.36), rock, Vector3(1.0, 0.9, 1.0), 6)
	_cyl(n, 0.5, 0.5, 0.03, Vector3(0, 0.12, 0), P.m("ff6a1a", 2.8), Vector3.ZERO, 14)
	Gfx.glow(n, Vector3(0, 0.45, 0), 2.4, Color(1.0, 0.5, 0.2, 0.6))
	Gfx.glow(n, Vector3(0, 0.95, 0), 1.8, Color(0.9, 0.9, 0.95, 0.22))


static func _charred_logs(n: Node3D) -> void:
	var ch := P.m("1b1512", 0.0, 1.0)
	var ember := P.m("ff7a2a", 1.8, 0.7)
	for i in 3:
		_cyl(n, 0.16, 0.16, 1.7, Vector3(0, 0.17 + (0.3 if i == 2 else 0.0), -0.2 + i * 0.2 if i < 2 else 0.0), ch, Vector3(0, 90 if i != 1 else 78, 90), 8)
	_box(n, Vector3(0.9, 0.03, 0.05), Vector3(-0.1, 0.35, 0.25), ember)
	Gfx.glow(n, Vector3(0, 0.3, 0.3), 1.6, Color(1.0, 0.5, 0.2, 0.4))


static func _cracked_slab(n: Node3D) -> void:
	var rock := P.m("2c2a30", 0.0, 0.9)
	var lava := P.m("ff5a14", 2.6, 0.5)
	_box(n, Vector3(1.8, 0.35, 0.8), Vector3(0, 0.18, 0), rock)
	_box(n, Vector3(0.8, 0.3, 0.7), Vector3(-0.4, 0.5, 0), rock, Vector3(0, 6, 4))
	for k in 4:
		_box(n, Vector3(0.05, 0.03, 0.7), Vector3(-0.7 + k * 0.45, 0.37, 0), lava, Vector3(0, _rng.randf_range(-25, 25), 0))
	Gfx.glow(n, Vector3(0, 0.45, 0.2), 1.8, Color(1.0, 0.45, 0.1, 0.35))


# =============================================================
#                      OVER (سُرخوردن)
# =============================================================
## همه: تیر افقی در ارتفاع ≈۱٫۰ تا ۲٫۲ و تکیه‌گاه‌های کناری تا ۳٫۲
static func over(zone: int, v: int, n: Node3D) -> void:
	_rng.randomize()
	match zone:
		0:
			if v == 3: _scaffold(n)
			else: _pipe_run(n)
		1:
			if v == 3: _bunting(n)
			else: _rock_bridge(n)
		2:
			if v == 3: _big_branch(n)
			else: _lantern_beam(n)
		3:
			match v % 5:
				0: _icicle_beam(n)
				1: _ski_lift(n)
				2: _frozen_branch(n)
				3: _cornice(n)
				_: _snow_sign(n)
		4:
			match v % 5:
				0: _crane_hook(n)
				1: _spot_gantry(n)
				2: _cargo_net(n)
				3: _pipe_run(n)
				_: _hanging_crates(n)
		_:
			match v % 5:
				0: _stalactites(n)
				1: _basalt_arch(n)
				2: _lava_drips(n)
				3: _chain_skulls(n)
				_: _rock_bridge(n, true)


static func _posts(n: Node3D, mat: Material, h: float = 3.2) -> void:
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.18, h, 0.18), Vector3(s * 1.0, h * 0.5, 0), mat)
		_box(n, Vector3(0.42, 0.08, 0.42), Vector3(s * 1.0, 0.04, 0), mat)


static func _scaffold(n: Node3D) -> void:
	var tube := P.m("9aa3ad", 0.0, 0.35, 0.9)
	var plank := P.m("b98a4a", 0.0, 0.9)
	var net := P.m("39a86a", 0.0, 0.95)
	_posts(n, tube)
	for y in [1.15, 2.1, 3.05]:
		_box(n, Vector3(2.2, 0.08, 0.1), Vector3(0, y, 0.15), tube)
		_box(n, Vector3(2.2, 0.08, 0.1), Vector3(0, y, -0.15), tube)
	_box(n, Vector3(2.2, 0.06, 0.4), Vector3(0, 2.14, 0), plank)
	_box(n, Vector3(2.0, 0.9, 0.03), Vector3(0, 2.6, 0.22), net)
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.05, 2.3, 0.05), Vector3(s * 0.55, 2.1, 0.16), tube, Vector3(0, 0, s * 38))
	_box(n, Vector3(2.0, 0.1, 0.3), Vector3(0, 1.12, 0), P.m("ffc400", 0.2))
	_box(n, Vector3(0.12, 0.12, 0.12), Vector3(0.0, 1.1, 0.25), P.m("ff7a00", 3.0))


static func _pipe_run(n: Node3D) -> void:
	var pipe := P.m("8a96a3", 0.0, 0.35, 0.8)
	var red := P.m("c8322a", 0.0, 0.45, 0.5)
	_posts(n, P.m("3a3f46", 0.0, 0.5, 0.6))
	for i in 3:
		_cyl(n, 0.16, 0.16, 2.2, Vector3(0, 1.3 + i * 0.4 + (0.15 if i == 1 else 0.0), -0.15 + i * 0.15), pipe if i != 1 else red, Vector3(0, 0, 90), 12)
	_cyl(n, 0.2, 0.2, 0.12, Vector3(-0.5, 1.45, 0.0), pipe, Vector3(0, 0, 90), 12)
	_cyl(n, 0.14, 0.14, 0.1, Vector3(0.45, 1.9, 0.0), red, Vector3(90, 0, 0), 12)
	Gfx.glow(n, Vector3(0.45, 2.0, 0.2), 1.2, Color(0.9, 0.9, 1.0, 0.2))
	_box(n, Vector3(2.1, 0.1, 0.5), Vector3(0, 1.08, 0), P.m("ffc400", 0.2))


static func _bunting(n: Node3D) -> void:
	var wood := P.m("7a5230", 0.0, 0.9)
	_posts(n, wood, 3.4)
	_cyl(n, 0.025, 0.025, 2.1, Vector3(0, 2.2, 0), P.m("c9b27a"), Vector3(0, 0, 90), 5)
	_cyl(n, 0.025, 0.025, 2.1, Vector3(0, 1.3, 0), P.m("c9b27a"), Vector3(0, 0, 90), 5)
	var cols := ["e8503a", "f2b632", "2fa89a", "7a4fd0", "f27aa0"]
	for k in 9:
		var x := -0.9 + k * 0.225
		_box(n, Vector3(0.2, 0.34, 0.02), Vector3(x, 1.12, 0.0), P.m(cols[k % 5], 0.15, 0.9), Vector3(0, 0, 45)).scale = Vector3(1, 1, 1)
	_box(n, Vector3(2.0, 0.5, 0.03), Vector3(0, 1.62, 0.0), P.m("e8503a", 0.1, 0.9))
	_box(n, Vector3(2.0, 0.08, 0.04), Vector3(0, 1.38, 0.0), P.m("f2b632", 0.1))


static func _rock_bridge(n: Node3D, dark := false) -> void:
	var rock := P.m("33303a", 0.0, 0.95) if dark else P.m("b9835e", 0.0, 0.95)
	var rock2 := P.m("4a4552", 0.0, 0.95) if dark else P.m("a2704d", 0.0, 0.95)
	for s in [-1.0, 1.0]:
		_sph(n, 0.55, Vector3(s * 1.0, 1.4, 0), rock, Vector3(0.9, 3.0, 1.0), 8)
		_sph(n, 0.4, Vector3(s * 1.05, 0.4, 0.1), rock2, Vector3(1.2, 1.0, 1.0), 8)
	_sph(n, 0.5, Vector3(0, 2.0, 0), rock2, Vector3(2.3, 0.9, 0.9), 10)
	_sph(n, 0.45, Vector3(0.35, 1.35, 0), rock, Vector3(1.2, 0.5, 0.8), 8)
	if dark:
		Gfx.glow(n, Vector3(0, 1.1, 0.2), 2.0, Color(1.0, 0.35, 0.1, 0.35))
		_box(n, Vector3(1.6, 0.03, 0.05), Vector3(0, 1.28, 0.3), P.m("ff5a14", 2.6))


static func _big_branch(n: Node3D) -> void:
	var bark := P.m("5a3d22", 0.0, 1.0)
	var leaf := P.m("3f8d38", 0.0, 1.0)
	_cyl(n, 0.2, 0.2, 3.4, Vector3(-1.05, 1.7, 0), bark, Vector3.ZERO, 8)
	_cyl(n, 0.15, 0.2, 2.4, Vector3(0, 1.45, 0), bark, Vector3(0, 0, 90), 8)
	_cyl(n, 0.2, 0.2, 3.4, Vector3(1.05, 1.7, 0), bark, Vector3.ZERO, 8)
	for i in 6:
		_sph(n, 0.3, Vector3(-0.9 + i * 0.36, 1.8, _rng.randf_range(-0.2, 0.2)), leaf, Vector3(1.2, 0.6, 1.0), 6)
	for i in 5:
		_cyl(n, 0.012, 0.012, _rng.randf_range(0.3, 0.6), Vector3(-0.8 + i * 0.4, 1.2, 0.1), P.m("5fa84a"), Vector3.ZERO, 4)


static func _lantern_beam(n: Node3D) -> void:
	var wood := P.m("6a4426", 0.0, 0.9)
	_posts(n, wood)
	_box(n, Vector3(2.3, 0.28, 0.3), Vector3(0, 1.5, 0), wood)
	_box(n, Vector3(2.3, 0.1, 0.4), Vector3(0, 1.7, 0), P.m("8a5a30", 0.0, 0.9))
	for x in [-0.6, 0.6]:
		_cyl(n, 0.012, 0.012, 0.3, Vector3(x, 1.2, 0), P.m("2a2a2a"), Vector3.ZERO, 4)
		_box(n, Vector3(0.16, 0.2, 0.16), Vector3(x, 1.0, 0), P.m("ffcf5a", 2.2))
		Gfx.glow(n, Vector3(x, 1.0, 0.15), 1.1, Color(1.0, 0.8, 0.3, 0.45))


static func _icicle_beam(n: Node3D) -> void:
	var wood := P.m("6a4a2c", 0.0, 0.9)
	var snow := P.m("f2f7ff", 0.1, 0.95)
	var ice := P.m("b6e8ff", 0.4, 0.1, 0.1)
	_posts(n, wood)
	_box(n, Vector3(2.3, 0.3, 0.35), Vector3(0, 1.8, 0), wood)
	_box(n, Vector3(2.35, 0.14, 0.45), Vector3(0, 2.0, 0), snow)
	for i in 8:
		var h := _rng.randf_range(0.3, 0.7)
		_cone(n, 0.06, h, Vector3(-0.95 + i * 0.27, 1.65 - h, 0.05), ice, 5).rotation_degrees = Vector3(180, 0, 0)


static func _ski_lift(n: Node3D) -> void:
	var steel := P.m("5a6670", 0.0, 0.4, 0.7)
	_posts(n, steel)
	_box(n, Vector3(2.3, 0.12, 0.12), Vector3(0, 3.0, 0), steel)
	for x in [-0.5, 0.5]:
		_cyl(n, 0.025, 0.025, 1.4, Vector3(x, 2.3, 0), steel, Vector3.ZERO, 5)
		_box(n, Vector3(0.7, 0.1, 0.5), Vector3(x, 1.55, 0), P.m("d93a2f", 0.0, 0.7))
		_box(n, Vector3(0.7, 0.4, 0.08), Vector3(x, 1.8, -0.22), P.m("d93a2f", 0.0, 0.7))
		_box(n, Vector3(0.72, 0.05, 0.05), Vector3(x, 1.7, 0.25), steel)
	_box(n, Vector3(0.9, 0.12, 0.2), Vector3(0, 1.2, 0), P.m("f2f7ff", 0.1))


static func _frozen_branch(n: Node3D) -> void:
	var bark := P.m("4a3a2c", 0.0, 1.0)
	var snow := P.m("f2f7ff", 0.1, 0.95)
	var ice := P.m("b6e8ff", 0.3, 0.15)
	_cyl(n, 0.22, 0.26, 3.3, Vector3(-1.05, 1.65, 0), bark, Vector3.ZERO, 8)
	_cyl(n, 0.2, 0.2, 3.3, Vector3(1.05, 1.65, 0), bark, Vector3.ZERO, 8)
	_cyl(n, 0.16, 0.2, 2.4, Vector3(0, 1.55, 0), bark, Vector3(0, 0, 90), 8)
	_box(n, Vector3(2.2, 0.14, 0.34), Vector3(0, 1.75, 0), snow)
	for i in 5:
		_cone(n, 0.05, 0.35, Vector3(-0.9 + i * 0.45, 1.2, 0.0), ice, 5).rotation_degrees = Vector3(180, 0, 0)


static func _cornice(n: Node3D) -> void:
	var snow := P.m("f4f8ff", 0.12, 0.95)
	var rock := P.m("6d6f78", 0.0, 0.95)
	for s in [-1.0, 1.0]:
		_sph(n, 0.6, Vector3(s * 1.05, 1.3, 0), rock, Vector3(0.8, 2.8, 1.0), 8)
	_sph(n, 0.6, Vector3(0, 2.0, 0), snow, Vector3(2.0, 0.9, 0.9), 10)
	_sph(n, 0.5, Vector3(0.0, 1.45, 0.1), snow, Vector3(1.4, 0.5, 0.8), 8)
	for i in 4:
		_cone(n, 0.06, 0.28, Vector3(-0.6 + i * 0.4, 1.12, 0.1), P.m("b6e8ff", 0.3, 0.15), 5).rotation_degrees = Vector3(180, 0, 0)


static func _snow_sign(n: Node3D) -> void:
	var wood := P.m("6a4a2c", 0.0, 0.9)
	_posts(n, wood)
	_box(n, Vector3(2.3, 0.7, 0.14), Vector3(0, 1.55, 0), P.m("c43a2a", 0.1, 0.8))
	_box(n, Vector3(2.0, 0.08, 0.16), Vector3(0, 1.28, 0.0), P.m("f2f2ee"))
	_box(n, Vector3(2.34, 0.12, 0.3), Vector3(0, 1.95, 0), P.m("f4f8ff", 0.1, 0.95))
	Gfx.label(n, "STOP", Vector3(0, 1.58, 0.1), 60, Color.WHITE, 0.0085)


static func _crane_hook(n: Node3D) -> void:
	var steel := P.m("7a8591", 0.0, 0.4, 0.8)
	var yellow := P.m("f5c518", 0.0, 0.5, 0.3)
	_posts(n, yellow, 3.3)
	_box(n, Vector3(2.3, 0.18, 0.2), Vector3(0, 3.2, 0), yellow)
	for x in [-0.35, 0.35]:
		_cyl(n, 0.02, 0.02, 1.4, Vector3(x, 2.5, 0), P.m("22262b"), Vector3.ZERO, 5)
	_box(n, Vector3(0.9, 0.3, 0.4), Vector3(0, 1.7, 0), yellow)
	_cyl(n, 0.07, 0.07, 0.3, Vector3(0, 1.4, 0), steel, Vector3.ZERO, 8)
	P.torus(n, 0.2, 0.06, Vector3(0, 1.15, 0), steel, Vector3(90, 0, 0), 14)
	_box(n, Vector3(0.2, 0.1, 0.2), Vector3(0, 1.58, 0.24), P.m("ff7a00", 2.6))


static func _spot_gantry(n: Node3D) -> void:
	var steel := P.m("3a4048", 0.0, 0.45, 0.7)
	_posts(n, steel)
	_box(n, Vector3(2.3, 0.9, 0.3), Vector3(0, 1.6, 0), steel)
	_box(n, Vector3(2.1, 0.1, 0.34), Vector3(0, 1.1, 0), P.m("ffc400", 0.3))
	for x in [-0.7, 0.0, 0.7]:
		_cyl(n, 0.18, 0.15, 0.2, Vector3(x, 2.2, 0.1), steel, Vector3(70, 0, 0), 10)
		_cyl(n, 0.14, 0.14, 0.02, Vector3(x, 2.17, 0.24), P.m("fff5cf", 3.0), Vector3(70, 0, 0), 10)
		Gfx.glow(n, Vector3(x, 2.15, 0.3), 1.6, Color(1.0, 0.95, 0.75, 0.55))
	Gfx.pool(n, Vector3(0, 0.03, 0.8), Vector2(2.4, 2.4), Color(1.0, 0.95, 0.7, 0.18))


static func _cargo_net(n: Node3D) -> void:
	var rope := P.m("c9a24a", 0.0, 0.95)
	var steel := P.m("5a6670", 0.0, 0.4, 0.7)
	_posts(n, steel)
	_box(n, Vector3(2.3, 0.1, 0.1), Vector3(0, 3.0, 0), steel)
	for i in 8:
		_box(n, Vector3(0.025, 1.9, 0.025), Vector3(-0.9 + i * 0.26, 2.05, 0), rope)
	for j in 6:
		_box(n, Vector3(2.0, 0.025, 0.025), Vector3(0, 1.1 + j * 0.34, 0.0), rope)
	_box(n, Vector3(0.9, 0.5, 0.4), Vector3(0.1, 1.5, 0.1), P.m("8a6a3a", 0.0, 0.9), Vector3(0, 8, 0))


static func _hanging_crates(n: Node3D) -> void:
	var crate := Gfx.mat(Color.WHITE, 0.0, Gfx.crate_tex(), 0.85)
	var steel := P.m("22262b")
	_posts(n, P.m("5a6670", 0.0, 0.4, 0.7))
	_box(n, Vector3(2.3, 0.14, 0.14), Vector3(0, 3.1, 0), P.m("5a6670", 0.0, 0.4, 0.7))
	for x in [-0.55, 0.55]:
		_box(n, Vector3(0.9, 0.8, 0.9), Vector3(x, 1.5, 0), crate, Vector3(0, 10 * x, 0))
		for sx in [-0.3, 0.3]:
			_cyl(n, 0.012, 0.012, 1.3, Vector3(x + sx * 0.5, 2.55, 0), steel, Vector3.ZERO, 4)


static func _stalactites(n: Node3D) -> void:
	var rock := P.m("2c2a30", 0.0, 0.95)
	for s in [-1.0, 1.0]:
		_sph(n, 0.55, Vector3(s * 1.05, 1.4, 0), rock, Vector3(0.8, 3.0, 1.0), 8)
	_sph(n, 0.55, Vector3(0, 2.3, 0), rock, Vector3(2.0, 0.8, 0.9), 8)
	for i in 6:
		var h := _rng.randf_range(0.4, 1.0)
		_cone(n, _rng.randf_range(0.08, 0.16), h, Vector3(-0.85 + i * 0.34, 2.1 - h, 0.0), rock, 6).rotation_degrees = Vector3(180, 0, 0)
	Gfx.glow(n, Vector3(0, 1.5, 0.3), 2.0, Color(1.0, 0.4, 0.1, 0.25))


static func _basalt_arch(n: Node3D) -> void:
	var b := P.m("2f2d35", 0.0, 0.7, 0.2)
	for s in [-1.0, 1.0]:
		for k in 3:
			var h := 2.8 + k * 0.3
			_cyl(n, 0.2, 0.22, h, Vector3(s * (0.85 + k * 0.17), h * 0.5, (k - 1) * 0.12), b, Vector3.ZERO, 6)
	_box(n, Vector3(2.3, 0.45, 0.6), Vector3(0, 2.0, 0), b)
	_box(n, Vector3(1.9, 0.04, 0.05), Vector3(0, 1.74, 0.31), P.m("ff5a14", 2.6))


static func _lava_drips(n: Node3D) -> void:
	var rock := P.m("26232a", 0.0, 0.95)
	var lava := P.m("ff5a14", 3.0, 0.4)
	_posts(n, rock)
	_box(n, Vector3(2.3, 0.5, 0.6), Vector3(0, 2.2, 0), rock)
	for i in 5:
		var h := _rng.randf_range(0.4, 1.0)
		_cyl(n, 0.05, 0.08, h, Vector3(-0.85 + i * 0.42, 1.95 - h * 0.5, 0.0), lava, Vector3.ZERO, 6)
		_sph(n, 0.09, Vector3(-0.85 + i * 0.42, 1.95 - h, 0.0), lava, Vector3.ONE, 6)
	Gfx.glow(n, Vector3(0, 1.4, 0.3), 2.4, Color(1.0, 0.4, 0.1, 0.4))


static func _chain_skulls(n: Node3D) -> void:
	var rock := P.m("2c2a30", 0.0, 0.9)
	var bone := P.m("e6dcc4", 0.0, 0.8)
	_posts(n, rock)
	_box(n, Vector3(2.3, 0.24, 0.3), Vector3(0, 3.0, 0), rock)
	for x in [-0.55, 0.0, 0.55]:
		_cyl(n, 0.015, 0.015, 1.4, Vector3(x, 2.2, 0), P.m("1a1a1d", 0.0, 0.4, 0.8), Vector3.ZERO, 4)
		_sph(n, 0.2, Vector3(x, 1.4, 0), bone, Vector3(1, 1.05, 1.0), 8)
		_box(n, Vector3(0.18, 0.1, 0.16), Vector3(x, 1.2, 0.02), bone)
		for ex in [-0.07, 0.07]:
			_sph(n, 0.04, Vector3(x + ex, 1.42, 0.17), P.m("ff4a1a", 3.0), Vector3.ONE, 5)


# =============================================================
#                      FULL (مانع کامل)
# =============================================================
static func full(zone: int, v: int, n: Node3D) -> void:
	_rng.randomize()
	match zone:
		0:
			if v == 4: _van(n)
			else: _cabin(n)
		1:
			if v == 4: _adobe_hut(n)
			else: _tent(n)
		2:
			if v == 4: _giant_roots(n)
			else: _face_block(n)
		3:
			match v % 6:
				0: _snow_pickup(n)
				1: _ice_wall(n)
				2: _pine_pile(n)
				3: _snowcat(n)
				4: _igloo(n)
				_: _snow_boulders(n)
		4:
			match v % 6:
				0: _container_stack(n)
				1: _truck_cab(n)
				2: _boat_trailer(n)
				3: _drum_pallets(n)
				4: _open_container(n)
				_: _forklift_block(n)
		_:
			match v % 6:
				0: _spire_cluster(n)
				1: _basalt_columns(n)
				2: _lava_wall(n)
				3: _fallen_pillar(n)
				4: _geyser_rock(n)
				_: _skull_rock(n)


static func _lights(n: Node3D, z: float, y: float, dx: float, col: String = "fff2c0") -> void:
	for sx in [-dx, dx]:
		_box(n, Vector3(0.3, 0.16, 0.06), Vector3(sx, y, z), P.m(col, 2.2))
		Gfx.glow(n, Vector3(sx, y, z + 0.1), 0.9, Color(1.0, 0.95, 0.7, 0.35))


static func _van(n: Node3D) -> void:
	var cols := ["f2f2ee", "2f7dd1", "d1432f", "3b9a58"]
	var body := P.m(cols[_rng.randi() % 4], 0.0, 0.35, 0.3)
	var glass := P.m("1c2a38", 0.1, 0.1, 0.5)
	_box(n, Vector3(1.96, 1.7, 2.6), Vector3(0, 1.2, 0), body)
	_box(n, Vector3(2.0, 0.4, 2.64), Vector3(0, 0.45, 0), P.m("2a2d31", 0.0, 0.6))
	_box(n, Vector3(1.9, 0.75, 0.06), Vector3(0, 1.75, 1.31), glass, Vector3(-8, 0, 0))
	_box(n, Vector3(0.05, 0.6, 1.0), Vector3(-0.99, 1.65, 0.7), glass)
	_box(n, Vector3(0.05, 0.6, 1.0), Vector3(0.99, 1.65, 0.7), glass)
	_box(n, Vector3(1.9, 0.18, 0.1), Vector3(0, 0.45, 1.34), P.m("c9cfd6", 0.0, 0.3, 0.9))
	_box(n, Vector3(1.0, 0.25, 0.05), Vector3(0, 1.0, 1.32), P.m("f2f2ee"))
	Gfx.label(n, "EXPRESS", Vector3(0, 1.0, 1.36), 38, Color("2a2d31"), 0.0052)
	_box(n, Vector3(0.1, 0.1, 0.4), Vector3(-1.05, 1.55, 1.1), P.m("22262b"))
	_lights(n, 1.32, 0.7, 0.72)
	_wheels(n, [-0.98, 0.98], [-0.85, 0.85], 0.36)


static func _cabin(n: Node3D) -> void:
	var body := P.m("e3d9bf", 0.0, 0.6)
	_box(n, Vector3(1.96, 2.2, 2.6), Vector3(0, 1.4, 0), body)
	_box(n, Vector3(2.0, 0.3, 2.64), Vector3(0, 0.25, 0), P.m("3a3f46", 0.0, 0.7))
	_box(n, Vector3(2.04, 0.12, 2.64), Vector3(0, 2.56, 0), P.m("8a8f96", 0.0, 0.5, 0.5))
	_box(n, Vector3(0.9, 0.7, 0.05), Vector3(-0.4, 1.7, 1.31), P.m("274a6a", 0.2, 0.1, 0.4))
	_box(n, Vector3(0.7, 1.5, 0.05), Vector3(0.6, 1.0, 1.31), P.m("5a6a7a", 0.0, 0.5, 0.4))
	_box(n, Vector3(0.9, 0.5, 0.45), Vector3(-0.3, 2.82, 0.4), P.m("b8bec6", 0.0, 0.4, 0.7))
	_cyl(n, 0.2, 0.2, 0.05, Vector3(-0.3, 2.86, 0.4), P.m("2a2d31"), Vector3.ZERO, 12)
	_box(n, Vector3(0.5, 0.35, 0.04), Vector3(0.6, 2.1, 1.33), P.m("2a7fc0", 0.2))
	Gfx.label(n, "OFFICE", Vector3(0.6, 2.1, 1.36), 28, Color.WHITE, 0.0045)
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.1, 0.9, 0.1), Vector3(s * 0.98, 0.45, 1.25), P.m("3a3f46"))


static func _adobe_hut(n: Node3D) -> void:
	var wall := P.m("d6a76a", 0.0, 1.0)
	var wall2 := P.m("c0925a", 0.0, 1.0)
	_box(n, Vector3(2.0, 2.0, 2.6), Vector3(0, 1.0, 0), wall)
	_box(n, Vector3(2.1, 0.22, 2.7), Vector3(0, 2.1, 0), wall2)
	for k in 5:
		_cyl(n, 0.06, 0.06, 0.5, Vector3(-0.8 + k * 0.4, 1.85, 1.38), P.m("6a4426", 0.0, 0.95), Vector3(90, 0, 0), 6)
	_box(n, Vector3(0.7, 1.3, 0.05), Vector3(0.1, 0.65, 1.31), P.m("3a2a1c"))
	_box(n, Vector3(0.9, 0.12, 0.12), Vector3(0.1, 1.35, 1.34), P.m("6a4426"))
	_box(n, Vector3(0.4, 0.4, 0.05), Vector3(-0.6, 1.4, 1.31), P.m("2a1c12"))
	_box(n, Vector3(0.5, 0.3, 0.06), Vector3(-0.6, 1.7, 1.33), P.m("2fa89a", 0.1, 0.9))
	_sph(n, 0.3, Vector3(0.7, 0.2, 1.5), P.m("b8935a", 0.0, 1.0), Vector3(1.2, 0.5, 1.0), 6)


static func _tent(n: Node3D) -> void:
	var cloth := P.m("c9473a", 0.0, 0.95)
	var cloth2 := P.m("f2e2c0", 0.0, 0.95)
	_box(n, Vector3(2.0, 1.1, 2.6), Vector3(0, 0.55, 0), cloth2)
	_box(n, Vector3(2.1, 1.6, 2.7), Vector3(0, 1.9, 0), cloth, Vector3(0, 0, 0)).scale = Vector3(1, 1, 1)
	_sph(n, 1.0, Vector3(0, 1.9, 0), cloth, Vector3(1.05, 0.55, 1.3), 10)
	for s in [-1.0, 1.0]:
		_cyl(n, 0.05, 0.05, 2.8, Vector3(s * 1.0, 1.4, 1.35), P.m("5a3a1c"), Vector3.ZERO, 6)
	_box(n, Vector3(1.0, 1.1, 0.05), Vector3(0, 0.6, 1.36), P.m("2a1c12"))
	_box(n, Vector3(2.0, 0.14, 0.05), Vector3(0, 1.2, 1.37), P.m("f2b632"))
	_cyl(n, 0.02, 0.02, 0.6, Vector3(0, 2.9, 0), P.m("5a3a1c"), Vector3.ZERO, 4)
	_box(n, Vector3(0.4, 0.22, 0.02), Vector3(0.2, 3.0, 0), P.m("e8503a", 0.2))


static func _giant_roots(n: Node3D) -> void:
	var bark := P.m("4b3320", 0.0, 1.0)
	var moss := P.m("4f7d3c", 0.0, 1.0)
	_cyl(n, 0.55, 0.75, 2.8, Vector3(0, 1.4, 0), bark, Vector3.ZERO, 10)
	for k in 7:
		var a := k * TAU / 7.0
		var r := _box(n, Vector3(0.34, 1.6, 1.3), Vector3(cos(a) * 0.95, 0.5, sin(a) * 0.95), bark, Vector3(0, -rad_to_deg(a), 22 if cos(a) > 0 else -22))
	_sph(n, 0.9, Vector3(0, 2.7, 0), moss, Vector3(1.3, 0.6, 1.3), 8)
	_sph(n, 0.6, Vector3(0.5, 0.7, 0.9), moss, Vector3(1.4, 0.4, 1.0), 8)


static func _face_block(n: Node3D) -> void:
	var st := P.m("8c9183", 0.0, 0.95)
	var moss := P.m("4f7d3c", 0.0, 1.0)
	_box(n, Vector3(2.0, 2.6, 2.6), Vector3(0, 1.3, 0), st)
	_box(n, Vector3(2.15, 0.25, 2.75), Vector3(0, 2.7, 0), P.m("767c6e", 0.0, 0.95))
	_sph(n, 0.9, Vector3(-0.2, 2.75, 0.2), moss, Vector3(1.4, 0.35, 1.2), 8)
	var dk := P.m("2c3027")
	_box(n, Vector3(1.2, 0.14, 0.06), Vector3(0, 1.75, 1.31), dk)
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.35, 0.3, 0.06), Vector3(s * 0.45, 1.45, 1.31), dk)
	_box(n, Vector3(0.7, 0.18, 0.06), Vector3(0, 0.85, 1.31), dk)
	_box(n, Vector3(0.1, 0.5, 0.06), Vector3(0, 1.25, 1.31), dk)
	_box(n, Vector3(1.9, 0.12, 0.06), Vector3(0, 0.25, 1.31), P.m("a89a6a", 0.1, 0.9))


static func _snowcover(n: Node3D, w: float, z: float, y: float, d: float = 0.0) -> void:
	_sph(n, 0.5, Vector3(0, y, z), P.m("f4f8ff", 0.12, 0.95), Vector3(w * 1.0, 0.28, 1.35 + d), 10)


static func _snow_pickup(n: Node3D) -> void:
	var body := P.m("b3322a", 0.0, 0.4, 0.3)
	_box(n, Vector3(1.96, 0.9, 2.6), Vector3(0, 0.95, 0), body)
	_box(n, Vector3(1.9, 0.75, 1.1), Vector3(0, 1.75, 0.65), body)
	_box(n, Vector3(1.94, 0.6, 0.06), Vector3(0, 1.8, 1.21), P.m("1c2a38", 0.1, 0.1, 0.5), Vector3(-12, 0, 0))
	_box(n, Vector3(2.0, 0.3, 2.64), Vector3(0, 0.4, 0), P.m("1e2024", 0.0, 0.7))
	_box(n, Vector3(1.9, 0.1, 0.1), Vector3(0, 0.45, 1.34), P.m("c9cfd6", 0.0, 0.3, 0.9))
	_snowcover(n, 1.9, -0.6, 1.5)
	_snowcover(n, 1.6, 0.75, 2.2, -0.9)
	for k in 2:
		_box(n, Vector3(0.05, 0.05, 0.9), Vector3(-0.8 + k * 1.6, 1.45, -0.5), P.m("22262b"), Vector3(0, 0, 0))
	_lights(n, 1.32, 0.72, 0.72)
	_wheels(n, [-0.98, 0.98], [-0.85, 0.85], 0.42)


static func _ice_wall(n: Node3D) -> void:
	var ice := P.m("8fd6ff", 0.3, 0.12, 0.1)
	var ice2 := P.m("c9f0ff", 0.35, 0.1, 0.1)
	var deep := P.m("4a9fd6", 0.2, 0.15, 0.1)
	_box(n, Vector3(2.0, 2.2, 1.8), Vector3(0, 1.1, 0), deep, Vector3(0, 3, 0))
	_box(n, Vector3(1.4, 2.7, 1.2), Vector3(-0.35, 1.35, 0.1), ice, Vector3(4, 16, -3))
	_box(n, Vector3(1.0, 2.2, 1.0), Vector3(0.55, 1.1, 0.4), ice2, Vector3(-3, -20, 4))
	for k in 5:
		_cone(n, 0.18, _rng.randf_range(0.6, 1.2), Vector3(-0.8 + k * 0.4, 2.0, 0.7), ice2, 5)
	Gfx.glow(n, Vector3(0, 1.5, 1.1), 3.0, Color(0.6, 0.9, 1.0, 0.3))
	_sph(n, 0.8, Vector3(0, 0.1, 1.1), P.m("f4f8ff", 0.1, 0.95), Vector3(1.3, 0.35, 0.8), 8)


static func _pine_pile(n: Node3D) -> void:
	var bark := P.m("4a3524", 0.0, 1.0)
	var pine := P.m("1f5a35", 0.0, 1.0)
	var snow := P.m("f4f8ff", 0.1, 0.95)
	for i in 4:
		_cyl(n, 0.2, 0.26, 2.0, Vector3(0, 0.25 + (i % 2) * 0.45 + (0.35 if i == 3 else 0.0), -0.9 + i * 0.6), bark, Vector3(0, 90 + (i - 1.5) * 8, 90), 8)
	for k in 6:
		_sph(n, 0.55, Vector3(-0.7 + (k % 3) * 0.7, 0.8 + (k / 3) * 0.6, -0.8 + (k % 2) * 1.6), pine, Vector3(1.0, 0.7, 1.1), 7)
	_snowcover(n, 1.8, 0.0, 1.55, 0.2)
	_cyl(n, 0.05, 0.05, 0.9, Vector3(0.7, 1.9, 0.7), bark, Vector3(30, 0, 10), 5)


static func _snowcat(n: Node3D) -> void:
	var body := P.m("e8761a", 0.0, 0.4, 0.3)
	var track := P.m("1d1e21", 0.0, 0.95)
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.55, 0.62, 2.6), Vector3(s * 0.7, 0.4, 0), track)
		for k in 5:
			_cyl(n, 0.28, 0.28, 0.45, Vector3(s * 0.7, 0.3, -1.0 + k * 0.5), P.m("3a3d44", 0.0, 0.6, 0.6), Vector3(0, 0, 90), 10)
	_box(n, Vector3(1.8, 0.8, 2.2), Vector3(0, 1.0, 0.1), body)
	_box(n, Vector3(1.7, 0.9, 1.2), Vector3(0, 1.85, 0.4), body)
	_box(n, Vector3(1.6, 0.6, 0.06), Vector3(0, 1.9, 1.02), P.m("1c2a38", 0.1, 0.1, 0.5), Vector3(-10, 0, 0))
	_box(n, Vector3(2.0, 0.5, 0.2), Vector3(0, 0.6, 1.4), P.m("3a3d44", 0.0, 0.5, 0.7), Vector3(0, 0, 0))
	_box(n, Vector3(1.4, 0.2, 0.2), Vector3(0, 2.4, 0.4), P.m("ffcf00", 0.0, 0.5))
	_box(n, Vector3(0.3, 0.14, 0.14), Vector3(0, 2.55, 0.4), P.m("ff8a00", 3.0))
	_lights(n, 1.15, 1.25, 0.6)
	_snowcover(n, 1.5, 0.3, 2.35, -0.6)


static func _igloo(n: Node3D) -> void:
	var snow := P.m("eef5ff", 0.15, 0.9)
	var line := P.m("b9cfe6", 0.0, 0.9)
	var half := _sph(n, 1.3, Vector3(0, 0.0, 0.0), snow, Vector3(1.0, 1.7, 1.45), 14)
	for k in 4:
		_torus_line(n, line, 0.4 + k * 0.4)
	_box(n, Vector3(0.9, 0.9, 0.9), Vector3(0, 0.45, 1.5), snow)
	_box(n, Vector3(0.6, 0.7, 0.95), Vector3(0, 0.38, 1.55), P.m("17202a"))
	_box(n, Vector3(0.1, 0.35, 0.1), Vector3(0.8, 0.3, 1.3), P.m("e8b552", 1.6))
	Gfx.glow(n, Vector3(0, 0.4, 1.9), 1.8, Color(1.0, 0.7, 0.3, 0.3))


static func _torus_line(n: Node3D, mat: Material, y: float) -> void:
	P.torus(n, 1.28, 1.25, Vector3(0, y, 0), mat, Vector3.ZERO, 16).scale = Vector3(0.94 - y * 0.12, 1.0, 1.3 - y * 0.1)


static func _snow_boulders(n: Node3D) -> void:
	var rock := P.m("6d7078", 0.0, 0.95)
	var snow := P.m("f4f8ff", 0.1, 0.95)
	_sph(n, 1.0, Vector3(-0.4, 0.8, 0.2), rock, Vector3(1.0, 0.95, 1.2), 10)
	_sph(n, 0.8, Vector3(0.6, 0.7, -0.4), rock, Vector3(1.0, 1.1, 1.0), 10)
	_sph(n, 0.7, Vector3(0.3, 0.6, 0.8), rock, Vector3(1.0, 0.9, 1.0), 10)
	_snowcover(n, 1.6, 0.1, 1.7, 0.0)
	_sph(n, 0.6, Vector3(0.6, 1.5, -0.4), snow, Vector3(1.1, 0.4, 1.0), 8)


static func _container_stack(n: Node3D) -> void:
	var cols := ["d6502d", "2f7fc0", "3b9a58", "e0a82a", "7a4fd0", "2fa89a"]
	var rib := Gfx.ribs_tex()
	var a := Gfx.mat(Color(cols[_rng.randi() % 6]), 0.0, rib, 0.55)
	var b := Gfx.mat(Color(cols[_rng.randi() % 6]), 0.0, rib, 0.55)
	var steel := P.m("5a6670", 0.0, 0.4, 0.8)
	_box(n, Vector3(2.0, 1.35, 2.6), Vector3(0, 0.68, 0), a)
	_box(n, Vector3(2.0, 1.35, 2.6), Vector3(0, 2.05, 0), b)
	for y in [0.0, 1.38, 2.74]:
		_box(n, Vector3(2.06, 0.08, 2.66), Vector3(0, y + 0.03, 0), steel)
	for sx in [-0.98, 0.98]:
		_box(n, Vector3(0.07, 2.76, 0.07), Vector3(sx, 1.38, 1.3), steel)
	for y in [0.68, 2.05]:
		_box(n, Vector3(0.05, 1.15, 0.05), Vector3(-0.3, y, 1.32), steel)
		_box(n, Vector3(0.05, 1.15, 0.05), Vector3(0.3, y, 1.32), steel)
		_box(n, Vector3(0.9, 0.06, 0.04), Vector3(0, y + 0.3, 1.33), P.m("f2f2ee"))
	Gfx.label(n, "MSKU 4821", Vector3(0, 1.1, 1.35), 24, Color("f2f2ee"), 0.0045)


static func _truck_cab(n: Node3D) -> void:
	var body := P.m("2f7fc0", 0.0, 0.4, 0.3)
	_box(n, Vector3(1.96, 1.9, 1.3), Vector3(0, 1.4, 0.65), body)
	_box(n, Vector3(1.9, 0.7, 0.06), Vector3(0, 1.95, 1.31), P.m("1c2a38", 0.1, 0.1, 0.5), Vector3(-6, 0, 0))
	_box(n, Vector3(1.94, 0.5, 0.2), Vector3(0, 0.55, 1.35), P.m("c9cfd6", 0.0, 0.3, 0.9))
	_box(n, Vector3(1.4, 0.5, 0.06), Vector3(0, 1.1, 1.32), P.m("20252a", 0.0, 0.5, 0.6))
	for k in 4:
		_box(n, Vector3(1.3, 0.04, 0.04), Vector3(0, 0.95 + k * 0.1, 1.35), P.m("c9cfd6", 0.0, 0.3, 0.9))
	_box(n, Vector3(1.9, 0.6, 1.3), Vector3(0, 2.7, 0.25), body)
	_box(n, Vector3(1.94, 1.9, 1.3), Vector3(0, 1.1, -0.9), P.m("e8e8e4", 0.0, 0.5))
	_box(n, Vector3(1.9, 0.3, 1.3), Vector3(0, 0.3, -0.9), P.m("2a2d31"))
	_cyl(n, 0.06, 0.06, 1.8, Vector3(-1.0, 2.0, 1.0), P.m("c9cfd6", 0.0, 0.2, 1.0), Vector3.ZERO, 8)
	_cyl(n, 0.06, 0.06, 1.8, Vector3(1.0, 2.0, 1.0), P.m("c9cfd6", 0.0, 0.2, 1.0), Vector3.ZERO, 8)
	_lights(n, 1.34, 0.9, 0.72)
	_wheels(n, [-0.98, 0.98], [0.7, -0.5, -1.1], 0.4)


static func _boat_trailer(n: Node3D) -> void:
	var hull := P.m("f2f2ee", 0.0, 0.3, 0.2)
	var stripe := P.m("1f5f94", 0.0, 0.4)
	_box(n, Vector3(1.0, 0.18, 2.8), Vector3(0, 0.62, 0), P.m("3a3f46", 0.0, 0.5, 0.7))
	_wheels(n, [-0.98, 0.98], [-0.3], 0.38)
	_sph(n, 1.0, Vector3(0, 1.25, 0.1), hull, Vector3(0.98, 0.9, 1.4), 14)
	_box(n, Vector3(1.9, 0.08, 2.5), Vector3(0, 1.6, 0.1), P.m("c9a56a", 0.0, 0.85))
	_box(n, Vector3(1.0, 0.7, 0.8), Vector3(0, 2.0, -0.2), hull)
	_box(n, Vector3(0.9, 0.35, 0.06), Vector3(0, 2.1, 0.22), P.m("1c2a38", 0.1, 0.1, 0.5))
	_box(n, Vector3(1.96, 0.16, 2.0), Vector3(0, 1.2, 0.2), stripe)
	_cyl(n, 0.03, 0.03, 1.0, Vector3(0.3, 2.65, -0.2), P.m("c9cfd6", 0.0, 0.2, 1.0), Vector3.ZERO, 5)
	_box(n, Vector3(0.2, 0.2, 0.2), Vector3(0, 0.55, 1.45), P.m("ff8a00", 2.4))


static func _drum_pallets(n: Node3D) -> void:
	var cols := ["2a6fb0", "c8322a", "3b9a58"]
	var wood := P.m("a97a3e", 0.0, 0.9)
	for lvl in 2:
		_box(n, Vector3(1.9, 0.12, 2.5), Vector3(0, 0.06 + lvl * 1.35, 0), wood)
		for i in 3:
			for j in 4:
				var c := P.m(cols[(i + j + lvl) % 3], 0.0, 0.55, 0.5)
				var x := -0.6 + i * 0.6
				var z := -0.95 + j * 0.62
				_cyl(n, 0.26, 0.26, 1.0, Vector3(x, 0.68 + lvl * 1.35, z), c, Vector3.ZERO, 12)
				_cyl(n, 0.27, 0.27, 0.05, Vector3(x, 0.5 + lvl * 1.35, z), P.m("2e2a28", 0.0, 0.6, 0.6), Vector3.ZERO, 12)
	_box(n, Vector3(1.96, 0.04, 0.04), Vector3(0, 1.0, 1.26), P.m("f5c518", 0.5))


static func _open_container(n: Node3D) -> void:
	var cols := ["d6502d", "2f7fc0", "3b9a58"]
	var m := Gfx.mat(Color(cols[_rng.randi() % 3]), 0.0, Gfx.ribs_tex(), 0.55)
	var steel := P.m("5a6670", 0.0, 0.4, 0.8)
	_box(n, Vector3(2.0, 2.4, 0.15), Vector3(0, 1.2, -1.22), m)
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.15, 2.4, 2.6), Vector3(s * 0.93, 1.2, 0), m)
	_box(n, Vector3(2.0, 0.15, 2.6), Vector3(0, 2.4, 0), m)
	_box(n, Vector3(2.0, 0.15, 2.6), Vector3(0, 0.08, 0), P.m("6a4a2c", 0.0, 0.9))
	var crate := Gfx.mat(Color.WHITE, 0.0, Gfx.crate_tex(), 0.85)
	_box(n, Vector3(0.9, 0.9, 0.9), Vector3(-0.3, 0.55, -0.3), crate)
	_box(n, Vector3(0.7, 0.7, 0.7), Vector3(0.3, 0.45, 0.4), crate, Vector3(0, 20, 0))
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.08, 2.4, 0.08), Vector3(s * 0.55, 1.2, 1.3), steel)
	Gfx.glow(n, Vector3(0, 1.0, 0.6), 2.0, Color(1.0, 0.9, 0.7, 0.18))


static func _forklift_block(n: Node3D) -> void:
	var body := P.m("f5a31a", 0.0, 0.4, 0.3)
	var dark := P.m("2a2d31", 0.0, 0.6)
	_box(n, Vector3(1.5, 0.9, 1.7), Vector3(0, 0.75, -0.3), body)
	_box(n, Vector3(1.5, 0.15, 1.2), Vector3(0, 1.3, -0.5), body)
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.08, 1.0, 0.08), Vector3(s * 0.7, 1.9, -0.2), dark)
		_box(n, Vector3(0.08, 1.0, 0.08), Vector3(s * 0.7, 1.9, -1.1), dark)
	_box(n, Vector3(1.5, 0.08, 1.2), Vector3(0, 2.45, -0.6), dark)
	_box(n, Vector3(0.6, 0.5, 0.5), Vector3(0, 1.6, -0.7), P.m("2a2d31", 0.0, 0.8))
	_box(n, Vector3(0.12, 2.6, 0.12), Vector3(-0.45, 1.3, 1.0), P.m("8a96a3", 0.0, 0.4, 0.8))
	_box(n, Vector3(0.12, 2.6, 0.12), Vector3(0.45, 1.3, 1.0), P.m("8a96a3", 0.0, 0.4, 0.8))
	for s in [-0.4, 0.4]:
		_box(n, Vector3(0.12, 0.08, 1.3), Vector3(s, 0.1, 1.5), P.m("8a96a3", 0.0, 0.4, 0.8))
	var crate := Gfx.mat(Color.WHITE, 0.0, Gfx.crate_tex(), 0.85)
	_box(n, Vector3(1.1, 0.9, 1.0), Vector3(0, 0.62, 1.55), crate)
	_box(n, Vector3(0.14, 0.14, 0.14), Vector3(0, 2.55, -0.6), P.m("ff8a00", 3.0))
	_wheels(n, [-0.8, 0.8], [0.3, -0.9], 0.36)
	_box(n, Vector3(2.0, 0.9, 0.3), Vector3(0, 0.6, -1.25), P.m("c9951a", 0.0, 0.6))


static func _spire_cluster(n: Node3D) -> void:
	var obs := P.m("15121a", 0.25, 0.15, 0.4)
	var lava := P.m("ff5a14", 2.6, 0.5)
	var hs := [2.8, 2.0, 1.6, 2.4, 1.2]
	var xs := [-0.5, 0.4, 0.0, 0.7, -0.8]
	var zs := [0.0, -0.4, 0.8, 0.6, 0.5]
	for i in 5:
		var c := _cone(n, 0.5 - i * 0.04, hs[i], Vector3(xs[i], 0, zs[i]), obs, 6)
		c.rotation_degrees = Vector3(_rng.randf_range(-4, 4), 0, _rng.randf_range(-5, 5))
	_box(n, Vector3(0.05, 0.9, 0.05), Vector3(-0.35, 0.8, 0.45), lava, Vector3(0, 0, 8))
	_box(n, Vector3(0.05, 1.1, 0.05), Vector3(0.55, 0.7, 0.2), lava, Vector3(0, 0, -6))
	_sph(n, 0.9, Vector3(0, 0.1, 0.4), P.m("26232a", 0.0, 0.95), Vector3(1.2, 0.35, 1.1), 8)
	Gfx.glow(n, Vector3(0, 0.5, 1.2), 3.0, Color(1.0, 0.4, 0.15, 0.3))


static func _basalt_columns(n: Node3D) -> void:
	var b := P.m("33303a", 0.0, 0.7, 0.2)
	var b2 := P.m("45414d", 0.0, 0.7, 0.2)
	for i in 3:
		for j in 3:
			var h := _rng.randf_range(1.2, 2.8)
			_cyl(n, 0.34, 0.36, h, Vector3(-0.62 + i * 0.62, h * 0.5, -0.8 + j * 0.8), b if (i + j) % 2 == 0 else b2, Vector3.ZERO, 6)
	Gfx.glow(n, Vector3(0, 0.3, 1.3), 2.6, Color(1.0, 0.4, 0.1, 0.25))
	_box(n, Vector3(1.8, 0.04, 0.05), Vector3(0, 0.08, 1.32), P.m("ff5a14", 2.6))


static func _lava_wall(n: Node3D) -> void:
	var rock := P.m("2c2a30", 0.0, 0.95)
	var lava := P.m("ff5a14", 2.8, 0.5)
	_box(n, Vector3(2.0, 2.6, 2.4), Vector3(0, 1.3, 0), rock, Vector3(0, 2, 0))
	_sph(n, 1.0, Vector3(0, 2.5, 0.1), rock, Vector3(1.0, 0.55, 1.2), 8)
	for k in 5:
		var x := -0.8 + k * 0.4
		_box(n, Vector3(0.06, _rng.randf_range(0.8, 2.0), 0.05), Vector3(x, 1.0 + _rng.randf_range(0, 0.6), 1.22), lava, Vector3(0, 0, _rng.randf_range(-18, 18)))
	Gfx.glow(n, Vector3(0, 1.4, 1.5), 3.4, Color(1.0, 0.4, 0.1, 0.4))


static func _fallen_pillar(n: Node3D) -> void:
	var st := P.m("5a5660", 0.0, 0.9)
	var lava := P.m("ff5a14", 2.6, 0.5)
	_cyl(n, 0.55, 0.55, 2.6, Vector3(0, 0.6, 0), st, Vector3(90, 0, 10), 10)
	_cyl(n, 0.62, 0.62, 0.15, Vector3(0, 0.6, 1.3), st, Vector3(90, 0, 10), 10)
	_cyl(n, 0.5, 0.5, 1.4, Vector3(0, 1.9, -0.9), st, Vector3(-20, 0, 6), 10)
	for k in 3:
		_box(n, Vector3(0.05, 0.05, 0.6), Vector3(-0.8 + k * 0.8, 0.12, 0.6), lava)
	_sph(n, 0.6, Vector3(-0.6, 0.3, 1.0), P.m("26232a", 0.0, 0.95), Vector3(1.2, 0.6, 1.0), 6)
	Gfx.glow(n, Vector3(0, 0.3, 1.4), 2.4, Color(1.0, 0.4, 0.1, 0.3))


static func _geyser_rock(n: Node3D) -> void:
	var rock := P.m("26232a", 0.0, 0.95)
	_cyl(n, 0.7, 1.0, 1.8, Vector3(0, 0.9, 0), rock, Vector3.ZERO, 8)
	_cyl(n, 0.45, 0.6, 0.5, Vector3(0, 2.0, 0), rock, Vector3.ZERO, 8)
	_cyl(n, 0.3, 0.3, 0.05, Vector3(0, 2.26, 0), P.m("ff5a14", 3.0), Vector3.ZERO, 8)
	Gfx.glow(n, Vector3(0, 2.6, 0), 2.6, Color(1.0, 0.5, 0.2, 0.55))
	Gfx.glow(n, Vector3(0, 3.2, 0), 2.2, Color(0.9, 0.85, 0.85, 0.2))
	for k in 3:
		_sph(n, 0.4, Vector3(-0.9 + k * 0.9, 0.3, 0.9), rock, Vector3(1.0, 0.7, 1.0), 6)


static func _skull_rock(n: Node3D) -> void:
	var rock := P.m("3a363e", 0.0, 0.9)
	var bone := P.m("e6dcc4", 0.0, 0.8)
	_sph(n, 1.0, Vector3(0, 1.0, 0), rock, Vector3(1.0, 1.1, 1.2), 10)
	_sph(n, 0.7, Vector3(0, 1.6, 0.8), bone, Vector3(1.0, 1.0, 0.9), 10)
	_box(n, Vector3(0.7, 0.35, 0.5), Vector3(0, 1.1, 1.0), bone)
	for s in [-1.0, 1.0]:
		_sph(n, 0.18, Vector3(s * 0.28, 1.65, 1.35), P.m("15121a"), Vector3.ONE, 6)
		_sph(n, 0.08, Vector3(s * 0.28, 1.65, 1.45), P.m("ff4a1a", 3.0), Vector3.ONE, 6)
	for k in 5:
		_box(n, Vector3(0.1, 0.18, 0.06), Vector3(-0.24 + k * 0.12, 0.98, 1.27), bone)
	Gfx.glow(n, Vector3(0, 1.6, 1.6), 1.6, Color(1.0, 0.3, 0.1, 0.35))
