extends CanvasLayer
## رابط کاربری: منو، HUD، فروشگاه، پایان بازی، صفحه‌ی کاراکتر، ساخت کاراکتر از چند عکس و طراحی سکه.
## همه‌چیز با کد ساخته می‌شود.

const COL_PURPLE := Color("8b019d")
const COL_PURPLE_HOVER := Color("a912bd")
const COL_PURPLE_DOWN := Color("6a0078")
const COL_TEXT := Color("fff1de")
const COL_ORANGE := Color("ffb02e")
const COL_GOOD := Color("5dff8a")
const COL_BAD := Color("ff5b6e")
const COL_PINK := Color("ffc04d")

const CharacterModel := preload("res://scripts/character_model.gd")
const SkinLib := preload("res://scripts/skin_lib.gd")
const Studio := preload("res://scripts/studio.gd")
const GlbModel := preload("res://scripts/glb_model.gd")
const UiArt := preload("res://scripts/ui_art.gd")
const SettingsScreen := preload("res://scripts/settings_screen.gd")

const POWER_KIND: Array[String] = ["magnet", "shield", "x2", "jet", "spring", "slow"]
const BoostBar := preload("res://scripts/boost_bar.gd")
var _boost_bar
const POWER_UI_COLORS: Array[Color] = [Color("ff4a4a"), Color("38d6ff"), Color("ffd23a"), Color("ff8a2a"), Color("8aff3a"), Color("b07aff")]

enum Screen { INTRO, START, GAME, SHOP, GAMEOVER, CHARACTER, BUILDER, COIN, STUDIO, SETTINGS, MISSIONS, ACCOUNT, BOARD, ONLINE_STORE, CHALLENGE, CONTENT, RULES, CHOOSER }

const SLOT_TITLES := {"face": "صورت", "front": "جلو", "back": "پشت", "right": "راست", "left": "چپ"}
const SLOT_HINTS := {
	"face": "عکس نزدیک از صورت (اختیاری، جزئیات چهره)",
	"front": "تمام‌قد از روبه‌رو، پس‌زمینه‌ی ساده بهتر است",
	"back": "تمام‌قد از پشت (اختیاری)",
	"right": "نیم‌رخ؛ فرد رو به راست عکس (اختیاری)",
	"left": "نیم‌رخ؛ فرد رو به چپ عکس (اختیاری)",
}

var _screen: int = Screen.START

var _char_ui: Control
var _skin_row: HBoxContainer
var _char_name: Label
var _char_info: Label
var _mode_btn: Button
var _slim_btn: Button
var _style_btn: Button
var _export_btn: Button
var _del_btn: Button
var _glb_add_btn: Button
var _glb_hint: Label
var _glb_yaw_btn: Button
var _glb_ctl_btn: Button
var _char_tab := 2
var _char_tab_btns: Array[Button] = []
var _tab_boxes: Array = []
var _mc_box: HBoxContainer
var _mc_name: LineEdit
var _mc_btn: Button
var _mc_http: HTTPRequest
var _edit_btn: Button
var _file_dialog: FileDialog
var _pick_target := "char"
var _pv := {}   # کلید پیش‌نمایش → {pivot, content, yaw, cd, spin}

var _builder_ui: Control
var _b_slots := {}
var _b_style := 0
var _b_thumbs := {}
var _b_style_btn: Button
var _b_msg: Label
var _b_name: LineEdit

var _coin_ui: Control
var _studio_ui: Control
var _studio
var _settings_ui: Control
var _missions_ui: Control
var _online: Node
var _account_chip: Button
var _announce: Label
var _missions_box: VBoxContainer
var _settings
var _coin_info: Label
var _coin_style_btn: Button
var _coin_save_btn: Button
var _coin_photo_box: VBoxContainer
var _coin_cut_img: TextureRect
var _coin_bg_lbl: Label
var _coin_bg_btn: Button
var _coin_cut_stamp := -1
var _coin_density: HSlider
var _coin_contrast: HSlider
var _coin_design_btns: Array[Button] = []
var _coin_updating := false

var _countdown := -1.0
var _toast_tween: Tween
var _hint_tween: Tween
var _rng := RandomNumberGenerator.new()

var _root: Control
var _menu_box: VBoxContainer
var _start_coin_row: Control
var _hud_coin_row: Control
var _editors
var _intro_ui: Control
var _intro_title: Label
var _intro_hint: Label
var _start_ui: Control
var _hud_ui: Control
var _shop_ui: Control
var _over_ui: Control
var _pause_ui: Control

var _start_coins: Label
var _start_coin_icon: TextureRect
var _rays: TextureRect
var _menu_grad: TextureRect
var _menu_title: Label
var _stars: Array[Dictionary] = []
const MENU_PAL := [
	{"top": Color(0.18, 0.04, 0.02, 0.62), "bot": Color(0.06, 0.0, 0.1, 0.78), "ray": Color(1.0, 0.82, 0.4, 0.2), "title": Color("ffc04d"), "outline": Color("5a2a08"), "star": Color("ffe08a")},
	{"top": Color(0.02, 0.0, 0.12, 0.7), "bot": Color(0.25, 0.0, 0.22, 0.78), "ray": Color(1.0, 0.2, 0.7, 0.2), "title": Color("ff5ac8"), "outline": Color("2a0a4a"), "star": Color("27e8ff")},
	{"top": Color(0.0, 0.12, 0.05, 0.6), "bot": Color(0.02, 0.06, 0.02, 0.8), "ray": Color(0.6, 1.0, 0.5, 0.18), "title": Color("a6ff6a"), "outline": Color("0e3a12"), "star": Color("e8ffb0")},
	{"top": Color(0.0, 0.1, 0.25, 0.6), "bot": Color(0.0, 0.02, 0.12, 0.82), "ray": Color(0.4, 0.9, 1.0, 0.18), "title": Color("6ae4ff"), "outline": Color("062a4a"), "star": Color("ffffff")},
]
var _start_best: Label
var _sound_btn: Button
var _vib_btn: Button

var _score_lbl: Label
var _coins_lbl: Label
var _coin_icon: TextureRect
var _dist_lbl: Label
var _hint_lbl: Label
var _warn_lbl: Label
var _power_rows: Array[Control] = []
var _power_bars: Array[ProgressBar] = []
var _power_lbls: Array[Label] = []

var _shop_coins: Label
var _shop_best: Label
var _shop_desc: Array[Label] = []
var _shop_price: Array[Label] = []
var _shop_btn: Array[Button] = []

var _pause_coins: Label
var _over_title: Label
var _over_msg: Label
var _revive_btn: Button
var _ticket_btn: Button
var _start_loadout: HBoxContainer

var _countdown_lbl: Label
var _toast_panel: PanelContainer
var _toast_lbl: Label
var _flash: ColorRect


func _ready() -> void:
	_setup_auto_fit()
	layer = 10
	_rng.randomize()
	get_tree().node_added.connect(_on_node_added)

	_root = Control.new()
	add_child(_root)
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.layout_direction = Control.LAYOUT_DIRECTION_LTR
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UiArt.style = String(Content.look("style", "classic"))
	_root.theme = _build_theme()
	_sig = _look_sig()
	Content.changed.connect(func(): apply_look())

	_build_start()
	_build_intro()
	_build_shop()
	_build_character()
	_build_builder()
	_build_coin_screen()
	_build_studio()
	_build_settings()
	_build_missions()
	_online = preload("res://scripts/online_screens.gd").new()
	add_child(_online)
	_online.build(self, _root)
	_editors = preload("res://scripts/content_editor.gd").new()
	add_child(_editors)
	_editors.build(self, _root)
	_build_hud()
	_build_over()
	_build_pause()
	_build_overlays()
	_build_net_lock()

	Game.score_changed.connect(func(v: int): _score_lbl.text = "امتیاز: %d" % v)
	Game.run_coins_changed.connect(func(v: int): _coins_lbl.text = str(v))
	Game.distance_changed.connect(func(v: int): _dist_lbl.text = "%d متر" % v)
	Game.coins_changed.connect(func(_v: int): _refresh_all())
	Game.high_score_changed.connect(func(_v: int): _refresh_all())
	Game.game_started.connect(_on_game_started)
	Game.intro_started.connect(_on_intro_started)
	Game.game_over.connect(_on_game_over)
	Game.revived.connect(func(): _set_screen(Screen.GAME))
	Game.session_ended.connect(func(): _set_screen(Screen.START))
	Game.pause_changed.connect(_on_pause_changed)
	Game.popup.connect(_show_popup)
	Game.toast.connect(_show_toast)
	Game.player_hit.connect(_on_player_hit)
	Skins.changed.connect(_refresh_character)
	Edition.changed.connect(_refresh_character)
	Skins.glb_cfg_changed.connect(func():
		for k in _pv:
			var c = _pv[k]["content"]
			if c.get("is_glb") == true:
				c.apply_config(Skins.glb_cfg(Skins.current_entry())))
	CoinSkin.changed.connect(_refresh_coin)
	CoinSkin.draft_changed.connect(_refresh_coin)
	get_window().files_dropped.connect(_on_files_dropped)

	Content.changed.connect(func():
		_rebuild_menu()
		_refresh_all()
		Content.apply_tree.call_deferred(_root))
	Edition.changed.connect(func():
		_rebuild_menu()
		_refresh_all())
	_rebuild_menu()
	_refresh_character()
	_refresh_coin()
	_b_update_preview()
	_set_screen(Screen.START)


func _process(delta: float) -> void:
	_update_pads()
	for key in _pv:
		var d: Dictionary = _pv[key]
		var pivot: Node3D = d["pivot"]
		if not pivot.is_inside_tree() or not (d["holder"] as Control).is_visible_in_tree():
			continue
		d["cd"] = maxf(0.0, float(d["cd"]) - delta)
		if float(d["cd"]) <= 0.0 and bool(d.get("auto", true)):
			d["yaw"] = float(d["yaw"]) + delta * (2.2 if d["spin"] else 0.9)
		pivot.rotation.y = float(d["yaw"])
		if d.has("cam") and is_instance_valid(d["cam"]):
			var off: Vector3 = (d["cam_pos"] - d["look"]).rotated(Vector3.RIGHT, float(d["pitch"])) / float(d["zoom"])
			var cpos: Vector3 = d["look"] + off
			d["cam"].transform = Transform3D(Basis.looking_at(d["look"] - cpos, Vector3.UP), cpos)
		if not d["spin"]:
			(d["content"]).pose_idle(Time.get_ticks_msec() / 1000.0)
	if _start_ui.visible:
		_rays.rotation += delta * 0.12
		_tick_stars(delta)
	if _screen == Screen.GAME:
		_update_hud()
	if _countdown <= 0.0:
		return
	var prev := ceili(_countdown)
	_countdown -= delta
	if _countdown <= 0.0:
		_countdown = -1.0
		_countdown_lbl.visible = false
		Game.resume_game()
		Sfx.play("go")
	else:
		var cur := ceili(_countdown)
		_countdown_lbl.text = str(cur)
		if cur != prev:
			Sfx.play("tick")


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_on_back()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_on_back()


## دکمه‌ی Back اندروید (و Esc در کامپیوتر)
func _on_back() -> void:
	if _countdown > 0.0:
		return
	match _screen:
		Screen.GAME:
			if Game.is_paused:
				_on_resume_pressed()
			elif Game.is_active:
				Game.pause_game()
		Screen.BUILDER, Screen.STUDIO:
			if _screen == Screen.STUDIO:
				_studio._save_draft()
			_set_screen(Screen.CHARACTER)
		Screen.SHOP, Screen.CHARACTER, Screen.COIN, Screen.SETTINGS, Screen.MISSIONS, Screen.ACCOUNT, Screen.BOARD, Screen.ONLINE_STORE, Screen.CONTENT, Screen.RULES, Screen.CHOOSER:
			_set_screen(Screen.START)
		Screen.GAMEOVER:
			Game.quit_to_menu()
		Screen.START:
			get_tree().quit()


# ------------------------- تم و ابزارهای ساخت -------------------------
func _flat(color: Color, radius: int, border: int = 0) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 24
	sb.content_margin_right = 24
	sb.content_margin_top = 12
	sb.content_margin_bottom = 12
	if border > 0:
		sb.border_width_bottom = border
		sb.border_color = color.darkened(0.35)
	return sb

const CUSTOM_FONT := "user://custom_font.dat"
var _font_cache := {}


## فونت انتخاب‌شده: وزیرمتن (فارسی، پیش‌فرض)، سیستم، یا فایل خودت
func look_font() -> Font:
	var id := String(Content.look("font", "vazir"))
	if _font_cache.has(id):
		return _font_cache[id]
	var vz: Font = load("res://assets/fonts/Vazirmatn-Regular.ttf")
	var f: Font = vz
	match id:
		"vazir_bold":
			f = load("res://assets/fonts/Vazirmatn-Bold.ttf")
		"vazir_black":
			f = load("res://assets/fonts/Vazirmatn-Black.ttf")
		"system":
			var sf := SystemFont.new()
			sf.font_names = PackedStringArray(["sans-serif"])
			f = sf
		"custom":
			if FileAccess.file_exists(CUSTOM_FONT):
				var ff := FontFile.new()
				ff.data = FileAccess.get_file_as_bytes(CUSTOM_FONT)
				if ff.data.size() > 0:
					ff.fallbacks = [vz]      # حرف‌هایی که فونت تو ندارد (مثل فارسی) از وزیرمتن می‌آید
					f = ff
	if f == null:
		f = vz
	_font_cache[id] = f
	return f


func _look_sig() -> String:
	var c := []
	for k in Content.LOOK_KINDS:
		c.append(Content.look_color(k[0]).to_html())
	return "%s|%s|%s|%s" % [Content.look("style", "classic"), ",".join(c), Content.look("font", "vazir"), FileAccess.get_modified_time(CUSTOM_FONT) if FileAccess.file_exists(CUSTOM_FONT) else 0]


var _sig := ""


func apply_look(force: bool = false) -> void:
	var sig := _look_sig()
	if sig == _sig and not force:
		return
	_sig = sig
	_font_cache.clear()
	UiArt.style = String(Content.look("style", "classic"))
	if _root != null:
		_root.theme = _build_theme()


func _build_theme() -> Theme:
	var th := Theme.new()
	var fnt := look_font()
	if fnt != null:
		th.default_font = fnt
		ThemeDB.fallback_font = fnt
	th.set_color("font_color", "Label", COL_TEXT)
	th.set_font_size("font_size", "Label", 34)
	th.set_font_size("font_size", "Button", 38)
	th.set_color("font_color", "Button", Color.WHITE)
	th.set_color("font_hover_color", "Button", Color.WHITE)
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	th.set_color("font_disabled_color", "Button", Color("aaaaaa"))
	var kinds := {
		"Button": [Content.look_color("Button"), Color.WHITE],
		"GoldButton": [Content.look_color("GoldButton"), Color("4a2300")],
		"TealButton": [Content.look_color("TealButton"), Color.WHITE],
		"RedButton": [Content.look_color("RedButton"), Color.WHITE],
		"DarkButton": [Content.look_color("DarkButton"), Color.WHITE],
	}
	var st_id: String = UiArt.style
	for k in kinds:
		var base: Color = kinds[k][0]
		var fc: Color = kinds[k][1]
		if st_id == "glass":
			fc = Color.WHITE
		elif st_id == "neon" or st_id == "outline":
			fc = base.lightened(0.78)
		elif k == "GoldButton" and base.get_luminance() < 0.45:
			fc = Color.WHITE
		if k != "Button":
			th.set_type_variation(k, "Button")
		th.set_stylebox("normal", k, UiArt.button_style(base))
		th.set_stylebox("hover", k, UiArt.button_style(base.lightened(0.14)))
		th.set_stylebox("pressed", k, UiArt.button_style(base.darkened(0.12), 3, 0.5))
		th.set_stylebox("disabled", k, UiArt.button_style(Color("55506a"), 8, 0.3))
		if st_id == "glass" or st_id == "neon":
			th.set_color("font_outline_color", k, Color(0, 0, 0, 0.45))
		th.set_stylebox("focus", k, StyleBoxEmpty.new())
		th.set_color("font_color", k, fc)
		th.set_color("font_hover_color", k, fc)
		th.set_color("font_pressed_color", k, fc)
		th.set_color("font_disabled_color", k, Color("a9a4bd"))
		th.set_color("font_outline_color", k, Color(0, 0, 0, 0.35) if k != "GoldButton" else Color(1, 1, 1, 0.25))
		th.set_constant("outline_size", k, 3)
	for st in ["normal", "hover", "pressed", "disabled"]:
		th.set_stylebox(st, "OptionButton", UiArt.button_style(Color("3b1f66") if st != "hover" else Color("55308c"), 6))
	th.set_stylebox("focus", "OptionButton", StyleBoxEmpty.new())
	# تیک‌باکس و دکمه‌ی روشن/خاموش: بدون قاب دکمه (قبلاً از استایل Button ارث می‌برد و به‌هم می‌ریخت)
	for ck in ["CheckBox", "CheckButton"]:
		for st in ["normal", "hover", "pressed", "disabled", "focus", "hover_pressed"]:
			var eb := StyleBoxEmpty.new()
			eb.content_margin_left = 6
			eb.content_margin_right = 6
			eb.content_margin_top = 6
			eb.content_margin_bottom = 6
			th.set_stylebox(st, ck, eb)
		th.set_icon("checked", ck, UiArt.check_tex(true))
		th.set_icon("unchecked", ck, UiArt.check_tex(false))
		th.set_icon("checked_disabled", ck, UiArt.check_tex(true))
		th.set_icon("unchecked_disabled", ck, UiArt.check_tex(false))
		for fc in ["font_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color", "font_focus_color"]:
			th.set_color(fc, ck, Color.WHITE)
		th.set_constant("h_separation", ck, 14)
		th.set_font_size("font_size", ck, 28)
	th.set_font_size("font_size", "OptionButton", 24)
	th.set_font_size("font_size", "PopupMenu", 28)
	th.set_constant("v_separation", "PopupMenu", 16)
	# سایه‌ی نوشته‌ها و پنل‌های شیشه‌ای
	th.set_color("font_shadow_color", "Label", Color(0, 0, 0, 0.55))
	th.set_constant("shadow_offset_x", "Label", 0)
	th.set_constant("shadow_offset_y", "Label", 3)
	th.set_stylebox("panel", "PanelContainer", UiArt.panel_style())
	# اسلایدر طلایی
	th.set_stylebox("slider", "HSlider", UiArt.track_style(Color(0.05, 0.02, 0.12, 0.85), 14))
	th.set_stylebox("grabber_area", "HSlider", UiArt.track_style(Color("ffb02e"), 14))
	th.set_stylebox("grabber_area_highlight", "HSlider", UiArt.track_style(Color("ffc95a"), 14))
	th.set_icon("grabber", "HSlider", UiArt.knob_tex(Color("ffb02e")))
	th.set_icon("grabber_highlight", "HSlider", UiArt.knob_tex(Color("ffd36a")))
	th.set_icon("grabber_disabled", "HSlider", UiArt.knob_tex(Color("888888")))
	# برای دیالوگ انتخاب فایل (در موبایل خوانا باشد)
	th.set_font_size("font_size", "LineEdit", 30)
	th.set_font_size("font_size", "Tree", 28)
	th.set_font_size("font_size", "ItemList", 28)
	th.set_constant("v_separation", "Tree", 16)
	return th

func _label(text: String, size: int = 34, color: Color = COL_TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.text_direction = Control.TEXT_DIRECTION_AUTO
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l

func _button(text: String, cb: Callable, min_size: Vector2 = Vector2(540, 104), size: int = 38, kind: String = "") -> Button:
	var b := Button.new()
	if kind != "":
		b.theme_type_variation = kind + "Button"
	b.resized.connect(func(): b.pivot_offset = b.size * 0.5)
	b.button_down.connect(func(): b.scale = Vector2(0.96, 0.96))
	b.button_up.connect(func(): b.scale = Vector2.ONE)
	b.text = text
	b.text_direction = Control.TEXT_DIRECTION_AUTO
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", size)
	b.pressed.connect(func():
		Sfx.play("click")
		cb.call())
	return b

func _pill(content: Control) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiArt.panel_style(Color(0.1, 0.03, 0.2, 0.66)))
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(content)
	return p

func _add_full(parent: Node, c: Control) -> void:
	parent.add_child(c)
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _dim_rect(alpha: float) -> ColorRect:
	var r := ColorRect.new()
	r.color = Color(0.05, 0.0, 0.1, alpha)
	return r


# ------------------------- اینترو -------------------------
func _build_intro() -> void:
	_intro_ui = Control.new()
	_add_full(_root, _intro_ui)
	_intro_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_intro_ui.visible = false
	var top := ColorRect.new()          # نوار سینمایی
	top.color = Color(0, 0, 0, 0.85)
	_add_full(_intro_ui, top)
	top.anchor_bottom = 0.0
	top.offset_bottom = 150
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bot := ColorRect.new()
	bot.color = Color(0, 0, 0, 0.85)
	_add_full(_intro_ui, bot)
	bot.anchor_top = 1.0
	bot.offset_top = -190
	bot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_intro_title = _label("فرار از دلقک", 92, Color("ffd84a"))
	_intro_title.add_theme_color_override("font_outline_color", Color.BLACK)
	_intro_title.add_theme_constant_override("outline_size", 12)
	_add_full(_intro_ui, _intro_title)
	_intro_title.anchor_bottom = 0.0
	_intro_title.offset_top = 30
	_intro_title.offset_bottom = 140
	_intro_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_intro_hint = _label("فرار کن!  لمس کن تا رد شود", 38, Color("ffffff"))
	_add_full(_intro_ui, _intro_hint)
	_intro_hint.anchor_top = 1.0
	_intro_hint.offset_top = -150
	_intro_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER


func _on_intro_started() -> void:
	_set_screen(Screen.INTRO)
	_intro_title.modulate.a = 0.0
	create_tween().tween_property(_intro_title, "modulate:a", 1.0, 0.8)
	_intro_hint.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_interval(1.4)
	tw.tween_property(_intro_hint, "modulate:a", 1.0, 0.4)


# ------------------------- منوی شروع -------------------------
const LOGO_PATH := "user://logo.png"
var _logo_rect: TextureRect


## عکس لوگوی منو (انتخاب‌شده از فایل‌های گوشی)؛ اگر نباشد پنهان می‌ماند
func refresh_logo() -> void:
	if _logo_rect == null:
		return
	var img: Image = Image.load_from_file(LOGO_PATH) if FileAccess.file_exists(LOGO_PATH) else null
	if img != null and not img.is_empty():
		_logo_rect.texture = ImageTexture.create_from_image(img)
		_logo_rect.visible = true
	else:
		_logo_rect.texture = null
		_logo_rect.visible = false


func set_logo(img: Image) -> void:
	var m := maxi(img.get_width(), img.get_height())
	if m > 512:
		var k := 512.0 / float(m)
		img.resize(int(img.get_width() * k), int(img.get_height() * k), Image.INTERPOLATE_LANCZOS)
	img.save_png(LOGO_PATH)
	refresh_logo()


func clear_logo() -> void:
	if FileAccess.file_exists(LOGO_PATH):
		DirAccess.remove_absolute(LOGO_PATH)
	refresh_logo()


func _build_start() -> void:
	_start_ui = Control.new()
	_add_full(_root, _start_ui)
	_menu_grad = TextureRect.new()
	_menu_grad.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_menu_grad.stretch_mode = TextureRect.STRETCH_SCALE
	_menu_grad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_add_full(_start_ui, _menu_grad)
	var vig := TextureRect.new()
	vig.texture = UiArt.vignette_tex()
	vig.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vig.stretch_mode = TextureRect.STRETCH_SCALE
	vig.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_add_full(_start_ui, vig)
	_rays = TextureRect.new()
	_rays.texture = UiArt.rays_tex(Color(1.0, 0.82, 0.4, 0.2), 16)
	_rays.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_rays.stretch_mode = TextureRect.STRETCH_SCALE
	_rays.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rays.size = Vector2(980, 980)
	_rays.position = Vector2(360.0 - 490.0, 230.0 - 490.0)
	_rays.pivot_offset = Vector2(490, 490)
	_start_ui.add_child(_rays)
	# ستون منو داخل اسکرول است: وقتی بخش‌ها زیاد باشند (نسخه‌ی مالک) از صفحه بیرون نمی‌زند و همه در دسترس‌اند
	var start_sc := ScrollContainer.new()
	start_sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_add_full(_start_ui, start_sc)
	var center := CenterContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	start_sc.add_child(center)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 20)
	center.add_child(col)
	var top_gap := Control.new()          # جای نوار حساب و اعلان بالای صفحه
	top_gap.custom_minimum_size = Vector2(0, 110)
	col.add_child(top_gap)

	_logo_rect = TextureRect.new()
	_logo_rect.custom_minimum_size = Vector2(0, 150)
	_logo_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_logo_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	col.add_child(_logo_rect)
	refresh_logo()
	var title := _label("فرار از دلقک", 92, COL_PINK)
	_menu_title = title
	title.add_theme_color_override("font_outline_color", Color("5a2a08"))
	title.add_theme_constant_override("outline_size", 16)
	col.add_child(title)
	col.add_child(_label("بدو، سکه جمع کن، فرار کن!", 38))

	_start_coins = _label("", 40, COL_ORANGE)
	_start_best = _label("", 30)
	var cr := HBoxContainer.new()
	cr.alignment = BoxContainer.ALIGNMENT_CENTER
	cr.add_theme_constant_override("separation", 12)
	_start_coin_icon = TextureRect.new()
	_start_coin_icon.custom_minimum_size = Vector2(56, 56)
	_start_coin_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_start_coin_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	cr.add_child(_start_coin_icon)
	cr.add_child(_start_coins)
	_start_coin_row = cr
	col.add_child(cr)
	col.add_child(_start_best)
	_start_loadout = HBoxContainer.new()
	_start_loadout.alignment = BoxContainer.ALIGNMENT_CENTER
	_start_loadout.add_theme_constant_override("separation", 14)
	col.add_child(_start_loadout)
	Game.boosts_changed.connect(_refresh_loadout_strip)

	col.add_theme_constant_override("separation", 14)
	_menu_box = VBoxContainer.new()
	_menu_box.add_theme_constant_override("separation", 14)
	col.add_child(_menu_box)
	_sound_btn = Button.new()
	_vib_btn = Button.new()

	Game.menu_theme_changed.connect(_apply_menu_theme)
	_build_stars()
	_apply_menu_theme()
	# نوار بالای منو: نام حساب و اعلان مدیر
	_account_chip = _button("ورود / ثبت‌نام", func(): _set_screen(Screen.ACCOUNT), Vector2(300, 64), 26, "Dark")
	_account_chip.position = Vector2(24, 26)
	_start_ui.add_child(_account_chip)
	_announce = _label("", 26, COL_ORANGE)
	_announce.position = Vector2(24, 96)
	_announce.size = Vector2(672, 40)
	_announce.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_start_ui.add_child(_announce)
	_build_update_card(col)
	_build_version_label(col)

	var help := _label("سوایپ چپ/راست: عوض‌کردن خط\nسوایپ بالا: پرش  •  سوایپ پایین: سُرخوردن", 26)
	help.modulate = Color(1, 1, 1, 0.85)
	col.add_child(help)


## منوی اصلی از روی Content ساخته می‌شود (بخش‌ها، ترتیب و قابلیت‌ها قابل‌ویرایش‌اند)
func _rebuild_menu() -> void:
	if _menu_box == null:
		return
	for c in _menu_box.get_children():
		c.queue_free()
	var pending: Control = null
	for it: Dictionary in Content.menu_all():
		var ab := String(it.ability)
		var on := Content.can(ab)
		if not on and not Edition.is_owner():
			continue
		var half := bool(it.get("half", false))
		var big := bool(it.get("big", false))
		var label := String(it.text) + ("" if on else " (مخفی در عمومی)")
		var style := String(it.get("style", ""))
		var act := String(it.act)
		var btn := _button(label, func(): _menu_act(act), Vector2(272 if half else 560, 112 if big else 88), 50 if big else (30 if half else 34), style)
		var ico := MenuIcons.for_act(act)
		if ico != "":
			btn.icon = MenuIcons.tex(ico)
			btn.expand_icon = false
			btn.add_theme_constant_override("h_separation", 8 if half else 16)
		if not on:
			btn.modulate = Color(1, 1, 1, 0.55)
		if half:
			if pending == null:
				pending = btn
			else:
				_menu_box.add_child(_row2(pending, btn))
				pending = null
		else:
			if pending != null:
				_menu_box.add_child(_row2(pending, _spacer(272)))
				pending = null
			_menu_box.add_child(btn)
	if pending != null:
		_menu_box.add_child(_row2(pending, _spacer(272)))
	if Edition.is_owner():
		_menu_box.add_child(_row2(
			_button("ویرایش محتوا", func(): _set_screen(Screen.CONTENT), Vector2(272, 60), 24, "Dark"),
			_button("قوانین صدا", func(): _set_screen(Screen.RULES), Vector2(272, 60), 24, "Dark")))
	Content.apply_tree.call_deferred(_menu_box)
	# ورود پله‌پله‌ی دکمه‌ها (لغزش + محو)
	var k := 0
	for c in _menu_box.get_children():
		if c is Control:
			var ctl: Control = c
			var a0: float = ctl.modulate.a
			ctl.modulate.a = 0.0
			var tw := ctl.create_tween()
			tw.tween_interval(0.05 * k)
			tw.tween_property(ctl, "modulate:a", a0, 0.35)
			k += 1


## نوار جهان‌های پرتال در منو: کارت رنگی برای هر جهان/بازی (خودکار آرام می‌لغزد)
func _worlds_strip() -> Control:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	box.add_child(_label("جهان‌های پرتال: %d مقصد تصادفی" % Modes.IDS.size(), 26, Color("ffd27a")))
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(560, 150)
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	box.add_child(sc)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	sc.add_child(hb)
	for id in Modes.IDS:
		var d: Dictionary = Modes.def(id)
		var tint: Color = d.get("tint", Color("9d5cff"))
		var pc := PanelContainer.new()
		pc.custom_minimum_size = Vector2(170, 130)
		var sb := StyleBoxFlat.new()
		sb.bg_color = tint.darkened(0.55)
		sb.border_color = tint
		sb.set_border_width_all(3)
		sb.border_width_bottom = 8
		sb.set_corner_radius_all(20)
		sb.shadow_color = Color(tint.r, tint.g, tint.b, 0.35)
		sb.shadow_size = 8
		sb.content_margin_left = 10
		sb.content_margin_right = 10
		sb.content_margin_top = 10
		sb.content_margin_bottom = 8
		pc.add_theme_stylebox_override("panel", sb)
		var v := VBoxContainer.new()
		v.alignment = BoxContainer.ALIGNMENT_CENTER
		pc.add_child(v)
		var tag := _label("بازی مستقل" if Modes.is_mini(id) else "جهان دویدنی", 17, tint.lightened(0.4))
		tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(tag)
		var nm := _label(String(d.get("name", id)), 25, Color.WHITE)
		nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		nm.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		nm.custom_minimum_size = Vector2(150, 0)
		v.add_child(nm)
		pc.mouse_filter = Control.MOUSE_FILTER_PASS
		var wid: String = id
		pc.gui_input.connect(func(ev: InputEvent) -> void:
			if ev is InputEventMouseButton and ev.pressed:
				Game.popup.emit(String(Modes.def(wid).get("name", "")) + ": " + String(Modes.def(wid).get("desc", "")), false))
		hb.add_child(pc)
	var tw := sc.create_tween().set_loops()
	tw.tween_property(sc, "scroll_horizontal", 1600, 26.0).set_trans(Tween.TRANS_SINE)
	tw.tween_property(sc, "scroll_horizontal", 0, 26.0).set_trans(Tween.TRANS_SINE)
	return box


func _apply_menu_theme() -> void:
	var p: Dictionary = MENU_PAL[clampi(Game.menu_theme, 0, MENU_PAL.size() - 1)]
	if _menu_grad != null:
		_menu_grad.texture = preload("res://scripts/store_fx.gd").gradient_tex(p.top, p.bot, true)
	if _rays != null:
		_rays.texture = UiArt.rays_tex(p.ray, 16)
	if _menu_title != null:
		_menu_title.add_theme_color_override("font_color", p.title)
		_menu_title.add_theme_color_override("font_outline_color", p.outline)
	for s in _stars:
		(s.node as ColorRect).color = Color(p.star.r, p.star.g, p.star.b, 0.8)


## ستاره‌ها/ذره‌های شناور پشت منو
func _build_stars() -> void:
	_stars.clear()
	for i in 26:
		var r := ColorRect.new()
		var sz := randf_range(3.0, 7.0)
		r.size = Vector2(sz, sz)
		r.rotation = randf() * PI
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		r.position = Vector2(randf() * 720.0, randf() * 1280.0)
		_start_ui.add_child(r)
		_start_ui.move_child(r, 3)
		_stars.append({"node": r, "spd": randf_range(18.0, 60.0), "ph": randf() * TAU})


func _tick_stars(delta: float) -> void:
	for s in _stars:
		var r: ColorRect = s.node
		r.position.y -= float(s.spd) * delta
		r.position.x += sin(Time.get_ticks_msec() * 0.001 + float(s.ph)) * 12.0 * delta
		if r.position.y < -10.0:
			r.position = Vector2(randf() * 720.0, 1290.0)
		r.modulate.a = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.003 + float(s.ph))


## نوار ابزارهای همراه زیر امتیاز در منوی شروع؛ با لمس وارد فروشگاه قدرت‌ها می‌شود
func _refresh_loadout_strip() -> void:
	if _start_loadout == null:
		return
	for c in _start_loadout.get_children():
		c.queue_free()
	_start_loadout.visible = Content.can("power_shop") and Online.logged_in()
	if not _start_loadout.visible:
		return
	for id in Game.loadout:
		var d := Game.boost_def(String(id))
		if d.is_empty():
			continue
		var cell := VBoxContainer.new()
		cell.add_theme_constant_override("separation", 0)
		var ic := BoostIcon.make(String(d.icon), Color(String(d.color)), 84)
		ic.dim = Game.boost_count(String(id)) <= 0
		cell.add_child(ic)
		var l: Label = _label("×%d%s" % [Game.boost_count(String(id)), "  ▶" if bool(Game.auto_start.get(String(id), false)) else ""], 22, Color("ffd27a"))
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		cell.add_child(l)
		_start_loadout.add_child(cell)
	var more := _button("ابزارها" if Game.loadout.is_empty() else "تغییر", func(): _set_screen(Screen.SHOP), Vector2(150, 64), 24, "Dark")
	_start_loadout.add_child(more)


func _spacer(w: float) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(w, 4)
	return c


func _menu_act(act: String) -> void:
	if act == "play":
		Game.play_normal()
	elif act == "studio":
		_open_studio("draft")
	elif act == "item_studio":
		_set_screen(Screen.ONLINE_STORE)
		_online.item_studio.open()
	elif act.begins_with("screen:"):
		var nm := act.substr(7)
		var idx: int = Screen.get(nm) if Screen.has(nm) else -1
		if idx >= 0:
			_set_screen(idx)
	elif act.begins_with("url:"):
		OS.shell_open(act.substr(4))
	elif act.begins_with("text:"):
		_show_toast(act.substr(5))


## قابلیت هر صفحه (برای بستن صفحه‌هایی که در نسخه‌ی عمومی خاموش‌اند)
func _screen_ability(s: int) -> String:
	match s:
		Screen.CHARACTER, Screen.BUILDER: return "character"
		Screen.COIN: return "coin_designer"
		Screen.STUDIO: return "studio"
		Screen.SHOP: return "power_shop"
		Screen.ONLINE_STORE: return "online_store"
		Screen.MISSIONS: return "missions"
		Screen.CHALLENGE: return "challenge"
		Screen.BOARD: return "leaderboard"
		Screen.ACCOUNT: return "account"
		Screen.SETTINGS: return "settings"
		Screen.CHOOSER: return "chooser"
	return ""


func _row2(a: Control, b: Control) -> HBoxContainer:
	var r := HBoxContainer.new()
	r.alignment = BoxContainer.ALIGNMENT_CENTER
	r.add_theme_constant_override("separation", 16)
	r.add_child(a)
	r.add_child(b)
	return r


func _on_sound_pressed() -> void:
	Game.set_sound(not Game.sound_on)
	_refresh_all()

func _on_vib_pressed() -> void:
	Game.set_vibration(not Game.vibration_on)
	_refresh_all()


# ------------------------- HUD -------------------------
func _build_hud() -> void:
	_hud_ui = Control.new()
	_add_full(_root, _hud_ui)
	_hud_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var _fx := HudFx.new()
	_add_full(_hud_ui, _fx)

	var margin := MarginContainer.new()
	_add_full(_hud_ui, margin)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 64)
	margin.add_theme_constant_override("margin_bottom", 24)

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(row)

	var left := VBoxContainer.new()
	left.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left.add_theme_constant_override("separation", 10)
	left.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	row.add_child(left)
	_score_lbl = _label("امتیاز: 0", 32)
	left.add_child(_pill(_score_lbl))
	var crow := HBoxContainer.new()
	crow.add_theme_constant_override("separation", 8)
	_coin_icon = TextureRect.new()
	_coin_icon.custom_minimum_size = Vector2(44, 44)
	_coin_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_coin_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	crow.add_child(_coin_icon)
	_coins_lbl = _label("0", 34, COL_ORANGE)
	crow.add_child(_coins_lbl)
	_hud_coin_row = _pill(crow)
	left.add_child(_hud_coin_row)

	var sp1 := Control.new()
	sp1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sp1.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(sp1)

	var pause_btn := _button("توقف", _on_pause_pressed, Vector2(150, 78), 30)
	pause_btn.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	row.add_child(pause_btn)

	var sp2 := Control.new()
	sp2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sp2.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(sp2)

	var right := VBoxContainer.new()
	right.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_theme_constant_override("separation", 8)
	right.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	row.add_child(right)
	_dist_lbl = _label("0 متر", 30)
	right.add_child(_pill(_dist_lbl))
	# نوار قدرت‌های فعال
	for i in Game.POWER_NAMES.size():
		var pr := HBoxContainer.new()
		pr.add_theme_constant_override("separation", 8)
		var pic := BoostIcon.make(POWER_KIND[i], POWER_UI_COLORS[i], 52)
		pic.set_pulse(true)
		pr.add_child(pic)
		var nm := _label(Game.POWER_NAMES[i], 24, Color.WHITE)
		_power_lbls.append(nm)
		pr.add_child(nm)
		var bar := ProgressBar.new()
		bar.custom_minimum_size = Vector2(120, 16)
		bar.show_percentage = false
		bar.max_value = 1.0
		bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color("ffcf4a")
		sb.set_corner_radius_all(8)
		bar.add_theme_stylebox_override("fill", sb)
		var bg := StyleBoxFlat.new()
		bg.bg_color = Color(0, 0, 0, 0.4)
		bg.set_corner_radius_all(8)
		bar.add_theme_stylebox_override("background", bg)
		_power_bars.append(bar)
		pr.add_child(bar)
		var p := _pill(pr)
		p.visible = false
		right.add_child(p)
		_power_rows.append(p)

	_boost_bar = BoostBar.new()
	_boost_bar.setup(self)
	_hud_ui.add_child(_boost_bar)
	_boost_bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_boost_bar.offset_top = -190
	_boost_bar.offset_bottom = -30

	_warn_lbl = _label("", 34, COL_BAD)
	_warn_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	_warn_lbl.add_theme_constant_override("outline_size", 10)
	_warn_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_ui.add_child(_warn_lbl)
	_warn_lbl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_warn_lbl.offset_left = -330
	_warn_lbl.offset_right = 330
	_warn_lbl.offset_top = 200
	_warn_lbl.offset_bottom = 260
	_warn_lbl.visible = false

	_hint_lbl = _label("", 40, Color.WHITE)
	_hint_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hint_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	_hint_lbl.add_theme_constant_override("outline_size", 12)
	_hud_ui.add_child(_hint_lbl)
	_hint_lbl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_hint_lbl.offset_left = -330
	_hint_lbl.offset_right = 330
	_hint_lbl.offset_top = 280
	_hint_lbl.offset_bottom = 440
	_hint_lbl.modulate.a = 0.0


func _update_hud() -> void:
	if _boost_bar != null:
		_boost_bar.tick()
	for i in Game.POWER_NAMES.size():
		var left: float = Game.power_left[i]
		_power_rows[i].visible = left > 0.0
		if left > 0.0:
			_power_bars[i].value = left / maxf(Game.power_total[i], 0.1)
	if Game.stumble > 0.0:
		_warn_lbl.visible = true
		_warn_lbl.text = "مراقب باش! برخورد بعدی = گرفتنت (%d)" % ceili(Game.stumble)
	else:
		_warn_lbl.visible = false


# ------------------------- فروشگاه -------------------------
const PowerShop := preload("res://scripts/power_shop.gd")
var _pshop


func _build_shop() -> void:
	_shop_ui = Control.new()
	_add_full(_root, _shop_ui)
	_pshop = PowerShop.new()
	_pshop.build(self, _shop_ui)
	_shop_coins = _pshop.coins_lbl
	_shop_best = _pshop.best_lbl


func _refresh_shop() -> void:
	if _pshop != null:
		_pshop.refresh()


# ------------------------- صفحه‌ی کاراکتر -------------------------
func _build_character() -> void:
	_char_ui = Control.new()
	_add_full(_root, _char_ui)
	_add_full(_char_ui, _dim_rect(0.86))

	var scroll := ScrollContainer.new()
	_add_full(_char_ui, scroll)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED

	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 56)
	margin.add_theme_constant_override("margin_bottom", 36)
	scroll.add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 12)
	margin.add_child(col)

	col.add_child(_label("کاراکتر", 56, Color.WHITE))
	col.add_child(_make_preview("char", 330, CharacterModel.new(), false))

	# سه بخش: مدل GLB ، نقاشی ، اسکین ۶۴×۶۴
	var tabs := HBoxContainer.new()
	tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	tabs.add_theme_constant_override("separation", 8)
	col.add_child(tabs)
	var tab_names := ["مدل GLB", "نقاشی", "اسکین ۶۴×۶۴"]
	for i in 3:
		var ti: int = i
		var tb := _button(tab_names[i], func(): _set_char_tab(ti), Vector2(190, 76), 26)
		tabs.add_child(tb)
		_char_tab_btns.append(tb)

	var skin_scroll := ScrollContainer.new()
	skin_scroll.custom_minimum_size = Vector2(0, 156)
	skin_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	skin_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	col.add_child(skin_scroll)
	_skin_row = HBoxContainer.new()
	_skin_row.add_theme_constant_override("separation", 14)
	skin_scroll.add_child(_skin_row)

	_char_name = _label("", 38, Color.WHITE)
	col.add_child(_char_name)
	_char_info = _label("", 24)
	_char_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_char_info.custom_minimum_size = Vector2(560, 0)
	col.add_child(_char_info)

	# --- تب ۰: GLB ---
	_tab_boxes.append(_tab_box(col))
	var t0: VBoxContainer = _tab_boxes[0]
	var gh := _label("", 22)
	_glb_hint = gh
	gh.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	gh.custom_minimum_size = Vector2(580, 0)
	gh.modulate = Color(1, 1, 1, 0.8)
	t0.add_child(gh)
	_glb_add_btn = _button("افزودن مدل GLB", func(): _open_picker("glb"), Vector2(580, 96), 34, "Gold")
	t0.add_child(_glb_add_btn)
	_glb_yaw_btn = _button("", func(): Skins.cycle_glb_yaw(), Vector2(580, 72), 26)
	t0.add_child(_glb_yaw_btn)
	_glb_ctl_btn = _button("کنترل بدن و حرکت‌های این مدل", func(): _set_screen(Screen.SETTINGS); _settings._show_tab("character"), Vector2(580, 80), 28, "Teal")
	t0.add_child(_glb_ctl_btn)

	# --- تب ۱: نقاشی ---
	_tab_boxes.append(_tab_box(col))
	var t1: VBoxContainer = _tab_boxes[1]
	var dh := _label("روی بدن کاراکتر مستقیم نقاشی کن: قلم، پاک‌کن، پرکردن، قطره‌چکان، تقارن، واگرد و پیش‌نمایش زنده.", 22)
	dh.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dh.custom_minimum_size = Vector2(580, 0)
	dh.modulate = Color(1, 1, 1, 0.8)
	t1.add_child(dh)
	t1.add_child(_button("نقاشی جدید در استودیو", func(): _open_studio("draft"), Vector2(580, 96), 34, "Gold"))
	_edit_btn = _button("ویرایش کاراکتر انتخاب‌شده", func(): _open_studio("current"), Vector2(580, 80), 28, "Teal")
	t1.add_child(_edit_btn)

	# --- تب ۲: اسکین ۶۴×۶۴ ---
	_tab_boxes.append(_tab_box(col))
	var t2: VBoxContainer = _tab_boxes[2]
	var sh := _label("اسکین واقعی ماینکرفت ۶۴×۶۴: از چند عکس بساز، فایل PNG اسکین واقعی را وارد کن، یا با نام کاربری ماینکرفت دریافتش کن.", 22)
	sh.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sh.custom_minimum_size = Vector2(580, 0)
	sh.modulate = Color(1, 1, 1, 0.8)
	t2.add_child(sh)
	t2.add_child(_button("ساخت اسکین از چند عکس", func(): _open_builder(), Vector2(580, 92), 32, "Gold"))
	t2.add_child(_button("وارد کردن اسکین واقعی / عکس (PNG)", func(): _open_picker("char"), Vector2(580, 80), 28))
	t2.add_child(_button("دریافت اسکین با نام کاربری ماینکرفت", func(): _toggle_mc_box(), Vector2(580, 80), 28, "Teal"))
	_mc_box = HBoxContainer.new()
	_mc_box.add_theme_constant_override("separation", 8)
	_mc_box.visible = false
	t2.add_child(_mc_box)
	_mc_name = LineEdit.new()
	_mc_name.placeholder_text = "نام کاربری (مثلاً Notch)"
	_mc_name.custom_minimum_size = Vector2(380, 70)
	_mc_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_mc_name.add_theme_font_size_override("font_size", 26)
	_mc_name.max_length = 16
	_mc_name.text_submitted.connect(func(_t: String): _fetch_mc_skin())
	_mc_box.add_child(_mc_name)
	_mc_btn = _button("دریافت", func(): _fetch_mc_skin(), Vector2(160, 70), 26, "Gold")
	_mc_box.add_child(_mc_btn)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	t2.add_child(row)
	_mode_btn = _button("", func(): Skins.cycle_mode(), Vector2(176, 72), 22)
	_slim_btn = _button("", func(): Skins.cycle_slim(), Vector2(176, 72), 22)
	_style_btn = _button("", func(): Skins.cycle_style(), Vector2(176, 72), 22)
	row.add_child(_mode_btn)
	row.add_child(_slim_btn)
	row.add_child(_style_btn)
	_export_btn = _button("ذخیره‌ی اسکین به‌صورت PNG ماینکرفت", func(): _on_export(), Vector2(580, 76), 26)
	t2.add_child(_export_btn)

	_del_btn = _button("حذف این کاراکتر", func(): Skins.delete_current(), Vector2(540, 72), 26, "Red")
	col.add_child(_del_btn)
	col.add_child(_button("تأیید", func(): _set_screen(Screen.START), Vector2(540, 92), 38, "Teal"))

	_mc_http = HTTPRequest.new()
	_mc_http.timeout = 15.0
	add_child(_mc_http)
	_mc_http.request_completed.connect(_on_mc_done)


func _tab_box(parent: Control) -> VBoxContainer:
	var b := VBoxContainer.new()
	b.add_theme_constant_override("separation", 10)
	parent.add_child(b)
	return b


func _tab_of(e: Dictionary) -> int:
	if Skins.is_glb(e):
		return 0
	if str(e.get("origin", "")) == "paint":
		return 1
	return 2


func _set_char_tab(i: int) -> void:
	_char_tab = i
	for k in _tab_boxes.size():
		(_tab_boxes[k] as Control).visible = k == i
		(_char_tab_btns[k] as Button).modulate = Color(1, 1, 1, 1) if k == i else Color(1, 1, 1, 0.55)
	_refresh_character()


# ---- دریافت اسکین واقعی با نام کاربری ----
const MC_SKIN_URLS: Array[String] = ["https://minotar.net/skin/%s", "https://mc-heads.net/skin/%s", "https://crafatar.com/skins/%s"]
var _mc_try := 0
var _mc_user := ""


func _toggle_mc_box() -> void:
	_mc_box.visible = not _mc_box.visible


func _fetch_mc_skin() -> void:
	var nm := _mc_name.text.strip_edges()
	var valid := RegEx.new()
	valid.compile("^[A-Za-z0-9_]{3,16}$")
	if valid.search(nm) == null:
		_show_toast("نام کاربری ماینکرفت معتبر نیست (۳ تا ۱۶ حرف انگلیسی/عدد)")
		Sfx.play("error")
		return
	_mc_user = nm
	_mc_try = 0
	_mc_btn.disabled = true
	_mc_request()


func _mc_request() -> void:
	var err := _mc_http.request(MC_SKIN_URLS[_mc_try] % _mc_user)
	if err != OK:
		_mc_fail()


func _on_mc_done(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result == HTTPRequest.RESULT_SUCCESS and code == 200:
		var img := Image.new()
		if img.load_png_from_buffer(body) == OK and SkinLib.looks_like_skin_dims(img):
			_mc_btn.disabled = false
			var err := Skins.add_image(img, _mc_user)
			if err != "":
				_show_toast(err)
				Sfx.play("error")
			else:
				_show_toast("اسکین «%s» دریافت شد!" % _mc_user)
				Sfx.play("buy")
			return
	_mc_try += 1
	if _mc_try < MC_SKIN_URLS.size():
		_mc_request()
	else:
		_mc_fail()


func _mc_fail() -> void:
	_mc_btn.disabled = false
	_show_toast("دریافت اسکین ناموفق بود. اینترنت و نام کاربری را بررسی کن")
	Sfx.play("error")


## پیش‌نمایش سه‌بعدی چرخان (SubViewport با دنیای مستقل). content داخل pivot قرار می‌گیرد.
func _make_preview(key: String, height: int, content: Node3D, spin: bool) -> Control:
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, height)
	holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	var svc := SubViewportContainer.new()
	svc.stretch = true
	svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(svc)
	svc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var vp := SubViewport.new()
	vp.own_world_3d = true
	vp.transparent_bg = true
	vp.msaa_3d = Viewport.MSAA_DISABLED
	svc.add_child(vp)

	var env := Environment.new()
	env.background_mode = Environment.BG_CLEAR_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("ffe6c8")
	env.ambient_light_energy = 0.9
	var cam := Camera3D.new()
	cam.environment = env
	cam.fov = 34.0
	var cam_pos := Vector3(0.0, 1.15, 4.2) if not spin else Vector3(0.0, 0.2, 2.6)
	var look := Vector3(0.0, 0.92, 0.0) if not spin else Vector3.ZERO
	cam.transform = Transform3D(Basis.looking_at(look - cam_pos, Vector3.UP), cam_pos)
	vp.add_child(cam)

	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-35.0, 30.0, 0.0)
	light.light_energy = 1.0
	light.light_color = Color("fff0dc")
	vp.add_child(light)

	if not spin:
		var disc := CylinderMesh.new()
		disc.top_radius = 0.75
		disc.bottom_radius = 0.75
		disc.height = 0.05
		var disc_mat := StandardMaterial3D.new()
		disc_mat.albedo_color = Color("6a3a1a")
		disc_mat.emission_enabled = true
		disc_mat.emission = Color("ffb04a")
		disc_mat.emission_energy_multiplier = 0.5
		var disc_mi := MeshInstance3D.new()
		disc_mi.mesh = disc
		disc_mi.material_override = disc_mat
		disc_mi.position = Vector3(0.0, -0.025, 0.0)
		vp.add_child(disc_mi)

	var pivot := Node3D.new()
	vp.add_child(pivot)
	pivot.add_child(content)
	_pv[key] = {"pivot": pivot, "content": content, "yaw": PI if not spin else 0.0, "cd": 0.0, "spin": spin, "holder": holder,
		"cam": cam, "cam_pos": cam_pos, "look": look, "pitch": 0.0, "zoom": 1.0, "auto": true}

	# لایه‌ی شفاف برای چرخاندن با کشیدن انگشت/ماوس
	var drag := Control.new()
	drag.mouse_filter = Control.MOUSE_FILTER_STOP
	holder.add_child(drag)
	drag.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	drag.gui_input.connect(func(event: InputEvent):
		if event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
			_pv[key]["yaw"] = float(_pv[key]["yaw"]) + event.relative.x * 0.012
			_pv[key]["pitch"] = clampf(float(_pv[key]["pitch"]) + event.relative.y * 0.006, -0.7, 0.9)
			_pv[key]["cd"] = 2.5
		elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			preview_zoom(key, 1.12)
		elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			preview_zoom(key, 1.0 / 1.12)
		elif event is InputEventMagnifyGesture:
			preview_zoom(key, event.factor)
		elif event is InputEventMouseButton and event.pressed and event.double_click:
			preview_reset(key))
	return holder


func preview_zoom(key: String, f: float) -> void:
	if _pv.has(key):
		_pv[key]["zoom"] = clampf(float(_pv[key]["zoom"]) * f, 0.6, 3.0)


func preview_reset(key: String) -> void:
	if _pv.has(key):
		_pv[key]["zoom"] = 1.0
		_pv[key]["pitch"] = 0.0
		_pv[key]["cd"] = 0.0


## نوار ابزار روی هر پیش‌نمایش: چرخش خودکار، بزرگ/کوچک، بازنشانی. نشانِ «۳۶۰°» یعنی با کشیدن می‌چرخد.
func preview_toolbar(key: String) -> Control:
	var d: Dictionary = _pv[key]
	var holder: Control = d["holder"]
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 6)
	holder.add_child(bar)
	bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bar.offset_top = -62
	bar.offset_bottom = -6
	bar.offset_left = 8
	bar.offset_right = -8
	bar.alignment = BoxContainer.ALIGNMENT_CENTER
	var tag: Label = _label("۳۶۰° با انگشت بچرخان", 20, Color(1, 1, 1, 0.8))
	tag.set_meta("ct_skip", true)
	tag.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.add_child(tag)
	var auto: Button = _button("چرخش", func(): pass, Vector2(110, 52), 20, "Teal")
	auto.pressed.connect(func():
		d["auto"] = not bool(d["auto"])
		auto.modulate = Color.WHITE if d["auto"] else Color(1, 1, 1, 0.55))
	bar.add_child(auto)
	bar.add_child(_button("+", func(): preview_zoom(key, 1.2), Vector2(60, 52), 28, "Teal"))
	bar.add_child(_button("−", func(): preview_zoom(key, 1.0 / 1.2), Vector2(60, 52), 28, "Teal"))
	bar.add_child(_button("اصلی", func(): preview_reset(key), Vector2(90, 52), 20, "Dark"))
	return bar


func _tile_style(selected: bool) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color("2a0a4a")
	sb.set_corner_radius_all(18)
	sb.set_content_margin_all(10)
	if selected:
		sb.set_border_width_all(6)
		sb.border_color = COL_PINK
	return sb

func _skin_tile(e: Dictionary) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(132, 132)
	b.icon = Skins.thumbnail(e)
	b.expand_icon = true
	var sel: bool = e["id"] == Skins.current_id
	for st in ["normal", "hover", "pressed", "focus"]:
		b.add_theme_stylebox_override(st, _tile_style(sel))
	var sid: String = e["id"]
	b.pressed.connect(func():
		Sfx.play("click")
		Skins.select(sid))
	return b


func _refresh_character() -> void:
	if _skin_row == null or _tab_boxes.size() < 3:
		return
	for c in _skin_row.get_children():
		_skin_row.remove_child(c)
		c.queue_free()
	for e in Skins.entries:
		if _tab_of(e) == _char_tab:
			_skin_row.add_child(_skin_tile(e))
	var plus := Button.new()
	plus.text = "+"
	plus.custom_minimum_size = Vector2(132, 132)
	plus.add_theme_font_size_override("font_size", 64)
	plus.pressed.connect(func():
		Sfx.play("click")
		if _char_tab == 0:
			_open_picker("glb")
		elif _char_tab == 1:
			_open_studio("draft")
		else:
			_open_builder())
	_skin_row.add_child(plus)
	for k in _tab_boxes.size():
		(_tab_boxes[k] as Control).visible = k == _char_tab
		(_char_tab_btns[k] as Button).modulate = Color(1, 1, 1, 1) if k == _char_tab else Color(1, 1, 1, 0.55)

	var cur := Skins.current_entry()
	var custom := Skins.is_custom(cur)
	var multi := Skins.is_multi(cur)
	var is_glb := Skins.is_glb(cur)
	_sync_preview_model("char")
	_char_name.text = str(cur.get("name", ""))
	_char_info.text = Skins.info
	_glb_yaw_btn.visible = is_glb
	_glb_ctl_btn.visible = is_glb
	_glb_yaw_btn.text = "چرخاندن مدل (جهت فعلی: %d°)" % (int(cur.get("glb_yaw", 0)) * 90)
	_edit_btn.visible = not is_glb
	_export_btn.visible = not is_glb
	_mode_btn.visible = custom and not multi and not is_glb
	_slim_btn.visible = custom and not multi and not Skins.is_photo and not is_glb
	_style_btn.visible = custom and (multi or Skins.is_photo) and not is_glb
	_del_btn.visible = custom
	var can_glb: bool = Edition.can_import_glb()
	_glb_add_btn.text = "افزودن مدل GLB" if can_glb else "مدل‌های بیشتر (قفل) — فروشگاه آنلاین"
	_glb_add_btn.modulate = Color.WHITE if can_glb else Color(1, 1, 1, 0.85)
	_glb_hint.text = ("مدل سه‌بعدی (.glb) از Blender، Mixamo، Sketchfab و ... را اضافه کن. اسکلت انسانی خودکار تشخیص داده می‌شود و همه‌ی حرکت‌ها ساخته می‌شود."
		if can_glb else "مدل‌های سه‌بعدی قفل‌اند و از فروشگاه آنلاین با سکه باز می‌شوند. حالت‌های ماینکرفتی (تب نقاشی و اسکین ۶۴×۶۴) آزادند.")
	_mode_btn.text = "تشخیص: " + Skins.MODE_NAMES[int(cur.get("mode", 0))]
	_slim_btn.text = "بازو: " + Skins.SLIM_NAMES[int(cur.get("slim_mode", 0))]
	_style_btn.text = "سبک: " + SkinLib.STYLE_NAMES[int(cur.get("style", 0))]


## مدل پیش‌نمایش را با کاراکتر انتخاب‌شده هماهنگ می‌کند (بلوکی ↔ GLB)
func _sync_preview_model(key: String, entry: Dictionary = {}) -> void:
	var d: Dictionary = _pv[key]
	var pivot: Node3D = d["pivot"]
	var cur: Node3D = d["content"]
	var e: Dictionary = Skins.current_entry() if entry.is_empty() else entry
	if Skins.is_glb(e):
		var gkey := "%s|%d|%d" % [str(e["glb"]), int(e["glb_yaw"]), FileAccess.get_modified_time(str(e["glb"]))]
		if d.get("glb_key", "") == gkey and cur.get("is_glb") == true:
			cur.apply_config(Skins.glb_cfg(e))
			return
		var gm := GlbModel.new()
		pivot.add_child(gm)
		if gm.load_from_file(str(e["glb"]), int(e["glb_yaw"])):
			pivot.remove_child(cur)
			cur.queue_free()
			gm.apply_config(Skins.glb_cfg(e))
			d["content"] = gm
			d["glb_key"] = gkey
			return
		gm.queue_free()
		_show_toast("مدل GLB بارگذاری نشد: " + gm.load_error)
	if cur.get("is_glb") == true:
		pivot.remove_child(cur)
		cur.queue_free()
		cur = CharacterModel.new()
		pivot.add_child(cur)
		d["content"] = cur
		d["glb_key"] = ""
	cur.set_skin(Skins.texture, Skins.slim, Skins.smooth)


func _on_export() -> void:
	var r := Skins.export_current()
	if r["ok"]:
		_show_toast("اسکین ذخیره شد:\n" + str(r["path"]))
		Sfx.play("buy")
	else:
		_show_toast("ذخیره‌ی فایل ناموفق بود")
		Sfx.play("error")


# ------------------------- ساخت کاراکتر از چند عکس -------------------------
func _open_builder() -> void:
	_b_slots.clear()
	_b_style = 0
	if _b_name != null:
		_b_name.text = ""
	_set_screen(Screen.BUILDER)
	_b_refresh_slots()
	_b_update_preview()


func _build_builder() -> void:
	_builder_ui = Control.new()
	_add_full(_root, _builder_ui)
	_add_full(_builder_ui, _dim_rect(0.9))

	var scroll := ScrollContainer.new()
	_add_full(_builder_ui, scroll)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED

	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 56)
	margin.add_theme_constant_override("margin_bottom", 36)
	scroll.add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	margin.add_child(col)

	col.add_child(_label("ساخت اسکین از عکس", 50, Color.WHITE))
	col.add_child(_make_preview("builder", 300, CharacterModel.new(), false))
	_b_msg = _label("", 24, COL_ORANGE)
	_b_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_b_msg.custom_minimum_size = Vector2(560, 0)
	col.add_child(_b_msg)

	for slot in SkinLib.SLOT_NAMES:
		col.add_child(_slot_row(slot))

	_b_style_btn = _button("", func():
		_b_style = (_b_style + 1) % SkinLib.STYLE_NAMES.size()
		_b_update_preview(), Vector2(560, 76), 28)
	col.add_child(_b_style_btn)

	_b_name = LineEdit.new()
	_b_name.placeholder_text = "نام کاراکتر (اختیاری)"
	_b_name.custom_minimum_size = Vector2(560, 72)
	_b_name.alignment = HORIZONTAL_ALIGNMENT_CENTER
	_b_name.add_theme_font_size_override("font_size", 28)
	_b_name.max_length = 16
	col.add_child(_b_name)

	col.add_child(_button("ساخت و ذخیره", func(): _b_save(), Vector2(560, 100), 38, "Gold"))
	col.add_child(_button("بازگشت", func(): _set_screen(Screen.CHARACTER), Vector2(560, 80), 30, "Dark"))


func _slot_row(slot: String) -> Control:
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel", UiArt.panel_style(Color(0.2, 0.07, 0.28, 0.8)))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	card.add_child(row)
	var th := TextureRect.new()
	th.custom_minimum_size = Vector2(84, 84)
	th.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	th.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	row.add_child(th)
	_b_thumbs[slot] = th
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(info)
	info.add_child(_label(SLOT_TITLES[slot], 30, Color.WHITE))
	var h := _label(SLOT_HINTS[slot], 20)
	h.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	h.custom_minimum_size = Vector2(190, 0)
	h.modulate = Color(1, 1, 1, 0.8)
	info.add_child(h)
	row.add_child(_button("انتخاب", func(): _open_picker(slot), Vector2(120, 70), 24))
	row.add_child(_button("×", func():
		_b_slots.erase(slot)
		_b_refresh_slots()
		_b_update_preview(), Vector2(70, 70), 32))
	return card


func _b_refresh_slots() -> void:
	for slot in SkinLib.SLOT_NAMES:
		var th: TextureRect = _b_thumbs[slot]
		if _b_slots.has(slot):
			th.texture = ImageTexture.create_from_image(_b_slots[slot])
		else:
			th.texture = null


func _b_update_preview() -> void:
	if _b_style_btn == null or not _pv.has("builder"):
		return
	_b_style_btn.text = "سبک: " + SkinLib.STYLE_NAMES[_b_style]
	var model = _pv["builder"]["content"]
	var res := Skins.preview_from_slots(_b_slots, _b_style)
	if res.has("error"):
		_b_msg.text = str(res["error"])
		var d := SkinLib.process(SkinLib.preset(0), 1, 1)
		model.set_skin(ImageTexture.create_from_image(d["image"]), false, false)
		return
	var img: Image = (res["image"] as Image).duplicate()
	var sc: int = res["scale"]
	if sc > 1:
		img.generate_mipmaps()
	model.set_skin(ImageTexture.create_from_image(img), false, sc > 1)
	var notes: Array[String] = []
	if not res.get("had_back", false):
		notes.append("پشت از رنگ‌ها ساخته می‌شود")
	if not res.get("had_sides", false):
		notes.append("کناره‌ها خودکار")
	_b_msg.text = "پیش‌نمایش زنده — " + ("؛ ".join(notes) if not notes.is_empty() else "همه‌ی زاویه‌ها دارند")


func _b_save() -> void:
	var nm := _b_name.text if _b_name != null else ""
	var err := Skins.add_multi(_b_slots, _b_style, nm)
	if err != "":
		_show_toast(err)
		Sfx.play("error")
		return
	_show_toast("کاراکتر ساخته شد!")
	Sfx.play("buy")
	_set_screen(Screen.CHARACTER)


# ------------------------- استودیوی اسکین -------------------------
func _build_studio() -> void:
	_studio = Studio.new()
	_studio_ui = _studio
	_add_full(_root, _studio_ui)
	_studio.setup(self)
	_studio.close_requested.connect(func(): _set_screen(Screen.CHARACTER))
	_studio.pick_requested.connect(func(t: String): _open_picker(t))
	_studio.toast_requested.connect(func(t: String): _show_toast(t))


# ------------------------- لیست اسکرولی با دکمه‌های ▲▼ -------------------------
## (دکمه‌های ▲▼ برای همه‌ی لیست‌های اسکرولی خودکار در _attach_pad ساخته می‌شود)
## parent: جایی که لیست داخلش قرار می‌گیرد. خروجی: VBox محتوا.
# ------------------------- جلوگیری از بیرون‌زدن محتوا از عرض صفحه -------------------------
## متن‌های بلند (برچسب، دکمه، تیک‌باکس) عرض لیست را بزرگ‌تر از صفحه می‌کردند و فرم‌ها از لبه بیرون می‌زد.
## هر ScrollContainerی که اسکرول افقی ندارد خودکار بررسی می‌شود: متن‌ها شکسته می‌شوند و دکمه‌ها از عرض بیشتر نمی‌شوند.
const FIT_META := "_fitted"
var _fit_scrolls: Array = []


func _setup_auto_fit() -> void:
	get_tree().node_added.connect(_on_node_added_fit)
	var t := Timer.new()
	t.wait_time = 0.3
	t.autostart = true
	t.timeout.connect(_fit_tick)
	add_child(t)


func _on_node_added_fit(n: Node) -> void:
	if n is ScrollContainer and n.is_inside_tree():
		_fit_scrolls.append(n)


func _fit_tick() -> void:
	var alive: Array = []
	for sc in _fit_scrolls:
		if not is_instance_valid(sc):
			continue
		alive.append(sc)
		var scc := sc as ScrollContainer
		if scc.horizontal_scroll_mode == ScrollContainer.SCROLL_MODE_DISABLED and scc.is_visible_in_tree():
			for c in scc.get_children():
				fit_tree(c)
	_fit_scrolls = alive


static func fit_tree(n: Node) -> void:
	if n.has_meta(FIT_META):
		# فرزندان تازه ممکن است اضافه شده باشند
		for c in n.get_children():
			fit_tree(c)
		return
	n.set_meta(FIT_META, true)
	var par := n.get_parent()
	var in_row := par is HBoxContainer or par is HFlowContainer
	if n is Label:
		var l := n as Label
		if par is Container and l.autowrap_mode == TextServer.AUTOWRAP_OFF and l.text_overrun_behavior == TextServer.OVERRUN_NO_TRIMMING:
			l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			if par is HBoxContainer and l.size_flags_horizontal == Control.SIZE_FILL:
				l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			elif in_row and par is HFlowContainer:
				l.autowrap_mode = TextServer.AUTOWRAP_OFF
	elif n is Button and not (n is OptionButton) and not (n is MenuButton):
		var b := n as Button
		if par is HBoxContainer and (b.size_flags_horizontal & Control.SIZE_EXPAND) != 0:
			b.clip_text = true      # فقط دکمه‌ی کش‌آمده می‌تواند کوچک شود؛ در HFlow/بقیه کلیپ نمی‌کنیم (عرض دکمه صفر می‌شد)
		elif b.text.length() > 14 and not b.clip_text and not (par is HFlowContainer):
			b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	for c in n.get_children():
		fit_tree(c)


func make_scroll_view(parent: Control) -> VBoxContainer:
	var holder := Control.new()
	holder.size_flags_vertical = Control.SIZE_EXPAND_FILL
	holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	holder.custom_minimum_size = Vector2(0, 200)
	parent.add_child(holder)
	var sc := ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	holder.add_child(sc)
	sc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 8)
	sc.add_child(v)
	return v


# ------------------------- اسکرول لمسی -------------------------
## دکمه/ورودی‌هایی که داخل یک ScrollContainer هستند رویداد کشیدن را می‌بلعیدند (mouse_filter=STOP)
## و لیست با انگشت اسکرول نمی‌شد. با PASS رویداد به ScrollContainer هم می‌رسد.
var _pad_layer: Control
var _pads: Array = []


func _on_node_added(n: Node) -> void:
	if n is ScrollContainer:
		(n as ScrollContainer).scroll_deadzone = 14
		_attach_pad.call_deferred(n)
	elif n is OptionButton:
		_hook_option.call_deferred(n)
		_scroll_fix.call_deferred(n)
	elif n is BaseButton or n is LineEdit or n is TextEdit or n is SpinBox:
		_scroll_fix.call_deferred(n)


## منوی کشویی بومی روی لمس اسکرول نمی‌شود؛ به‌جایش یک صفحه‌ی انتخاب با لیست اسکرولی باز می‌کنیم.
var _picker: Control


func _ensure_layer() -> void:
	if _pad_layer == null:
		_pad_layer = Control.new()
		_pad_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_pad_layer.set_meta("ct_skip", true)
		add_child(_pad_layer)
		_pad_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _hook_option(ob: OptionButton) -> void:
	if not is_instance_valid(ob):
		return
	var pm := ob.get_popup()
	pm.about_to_popup.connect(func():
		pm.hide.call_deferred()
		_open_picker_list.call_deferred(ob))


func _open_picker_list(ob: OptionButton) -> void:
	if not is_instance_valid(ob) or _picker != null:
		return
	_ensure_layer()
	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.theme = _root.theme
	_pad_layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_picker = root
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var box := VBoxContainer.new()
	root.add_child(box)
	box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	box.offset_left = 24; box.offset_right = -24; box.offset_top = 40; box.offset_bottom = -40
	box.add_theme_constant_override("separation", 10)
	var close := func():
		_picker = null
		root.queue_free()
	var cb := Button.new()
	cb.text = "✕  بستن"
	cb.custom_minimum_size = Vector2(0, 84)
	cb.pressed.connect(close)
	box.add_child(cb)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	box.add_child(sc)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 6)
	sc.add_child(v)
	for i in ob.item_count:
		if ob.is_item_separator(i):
			continue
		var b := Button.new()
		b.text = ("● " if i == ob.selected else "○ ") + ob.get_item_text(i)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size = Vector2(0, 84)
		b.disabled = ob.is_item_disabled(i)
		b.clip_text = false
		b.mouse_filter = Control.MOUSE_FILTER_PASS
		b.pressed.connect(func():
			if is_instance_valid(ob):
				ob.select(i)
				ob.item_selected.emit(i)
			close.call())
		v.add_child(b)


## دکمه‌های ▲▼ شناور برای هر لیست اسکرولی (اگر کشیدن با انگشت جواب نداد؛ نگه‌داشتن = اسکرول پیوسته)
func _attach_pad(sc: ScrollContainer) -> void:
	if not is_instance_valid(sc) or sc.vertical_scroll_mode == ScrollContainer.SCROLL_MODE_DISABLED:
		return
	_ensure_layer()
	var pad := VBoxContainer.new()
	pad.add_theme_constant_override("separation", 10)
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pad.visible = false
	_pad_layer.add_child(pad)
	var dir := [0]
	var timer := Timer.new()
	timer.wait_time = 0.03
	pad.add_child(timer)
	timer.timeout.connect(func(): sc.scroll_vertical += int(dir[0] * 34))
	for d in [[-1, "▲"], [1, "▼"]]:
		var b := Button.new()
		b.text = d[1]
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(56, 84)
		b.add_theme_font_size_override("font_size", 32)
		b.modulate = Color(1, 1, 1, 0.8)
		var sgn: int = d[0]
		b.button_down.connect(func(): dir[0] = sgn; sc.scroll_vertical += sgn * 120; timer.start())
		b.button_up.connect(func(): dir[0] = 0; timer.stop())
		pad.add_child(b)
	_pads.append({"sc": sc, "pad": pad})


func _update_pads() -> void:
	var keep: Array = []
	for e in _pads:
		if not is_instance_valid(e.sc):
			if is_instance_valid(e.pad):
				e.pad.queue_free()
			continue
		keep.append(e)
		var sc: ScrollContainer = e.sc
		var bar := sc.get_v_scroll_bar()
		var show := (_picker == null or _picker.is_ancestor_of(sc)) and sc.is_visible_in_tree() and sc.size.y > 260.0 and bar.max_value > bar.page + 8.0
		e.pad.visible = show
		if show:
			_gutter(sc)
			var r := sc.get_global_rect()
			e.pad.global_position = Vector2(r.end.x - 62.0, r.end.y - 190.0)
	_pads = keep


## جای دکمه‌های ▲▼ را از محتوا خالی می‌کند تا روی نوشته‌ها و دکمه‌ها نیفتند (فقط یک‌بار برای هر لیست)
func _gutter(sc: ScrollContainer) -> void:
	if sc.has_meta("gutter") or sc.get_child_count() == 0:
		return
	var c := sc.get_child(0)
	if not c is Control or c is MarginContainer and c.has_meta("gutter_wrap"):
		return
	sc.set_meta("gutter", true)
	var ctl := c as Control
	var m := MarginContainer.new()
	m.set_meta("gutter_wrap", true)
	m.add_theme_constant_override("margin_right", 64)
	m.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	m.size_flags_vertical = ctl.size_flags_vertical
	sc.remove_child(ctl)
	m.add_child(ctl)
	ctl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(m)


func _scroll_fix(n: Node) -> void:
	if not is_instance_valid(n) or not n.is_inside_tree():
		return
	var p := n.get_parent()
	while p != null:
		if p is ScrollContainer:
			if (n as Control).mouse_filter == Control.MOUSE_FILTER_STOP:
				(n as Control).mouse_filter = Control.MOUSE_FILTER_PASS
			if n is OptionButton:      # منو با «رها کردن» باز شود نه با «لمس»، تا کشیدن لیست منو را باز نکند
				(n as OptionButton).action_mode = BaseButton.ACTION_MODE_BUTTON_RELEASE
			return
		p = p.get_parent()


func settings_open_police() -> void:
	_set_screen(Screen.SETTINGS)
	_settings._show_tab("character")
	_settings._set_target("police")


func _build_settings() -> void:
	_settings = SettingsScreen.new()
	_settings_ui = _settings
	_add_full(_root, _settings_ui)
	_settings.setup(self)
	_settings.close_requested.connect(func(): _set_screen(Screen.START))
	_settings.goto_character_requested.connect(func(): _set_screen(Screen.CHARACTER))


func _build_missions() -> void:
	_missions_ui = Control.new()
	_add_full(_root, _missions_ui)
	var bg := ColorRect.new()
	bg.color = Color("2a1a4a")
	_add_full(_missions_ui, bg)
	var margin := MarginContainer.new()
	_add_full(_missions_ui, margin)
	for k in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + k, 36)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 18)
	margin.add_child(col)
	col.add_child(_label("ماموریت‌ها", 58, Color.WHITE))
	var tip := _label("با انجام هر ماموریت سکه جایزه می‌گیری و ماموریت جدید جایش می‌آید.", 26)
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.custom_minimum_size = Vector2(600, 0)
	col.add_child(tip)
	_missions_box = VBoxContainer.new()
	_missions_box.add_theme_constant_override("separation", 14)
	col.add_child(_missions_box)
	col.add_child(_button("بازگشت", func(): _set_screen(Screen.START), Vector2(540, 96), 38, "Dark"))
	Game.missions_changed.connect(func(): if _screen == Screen.MISSIONS: _refresh_missions())


func _refresh_missions() -> void:
	for c in _missions_box.get_children():
		c.queue_free()
	for m: Dictionary in Game.missions:
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel", UiArt.panel_style(Color(0.22, 0.07, 0.3, 0.82)))
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 8)
		card.add_child(v)
		var t := _label(Game.mission_text(m), 32, Color.WHITE)
		t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		t.custom_minimum_size = Vector2(560, 0)
		v.add_child(t)
		var bar := ProgressBar.new()
		bar.max_value = float(m.goal)
		bar.value = float(mini(int(m.prog), int(m.goal)))
		bar.show_percentage = false
		bar.custom_minimum_size = Vector2(560, 22)
		var fill := StyleBoxFlat.new()
		fill.bg_color = Color("ffb02e")
		fill.set_corner_radius_all(10)
		bar.add_theme_stylebox_override("fill", fill)
		var back := StyleBoxFlat.new()
		back.bg_color = Color(0, 0, 0, 0.4)
		back.set_corner_radius_all(10)
		bar.add_theme_stylebox_override("background", back)
		v.add_child(bar)
		v.add_child(_label("پیشرفت: %d از %d   •   جایزه: %d سکه" % [mini(int(m.prog), int(m.goal)), int(m.goal), int(m.reward)], 26, COL_ORANGE))
		_missions_box.add_child(card)


func _open_studio(mode: String) -> void:
	_set_screen(Screen.STUDIO)
	_studio.open_studio(mode)


# ------------------------- طراحی سکه -------------------------
func _build_coin_screen() -> void:
	_coin_ui = Control.new()
	_add_full(_root, _coin_ui)
	_add_full(_coin_ui, _dim_rect(0.86))
	var scroll := ScrollContainer.new()
	_add_full(_coin_ui, scroll)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 56)
	margin.add_theme_constant_override("margin_bottom", 36)
	scroll.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	margin.add_child(col)

	col.add_child(_label("طراح سکه", 56, Color.WHITE))
	var coin := CoinSkin.make_coin(true)
	coin.scale = Vector3.ONE * 2.0
	col.add_child(_make_preview("coin", 400, coin, true))
	_coin_info = _label("", 26)
	_coin_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_coin_info.custom_minimum_size = Vector2(600, 0)
	_coin_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(_coin_info)

	col.add_child(_label("طرح", 28, Color.WHITE))
	var drow := HBoxContainer.new()
	drow.alignment = BoxContainer.ALIGNMENT_CENTER
	drow.add_theme_constant_override("separation", 8)
	col.add_child(drow)
	for i in CoinSkin.DESIGN_NAMES.size():
		var di: int = i
		var db := _button(CoinSkin.DESIGN_NAMES[i], func():
			if di == CoinSkin.PHOTO and not CoinSkin.has_photo:
				_open_picker("coin")
			else:
				CoinSkin.select_design(di), Vector2(116, 76), 22)
		drow.add_child(db)
		_coin_design_btns.append(db)
	col.add_child(_button("انتخاب عکس از دستگاه", func(): _open_picker("coin"), Vector2(600, 86), 30))

	_coin_density = _coin_slider(col, "تراکم خط")
	_coin_density.value_changed.connect(func(v: float):
		if not _coin_updating:
			CoinSkin.set_density(v))
	_coin_contrast = _coin_slider(col, "کنتراست")
	_coin_contrast.value_changed.connect(func(v: float):
		if not _coin_updating:
			CoinSkin.set_contrast(v))

	_coin_photo_box = VBoxContainer.new()
	_coin_photo_box.add_theme_constant_override("separation", 10)
	col.add_child(_coin_photo_box)
	var cut_panel := PanelContainer.new()
	cut_panel.custom_minimum_size = Vector2(220, 220)
	cut_panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_coin_photo_box.add_child(cut_panel)
	_coin_cut_img = TextureRect.new()
	_coin_cut_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_coin_cut_img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_coin_cut_img.custom_minimum_size = Vector2(200, 200)
	cut_panel.add_child(_coin_cut_img)
	_coin_bg_lbl = _label("", 22, Color(1, 1, 1, 0.8))
	_coin_bg_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_coin_bg_lbl.custom_minimum_size = Vector2(600, 0)
	_coin_photo_box.add_child(_coin_bg_lbl)
	_coin_bg_btn = _button("", func(): CoinSkin.toggle_bg(), Vector2(600, 72), 26)
	_coin_photo_box.add_child(_coin_bg_btn)
	_coin_photo_box.add_child(_button("ذخیره‌ی عکس بدون پس‌زمینه (PNG)", func():
		var r: Dictionary = CoinSkin.export_cutout()
		if r["ok"]:
			_show_toast("PNG ذخیره شد:\n" + str(r["path"]))
			Sfx.play("buy")
		else:
			_show_toast("ذخیره‌ی فایل ناموفق بود")
			Sfx.play("error"), Vector2(600, 72), 24))
	_coin_style_btn = _button("", func(): CoinSkin.cycle_style(), Vector2(600, 76), 26)
	_coin_photo_box.add_child(_coin_style_btn)
	_coin_save_btn = _button("ذخیره این طرح", func():
		CoinSkin.save_draft()
		_show_toast("طرح ذخیره شد؛ همه‌ی سکه‌های بازی همین طرح را دارند")
		Sfx.play("buy"), Vector2(600, 104), 38, "Gold")
	col.add_child(_coin_save_btn)
	col.add_child(_button("بازگشت به ستاره‌ی پیش‌فرض", func(): CoinSkin.reset_default(), Vector2(600, 72), 24))
	var help := _label("هر طرح یا عکس به «حکاکی خطی» (مثل تصویر روی اسکناس) تبدیل و روی دو طرف سکه چاپ می‌شود. تراکم = فاصله‌ی خطوط، کنتراست = تفاوت روشن و تیره. تا «ذخیره» نزنی بازی عوض نمی‌شود.", 22)
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	help.custom_minimum_size = Vector2(600, 0)
	help.modulate = Color(1, 1, 1, 0.75)
	col.add_child(help)
	col.add_child(_button("تأیید", func(): _set_screen(Screen.START), Vector2(540, 92), 38, "Teal"))
	_refresh_coin()


func _coin_slider(parent: Control, title: String) -> HSlider:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	parent.add_child(row)
	var l := _label(title, 26)
	l.custom_minimum_size = Vector2(150, 0)
	row.add_child(l)
	var sl := HSlider.new()
	sl.min_value = 0.0
	sl.max_value = 1.0
	sl.step = 0.01
	sl.value = 0.5
	sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl.custom_minimum_size = Vector2(0, 52)
	row.add_child(sl)
	return sl


func _refresh_coin() -> void:
	if _coin_icon != null:
		_coin_icon.texture = CoinSkin.face_tex
	if _coin_info == null or _coin_save_btn == null:
		return
	var d: int = int(CoinSkin.draft["design"])
	var saved_txt: String = "ذخیره‌شده در بازی: " + CoinSkin.DESIGN_NAMES[int(CoinSkin.saved["design"])]
	_coin_info.text = saved_txt + ("  ✓ همین طرح" if CoinSkin.draft_is_saved() else "\nتغییرات ذخیره نشده")
	for i in _coin_design_btns.size():
		_coin_design_btns[i].modulate = Color(1, 1, 1, 1) if i == d else Color(1, 1, 1, 0.55)
	_coin_updating = true
	_coin_density.value = float(CoinSkin.draft["density"])
	_coin_contrast.value = float(CoinSkin.draft["contrast"])
	_coin_updating = false
	_coin_style_btn.text = "سبک چاپ: " + CoinSkin.STYLE_NAMES[int(CoinSkin.draft["style"])]
	_coin_photo_box.visible = d == CoinSkin.PHOTO
	_coin_bg_btn.text = "حذف خودکار پس‌زمینه: " + ("روشن" if int(CoinSkin.draft["bg"]) == 1 else "خاموش")
	_coin_bg_lbl.text = "عکس بدون پس‌زمینه (همین روی سکه حکاکی می‌شود):" if (int(CoinSkin.draft["bg"]) == 1 and CoinSkin.bg_removed_ok) else "پس‌زمینه‌ی این عکس ساده نبود و کامل حذف نشد؛ عکسی با پس‌زمینه‌ی یکدست انتخاب کن."
	if d == CoinSkin.PHOTO:
		var ci: Image = CoinSkin.cutout_image() if int(CoinSkin.draft["bg"]) == 1 else null
		if ci != null:
			var stamp := ci.get_instance_id()
			if stamp != _coin_cut_stamp:
				_coin_cut_stamp = stamp
				var th := ci.duplicate() as Image
				th.resize(200, 200 * th.get_height() / maxi(1, th.get_width()), Image.INTERPOLATE_BILINEAR)
				_coin_cut_img.texture = ImageTexture.create_from_image(th)
		else:
			_coin_cut_img.texture = null
			_coin_cut_stamp = -1
	_coin_style_btn.visible = d == CoinSkin.PHOTO
	_coin_save_btn.disabled = CoinSkin.draft_is_saved()


# ------------------------- انتخاب عکس / اسکین -------------------------
func _open_picker(target: String) -> void:
	if target == "police_glb" and not Edition.is_owner():
		return
	if target == "glb" and not Edition.can_import_glb():
		_show_toast("مدل‌های GLB قفل‌اند؛ از فروشگاه آنلاین باز کن")
		_online.store_filter = "glb"
		_set_screen(Screen.ONLINE_STORE)
		return
	_pick_target = target
	var android := OS.get_name() == "Android"
	if android:
		OS.request_permissions()
		if DisplayServer.has_feature(DisplayServer.FEATURE_NATIVE_DIALOG_FILE):
			_native_pick(target)
		else:
			_custom_pick(target)
		return
	if _file_dialog == null:
		_file_dialog = FileDialog.new()
		_file_dialog.title = "انتخاب عکس"
		_file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
		_file_dialog.use_native_dialog = not android  # روی اندروید دیالوگ داخلی Godot (با مسیر فایل کار می‌کند)؛ روی کامپیوتر دیالوگ سیستم
		_file_dialog.filters = PackedStringArray(["*.png, *.jpg, *.jpeg, *.webp, *.bmp ; تصاویر"])
		_file_dialog.theme = _dialog_theme()
		_file_dialog.ok_button_text = "انتخاب"
		_file_dialog.cancel_button_text = "لغو"
		_file_dialog.file_selected.connect(_on_picked)
		add_child(_file_dialog)
	_file_dialog.filters = _pick_filters(target)
	_file_dialog.title = "انتخاب فایل صوتی" if (target == "voice" or target == "music") else ("انتخاب مدل سه‌بعدی" if target == "glb" else ("انتخاب فونت" if target == "font" else "انتخاب عکس"))
	if target == "glb" or target == "font" or target == "music":
		_file_dialog.current_dir = "/storage/emulated/0/Download" if android else OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	else:
		_file_dialog.current_dir = "/storage/emulated/0/Pictures" if android else OS.get_system_dir(OS.SYSTEM_DIR_PICTURES)
	_file_dialog.popup_centered_ratio(0.95)


func _pick_filters(target: String) -> PackedStringArray:
	if target == "voice" or target == "music":
		return PackedStringArray(["*.ogg,*.mp3,*.wav ; فایل صوتی"])
	if target == "glb" or target == "police_glb":
		return PackedStringArray(["*.glb,*.gltf,*.fbx,*.obj,*.vrm,*.zip,*.bin ; مدل سه‌بعدی", "* ; همه‌ی فایل‌ها"])
	if target == "item_file":
		return PackedStringArray(["* ; همه‌ی فایل‌ها"])
	if target == "font":
		return PackedStringArray(["*.ttf,*.otf,*.woff,*.woff2 ; فونت"])
	return PackedStringArray(["*.png,*.jpg,*.jpeg,*.webp,*.bmp ; تصاویر"])


## انتخابگر بومیِ سیستم (اندروید). اگر مسیر قابل‌خواندن برنگرداند، صفحه‌ی خودمان باز می‌شود.
func _native_pick(target: String) -> void:
	var cb := func(status: bool, paths: PackedStringArray, _idx: int) -> void:
		if not status:
			return
		if paths.size() > 0:
			var p := paths[0]
			var fa := FileAccess.open(p, FileAccess.READ)
			if fa != null:
				fa.close()
				_on_picked.call_deferred(p)
				return
		_custom_pick.call_deferred(target)
	var err := DisplayServer.file_dialog_show("انتخاب فایل", "", "", false, DisplayServer.FILE_DIALOG_MODE_OPEN_FILE, _pick_filters(target), cb)
	if err != OK:
		_custom_pick(target)


func _custom_pick(target: String) -> void:
	var fp := preload("res://scripts/file_picker.gd").new()
	add_child(fp)
	var is_model := target == "glb" or target == "police_glb"
	if target == "voice" or target == "music":
		fp.setup("انتخاب فایل صوتی", ["ogg", "mp3", "wav"])
	elif target == "item_file":
		fp.setup("انتخاب فایل آیتم", [])
	elif target == "font":
		fp.setup("انتخاب فونت", ["ttf", "otf", "woff", "woff2"])
	else:
		fp.setup("انتخاب مدل سه‌بعدی" if is_model else "انتخاب عکس", ["glb", "gltf", "fbx", "obj", "vrm", "zip", "bin"] if is_model else ["png", "jpg", "jpeg", "webp", "bmp"])
	fp.picked.connect(func(p: String): _on_picked(p))


func _dialog_theme() -> Theme:
	var th := Theme.new()
	th.default_font = look_font()
	for t in ["Label", "Button", "LineEdit", "Tree", "ItemList", "OptionButton", "CheckBox"]:
		th.set_font_size("font_size", t, 24)
	th.set_color("font_color", "Label", COL_TEXT)
	th.set_color("font_color", "Button", Color.WHITE)
	th.set_color("font_hover_color", "Button", Color.WHITE)
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	var states := {"normal": COL_PURPLE, "hover": COL_PURPLE_HOVER, "pressed": COL_PURPLE_DOWN, "disabled": Color("444444")}
	for st in states:
		var sb := _flat(states[st], 12)
		sb.set_content_margin_all(8)
		th.set_stylebox(st, "Button", sb)
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_constant("v_separation", "Tree", 14)
	return th


func _on_files_dropped(files: PackedStringArray) -> void:
	if files.size() == 0:
		return
	match _screen:
		Screen.CHARACTER:
			_pick_target = "char"
			_on_picked(files[0])
		Screen.COIN:
			_pick_target = "coin"
			_on_picked(files[0])
		Screen.STUDIO:
			_pick_target = "studio_png"
			_on_picked(files[0])
		Screen.BUILDER:
			# هر فایل در اسلات خالی بعدی (به ترتیب جلو، پشت، راست، چپ، صورت)
			var order := ["front", "back", "right", "left", "face"]
			for f in files:
				for s in order:
					if not _b_slots.has(s):
						_pick_target = s
						_on_picked(f)
						break


func _on_picked_glb(path: String) -> void:
	if not Edition.can_import_glb():
		_show_toast("افزودن GLB در نسخه‌ی عمومی قفل است")
		return
	var gerr := Skins.add_glb(path, path.get_file().get_basename())
	if gerr != "":
		_show_toast(gerr)
		Sfx.play("error")
	else:
		_show_toast("مدل سه‌بعدی اضافه شد!")
		Sfx.play("buy")


var pick_callback: Callable = Callable()


## ویرایشگرها: فایل را انتخاب کن و نتیجه را به cb بده
func pick_file(target: String, cb: Callable) -> void:
	pick_callback = cb
	_open_picker(target)


func _on_picked(path: String) -> void:
	if _pick_target in ["voice", "music"]:
		var blocked := Content.import_block(_pick_target)
		if blocked != "":
			_show_toast(blocked)
			Sfx.play("error")
			return
	if _pick_target == "voice":
		var vn: String = Rules.import_voice(path)
		if vn == "":
			_show_toast("این فایل صوتی خوانده نشد (ogg، mp3 یا wav بدهید)")
			Sfx.play("error")
		elif pick_callback.is_valid():
			pick_callback.call(vn)
		return
	if _pick_target == "item_file":
		if pick_callback.is_valid():
			pick_callback.call(path)
		return
	if _pick_target == "item_preview":
		var pim := Image.load_from_file(path)
		if pim == null or pim.is_empty():
			_show_toast("این فایل عکس معتبر نیست (png، jpg، webp)")
			Sfx.play("error")
		elif pick_callback.is_valid():
			pick_callback.call(path)
		return
	if _pick_target == "music":
		var merr: String = Music.import_track(path)
		_show_toast(merr if merr != "" else "آهنگ اضافه شد")
		Sfx.play("error" if merr != "" else "buy")
		return
	if _pick_target == "font":
		var fb := FileAccess.get_file_as_bytes(path)
		var test := FontFile.new()
		test.data = fb
		if fb.size() == 0 or test.get_font_name() == "" and test.get_supported_chars().length() == 0:
			_show_toast("این فایل فونت معتبر نیست (ttf، otf یا woff)")
			Sfx.play("error")
			return
		var fo := FileAccess.open(CUSTOM_FONT, FileAccess.WRITE)
		fo.store_buffer(fb)
		fo.close()
		Content.look_set("font", "custom")
		_sig = ""
		apply_look(true)
		_show_toast("فونت اعمال شد")
		Sfx.play("buy")
		return
	if _pick_target == "police_glb":
		var perr: String = PoliceCfg.choose_model(path)
		_show_toast(perr if perr != "" else "مدل ذخیره شد")
		Sfx.play("error" if perr != "" else "buy")
		return
	if _pick_target == "glb" or (path.get_extension().to_lower() in ModelImport.EXTS and _pick_target == "char"):
		_pick_target = "glb"
		_on_picked_glb(path)
		return
	var img := Image.load_from_file(path)
	if _pick_target == "logo" and img != null and not img.is_empty():
		set_logo(img)
		_show_toast("لوگو تنظیم شد")
		Sfx.play("buy")
		return
	if img == null or img.is_empty():
		_show_toast("این فایل خوانده نشد. اگر روی گوشی هستی، مجوز دسترسی به عکس‌ها را بده")
		Sfx.play("error")
		return
	if _pick_target == "studio_png" or _pick_target == "studio_photo":
		_studio.import_image(img, _pick_target)
		return
	if _pick_target == "coin":
		var err := CoinSkin.set_image(img)
		if err != "":
			_show_toast(err)
			Sfx.play("error")
		else:
			_show_toast("عکس آماده شد؛ پیش‌نمایش را ببین و ذخیره کن")
			Sfx.play("buy")
	elif _pick_target == "char":
		var err2 := Skins.add_image(img, path.get_file().get_basename())
		if err2 != "":
			_show_toast(err2)
			Sfx.play("error")
		else:
			_show_toast("کاراکتر اضافه شد!")
			Sfx.play("buy")
	else:
		var m := maxi(img.get_width(), img.get_height())
		if m > 1024:
			var f := 1024.0 / float(m)
			img.resize(maxi(8, int(img.get_width() * f)), maxi(8, int(img.get_height() * f)), Image.INTERPOLATE_LANCZOS)
		_b_slots[_pick_target] = img
		_b_refresh_slots()
		_b_update_preview()


# ------------------------- پایان بازی و توقف -------------------------
func _build_over() -> void:
	_over_ui = Control.new()
	_add_full(_root, _over_ui)
	_add_full(_over_ui, _dim_rect(0.78))
	var center := CenterContainer.new()
	_add_full(_over_ui, center)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 22)
	center.add_child(col)
	_over_title = _label("", 84, COL_ORANGE)
	col.add_child(_over_title)
	_over_msg = _label("", 38)
	_over_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_over_msg.custom_minimum_size = Vector2(540, 0)
	col.add_child(_over_msg)
	_revive_btn = _button("", func(): Game.revive(false), Vector2(560, 100), 34)
	col.add_child(_revive_btn)
	_ticket_btn = _button("", func(): Game.revive(true), Vector2(560, 100), 34, "Purple")
	col.add_child(_ticket_btn)
	col.add_child(_button("بازی دوباره", func(): Game.play(), Vector2(560, 100), 38))
	col.add_child(_button("منوی اصلی", func(): Game.quit_to_menu(), Vector2(560, 92), 34))


func _build_pause() -> void:
	_pause_ui = Control.new()
	_add_full(_root, _pause_ui)
	_add_full(_pause_ui, _dim_rect(0.8))
	var center := CenterContainer.new()
	_add_full(_pause_ui, center)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 20)
	center.add_child(col)
	col.add_child(_label("توقف", 70, Color.WHITE))
	_pause_coins = _label("", 36, COL_ORANGE)
	col.add_child(_pause_coins)
	var sz := Vector2(560, 100)
	col.add_child(_button("ادامه بازی", _on_resume_pressed, sz, 40))
	col.add_child(_button("منوی اصلی", func(): Game.quit_to_menu(), sz, 34))


func _build_overlays() -> void:
	_flash = ColorRect.new()
	_flash.color = Color(1.0, 0.1, 0.2, 0.0)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_add_full(_root, _flash)

	_countdown_lbl = _label("3", 220, Color.WHITE)
	_countdown_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	_countdown_lbl.add_theme_constant_override("outline_size", 20)
	_countdown_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_add_full(_root, _countdown_lbl)
	_countdown_lbl.visible = false

	_toast_panel = PanelContainer.new()
	_toast_panel.add_theme_stylebox_override("panel", UiArt.panel_style(Color(0.06, 0.02, 0.12, 0.92), Color("ffb02e")))
	_toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast_lbl = _label("", 30, Color.WHITE)
	_toast_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast_lbl.custom_minimum_size = Vector2(520, 0)
	_toast_panel.add_child(_toast_lbl)
	_root.add_child(_toast_panel)
	_toast_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_toast_panel.offset_top = -330
	_toast_panel.offset_bottom = -230
	_toast_panel.offset_left = -290
	_toast_panel.offset_right = 290
	_toast_panel.modulate.a = 0.0


# ------------------------- منطق نمایش -------------------------
var _gated := false
var _net_lock: Control
var _net_label: Label


func _on_gate_change() -> void:
	if not Online.gate_open():
		if _screen != Screen.ACCOUNT:
			_set_screen(Screen.ACCOUNT)
	elif _gated:
		_set_screen(Screen.START)
	_update_net_lock()


func _build_net_lock() -> void:
	# هشدار قطع اینترنت: بازی هیچ‌وقت قطع نمی‌شود؛ فقط در منو هشدار می‌دهد
	_net_lock = PanelContainer.new()
	_net_lock.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_net_lock.visible = false
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.75, 0.2, 0.1, 0.95)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(12)
	_net_lock.add_theme_stylebox_override("panel", sb)
	_root.add_child(_net_lock)
	_net_lock.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_net_lock.offset_left = 16
	_net_lock.offset_right = -16
	_net_lock.offset_top = 12
	_net_label = _label("", 28, Color.WHITE)
	_net_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_net_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_net_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_net_lock.add_child(_net_label)
	Online.connection_changed.connect(func(_o: bool): _update_net_lock())
	Online.profile_changed.connect(_update_net_lock)
	Online.auth_changed.connect(_on_gate_change)


func _update_net_lock() -> void:
	if _net_lock == null:
		return
	var np: int = Online.pending.size()
	var show: bool = Online.logged_in() and Online.enabled() and (Online.offline or np > 0) and _screen != Screen.GAME and _screen != Screen.ACCOUNT
	_net_lock.visible = show
	if show:
		_net_label.text = ("اینترنت قطع است؛ امتیاز و سکه‌ها بعد از وصل شدن ثبت می‌شوند." if Online.offline
			else "در حال ثبت امتیاز و سکه‌ها روی حساب…")


func _set_screen(s: int) -> void:
	if not Online.gate_open():
		_gated = true
		s = Screen.ACCOUNT
	elif _gated and s == Screen.START:
		_gated = false
	if (s != Screen.ACCOUNT or Online.gate_open()) and (not Content.can(_screen_ability(s)) or ((s == Screen.CONTENT or s == Screen.RULES) and not Edition.is_owner())):
		s = Screen.START
	var warn: bool = (s == Screen.START or s == Screen.GAMEOVER) and _screen != s
	_screen = s
	_update_net_lock()
	if warn and Online.offline and Online.logged_in():
		_show_toast("اینترنت قطع است؛ نتیجه‌ی بازی‌ات بعد از وصل شدن ثبت می‌شود")
	_editors.content.visible = s == Screen.CONTENT
	_editors.rules.visible = s == Screen.RULES
	_editors.chooser.visible = s == Screen.CHOOSER
	if s == Screen.CHOOSER:
		_editors.refresh_chooser()
	if s == Screen.CONTENT:
		_editors.refresh_content()
	if s == Screen.RULES:
		_editors.refresh_rules()
	_intro_ui.visible = s == Screen.INTRO
	_start_ui.visible = s == Screen.START
	_hud_ui.visible = s == Screen.GAME
	_shop_ui.visible = s == Screen.SHOP
	_char_ui.visible = s == Screen.CHARACTER
	_builder_ui.visible = s == Screen.BUILDER
	_coin_ui.visible = s == Screen.COIN
	_studio_ui.visible = s == Screen.STUDIO
	_settings_ui.visible = s == Screen.SETTINGS
	_missions_ui.visible = s == Screen.MISSIONS
	_online.account.visible = s == Screen.ACCOUNT
	_online.board.visible = s == Screen.BOARD
	_online.store.visible = s == Screen.ONLINE_STORE
	_online.challenge.visible = s == Screen.CHALLENGE
	if s == Screen.CHALLENGE:
		_online.refresh_challenge()
	if s == Screen.ACCOUNT:
		_online.refresh_account()
	elif s == Screen.BOARD:
		_online.refresh_board()
	elif s == Screen.ONLINE_STORE:
		_online.open_store()
	if s == Screen.MISSIONS:
		_refresh_missions()
	if s == Screen.SETTINGS:
		_pv["settings"]["yaw"] = PI
		_pv["settings"]["cd"] = 0.0
		_settings.refresh()
	_over_ui.visible = s == Screen.GAMEOVER
	if s == Screen.CHARACTER:
		_char_tab = _tab_of(Skins.current_entry())
		_pv["char"]["yaw"] = PI
		_pv["char"]["cd"] = 0.0
		_refresh_character()
	if s == Screen.BUILDER:
		_pv["builder"]["yaw"] = PI
		_pv["builder"]["cd"] = 0.0
	Content.apply_tree.call_deferred(_root)
	for c: Control in [_start_ui, _shop_ui, _char_ui, _builder_ui, _coin_ui, _studio_ui, _settings_ui, _missions_ui, _over_ui]:
		if c.visible:
			c.modulate.a = 0.0
			create_tween().tween_property(c, "modulate:a", 1.0, 0.2)
	_pause_ui.visible = false
	_countdown = -1.0
	_countdown_lbl.visible = false
	_refresh_all()


# ------------------------- کارت بروزرسانی صفحه‌ی شروع -------------------------
var _upd_card: PanelContainer
var _upd_title: Label
var _upd_notes: Label
var _upd_btn: Button
var _upd_btn2: Button
var _upd_busy := false


func _build_version_label(col: VBoxContainer) -> void:
	var t := "ساخت %d" % Updater.BUILD
	if Updater.loaded_version > 0:
		var nm := String(Updater.active.get("name", ""))
		t += "  •  وصله %s" % (nm if nm != "" else str(Updater.loaded_version))
	var l := _label(t, 20, Color(1, 1, 1, 0.45))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(l)


func _build_update_card(col: VBoxContainer) -> void:
	_upd_card = PanelContainer.new()
	_upd_card.visible = false
	_upd_card.custom_minimum_size = Vector2(600, 0)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.10, 0.28, 0.20, 0.92)
	sb.set_corner_radius_all(22)
	sb.set_border_width_all(3)
	sb.border_color = Color("7dff9a")
	sb.set_content_margin_all(18)
	_upd_card.add_theme_stylebox_override("panel", sb)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	_upd_card.add_child(v)
	_upd_title = _label("", 32, Color("b9ffcb"))
	_upd_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_upd_title.custom_minimum_size = Vector2(560, 0)
	v.add_child(_upd_title)
	_upd_notes = _label("", 22, Color("d9ffe4"))
	_upd_notes.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_upd_notes.custom_minimum_size = Vector2(560, 0)
	v.add_child(_upd_notes)
	_upd_btn = _button("", func(): _on_update_pressed(), Vector2(560, 84), 30, "Gold")
	v.add_child(_upd_btn)
	_upd_btn2 = _button("کپی لینک دانلود", func(): DisplayServer.clipboard_set(Updater.apk_link()); _show_toast("لینک کپی شد"), Vector2(560, 64), 24, "Dark")
	v.add_child(_upd_btn2)
	col.add_child(_upd_card)
	Updater.changed.connect(_refresh_update_card)
	Online.transfer.connect(func(t: String): if _upd_busy and t != "": _upd_btn.text = t)
	_refresh_update_card()


func _refresh_update_card() -> void:
	if _upd_card == null or not is_instance_valid(_upd_card):
		return
	var pend := Updater.pending_restart()
	var has_patch := not Updater.patch_info.is_empty()
	var has_apk := not Updater.apk_info.is_empty()
	_upd_card.visible = pend or has_patch or has_apk
	_upd_btn2.visible = false
	if pend and not has_patch:
		_upd_title.text = "به‌روزرسانی دانلود شد ✓"
		_upd_notes.text = String(Updater.active.get("notes", ""))
		_upd_btn.text = "بستن بازی (با باز کردن دوباره اعمال می‌شود)"
		_upd_btn.disabled = false
	elif has_patch:
		var pi := Updater.patch_info
		_upd_title.text = "به‌روزرسانی %s آماده است" % String(pi.get("version_name", ""))
		_upd_notes.text = String(pi.get("notes", ""))
		_upd_btn.text = "به‌روزرسانی (%.1f مگابایت)" % (float(pi.get("size", 0)) / 1048576.0)
		_upd_btn.disabled = _upd_busy
	elif has_apk:
		var ai := Updater.apk_info
		_upd_title.text = "نسخه‌ی جدید %s منتشر شده" % String(ai.get("version_name", ""))
		_upd_notes.text = String(ai.get("notes", ""))
		_upd_btn.text = "دانلود نسخه‌ی جدید"
		_upd_btn.disabled = false
		_upd_btn2.visible = true


func _on_update_pressed() -> void:
	if Updater.pending_restart() and Updater.patch_info.is_empty():
		get_tree().quit()
		return
	if not Updater.patch_info.is_empty():
		if _upd_busy:
			return
		_upd_busy = true
		_upd_btn.disabled = true
		_upd_btn.text = "در حال دانلود…"
		var r: Dictionary = await Updater.download_patch()
		_upd_busy = false
		if r.ok:
			_show_toast("به‌روزرسانی آماده شد؛ بازی را ببند و دوباره باز کن")
		else:
			_show_toast("دانلود نشد: " + String(r.error))
		_refresh_update_card()
		return
	if not Updater.apk_info.is_empty():
		var link := Updater.apk_link()
		if link != "":
			OS.shell_open(link)


func _refresh_all() -> void:
	_start_coin_row.visible = Content.can("coins_ui")
	_hud_coin_row.visible = Content.can("coins_ui")
	_start_coins.text = "%d" % Game.coins
	_start_coin_icon.texture = CoinSkin.face_tex
	_start_best.text = "بیشترین امتیاز: %d  •  دورترین مسیر: %d متر" % [Game.high_score, Game.best_distance]
	_sound_btn.text = "صدا: روشن" if Game.sound_on else "صدا: خاموش"
	_vib_btn.text = "لرزش: روشن" if Game.vibration_on else "لرزش: خاموش"
	if _account_chip != null:
		_account_chip.text = ("%s  •  %d سکه" % [Online.username, Game.coins]) if Online.logged_in() else "ورود / ثبت‌نام"
		_announce.text = Online.announcement
	_pause_coins.text = "سکه‌ها: %d" % Game.coins
	_refresh_shop()
	_refresh_loadout_strip()
	if _revive_btn != null:
		_revive_btn.visible = Game.can_revive() and Game.coins >= Game.REVIVE_PRICE
		_revive_btn.text = "ادامه با %d سکه" % Game.REVIVE_PRICE
	if _ticket_btn != null:
		_ticket_btn.visible = Game.over and not Game.used_revive and Game.has_life_ticket()
		_ticket_btn.text = "ادامه رایگان با بلیت زندگی (%d)" % Game.boost_count("life")


func _on_game_started() -> void:
	_score_lbl.text = "امتیاز: 0"
	_coins_lbl.text = "0"
	_dist_lbl.text = "0 متر"
	_set_screen(Screen.GAME)
	_show_hint("سکه‌ها را جمع کن!\nاز موانع بپر، زیرشان سُر بخور یا خط عوض کن", 4.0)


func _on_game_over(summary: Dictionary) -> void:
	_pause_ui.visible = false
	var rec: bool = summary["new_record"]
	_over_title.text = "رکورد جدید!" if rec else "گرفتنت!"
	_over_title.add_theme_color_override("font_color", COL_GOOD if rec else COL_ORANGE)
	_over_msg.text = "امتیاز: %d\nمسافت: %d متر\nسکه‌ی این دور: %d\nبهترین امتیاز: %d" % [summary["score"], summary["distance"], summary["coins"], summary["high_score"]]
	_set_screen(Screen.GAMEOVER)


func _on_pause_pressed() -> void:
	if _countdown > 0.0:
		return
	if Game.is_active and not Game.is_paused:
		Game.pause_game()

func _on_pause_changed(paused: bool) -> void:
	_pause_ui.visible = paused and _screen == Screen.GAME and _countdown <= 0.0
	_refresh_all()

func _on_resume_pressed() -> void:
	_pause_ui.visible = false
	_countdown = 3.0
	_countdown_lbl.text = "3"
	_countdown_lbl.visible = true
	Sfx.play("tick")

func _on_player_hit() -> void:
	_flash.color.a = 0.35
	var tw := create_tween()
	tw.tween_property(_flash, "color:a", 0.0, 0.35)


# ------------------------- پیام‌ها و پاپ‌آپ‌ها -------------------------
func _place_toast(top: bool) -> void:
	if top:
		_toast_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
		_toast_panel.offset_top = 150
		_toast_panel.offset_bottom = 250
	else:
		_toast_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
		_toast_panel.offset_top = -330
		_toast_panel.offset_bottom = -230
	_toast_panel.offset_left = -290
	_toast_panel.offset_right = 290

func _show_toast(text: String) -> void:
	_place_toast(_screen == Screen.CHARACTER or _screen == Screen.BUILDER or _screen == Screen.COIN or _screen == Screen.STUDIO or _screen == Screen.SETTINGS)
	_toast_lbl.text = Content.dyn(text)
	if _toast_tween:
		_toast_tween.kill()
	_toast_panel.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(2.2)
	_toast_tween.tween_property(_toast_panel, "modulate:a", 0.0, 0.4)


func _show_hint(text: String, seconds: float) -> void:
	_hint_lbl.text = text
	if _hint_tween:
		_hint_tween.kill()
	_hint_lbl.modulate.a = 1.0
	_hint_tween = create_tween()
	_hint_tween.tween_interval(seconds)
	_hint_tween.tween_property(_hint_lbl, "modulate:a", 0.0, 0.6)

func _show_popup(text: String, good: bool) -> void:
	if _screen != Screen.GAME:
		return
	var l := _label(Content.dyn(text), 64, COL_GOOD if good else COL_BAD)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 10)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.custom_minimum_size = Vector2(300, 80)
	var cx := get_viewport().get_visible_rect().size.x * 0.5 - 150.0 + _rng.randf_range(-60.0, 60.0)
	l.position = Vector2(cx, 470.0)
	_root.add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", 380.0, 0.8)
	tw.tween_property(l, "modulate:a", 0.0, 0.8)
	tw.chain().tween_callback(l.queue_free)
