extends Node3D
## صحنه‌ی اصلی: همه‌چیز را می‌سازد، به هم وصل می‌کند و ترتیب به‌روزرسانی را مشخص می‌کند.

const WorldScript := preload("res://scripts/world.gd")
const PlayerScript := preload("res://scripts/player.gd")
const TrackScript := preload("res://scripts/track.gd")
const UIScript := preload("res://scripts/ui.gd")

const MENU_SPEED := 4.0
const CAM_HEIGHT := 4.8
const CAM_BACK := 7.5
# دوربین: وقتی پلیس می‌رسد کمی بالاتر و دورتر (تا پلیس و مسیر دیده شود)؛ وقتی رفت نزدیک‌تر و کمی پایین‌تر
const CHASE_HEIGHT := 5.0
const CHASE_BACK := 7.6
const FREE_HEIGHT := 3.9
const FREE_BACK := 5.3
const INTRO_LEN := 4.2
const BASE_FOV := 66.0

var world
var player
var track
var ui
var cam: Camera3D
var _cam_y := 0.0
var _cam_k := 1.0
var _coin_n := 0
var _intro_t := 0.0
var _from_intro := false
var _start_kick := 0.0
var police

var _world_speed := MENU_SPEED
var _trauma := 0.0
var _cam_x := 0.0
var _fov := BASE_FOV
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.randomize()
	add_child(LookFx.new())
	Game.mode_changed.connect(_portal_flash)
	Game.mini_started.connect(_begin_mini)

	world = WorldScript.new()
	world.name = "World"
	add_child(world)

	track = TrackScript.new()
	track.name = "Track"
	add_child(track)

	player = PlayerScript.new()
	player.name = "Player"
	add_child(player)
	track.player = player
	police = preload("res://scripts/police.gd").new()
	police.name = "Police"
	police.player = player
	add_child(police)

	cam = Camera3D.new()
	cam.name = "Camera"
	cam.keep_aspect = Camera3D.KEEP_WIDTH  # FOV افقی → در حالت عمودی هم هر سه لِین دیده می‌شوند
	cam.fov = BASE_FOV
	cam.near = 0.1
	cam.far = 260.0
	add_child(cam)
	cam.current = true
	_update_camera(0.0, true)

	ui = UIScript.new()
	ui.name = "UI"
	add_child(ui)

	Game.game_started.connect(_on_game_started)
	Game.intro_started.connect(_on_intro_started)
	Game.player_hit.connect(_on_player_hit)
	Game.coin_collected.connect(func(_v: int):
		Sfx.play("plus")
		_coin_n += 1
		var rep := Rules.fire("coin")
		if not rep and _coin_n % 6 == 0:
			Sfx.voice("coin", -4.0))
	Game.power_collected.connect(func(id: int):
		Sfx.play("p%d" % id)
		Rules.fire("power", float(id)))
	Game.grazed.connect(func():
		Sfx.play("graze")
		if not Rules.fire("graze"):
			Sfx.voice("hit")
		if not Rules.fire("chaser_near", 0.0, Rules.CHASER):
			Sfx.play("horn", -3.0))
	Game.shield_broke.connect(func(): Sfx.play("shield_break"))
	Game.zone_changed.connect(func(z: int):
		Sfx.play("zone")
		Rules.fire("zone", float(z)))
	player.landed.connect(func():
		Sfx.play("land", -3.0)
		if not Rules.fire("land"):
			Sfx.voice("land", -5.0))
	player.stepped.connect(func(): Sfx.play("step", -8.0 + randf_range(-2.0, 0.0), float(Sfx.VOICES[Game.voice_of(Skins.current_id)][3]) * randf_range(0.95, 1.05)))
	Game.game_over.connect(_on_game_over)
	Game.revived.connect(_on_revived)
	player.jumped.connect(func():
		Sfx.play("jump", -4.0)
		if not Rules.fire("jump"):
			Sfx.voice("jump"))
	player.slid.connect(func():
		Sfx.play("slide", -4.0)
		if not Rules.fire("slide"):
			Sfx.voice("slide"))
	player.lane_changed.connect(func():
		Sfx.play("swish")
		Rules.fire("lane"))


func _process(delta: float) -> void:
	if Game.is_paused:
		return
	if Game.intro_active:
		_update_loops()
		_tick_intro(delta)
		return
	var target := Game.run_speed if Game.is_active else MENU_SPEED
	_update_loops()
	_world_speed = move_toward(_world_speed, target, 20.0 * delta)
	world.scroll(delta, _world_speed)
	track.advance(delta, _world_speed)
	player.tick(delta, _world_speed)
	_update_camera(delta, false)


func _fire_start() -> void:
	Rules.fire("start")


func _update_loops() -> void:
	if Game.is_active:
		Rules.tick(Game.distance)
	var near: float = police.near_k() if (Game.is_active or Game.intro_active) else 0.0
	Music.update("game" if (Game.is_active or Game.intro_active) else "menu", 1.0 if not Game.over else 0.35)
	Sfx.set_loop("siren", near * 0.8)
	Sfx.set_loop("heart", maxf(0.0, near - 0.3) if Game.stumble > 0.0 else 0.0)
	Sfx.set_loop("wind", clampf(_world_speed / 22.0, 0.0, 1.0) if Game.is_active else 0.0)


## (ضریب فاصله، ضریب ارتفاع، جابه‌جایی نقطه‌ی نگاه، جابه‌جایی افقی) برای هر حالت دوربین
var _mini: MiniBase


func _begin_mini(id: String) -> void:
	_portal_flash(id)
	await get_tree().create_timer(0.25).timeout
	if _mini != null or Game.mini == "":
		return
	for n: Node in [world, track, player, police]:
		if n is Node3D:
			(n as Node3D).visible = false
	ui._hud_ui.visible = false
	match id:
		"drive": _mini = MiniDrive.new()
		"shooter": _mini = MiniSpace.new()
		"fruit": _mini = MiniFruit.new()
		"stack": _mini = MiniStack.new()
		_: _mini = MiniCraft.new()
	add_child(_mini)
	_mini.finished.connect(_end_mini)


func _end_mini(res: Dictionary) -> void:
	if _mini != null:
		_mini.queue_free()
		_mini = null
	for n: Node in [world, track, player, police]:
		if n is Node3D:
			(n as Node3D).visible = true
	cam.make_current()
	ui._hud_ui.visible = ui._screen == ui.Screen.GAME
	Game.finish_mini(res)
	_portal_flash("")


func _portal_flash(id: String) -> void:
	var layer := CanvasLayer.new()
	layer.layer = 8
	var r := ColorRect.new()
	r.set_anchors_preset(Control.PRESET_FULL_RECT)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tint: Color = Modes.def(id).get("tint", Color("9d5cff")) if id != "" else Color("ffffff")
	r.color = Color(tint.r * 0.4 + 0.6, tint.g * 0.4 + 0.6, tint.b * 0.4 + 0.6, 1.0)
	layer.add_child(r)
	add_child(layer)
	_start_kick = 1.0
	_trauma = maxf(_trauma, 0.5)
	var tw := create_tween()
	tw.tween_property(r, "color:a", 0.0, 0.7)
	tw.tween_callback(layer.queue_free)


func _cam_view_params() -> Vector4:
	match Game.cam_view:
		1: return Vector4(1.25, 1.55, 6.0, 0.0)     # بالا: دید وسیع
		2: return Vector4(0.72, 0.72, -3.0, 0.0)    # نزدیک: هیجانی
		3: return Vector4(0.95, 1.0, 0.0, 1.9)      # شانه: کمی کج
	return Vector4(1.0, 1.0, 0.0, 0.0)


func _update_camera(delta: float, snap: bool) -> void:
	var px: float = player.position.x
	var k := 1.0 if snap else 1.0 - exp(-7.0 * delta)
	_cam_x = lerpf(_cam_x, px * 0.55, k)
	_trauma = maxf(0.0, _trauma - delta * 1.6)
	var shake := _trauma * _trauma
	var off := Vector3(_rng.randf_range(-1.0, 1.0), _rng.randf_range(-1.0, 1.0), 0.0) * shake * 0.35
	var cv := _cam_view_params()
	# پلیس نزدیک → دوربین کمی جلوتر و پایین‌تر؛ فرار کردی → عقب‌تر و بالاتر
	var want_k := 1.0
	if Game.is_active and police != null:
		want_k = 1.0 - police.near_k()
	_cam_k = lerpf(_cam_k, want_k, 1.0 if snap else 1.0 - exp(-1.6 * delta))
	var back := lerpf(CHASE_BACK, FREE_BACK, _cam_k)
	var height := lerpf(CHASE_HEIGHT, FREE_HEIGHT, _cam_k)
	if not Game.is_active:
		back = CAM_BACK
		height = CAM_HEIGHT
	if Game.is_active:
		back *= cv.x
		height *= cv.y
	cam.position = Vector3(_cam_x + (cv.w if Game.is_active else 0.0), height, back) + off
	# دوربین هنگام پرش و پرواز کمی بالا می‌آید تا کاراکتر همیشه در کادر بماند
	_cam_y = lerpf(_cam_y, player.jump_y * 0.55, 1.0 if snap else 1.0 - exp(-8.0 * delta))
	cam.position.y += _cam_y
	var look_z := -13.0 + (cv.z if Game.is_active else 0.0)
	cam.look_at(Vector3(_cam_x * 0.6, 0.9 + _cam_y * 1.3, look_z), Vector3.UP)
	_start_kick = maxf(0.0, _start_kick - delta * 2.2)
	var target_fov := BASE_FOV + clampf((_world_speed - 9.0) * 0.7, 0.0, 10.0) + _start_kick * 12.0
	_fov = lerpf(_fov, target_fov, 1.0 - exp(-3.0 * delta)) if not snap else target_fov
	cam.fov = _fov


# ------------------------- اینترو -------------------------
func _on_intro_started() -> void:
	player.reset()
	track.reset()
	world.rebuild_all()
	_intro_t = 0.0
	_from_intro = true
	_world_speed = 0.0


func _input(event: InputEvent) -> void:
	if Game.intro_active and _intro_t > 0.6:
		var press: bool = (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed) or (event is InputEventKey and event.pressed)
		if press:
			_intro_t = INTRO_LEN
			get_viewport().set_input_as_handled()


func _tick_intro(delta: float) -> void:
	_intro_t += delta
	world.scroll(delta, 0.0)
	player.tick(delta, 0.0)
	var t := _intro_t
	var u := clampf(t / INTRO_LEN, 0.0, 1.0)
	# پلیس از دور می‌دود و پشت سر کاراکتر می‌رسد
	police.intro_gap = lerpf(13.0, 3.4, smoothstep(0.05, 0.85, u))
	police.intro_off = lerpf(1.5, 0.0, smoothstep(0.45, 0.9, u))
	# مدار دوربین: از روبه‌رو و پایین ← کنار ← پشت سر
	var a := lerpf(PI, 0.0, smoothstep(0.38, 1.0, u))
	var r := lerpf(3.1, CHASE_BACK, smoothstep(0.38, 1.0, u))
	var h := lerpf(1.25, CHASE_HEIGHT, smoothstep(0.38, 1.0, u))
	var push := lerpf(0.0, 0.5, clampf(u / 0.38, 0.0, 1.0))
	r -= push * (1.0 - smoothstep(0.38, 1.0, u))
	var c := Vector3(0.0, 1.0, 0.0)
	cam.position = c + Vector3(sin(a) * r * 0.75, h - 1.0, cos(a) * r)
	var look_from := Vector3(0.0, 1.05, 0.0)
	var look_to := Vector3(0.0, 0.9, -13.0)       # دقیقاً همان نقطه‌ی نگاهِ دوربین تعقیب (بدون پرش هنگام شروع)
	cam.look_at(look_from.lerp(look_to, smoothstep(0.55, 1.0, u)), Vector3.UP)
	cam.fov = lerpf(52.0, BASE_FOV, smoothstep(0.3, 1.0, u))
	if t >= INTRO_LEN:
		# تحویل نرم: وضعیت دوربین بازی را با آخرین فریم اینترو یکی کن
		_cam_x = 0.0
		_cam_y = 0.0
		_fov = cam.fov
		_start_kick = 1.0
		_cam_k = 0.0
		Music.play_start()
		Game.start_run()


# ------------------------- رویدادها -------------------------
func _on_game_started() -> void:
	call_deferred("_fire_start")
	player.reset()
	track.reset()
	if not _from_intro:
		world.rebuild_all()
	_from_intro = false
	_trauma = 0.0


func _on_revived() -> void:
	track.clear_obstacles_near()
	player.invuln = Game.REVIVE_INVULN
	Sfx.play("go")


func _on_player_hit() -> void:
	_trauma = 0.9
	if Game.vibration_on:
		Input.vibrate_handheld(120)


func _on_game_over(_summary: Dictionary) -> void:
	Sfx.play("crash")
	if not Rules.fire("crash"):
		Sfx.voice("hit")
	get_tree().create_timer(0.45).timeout.connect(func():
		if not Rules.fire("chaser_caught", 0.0, Rules.CHASER):
			Sfx.play("caught")
			Sfx.play("laugh", -2.0))
