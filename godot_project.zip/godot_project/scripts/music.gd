extends Node
## موسیقی پس‌زمینه (Autoload با نام «Music»)
## • موسیقی منو و موسیقی هنگام بازی جدا انتخاب می‌شوند.
## • انتخاب‌ها و آهنگ‌های اضافه‌شده برای هر بازیکن (حساب) جدا ذخیره می‌شود.
## • آهنگ دلخواه از گوشی (mp3 / ogg / wav) اضافه می‌شود.
## • صدای شروع بازی هم قابل انتخاب است.

signal changed

const PREF := "user://music_prefs.json"
const DIR := "user://music"
const NONE := "none"
const PROC := "proc"          # موسیقی قدیمیِ ساخته‌شده با کد
## [شناسه، نام، فایل]
const BUILTIN := [
	["adventure", "ماجراجویی", "res://assets/music/adventure.ogg"],
	["chase", "تعقیب (تند)", "res://assets/music/chase.ogg"],
	["night", "شب (ترسناک)", "res://assets/music/night.ogg"],
	["calm", "آرام", "res://assets/music/calm.ogg"],
	["menu", "منوی روشن", "res://assets/music/menu.ogg"],
	["proc", "کلاسیک بازی", ""],
]
const START_SOUNDS := [["go", "پیش‌فرض"], ["start_a", "فانفار ۱"], ["start_b", "بوق ۲"], ["start_c", "وووش ۳"], ["none", "بدون صدا"]]
const MAX_TRACKS := 60

var _prefs: Dictionary = {}
var _player: AudioStreamPlayer
var _scene := "menu"
var _level := 1.0
var _cur_id := ""
var _cache: Dictionary = {}


func _ready() -> void:
	if FileAccess.file_exists(PREF):
		var d = JSON.parse_string(FileAccess.get_file_as_string(PREF))
		if d is Dictionary:
			_prefs = d
	DirAccess.make_dir_recursive_absolute(DIR)
	_player = AudioStreamPlayer.new()
	_player.bus = "Master"
	add_child(_player)
	Online.profile_changed.connect(_on_player_changed)
	Online.auth_changed.connect(_on_player_changed)


func uid() -> String:
	return Online.user_id if (Online.logged_in() and Online.user_id != "") else "guest"


func _me() -> Dictionary:
	var u := uid()
	if not _prefs.has(u) or not (_prefs[u] is Dictionary):
		_prefs[u] = {"menu": "menu", "game": "adventure", "start": "go", "own": []}
	return _prefs[u]


func _save() -> void:
	var f := FileAccess.open(PREF, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(_prefs))


func choice(scene_name: String) -> String:
	return String(_me().get(scene_name, NONE))


func set_choice(scene_name: String, id: String) -> void:
	_me()[scene_name] = id
	_save()
	changed.emit()
	if scene_name == "start":
		return
	_cur_id = ""
	update(_scene, _level, true)


## موسیقی مخصوص هر کاراکتر ("" = از انتخاب «موسیقی هنگام بازی» پیروی کند)
func char_choice(key: String) -> String:
	var m = _me().get("char", {})
	return String(m.get(key, "")) if m is Dictionary else ""


func set_char_choice(key: String, id: String) -> void:
	var m = _me().get("char", {})
	if not m is Dictionary:
		m = {}
	if id == "":
		m.erase(key)
	else:
		m[key] = id
	_me()["char"] = m
	_save()
	changed.emit()
	_cur_id = ""
	update(_scene, _level, true)


func _game_id() -> String:
	var k := Skins.char_key(Skins.current_entry())
	var c := char_choice(k)
	return c if c != "" else choice("game")


func own_tracks() -> Array:
	var a = _me().get("own", [])
	return a if a is Array else []


## همه‌ی گزینه‌ها برای انتخاب: [{id, name, own}]
func all_tracks() -> Array:
	var out: Array = [{"id": NONE, "name": "بدون موسیقی", "own": false}]
	for b in BUILTIN:
		out.append({"id": b[0], "name": b[1], "own": false})
	for t in own_tracks():
		out.append({"id": "own:" + String(t.file), "name": "★ " + String(t.name), "own": true})
	return out


func import_track(path: String) -> String:
	var ext := path.get_extension().to_lower()
	if ext not in ["ogg", "mp3", "wav"]:
		return "فقط mp3، ogg و wav پشتیبانی می‌شود"
	if own_tracks().size() >= MAX_TRACKS:
		return "حداکثر %d آهنگ" % MAX_TRACKS
	var bytes := FileAccess.get_file_as_bytes(path)
	if bytes.is_empty():
		return "فایل خوانده نشد. مجوز دسترسی را بده"
	var d := "%s/%s" % [DIR, uid()]
	DirAccess.make_dir_recursive_absolute(d)
	var fname := "%d_%s" % [Time.get_ticks_msec(), path.get_file()]
	var f := FileAccess.open("%s/%s" % [d, fname], FileAccess.WRITE)
	if f == null:
		return "ذخیره‌ی فایل ناموفق بود"
	f.store_buffer(bytes)
	f.close()
	if _stream_of("own:" + fname) == null:
		DirAccess.remove_absolute("%s/%s" % [d, fname])
		return "این فایل خوانده نشد"
	var me := _me()
	var own := own_tracks().duplicate()
	own.append({"file": fname, "name": path.get_file().get_basename()})
	me["own"] = own
	last_import = "own:" + fname
	_save()
	changed.emit()
	return ""


func remove_track(file: String) -> void:
	var me := _me()
	var own := own_tracks().duplicate()
	for i in own.size():
		if String(own[i].file) == file:
			own.remove_at(i)
			break
	me["own"] = own
	for k in ["menu", "game"]:
		if String(me.get(k, "")) == "own:" + file:
			me[k] = NONE
	var cm = me.get("char", {})
	if cm is Dictionary:
		for k in cm.keys():
			if String(cm[k]) == "own:" + file:
				cm.erase(k)
	DirAccess.remove_absolute("%s/%s/%s" % [DIR, uid(), file])
	_cache.erase("own:" + file)
	_save()
	changed.emit()
	_cur_id = ""
	update(_scene, _level, true)


func _stream_of(id: String) -> AudioStream:
	if id == NONE or id == "":
		return null
	var key := uid() + "|" + id
	if _cache.has(key):
		return _cache[key]
	var st: AudioStream = null
	if id == PROC:
		st = Sfx.get_stream("music")
	elif id.begins_with("own:"):
		var p := "%s/%s/%s" % [DIR, uid(), id.substr(4)]
		if FileAccess.file_exists(p):
			st = Rules.stream_from_path(p)
	else:
		for b in BUILTIN:
			if b[0] == id and String(b[2]) != "":
				st = load(String(b[2]))
	if st != null:
		_loop(st)
	_cache[key] = st
	return st


func _loop(st: AudioStream) -> void:
	if st is AudioStreamOggVorbis:
		(st as AudioStreamOggVorbis).loop = true
	elif st is AudioStreamMP3:
		(st as AudioStreamMP3).loop = true
	elif st is AudioStreamWAV:
		var w := st as AudioStreamWAV
		if w.loop_mode == AudioStreamWAV.LOOP_DISABLED:
			var bps := (2 if w.format == AudioStreamWAV.FORMAT_16_BITS else 1) * (2 if w.stereo else 1)
			w.loop_mode = AudioStreamWAV.LOOP_FORWARD
			w.loop_begin = 0
			w.loop_end = w.data.size() / bps


func _on_player_changed() -> void:
	_cur_id = ""
	update(_scene, _level, true)
	changed.emit()


## هر فریم از main صدا زده می‌شود: صحنه (menu | game) و شدت (۰..۱)
## هنگام پیش‌نمایش آیتم در فروشگاه، موسیقی منو موقتاً ساکت می‌شود
var hold := false
var last_import := ""


func update(scene_name: String, level: float, force: bool = false) -> void:
	_scene = scene_name
	_level = level
	if _player != null:
		_player.stream_paused = hold
	if hold:
		return
	var id := _game_id() if scene_name == "game" else choice("menu")
	var vol: float = float(Game.vol.get("master", 1.0)) * float(Game.vol.get("music", 1.0)) * level
	if not Game.sound_on or id == NONE or vol <= 0.003:
		if _player.playing:
			_player.stop()
		_cur_id = ""
		return
	if id != _cur_id or force:
		var st := _stream_of(id)
		if st == null:
			_player.stop()
			_cur_id = ""
			return
		_cur_id = id
		_player.stream = st
		_player.play()
	elif not _player.playing:
		_player.play()
	_player.volume_db = linear_to_db(vol) - 4.0


## پیش‌شنیدن یک آهنگ (کوتاه) هنگام انتخاب
func preview(id: String) -> void:
	var st := _stream_of(id)
	if st == null:
		return
	_cur_id = "preview"
	_player.stream = st
	_player.volume_db = linear_to_db(maxf(float(Game.vol.get("master", 1.0)) * float(Game.vol.get("music", 1.0)), 0.2)) - 4.0
	_player.play()


func play_start() -> void:
	var id := choice("start")
	if id == NONE:
		return
	Sfx.play(id if id != "" else "go")
