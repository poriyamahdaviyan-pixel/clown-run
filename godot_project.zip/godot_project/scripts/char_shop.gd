extends Node
## فروشگاهِ هر کاراکتر: روی کاراکتر بزن ← انیمیشن‌ها و صدای همان کاراکتر.
##  • بازیکن: رایگان‌ها (پیش‌فرض) + آیتم‌های فروشی را می‌بیند و می‌خرد.
##  • مالک (حساب مدیر): برای هر کلیپِ مدل «پیش‌فرض رایگان / فروشی + قیمت / پنهان» تعیین می‌کند
##    و صدا (از فایل‌های گوشی) اضافه می‌کند. قیمت‌ها را همان‌جا عوض می‌کند.
const GlbModel := preload("res://scripts/glb_model.gd")

var ui
var scr                 # online_screens.gd
var _over: Control
var _body: VBoxContainer
var _entry: Dictionary = {}
var _tab := "anim"
var _mgr := false
var _mgr_items: Array = []
var _busy_note: Label


const SoundPanel := preload("res://scripts/sound_panel.gd")
var _new_event := "jump"
var _clip_events := {}          # کلیپ → رویدادی که مالک برایش انتخاب کرده (قبل از «ثبت»)


func setup(owner_ui, screens) -> void:
	ui = owner_ui
	scr = screens
	Online.items_changed.connect(func(): if _over != null and is_instance_valid(_over): _render())


var sel_key := ""           # کاراکتر انتخاب‌شده در فروشگاه
var sel_tab := "anim"       # anim | voice | music
const TABS := [["anim", "انیمیشن"], ["voice", "صدا"], ["music", "آهنگ"]]


func _entry_of(key: String) -> Dictionary:
	for e: Dictionary in Skins.entries:
		if Skins.char_key(e) == key:
			return e
	return {}


## بخش «کاراکترها» در فروشگاه: ۱) یک کاراکتر را انتخاب کن ۲) بخش ۳) آیتم‌های همان کاراکتر
func fill_grid(grid: GridContainer) -> void:
	grid.columns = 1
	if _entry_of(sel_key).is_empty():
		sel_key = Skins.char_key(Skins.current_entry())
	var e := _entry_of(sel_key)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 10)
	grid.add_child(col)
	col.add_child(_note("۱) کاراکتری را که می‌خواهی برایش بخری انتخاب کن:", 24, Color("ffb02e")))
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 220)
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(sc)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	sc.add_child(row)
	for ce: Dictionary in Skins.entries:
		var k := Skins.char_key(ce)
		var on := k == sel_key
		var tile := PanelContainer.new()
		tile.add_theme_stylebox_override("panel", scr._frame("legendary" if on else "common"))
		tile.custom_minimum_size = Vector2(150, 0)
		var tv := VBoxContainer.new()
		tv.add_theme_constant_override("separation", 2)
		tile.add_child(tv)
		var tr := TextureRect.new()
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.custom_minimum_size = Vector2(0, 110)
		tr.texture = Skins.thumbnail(ce)
		tv.add_child(tr)
		var nm: Label = ui._label(String(ce.name), 22, Color.WHITE)
		nm.set_meta("ct_skip", true)
		nm.clip_text = true
		nm.custom_minimum_size = Vector2(10, 0)
		nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		tv.add_child(nm)
		var cur := String(ce.id) == Skins.current_id
		var pick: Button = ui._button(("✓ انتخاب‌شده" if on else "انتخاب") + (" • فعلی" if cur else ""), func(): sel_key = k; scr.refresh_store(), Vector2(0, 52), 18, "Gold" if on else "Dark")
		pick.clip_text = true
		tv.add_child(pick)
		row.add_child(tile)
	if e.is_empty():
		col.add_child(_note("کاراکتری پیدا نشد."))
		return
	col.add_child(_note("۲) بخشِ «%s» را انتخاب کن:" % String(e.name), 24, Color("ffb02e")))
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	col.add_child(tabs)
	for t in TABS:
		var tid: String = t[0]
		var on2: bool = sel_tab == tid
		var n := Online.items_of_char(sel_key, "anim_clip" if tid == "anim" else tid).size()
		var tb: Button = ui._button("%s%s (%d)" % ["✓ " if on2 else "", t[1], n], func(): sel_tab = tid; scr.refresh_store(), Vector2(0, 66), 24, "Gold" if on2 else "Teal")
		tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tb.clip_text = true
		tabs.add_child(tb)
	var kind := "anim_clip" if sel_tab == "anim" else sel_tab
	if sel_tab == "anim":
		var defs := Content.char_defaults(sel_key)
		col.add_child(_note("رایگان برای این کاراکتر: " + ("، ".join(defs) if not defs.is_empty() else "هنوز تعیین نشده"), 20))
	elif sel_tab == "voice":
		col.add_child(_note("صدای اصلی کاراکتر همیشه هست؛ این‌ها صداهای اضافه‌ی همین کاراکتر است.", 20))
	else:
		col.add_child(_note("آهنگ پس‌زمینه‌ی مخصوص همین کاراکتر؛ بعد از خرید هنگام بازی با او پخش می‌شود.", 20))
	var list := Online.items_of_char(sel_key, kind)
	if list.is_empty():
		col.add_child(_note("هنوز آیتمی در این بخش برای این کاراکتر گذاشته نشده."))
	else:
		col.add_child(_note("۳) روی هر آیتم بزن تا روی همین کاراکتر پیش‌نمایش (قفل) ببینی و بخری:", 22, Color("ffb02e")))
		var g := GridContainer.new()
		g.columns = 2
		g.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		g.add_theme_constant_override("h_separation", 12)
		g.add_theme_constant_override("v_separation", 12)
		for it: Dictionary in list:
			g.add_child(scr._item_card(it))
		col.add_child(g)
	if Online.is_admin:
		col.add_child(ui._button("مدیریت این کاراکتر (قیمت، انیمیشن، صدا، آهنگ)", func(): open(e), Vector2(0, 70), 24, "Dark"))


func open(e: Dictionary) -> void:
	_entry = e
	_tab = "anim"
	_mgr = Edition.is_owner() and Online.is_admin
	if _over != null and is_instance_valid(_over):
		_over.queue_free()
	_over = Control.new()
	ui._add_full(scr.store, _over)
	var bg := ColorRect.new()
	bg.color = Color("1d0c36")
	ui._add_full(_over, bg)
	var m := MarginContainer.new()
	ui._add_full(_over, m)
	for k in ["left", "right", "bottom"]:
		m.add_theme_constant_override("margin_" + k, 22)
	m.add_theme_constant_override("margin_top", 56)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	m.add_child(col)
	var title: Label = ui._label(String(e.name), 44, Color.WHITE)
	title.set_meta("ct_skip", true)
	col.add_child(title)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	col.add_child(tabs)
	tabs.add_child(ui._button("انیمیشن‌ها", func(): _tab = "anim"; _render(), Vector2(200, 68), 28, "Teal"))
	tabs.add_child(ui._button("صداها", func(): _tab = "voice"; _render(), Vector2(200, 68), 28, "Teal"))
	tabs.add_child(ui._button("آهنگ‌ها", func(): _tab = "music"; _render(), Vector2(200, 68), 28, "Teal"))
	if Edition.is_owner():
		tabs.add_child(ui._button("مدیریت", func(): _toggle_mgr(), Vector2(200, 68), 28, "Gold"))
	_busy_note = ui._label("", 24, Color("ffd27a"))
	_busy_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_busy_note.custom_minimum_size = Vector2(600, 0)
	col.add_child(_busy_note)
	_body = ui.make_scroll_view(col)
	col.add_child(ui._button("بازگشت به فروشگاه", func(): _over.queue_free(), Vector2(540, 76), 30, "Dark"))
	_render()


func _note(t: String, size: int = 22, color: Color = Color("c9d6e6")) -> Label:
	var l: Label = ui._label(t, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(580, 0)
	return l


func _say(t: String) -> void:
	if _busy_note != null and is_instance_valid(_busy_note):
		_busy_note.text = t


func _toggle_mgr() -> void:
	_mgr = not _mgr
	if _mgr:
		if not Online.is_admin:
			_mgr = false
			_say("برای مدیریت باید با حساب مدیر وارد شوی (حساب من).")
			return
		_say("در حال دریافت…")
		_mgr_items = await Online.admin_load_char_items(Skins.char_key(_entry))
		_say("")
	_render()


func _render() -> void:
	if _body == null or not is_instance_valid(_body):
		return
	for c in _body.get_children():
		c.queue_free()
	var key := Skins.char_key(_entry)
	if _mgr:
		_render_manager(key)
	else:
		_render_shop(key)
	if _over != null and is_instance_valid(_over):
		Content.apply_tree.call_deferred(_over)


# ------------------------- نمای بازیکن -------------------------
func _render_shop(key: String) -> void:
	if _tab == "anim":
		_body.add_child(ui._label("رایگان (پیش‌فرض این کاراکتر)", 28, Color("ffb02e")))
		var defs := Content.char_defaults(key)
		_body.add_child(_note("، ".join(defs) if not defs.is_empty() else "هنوز انیمیشن رایگانی تعیین نشده."))
		_body.add_child(ui._label("انیمیشن‌های فروشی", 28, Color("ffb02e")))
		_grid_of(Online.items_of_char(key, "anim_clip"), "هنوز انیمیشنی برای فروش گذاشته نشده.")
	elif _tab == "music":
		_body.add_child(_note("آهنگ پس‌زمینه‌ی مخصوص همین کاراکتر."))
		_grid_of(Online.items_of_char(key, "music"), "هنوز آهنگی برای فروش گذاشته نشده.")
	else:
		_body.add_child(_note("صدای اصلی کاراکتر همیشه هست؛ این‌ها صداهای اضافه‌ی همین کاراکتر است."))
		_grid_of(Online.items_of_char(key, "voice"), "هنوز صدایی برای فروش گذاشته نشده.")
		_installed_sounds(key)


## صداهای خریده‌شده‌ی همین کاراکتر: پخش، انتخاب رویداد (پرش، سکه…) و بلندی
func _installed_sounds(key: String) -> void:
	if not Content.perm_b("snd_store_tune"):
		return
	var mine: Array = Rules.library_of("voice", false, key)
	if mine.is_empty():
		return
	var eid := String(_entry.get("id", ""))
	_body.add_child(ui._label("صداهای خریده‌شده‌ی این کاراکتر", 28, Color("ffb02e")))
	var evs: Array = Rules.SLOT_EVENTS.filter(func(x): return Content.perm_event_ok(String(x)))
	var names: Array = ["بدون رویداد"]
	for ev in evs:
		names.append("جایگزین صدای: " + Rules.event_name(String(ev)))
	for e in mine:
		var id := String(e.id)
		var box := VBoxContainer.new()
		box.add_theme_constant_override("separation", 6)
		var nm: Label = ui._label(String(e.name), 26, Color.WHITE)
		nm.set_meta("ct_skip", true)
		box.add_child(nm)
		var cur := Rules.slot_event_of(eid, id)
		var o := OptionButton.new()
		o.add_theme_font_size_override("font_size", 22)
		o.custom_minimum_size = Vector2(0, 58)
		for i in names.size():
			o.add_item(String(names[i]), i)
		var idx := evs.find(cur) + 1 if cur != "" else 0
		if cur != "" and idx == 0:
			o.add_item("رویداد فعلی: " + Rules.event_name(cur), names.size())
			idx = names.size()
		o.select(idx)
		o.item_selected.connect(func(k: int):
			var old := Rules.slot_event_of(eid, id)
			if old != "":
				Rules.set_slot(eid, old, "sound", "")
			if k > 0 and k <= evs.size():
				Rules.set_slot(eid, String(evs[k - 1]), "sound", id)
				Sfx.play_any(String(e.get("arg", ""))))
		box.add_child(o)
		SoundPanel.sound_row(ui, box, "بلندی", String(e.get("arg", "")))
		_body.add_child(box)


func _grid_of(list: Array, empty_text: String) -> void:
	if list.is_empty():
		_body.add_child(_note(empty_text))
		return
	var g := GridContainer.new()
	g.columns = 2
	g.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	g.add_theme_constant_override("h_separation", 12)
	g.add_theme_constant_override("v_separation", 12)
	for it: Dictionary in list:
		g.add_child(scr._item_card(it))
	_body.add_child(g)


# ------------------------- نمای مالک -------------------------
var clips_override := Callable()      # استودیو: از مدلِ روی صحنه می‌خواند تا مدل دومی ساخته نشود


func _clips_of(e: Dictionary) -> Array:
	if clips_override.is_valid():
		return clips_override.call(e)
	return load_clips(e)


func load_clips(e: Dictionary) -> Array:
	var out: Array = []
	if not Skins.is_glb(e):
		return out
	var m := GlbModel.new()
	add_child(m)
	if m.load_from_file(String(e.glb), 0):
		for c in m.clip_list():
			out.append(String(c))
	remove_child(m)
	m.free()          # فوری آزاد می‌شود؛ صبر برای فریم بعد در رندر بدون‌صفحه کرش می‌داد
	return out


func _find(kind: String, field: String, value: String) -> Dictionary:
	for it: Dictionary in _mgr_items:
		var p = it.get("payload", {})
		if String(it.kind) == kind and p is Dictionary and String(p.get(field, "")) == value:
			return it
	return {}


func _render_manager(key: String) -> void:
	if _tab == "anim":
		_body.add_child(_note("برای هر انیمیشنِ مدل: «پیش‌فرض» = رایگان برای همه‌ی بازیکن‌های این کاراکتر. «فروشی» = در بخش «کاراکتر من» با قیمت. «پنهان» = عرضه نمی‌شود. منوی «کاربرد» می‌گوید این انیمیشن برای چه کاری است (پرش، سر خوردن…) و بازیکن با همان دسته می‌بیندش. بعد از انتخاب «ثبت» را بزن."))
		var clips := _clips_of(_entry)
		if clips.is_empty():
			_body.add_child(_note("این کاراکتر مدل GLB با انیمیشن ندارد."))
		for clip: String in clips:
			_manager_clip_row(key, clip)
		_render_borrow(key)
	elif _tab == "music":
		_body.add_child(_note("آهنگ مخصوص این کاراکتر: فایل (mp3، ogg، wav) را از گوشی انتخاب کن. قیمت ۰ = رایگان."))
		_body.add_child(ui._button("افزودن آهنگ (انتخاب فایل)", func(): _add_file(key, "music"), Vector2(0, 76), 28, "Gold"))
		for it: Dictionary in Online.items_of_char(key, "music", _mgr_items):
			_manager_voice_row(key, it)
	else:
		_body.add_child(_note("صدای تازه برای این کاراکتر: فایل را از گوشی انتخاب کن. قیمت ۰ = رایگان."))
		_body.add_child(_note("این صدا جایگزین کدام رویداد این کاراکتر شود؟ (بازیکن بعد از خرید خودکار روی همان رویداد نصب می‌شود؛ تغییرش با خودش است)"))
		_body.add_child(_event_option(_new_event, func(ev: String): _new_event = ev))
		_body.add_child(ui._button("افزودن صدا (انتخاب فایل)", func(): _add_voice(key), Vector2(0, 76), 28, "Gold"))
		var vs := Online.items_of_char(key, "voice", _mgr_items)
		for it: Dictionary in vs:
			_manager_voice_row(key, it)


## منوی «کاربرد»: این صدا/انیمیشن برای چه کاری است؟ (پرش، سر خوردن، …). اولین گزینه همیشه انتخاب‌شده است؛ «سایر» = فقط در کتابخانه.
func _event_option(cur: String, cb: Callable) -> OptionButton:
	var o := OptionButton.new()
	o.add_theme_font_size_override("font_size", 22)
	o.custom_minimum_size = Vector2(0, 58)
	var ids: Array = []
	for ev in Rules.SLOT_EVENTS:
		ids.append(String(ev))
		o.add_item("کاربرد: " + Rules.event_name(String(ev)), ids.size() - 1)
	ids.append("")
	o.add_item("کاربرد: سایر (بازیکن بعداً خودش انتخاب کند)", ids.size() - 1)
	o.select(maxi(ids.find(cur), 0))
	o.item_selected.connect(func(k: int): cb.call(String(ids[k])))
	return o



func _spin(v: int) -> SpinBox:
	var s := SpinBox.new()
	s.min_value = 0
	s.max_value = 100000
	s.step = 5
	s.value = v
	s.custom_minimum_size = Vector2(170, 64)
	s.get_line_edit().add_theme_font_size_override("font_size", 26)
	return s


func _manager_clip_row(key: String, clip: String) -> void:
	var it := _find("anim_clip", "clip", clip)
	var mode := 2
	var price := 50
	if not it.is_empty() and String(it.status) == "approved":
		mode = 1
		price = int(it.price)
	elif clip in Content.char_defaults(key):
		mode = 0
	elif not it.is_empty():
		price = int(it.price)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 4)
	var nm: Label = ui._label(clip, 28, Color.WHITE)
	nm.set_meta("ct_skip", true)
	box.add_child(nm)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var o := OptionButton.new()
	o.add_theme_font_size_override("font_size", 24)
	o.custom_minimum_size = Vector2(0, 64)
	o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for t in ["پیش‌فرض (رایگان)", "فروشی", "پنهان"]:
		o.add_item(t)
	o.select(mode)
	row.add_child(o)
	var sp := _spin(price)
	row.add_child(sp)
	row.add_child(ui._button("ثبت", func(): _apply_anim(key, clip, o.selected, int(sp.value)), Vector2(100, 64), 24, "Gold"))
	box.add_child(row)
	var pl0: Dictionary = it.get("payload", {}) if it.get("payload") is Dictionary else {}
	var cur_ev := String(_clip_events.get(clip, String(pl0.get("event", Content.cat_of(key, clip)))))
	box.add_child(_event_option(cur_ev, func(ev: String): _clip_events[clip] = ev))
	_body.add_child(box)


func _apply_anim(key: String, clip: String, mode: int, price: int) -> void:
	_say("در حال ثبت…")
	var it := _find("anim_clip", "clip", clip)
	var err := ""
	var ev := String(_clip_events.get(clip, ""))
	if ev == "" and not _clip_events.has(clip):
		var pl1: Dictionary = it.get("payload", {}) if it.get("payload") is Dictionary else {}
		ev = String(pl1.get("event", Content.cat_of(key, clip)))
	Content.set_cat(key, clip, ev)
	match mode:
		0:
			Content.set_char_default(key, clip, true)
			if not it.is_empty() and String(it.status) == "approved":
				err = String((await Online.admin_patch_item(String(it.id), {"status": "hidden"})).error)
		1:
			Content.set_char_default(key, clip, false)
			if it.is_empty():
				var r := await Online.admin_save_item({"kind": "anim_clip", "name": clip, "description": "انیمیشن «%s» برای %s" % [clip, String(_entry.name)], "price": price, "status": "approved",
					"payload": {"char": key, "clip": clip, "char_name": String(_entry.name), "event": ev}})
				err = String(r.error)
			else:
				var np: Dictionary = it.get("payload", {}).duplicate() if it.get("payload") is Dictionary else {}
				np["event"] = ev
				err = String((await Online.admin_patch_item(String(it.id), {"price": price, "status": "approved", "payload": np})).error)
		2:
			Content.set_char_default(key, clip, false)
			if not it.is_empty() and String(it.status) == "approved":
				err = String((await Online.admin_patch_item(String(it.id), {"status": "hidden"})).error)
	if err == "":
		var pr: Dictionary = await Online.push_content(Content.export_json())
		if not pr.ok:
			err = "پیش‌فرض‌ها منتشر نشد: " + String(pr.error)
	_mgr_items = await Online.admin_load_char_items(key)
	await Online.load_items()
	_say("ثبت شد ✓" if err == "" else "خطا: " + err)
	_render()


func _manager_voice_row(key: String, it: Dictionary) -> void:
	var box := VBoxContainer.new()
	var nm: Label = ui._label("%s%s" % [String(it.name), "" if String(it.status) == "approved" else "  (پنهان)"], 26, Color.WHITE)
	nm.set_meta("ct_skip", true)
	box.add_child(nm)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var sp := _spin(int(it.price))
	row.add_child(sp)
	var id := String(it.id)
	var shown := String(it.status) == "approved"
	row.add_child(ui._button("ثبت قیمت", func(): _patch_voice(key, id, {"price": int(sp.value)}), Vector2(140, 64), 22, "Gold"))
	row.add_child(ui._button("پنهان" if shown else "نمایش", func(): _patch_voice(key, id, {"status": "hidden" if shown else "approved"}), Vector2(120, 64), 22, "Dark"))
	box.add_child(row)
	if String(it.kind) == "voice":
		var pl: Dictionary = it.get("payload", {}) if it.get("payload") is Dictionary else {}
		box.add_child(_event_option(String(pl.get("event", "")), func(ev: String):
			var np := pl.duplicate()
			np["event"] = ev
			_patch_voice(key, id, {"payload": np})))
	_body.add_child(box)


func _patch_voice(key: String, id: String, patch: Dictionary) -> void:
	_say("در حال ثبت…")
	var r: Dictionary = await Online.admin_patch_item(id, patch)
	_mgr_items = await Online.admin_load_char_items(key)
	await Online.load_items()
	_say("ثبت شد ✓" if r.ok else "خطا: " + String(r.error))
	_render()


func _add_voice(key: String) -> void:
	ui.pick_file("voice", func(vn: String):
		_upload_voice(key, vn))


func _upload_voice(key: String, vn: String) -> void:
	var fname := vn.substr(5) if vn.begins_with("file:") else vn
	var local := "%s/%s" % [Rules.VOICE_DIR, fname]
	var bytes := FileAccess.get_file_as_bytes(local)
	if bytes.is_empty():
		_say("فایل خوانده نشد")
		return
	_say("در حال آپلود…")
	var ext := fname.get_extension().to_lower()
	var id := _uuid()
	var path := "voice/%s.%s" % [id, ext]
	var ct := "audio/" + ("mpeg" if ext == "mp3" else ext)
	var up: Dictionary = await Online.admin_upload(path, bytes, ct)
	var pvpath := "pv/%s.%s" % [id, ext]
	if up.ok:
		up = await Online.admin_upload(pvpath, bytes, ct, "previews")
	if not up.ok:
		_say("خطا: " + String(up.error))
		return
	var r: Dictionary = await Online.admin_save_item({"id": id, "kind": "voice", "name": fname.get_basename(), "description": "صدا برای " + String(_entry.name), "price": 0, "status": "approved",
		"file_path": path, "payload": {"char": key, "char_name": String(_entry.name), "pv": pvpath, "event": _new_event}})
	_mgr_items = await Online.admin_load_char_items(key)
	await Online.load_items()
	_say("اضافه شد ✓ (قیمت ۰؛ قیمت را بگذار و ثبت کن)" if r.ok else "خطا: " + String(r.error))
	_render()


# ------------------------- انیمیشن از فایل کاراکترِ دیگر -------------------------
var _src_key := ""
var _src_clips: Array = []


func _render_borrow(key: String) -> void:
	_body.add_child(ui._label("انیمیشن از فایل کاراکتر دیگر", 30, Color("ffb02e")))
	_body.add_child(_note("یک کاراکتر دیگر را انتخاب کن؛ هر انیمیشنِ داخل فایلش را می‌شود برای «%s» فروخت (مثلاً پرشِ کاراکتر الف برای کاراکتر ب). روی اسکلت‌های هم‌نام (Mixamo، VRM) عالی کار می‌کند؛ قبل از ثبت حتماً «پیش‌نمایش» بزن." % String(_entry.name)))
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 8)
	fl.add_theme_constant_override("v_separation", 8)
	_body.add_child(fl)
	for e: Dictionary in Skins.entries:
		var k := Skins.char_key(e)
		if k == key or not Skins.is_glb(e):
			continue
		var on := k == _src_key
		fl.add_child(ui._button(("✓ " if on else "") + String(e.name), func(): _pick_src(e), Vector2(0, 62), 22, "Gold" if on else "Dark"))
	if _src_key == "":
		return
	var src := _entry_of(_src_key)
	if _src_clips.is_empty():
		_body.add_child(_note("این کاراکتر انیمیشنی در فایلش ندارد."))
	for clip: String in _src_clips:
		var box := VBoxContainer.new()
		box.add_theme_constant_override("separation", 4)
		var nm: Label = ui._label(clip, 26, Color.WHITE)
		nm.set_meta("ct_skip", true)
		box.add_child(nm)
		var row := HFlowContainer.new()
		row.add_theme_constant_override("h_separation", 6)
		row.add_theme_constant_override("v_separation", 6)
		var sp := _spin(50)
		row.add_child(sp)
		row.add_child(ui._button("پیش‌نمایش روی این کاراکتر", func(): _try_borrowed(src, clip), Vector2(0, 60), 20, "Teal"))
		row.add_child(ui._button("ثبت برای فروش", func(): _sell_borrowed(src, clip, int(sp.value)), Vector2(0, 60), 20, "Gold"))
		box.add_child(row)
		var bk := "b|" + clip
		box.add_child(_event_option(String(_clip_events.get(bk, Content.cat_of(_src_key, clip) if Content.cat_of(_src_key, clip) != "" else "jump")), func(ev: String): _clip_events[bk] = ev))
		_body.add_child(box)


func _pick_src(e: Dictionary) -> void:
	_src_key = Skins.char_key(e)
	_src_clips = AnimPack.clips_of_model(String(e.glb))
	_render()


func _try_borrowed(src: Dictionary, clip: String) -> void:
	var d := AnimPack.extract(String(src.glb), [clip])
	if d.is_empty() or not d.has(clip):
		_say("انیمیشن خوانده نشد")
		return
	var tmp := "user://pack_try.json"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	f.store_string(JSON.stringify(d[clip]))
	f.close()
	var fake := {"id": "try", "kind": "anim_clip", "name": clip, "price": 0, "payload": {"pack": true, "char": Skins.char_key(_entry)}, "_local": tmp}
	scr._open_detail(fake)


func _sell_borrowed(src: Dictionary, clip: String, price: int) -> void:
	_say("در حال ساخت بسته‌ی انیمیشن…")
	var bev := String(_clip_events.get("b|" + clip, Content.cat_of(_src_key, clip) if Content.cat_of(_src_key, clip) != "" else "jump"))
	var d := AnimPack.extract(String(src.glb), [clip])
	if d.is_empty() or not d.has(clip):
		_say("انیمیشن خوانده نشد")
		return
	var body := JSON.stringify(d[clip]).to_utf8_buffer()
	var id := _uuid()
	var stamp := str(Time.get_ticks_msec())
	var fpath := "anim/%s_%s.json" % [id, stamp]
	var pvpath := "pv/%s_%s.json" % [id, stamp]
	var up: Dictionary = await Online.admin_upload(fpath, body, "application/json")
	if up.ok:
		up = await Online.admin_upload(pvpath, body, "application/json", "previews")
	if not up.ok:
		_say("خطا: " + String(up.error))
		return
	var r: Dictionary = await Online.admin_save_item({"id": id, "kind": "anim_clip", "name": "%s (از %s)" % [clip, String(src.name)],
		"description": "انیمیشن «%s» از کاراکتر %s برای %s" % [clip, String(src.name), String(_entry.name)], "price": price, "status": "approved",
		"file_path": fpath, "payload": {"char": Skins.char_key(_entry), "clip": clip, "pack": true, "pv": pvpath, "char_name": String(_entry.name), "src_name": String(src.name), "event": bev}})
	_mgr_items = await Online.admin_load_char_items(Skins.char_key(_entry))
	await Online.load_items()
	_say("برای فروش ثبت شد ✓" if r.ok else "خطا: " + String(r.error))
	_render()


## آپلود فایلِ دلخواه (آهنگ…) برای همین کاراکتر + نسخه‌ی عمومی پیش‌نمایش
func _add_file(key: String, kind: String) -> void:
	ui.pick_file("item_file", func(path: String):
		var bytes := FileAccess.get_file_as_bytes(path)
		if bytes.is_empty():
			_say("فایل خوانده نشد")
			return
		_say("در حال آپلود…")
		var ext := path.get_extension().to_lower()
		var id := _uuid()
		var stamp := str(Time.get_ticks_msec())
		var fpath := "%s/%s_%s.%s" % [kind, id, stamp, ext]
		var pvpath := "pv/%s_%s.%s" % [id, stamp, ext]
		var ct := "audio/mpeg" if ext == "mp3" else "audio/" + ext
		var up: Dictionary = await Online.admin_upload(fpath, bytes, ct)
		if up.ok:
			up = await Online.admin_upload(pvpath, bytes, ct, "previews")
		if not up.ok:
			_say("خطا: " + String(up.error))
			return
		var r: Dictionary = await Online.admin_save_item({"id": id, "kind": kind, "name": path.get_file().get_basename(), "description": "برای " + String(_entry.name), "price": 0, "status": "approved",
			"file_path": fpath, "payload": {"char": key, "char_name": String(_entry.name), "pv": pvpath}})
		_mgr_items = await Online.admin_load_char_items(key)
		await Online.load_items()
		_say("اضافه شد ✓ (قیمت ۰؛ قیمت را بگذار و ثبت کن)" if r.ok else "خطا: " + String(r.error))
		_render())


func _uuid() -> String:
	var b := PackedByteArray()
	for i in 16:
		b.append(randi() % 256)
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	var h := b.hex_encode()
	return "%s-%s-%s-%s-%s" % [h.substr(0, 8), h.substr(8, 4), h.substr(12, 4), h.substr(16, 4), h.substr(20, 12)]
