class_name BoostIcon
extends Control
## آیتم‌های بازی (قدرت‌ها و ابزارها) به شکل نمادهای واقع‌نما؛ همه با کد کشیده می‌شوند (بدون فایل تصویر).
## kind: magnet | shield | x2 | jet | spring | slow | rocket | ghost | hourglass | heart | coin | bolt
## با plate=true پشتِ نماد یک «مدال» گرد با لبه‌ی فلزی و درخشش کشیده می‌شود.

var kind := "shield"
var tint := Color("38d6ff")
var plate := true
var pulse := false          # برای نمایش فعال بودن: درخشش ضربان‌دار
var dim := false            # خاموش (نداری / آماده نیست)
var _t := 0.0


static func make(k: String, c: Color, size: float = 96.0, with_plate: bool = true) -> BoostIcon:
	var b := BoostIcon.new()
	b.kind = k
	b.tint = c
	b.plate = with_plate
	b.custom_minimum_size = Vector2(size, size)
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return b


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(pulse)


func set_pulse(on: bool) -> void:
	pulse = on
	set_process(on)
	queue_redraw()


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()


func _draw() -> void:
	var u := minf(size.x, size.y) * 0.5
	var c := size * 0.5
	var a := 0.45 if dim else 1.0
	if plate:
		_plate(c, u, a)
	_symbol(c, u * (0.62 if plate else 0.92), a)


func _plate(c: Vector2, u: float, a: float) -> void:
	var glow := 0.0
	if pulse:
		glow = 0.5 + 0.5 * sin(_t * 5.0)
		draw_circle(c, u * (1.0 + 0.04 * glow), Color(tint.r, tint.g, tint.b, 0.35 + 0.25 * glow))
	draw_circle(c, u * 0.94, Color(0.05, 0.03, 0.1, 0.9 * a))                       # بدنه
	draw_circle(c, u * 0.88, tint.darkened(0.45) * Color(1, 1, 1, a))
	# درخشش درونیِ گرادیانی (چند حلقه‌ی هم‌مرکز)
	for i in 7:
		var f := float(i) / 7.0
		draw_circle(c + Vector2(0, -u * 0.12 * (1.0 - f)), u * (0.84 - 0.1 * f), Color(tint.r, tint.g, tint.b, (0.05 + 0.05 * (1.0 - f)) * a).lightened(0.1 * f))
	draw_arc(c, u * 0.9, 0, TAU, 48, Color(1, 0.92, 0.7, 0.9 * a), maxf(2.0, u * 0.06))   # لبه‌ی فلزی
	draw_arc(c, u * 0.8, PI * 1.1, PI * 1.9, 24, Color(1, 1, 1, 0.45 * a), maxf(1.5, u * 0.04))  # بازتاب نور


func _poly(pts: Array, col: Color, outline: Color = Color(0, 0, 0, 0.0), w: float = 0.0) -> void:
	var p := PackedVector2Array()
	for v in pts:
		p.append(v)
	draw_colored_polygon(p, col)
	if w > 0.0:
		p.append(p[0])
		draw_polyline(p, outline, w, true)


func _symbol(c: Vector2, r: float, a: float) -> void:
	var wl := Color(1, 1, 1, a)
	var dk := Color(0.1, 0.06, 0.15, a)
	match kind:
		"magnet":
			var red := Color("e8342f") * Color(1, 1, 1, a)
			var th := r * 0.42
			draw_arc(c + Vector2(0, r * 0.05), r * 0.62, PI, TAU, 28, red, th, true)
			draw_rect(Rect2(c + Vector2(-r * 0.62 - th * 0.5, r * 0.05), Vector2(th, r * 0.62)), red)
			draw_rect(Rect2(c + Vector2(r * 0.62 - th * 0.5, r * 0.05), Vector2(th, r * 0.62)), red)
			var sil := Color("e8edf5") * Color(1, 1, 1, a)
			draw_rect(Rect2(c + Vector2(-r * 0.62 - th * 0.5, r * 0.45), Vector2(th, r * 0.28)), sil)
			draw_rect(Rect2(c + Vector2(r * 0.62 - th * 0.5, r * 0.45), Vector2(th, r * 0.28)), sil)
			draw_arc(c + Vector2(0, r * 0.05), r * 0.7, PI * 1.05, PI * 1.45, 12, Color(1, 1, 1, 0.55 * a), r * 0.07)
			for i in 3:
				var o := 0.5 + 0.5 * sin(_t * 6.0 + float(i))
				draw_arc(c + Vector2(0, -r * 0.8), r * (0.2 + 0.18 * float(i)), PI * 1.2, PI * 1.8, 10, Color(tint.r, tint.g, tint.b, (0.3 + 0.4 * o) * a), 2.0)
		"shield":
			var pts := [c + Vector2(0, -r * 0.95), c + Vector2(r * 0.8, -r * 0.6), c + Vector2(r * 0.72, r * 0.25), c + Vector2(0, r * 0.98), c + Vector2(-r * 0.72, r * 0.25), c + Vector2(-r * 0.8, -r * 0.6)]
			_poly(pts, Color("2a8fe8") * Color(1, 1, 1, a), Color("d8f0ff") * Color(1, 1, 1, a), r * 0.1)
			_poly([c + Vector2(0, -r * 0.8), c + Vector2(r * 0.62, -r * 0.5), c + Vector2(r * 0.56, r * 0.2), c + Vector2(0, r * 0.82)], Color("49c1ff") * Color(1, 1, 1, a))
			_poly([c + Vector2(0, -r * 0.8), c + Vector2(0, r * 0.82), c + Vector2(-r * 0.56, r * 0.2), c + Vector2(-r * 0.62, -r * 0.5)], Color("1f6fc4") * Color(1, 1, 1, a))
			draw_line(c + Vector2(0, -r * 0.55), c + Vector2(0, r * 0.45), wl, r * 0.12, true)
			draw_line(c + Vector2(-r * 0.38, -r * 0.1), c + Vector2(r * 0.38, -r * 0.1), wl, r * 0.12, true)
		"x2", "coin":
			var gold := Color("ffc21a") * Color(1, 1, 1, a)
			draw_circle(c, r * 0.9, Color("a8650a") * Color(1, 1, 1, a))
			draw_circle(c, r * 0.8, gold)
			draw_arc(c, r * 0.64, 0, TAU, 32, Color("c07d12") * Color(1, 1, 1, a), r * 0.08)
			draw_arc(c, r * 0.8, PI * 1.1, PI * 1.6, 12, Color(1, 1, 1, 0.7 * a), r * 0.08)
			if kind == "x2":
				var f := ThemeDB.fallback_font
				draw_string(f, c + Vector2(-r * 0.5, r * 0.28), "×2", HORIZONTAL_ALIGNMENT_CENTER, r, int(r * 0.9), Color("7a3d00") * Color(1, 1, 1, a))
			else:
				draw_line(c + Vector2(0, -r * 0.4), c + Vector2(0, r * 0.4), Color("c07d12") * Color(1, 1, 1, a), r * 0.14, true)
		"jet":
			var body := Color("d8dee8") * Color(1, 1, 1, a)
			draw_rect(Rect2(c + Vector2(-r * 0.7, -r * 0.7), Vector2(r * 0.5, r * 1.25)), body)
			draw_rect(Rect2(c + Vector2(r * 0.2, -r * 0.7), Vector2(r * 0.5, r * 1.25)), body)
			draw_rect(Rect2(c + Vector2(-r * 0.7, -r * 0.7), Vector2(r * 0.5, r * 0.3)), Color("e8342f") * Color(1, 1, 1, a))
			draw_rect(Rect2(c + Vector2(r * 0.2, -r * 0.7), Vector2(r * 0.5, r * 0.3)), Color("e8342f") * Color(1, 1, 1, a))
			draw_rect(Rect2(c + Vector2(-r * 0.58, -r * 0.2), Vector2(r * 0.1, r * 0.6)), Color(1, 1, 1, 0.6 * a))
			for sx in [-0.45, 0.45]:
				var fl := 1.0 + 0.25 * sin(_t * 18.0 + sx * 7.0)
				_poly([c + Vector2(r * sx - r * 0.2, r * 0.55), c + Vector2(r * sx + r * 0.2, r * 0.55), c + Vector2(r * sx, r * (0.55 + 0.5 * fl))], Color("ff8a2a") * Color(1, 1, 1, a))
				_poly([c + Vector2(r * sx - r * 0.1, r * 0.55), c + Vector2(r * sx + r * 0.1, r * 0.55), c + Vector2(r * sx, r * (0.55 + 0.3 * fl))], Color("ffe27a") * Color(1, 1, 1, a))
		"rocket":
			var body2 := Color("f2f5fa") * Color(1, 1, 1, a)
			_poly([c + Vector2(0, -r), c + Vector2(r * 0.4, -r * 0.4), c + Vector2(r * 0.4, r * 0.45), c + Vector2(-r * 0.4, r * 0.45), c + Vector2(-r * 0.4, -r * 0.4)], body2, Color(0.5, 0.55, 0.65, a), 2.0)
			_poly([c + Vector2(0, -r), c + Vector2(r * 0.4, -r * 0.4), c + Vector2(-r * 0.4, -r * 0.4)], Color("e8342f") * Color(1, 1, 1, a))
			_poly([c + Vector2(-r * 0.4, r * 0.1), c + Vector2(-r * 0.8, r * 0.7), c + Vector2(-r * 0.4, r * 0.45)], Color("e8342f") * Color(1, 1, 1, a))
			_poly([c + Vector2(r * 0.4, r * 0.1), c + Vector2(r * 0.8, r * 0.7), c + Vector2(r * 0.4, r * 0.45)], Color("e8342f") * Color(1, 1, 1, a))
			draw_circle(c + Vector2(0, -r * 0.1), r * 0.2, Color("49c1ff") * Color(1, 1, 1, a))
			draw_arc(c + Vector2(0, -r * 0.1), r * 0.2, 0, TAU, 16, Color(0.4, 0.45, 0.55, a), 2.0)
			var fl2 := 1.0 + 0.3 * sin(_t * 16.0)
			_poly([c + Vector2(-r * 0.25, r * 0.45), c + Vector2(r * 0.25, r * 0.45), c + Vector2(0, r * (0.45 + 0.55 * fl2))], Color("ff8a2a") * Color(1, 1, 1, a))
			_poly([c + Vector2(-r * 0.12, r * 0.45), c + Vector2(r * 0.12, r * 0.45), c + Vector2(0, r * (0.45 + 0.3 * fl2))], Color("ffe27a") * Color(1, 1, 1, a))
		"spring":
			var sc := Color("8aff3a") * Color(1, 1, 1, a)
			for i in 4:
				var y := -r * 0.1 + r * 0.22 * float(i)
				draw_line(c + Vector2(-r * 0.45, y), c + Vector2(r * 0.45, y + r * 0.1), sc, r * 0.12, true)
				draw_line(c + Vector2(r * 0.45, y + r * 0.1), c + Vector2(-r * 0.45, y + r * 0.22), sc.darkened(0.25), r * 0.12, true)
			draw_rect(Rect2(c + Vector2(-r * 0.6, r * 0.72), Vector2(r * 1.2, r * 0.18)), Color("e8edf5") * Color(1, 1, 1, a))
			_poly([c + Vector2(0, -r * 0.95), c + Vector2(r * 0.45, -r * 0.45), c + Vector2(r * 0.15, -r * 0.45), c + Vector2(r * 0.15, -r * 0.2), c + Vector2(-r * 0.15, -r * 0.2), c + Vector2(-r * 0.15, -r * 0.45), c + Vector2(-r * 0.45, -r * 0.45)], wl)
		"slow", "hourglass":
			var gl := Color(0.85, 0.95, 1.0, 0.9 * a)
			var sand := Color("ffcf4a") * Color(1, 1, 1, a)
			draw_rect(Rect2(c + Vector2(-r * 0.62, -r * 0.92), Vector2(r * 1.24, r * 0.16)), Color("a8650a") * Color(1, 1, 1, a))
			draw_rect(Rect2(c + Vector2(-r * 0.62, r * 0.76), Vector2(r * 1.24, r * 0.16)), Color("a8650a") * Color(1, 1, 1, a))
			_poly([c + Vector2(-r * 0.5, -r * 0.76), c + Vector2(r * 0.5, -r * 0.76), c + Vector2(r * 0.06, 0), c + Vector2(r * 0.5, r * 0.76), c + Vector2(-r * 0.5, r * 0.76), c + Vector2(-r * 0.06, 0)], Color(0.55, 0.8, 1.0, 0.35 * a), gl, 2.5)
			var fall := fmod(_t * 0.5, 1.0) if pulse else 0.3
			_poly([c + Vector2(-r * 0.4, -r * 0.7 + r * 0.5 * fall), c + Vector2(r * 0.4, -r * 0.7 + r * 0.5 * fall), c + Vector2(0, -r * 0.05)], sand)
			_poly([c + Vector2(-r * 0.42, r * 0.7), c + Vector2(r * 0.42, r * 0.7), c + Vector2(0, r * (0.7 - 0.45 * (0.5 + fall * 0.5)))], sand)
			draw_line(c + Vector2(0, -r * 0.05), c + Vector2(0, r * 0.45), sand, 2.0)
		"ghost":
			var g := Color("f4f7ff") * Color(1, 1, 1, 0.95 * a)
			draw_circle(c + Vector2(0, -r * 0.2), r * 0.62, g)
			draw_rect(Rect2(c + Vector2(-r * 0.62, -r * 0.2), Vector2(r * 1.24, r * 0.85)), g)
			for i in 4:
				draw_circle(c + Vector2(-r * 0.465 + r * 0.31 * float(i), r * 0.65), r * 0.155, g)
			draw_circle(c + Vector2(-r * 0.22, -r * 0.25), r * 0.12, dk)
			draw_circle(c + Vector2(r * 0.22, -r * 0.25), r * 0.12, dk)
			draw_circle(c + Vector2(0, r * 0.05), r * 0.1, dk)
			draw_arc(c + Vector2(0, -r * 0.2), r * 0.62, PI * 1.1, PI * 1.5, 10, Color(0.7, 0.85, 1.0, 0.7 * a), r * 0.06)
		"heart":
			var hc := Color("ff3b5c") * Color(1, 1, 1, a)
			draw_circle(c + Vector2(-r * 0.32, -r * 0.25), r * 0.42, hc)
			draw_circle(c + Vector2(r * 0.32, -r * 0.25), r * 0.42, hc)
			_poly([c + Vector2(-r * 0.72, -r * 0.05), c + Vector2(r * 0.72, -r * 0.05), c + Vector2(0, r * 0.85)], hc)
			draw_arc(c + Vector2(-r * 0.32, -r * 0.25), r * 0.3, PI * 1.05, PI * 1.55, 8, Color(1, 1, 1, 0.65 * a), r * 0.08)
			draw_line(c + Vector2(0, -r * 0.18), c + Vector2(0, r * 0.3), wl, r * 0.14, true)
			draw_line(c + Vector2(-r * 0.24, r * 0.06), c + Vector2(r * 0.24, r * 0.06), wl, r * 0.14, true)
		_:
			_poly([c + Vector2(r * 0.15, -r), c + Vector2(-r * 0.55, r * 0.1), c + Vector2(-r * 0.05, r * 0.1), c + Vector2(-r * 0.2, r), c + Vector2(r * 0.55, -r * 0.2), c + Vector2(r * 0.05, -r * 0.2)], Color("ffd23a") * Color(1, 1, 1, a))
