class_name LookFx
extends CanvasLayer
## سبک تصویر کل بازی با شیدر پس‌پردازش (زیر رابط کاربری، پس فقط دنیای سه‌بعدی را تغییر می‌دهد)
## ۰ عادی (بدون هزینه) · ۱ مکعبی (لگو/ماینکرفت) · ۲ کارتونی · ۳ رترو · ۴ سینمایی

const NAMES: Array[String] = ["عادی", "مکعبی (لگو/ماین‌کرفت)", "کارتونی", "رترو", "سینمایی", "انیمه‌ای", "پیکسلی ۱۶ بیتی"]

const SHADER := """
shader_type canvas_item;
uniform sampler2D scr : hint_screen_texture, filter_nearest, repeat_disable;
uniform int style = 1;
uniform float block = 7.0;

vec3 post(vec3 c, float lv) { return floor(c * lv + 0.5) / lv; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void fragment() {
	vec2 px = SCREEN_PIXEL_SIZE;
	vec2 fc = FRAGCOORD.xy;
	vec3 col = textureLod(scr, SCREEN_UV, 0.0).rgb;
	if (style == 1) {
		vec2 cell = floor(fc / block);
		vec2 uv = (cell * block + block * 0.5) * px;
		col = textureLod(scr, uv, 0.0).rgb;
		col = post(col, 7.0);
		vec2 f = fract(fc / block);
		float edge = max(smoothstep(0.80, 1.0, max(f.x, f.y)), 0.0);
		float hi = smoothstep(0.18, 0.0, min(f.x, f.y));
		col *= 1.0 - 0.13 * edge;
		col += 0.035 * hi;
		float stud = smoothstep(0.30, 0.26, length(f - vec2(0.5)));
		col += 0.03 * stud;
		col = mix(vec3(luma(col)), col, 1.18);
	} else if (style == 2) {
		float a = luma(textureLod(scr, SCREEN_UV + vec2(px.x * 1.5, 0.0), 0.0).rgb);
		float b = luma(textureLod(scr, SCREEN_UV - vec2(px.x * 1.5, 0.0), 0.0).rgb);
		float c2 = luma(textureLod(scr, SCREEN_UV + vec2(0.0, px.y * 1.5), 0.0).rgb);
		float d = luma(textureLod(scr, SCREEN_UV - vec2(0.0, px.y * 1.5), 0.0).rgb);
		float e = length(vec2(a - b, c2 - d));
		vec3 sm = (textureLod(scr, SCREEN_UV + px * vec2(2.0, 2.0), 0.0).rgb + textureLod(scr, SCREEN_UV + px * vec2(-2.0, 2.0), 0.0).rgb + textureLod(scr, SCREEN_UV + px * vec2(2.0, -2.0), 0.0).rgb + textureLod(scr, SCREEN_UV + px * vec2(-2.0, -2.0), 0.0).rgb) * 0.25;
		col = post(mix(col, sm, 0.7), 6.0);
		col = mix(vec3(luma(col)), col, 1.2);
		col *= 1.0 - smoothstep(0.10, 0.28, e) * 0.8;
	} else if (style == 3) {
		float bl = max(3.0, floor(block * 0.55));
		vec2 uv = (floor(fc / bl) * bl + bl * 0.5) * px;
		col = textureLod(scr, uv, 0.0).rgb;
		col = post(col, 4.0);
		float line = 0.88 + 0.12 * step(0.5, fract(fc.y / (bl * 2.0)));
		col *= line;
		vec2 q = SCREEN_UV - 0.5;
		col *= 1.0 - dot(q, q) * 0.9;
	} else if (style == 5) {
		// انیمه: رنگ اشباع و پوستری نرم، خط دور تیره، درخشش گرم
		float a5 = luma(textureLod(scr, SCREEN_UV + vec2(px.x * 1.2, 0.0), 0.0).rgb);
		float b5 = luma(textureLod(scr, SCREEN_UV - vec2(px.x * 1.2, 0.0), 0.0).rgb);
		float c5 = luma(textureLod(scr, SCREEN_UV + vec2(0.0, px.y * 1.2), 0.0).rgb);
		float d5 = luma(textureLod(scr, SCREEN_UV - vec2(0.0, px.y * 1.2), 0.0).rgb);
		float e5 = length(vec2(a5 - b5, c5 - d5));
		vec3 sm5 = (textureLod(scr, SCREEN_UV + px * vec2(3.0, 3.0), 0.0).rgb + textureLod(scr, SCREEN_UV + px * vec2(-3.0, 3.0), 0.0).rgb + textureLod(scr, SCREEN_UV + px * vec2(3.0, -3.0), 0.0).rgb + textureLod(scr, SCREEN_UV + px * vec2(-3.0, -3.0), 0.0).rgb) * 0.25;
		col = post(mix(col, sm5, 0.5), 5.0);
		col = mix(vec3(luma(col)), col, 1.45);
		col += max(sm5 - 0.7, 0.0) * 0.35;
		col *= vec3(1.04, 1.0, 1.03);
		col *= 1.0 - smoothstep(0.07, 0.22, e5) * 0.85;
	} else if (style == 6) {
		// پیکسلی ۱۶ بیتی: بلوک‌های درشت، پالت کم‌رنگ، دیدرینگ ماتریسی
		float bl6 = max(4.0, floor(block * 0.8));
		vec2 uv6 = (floor(fc / bl6) * bl6 + bl6 * 0.5) * px;
		col = textureLod(scr, uv6, 0.0).rgb;
		vec2 cc = floor(fc / bl6);
		float dth = (mod(cc.x + cc.y * 2.0, 4.0) - 1.5) / 4.0 * 0.12;
		col = post(col + dth, 5.0);
		col = mix(vec3(luma(col)), col, 1.3);
	} else if (style == 4) {
		col = (col - 0.5) * 1.12 + 0.5;
		col = mix(vec3(luma(col)), col, 1.1);
		col *= vec3(1.03, 1.0, 0.96);
		vec2 q = SCREEN_UV - 0.5;
		col *= 1.0 - dot(q, q) * 1.25;
	}
	COLOR = vec4(clamp(col, 0.0, 1.0), 1.0);
}
"""

var _rect: ColorRect
var _mat: ShaderMaterial


func _ready() -> void:
	layer = 0
	_rect = ColorRect.new()
	_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = SHADER
	_mat = ShaderMaterial.new()
	_mat.shader = sh
	_rect.material = _mat
	add_child(_rect)
	Game.look_changed.connect(apply)
	apply()


func apply() -> void:
	var s := clampi(Game.look_style, 0, NAMES.size() - 1)
	_rect.visible = s > 0
	if s > 0:
		_mat.set_shader_parameter("style", s)
		var h := float(get_viewport().get_visible_rect().size.y)
		_mat.set_shader_parameter("block", clampf(h / 170.0, 4.0, 12.0))
