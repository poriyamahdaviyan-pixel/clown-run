extends RefCounted
## رابط‌های مشترک صدا (هم در «تنظیمات» و هم در «فروشگاه» استفاده می‌شود):
##   • build_player: کشوها و میکسِ بازیکن — فقط آنچه مالک اجازه داده دیده می‌شود
##   • build_perms:  ماتریس دسترسی بازیکن (فقط مالک): هر قابلیت صدا و فروشگاه، سقف‌ها و رویدادهای مجاز
##   • sound_row:    یک ردیفِ «پخش + بلندی» برای یک صدا (مثلاً صدای خریداری‌شده)

const HIDDEN_PREFIX_LEN := 3


static func _wrap(l: Label) -> Label:
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


static func slider_row(ui, parent: Control, title: String, value: float, hi: float, on_change: Callable, test: Callable = Callable()) -> HSlider:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	parent.add_child(row)
	var l: Label = ui._label(title, 24)
	l.custom_minimum_size = Vector2(210, 0)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	row.add_child(l)
	var sl := HSlider.new()
	sl.min_value = 0.0
	sl.max_value = maxf(hi, 0.05)
	sl.step = 0.05
	sl.value = clampf(value, 0.0, sl.max_value)
	sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl.custom_minimum_size = Vector2(0, 48)
	sl.value_changed.connect(func(v: float): on_change.call(v))
	row.add_child(sl)
	if test.is_valid():
		row.add_child(ui._button("▶", func(): test.call(), Vector2(64, 56), 24, "Teal"))
	return sl


## بلندی یک صدای مشخص (نام داخلی یا file:…) با دکمه‌ی پخش
static func sound_row(ui, parent: Control, title: String, sound: String, who: String = "") -> void:
	var cap := 2.0 if Edition.is_owner() else Content.vol_cap()
	slider_row(ui, parent, title, Content.mix_get("sound", sound), cap,
		func(v: float): Content.mix_set("sound", sound, v),
		func(): Sfx.play_any(sound, 0.0, who))


static func _plain_sounds() -> Array:
	var out: Array = []
	for n in Sfx.builtin_names():
		var s := String(n)
		if s.length() > 2 and s[0] == "v" and s[1].is_valid_int() and s[2] == "_":
			continue
		out.append(s)
	for extra in ["step", "step_p", "siren", "wind", "heart", "shield_break"]:
		if not extra in out:
			out.append(extra)
	return out


## بخش صدای بازیکن؛ فقط دسترسی‌هایی که مالک داده
static func build_player(ui, B: VBoxContainer) -> void:
	for c in B.get_children():
		c.queue_free()
	var any := false
	var head: Label = ui._label("تنظیمات صدا", 38, Color("ffb02e"))
	B.add_child(head)
	var cap := Content.vol_cap()
	for cat in Content.MIX_CATS:
		var k: String = cat[0]
		var perm := "snd_master" if k == "master" else "snd_mix_" + k
		if not Content.perm_b(perm):
			continue
		any = true
		slider_row(ui, B, String(cat[1]), float(Game.vol[k]), cap if k == "master" or cap < 1.0 else 1.0,
			func(v: float):
				Game.set_vol(k, v)
				Sfx.refresh_loops())
	if Content.perm_b("snd_voice_style"):
		any = true
		var vb: Button = ui._button("", func(): pass, Vector2(0, 64), 24, "Teal")
		var upd := func():
			vb.text = "نوع صدای این کاراکتر: %s (لمس = بعدی)" % Sfx.VOICES[Game.voice_of(Skins.current_id)][0]
		upd.call()
		vb.pressed.connect(func():
			Game.set_voice(Skins.current_id, Game.voice_of(Skins.current_id) + 1)
			Sfx.voice("jump")
			upd.call())
		B.add_child(vb)
	var mcap := 2.0 if Edition.is_owner() else cap
	if Content.perm_b("snd_per_char"):
		any = true
		B.add_child(ui._label("بلندی صدای هر کاراکتر", 28, Color.WHITE))
		var seen := {}
		for e: Dictionary in Skins.entries:
			var ck := Skins.char_key(e)
			if seen.has(ck):
				continue
			seen[ck] = true
			slider_row(ui, B, String(e.get("name", ck)), Content.mix_get("char", ck), mcap,
				func(v: float): Content.mix_set("char", ck, v),
				func():
					Sfx.play_any("v%d_jump" % Game.voice_of(String(e.get("id", ""))), 0.0, ck))
	if Content.perm_b("snd_per_chaser"):
		any = true
		slider_row(ui, B, "تعقیب‌کننده (همه‌ی صداهایش)", Content.mix_get("chaser", Rules.CHASER), mcap,
			func(v: float): Content.mix_set("chaser", Rules.CHASER, v),
			func(): Sfx.play("horn", 0.0, 1.0, Rules.CHASER))
	if Content.perm_b("snd_per_sound"):
		any = true
		B.add_child(ui._label("بلندی تک‌تک صداها (۰ = بی‌صدا)", 28, Color.WHITE))
		for n in _plain_sounds():
			sound_row(ui, B, String(n), String(n))
	if Edition.is_owner():
		B.add_child(ui._button("بازنشانی میکسِ صداها (محلی)", func():
			Content._local.erase("mix")
			Content._save()
			build_player(ui, B), Vector2(0, 64), 22, "Red"))
	elif not any:
		head.visible = false


# ------------------------- ماتریس دسترسی (مالک) -------------------------
static func _ability_title(id: String) -> String:
	for a in Content.ABILITIES:
		if a[0] == id:
			return String(a[1])
	return id


static func build_perms(ui, B: VBoxContainer, say: Callable) -> void:
	for c in B.get_children():
		c.queue_free()
	B.add_child(ui._label("دسترسی بازیکن (نسخه‌ی عمومی)", 38, Color("ff7a5a")))
	var intro := _wrap(ui._label("همه‌ی این‌ها فقط برای «نسخه‌ی عمومی» است؛ تو (مالک) همیشه همه‌چیز را داری. بعد از تغییر، «ارسال به همه» را بزن. برای دیدن نتیجه «شبیه‌سازی نسخه‌ی عمومی» را روشن کن.", 21, Color("c9d6e6")))
	B.add_child(intro)
	var rebuild := func(): build_perms(ui, B, say)
	var pr := HFlowContainer.new()
	pr.add_theme_constant_override("h_separation", 8)
	pr.add_theme_constant_override("v_separation", 8)
	B.add_child(pr)
	pr.add_child(ui._button("همه بسته (پیش‌فرض)", func():
		Content._local.erase("perms")
		for id in Content.SOUND_ABILITIES:
			Content.set_ability(id, Content.ability_default(id))
		Content._save()
		rebuild.call(), Vector2(0, 60), 22, "Dark"))
	pr.add_child(ui._button("همه باز (کنترل کامل صدا)", func():
		var pm: Dictionary = Content._local.get("perms", {})
		for p in Content.PERMS:
			if String(p[3]) == "b":
				pm[p[0]] = true
		Content._local["perms"] = pm
		for id in Content.SOUND_ABILITIES:
			Content.set_ability(id, true)
		Content._save()
		rebuild.call(), Vector2(0, 60), 22, "Dark"))
	B.add_child(ui._label("بخش‌ها و فروشگاه", 28, Color("ffb02e")))
	for id in Content.SOUND_ABILITIES:
		var aid: String = id
		var on := Content.public_enabled(aid)
		B.add_child(ui._button(("✓ " if on else "✗ ") + _ability_title(aid), func():
			Content.set_ability(aid, not Content.public_enabled(aid))
			rebuild.call(), Vector2(0, 60), 21, "Gold" if on else "Dark"))
	B.add_child(ui._label("امکانات صدا", 28, Color("ffb02e")))
	for p in Content.PERMS:
		var pid: String = p[0]
		var typ := String(p[3])
		if typ == "b":
			var pon := bool(Content.perm_public(pid))
			B.add_child(ui._button(("✓ " if pon else "✗ ") + String(p[1]), func():
				Content.set_perm(pid, not bool(Content.perm_public(pid)))
				rebuild.call(), Vector2(0, 60), 21, "Gold" if pon else "Dark"))
		elif typ == "n":
			var row := HBoxContainer.new()
			row.add_theme_constant_override("separation", 8)
			B.add_child(row)
			row.add_child(_wrap(ui._label(String(p[1]), 21)))
			var sb := SpinBox.new()
			sb.min_value = float(p[4])
			sb.max_value = float(p[5])
			sb.step = 1
			sb.value = float(Content.perm_public(pid))
			sb.custom_minimum_size = Vector2(150, 56)
			sb.value_changed.connect(func(v: float): Content.set_perm(pid, int(v)))
			row.add_child(sb)
		else:
			B.add_child(_wrap(ui._label(String(p[1]), 21)))
			var le := LineEdit.new()
			le.text = String(Content.perm_public(pid))
			le.custom_minimum_size = Vector2(0, 56)
			le.add_theme_font_size_override("font_size", 22)
			le.text_changed.connect(func(t: String): Content.set_perm(pid, t))
			B.add_child(le)
	B.add_child(_wrap(ui._label("رویدادهای قابل‌استفاده: " + ", ".join(PackedStringArray(Rules.SLOT_EVENTS)) + " | " + ", ".join(PackedStringArray(Rules.CHASER_SLOT_EVENTS)), 18, Color(1, 1, 1, 0.6))))
	B.add_child(ui._button("ارسال دسترسی‌ها (و میکس) به همه", func():
		if not Online.is_admin:
			say.call("برای ارسال، با حساب مدیر وارد شو (بخش حساب من).")
			return
		var r: Dictionary = await Online.push_content(Content.export_json())
		say.call("برای همه ذخیره شد؛ بازیکنان در اجرای بعدی می‌گیرند." if r.ok else "خطا: " + String(r.error)), Vector2(0, 76), 24, "Gold"))
