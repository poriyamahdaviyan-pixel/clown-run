class_name Batcher
extends RefCounted
## ادغام مش‌های ثابت یک گره در یک MeshInstance3D (یک سطح برای هر متریال)
## تا تعداد draw call روی گوشی کم شود. فقط مش‌های مات و ثابت ادغام می‌شوند:
## شفاف‌ها، بیلبوردها، مش‌های دارای متا (انیمیشن‌دار/NPC) و گره‌های نامرئی دست‌نخورده می‌مانند.

static func merge(root: Node3D) -> int:
	var groups := {}        # Material -> SurfaceTool
	var order: Array = []
	var kill: Array[MeshInstance3D] = []
	_collect(root, Transform3D.IDENTITY, groups, order, kill)
	if kill.is_empty():
		return 0
	var am := ArrayMesh.new()
	for m in order:
		var st: SurfaceTool = groups[m]
		st.commit(am)
	var mi := MeshInstance3D.new()
	mi.name = "merged"
	mi.mesh = am
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(mi)
	for k in kill:
		var p := k.get_parent()
		if p != null:
			p.remove_child(k)
		k.queue_free()
	return kill.size()


static func _collect(n: Node, xf: Transform3D, groups: Dictionary, order: Array, kill: Array[MeshInstance3D]) -> void:
	for c in n.get_children():
		if not (c is Node3D) or not (c as Node3D).visible:
			continue
		if c.get_meta_list().size() > 0:
			continue
		var cx: Transform3D = xf * (c as Node3D).transform
		if c is MeshInstance3D:
			var mi := c as MeshInstance3D
			if _can_merge(mi):
				var mat: Material = mi.get_active_material(0)
				var st: SurfaceTool = groups.get(mat)
				if st == null:
					st = SurfaceTool.new()
					st.begin(Mesh.PRIMITIVE_TRIANGLES)
					st.set_material(mat)
					groups[mat] = st
					order.append(mat)
				st.append_from(mi.mesh, 0, cx)
				kill.append(mi)
				continue
		if c.get_child_count() > 0 and not (c is MeshInstance3D):
			_collect(c, cx, groups, order, kill)


static func _can_merge(mi: MeshInstance3D) -> bool:
	if mi.mesh == null or mi.mesh.get_surface_count() != 1:
		return false
	if mi.mesh is ArrayMesh and (mi.mesh as ArrayMesh).surface_get_primitive_type(0) != Mesh.PRIMITIVE_TRIANGLES:
		return false
	var mat := mi.get_active_material(0)
	if not (mat is StandardMaterial3D):
		return false
	var sm := mat as StandardMaterial3D
	if sm.transparency != BaseMaterial3D.TRANSPARENCY_DISABLED or sm.billboard_mode != BaseMaterial3D.BILLBOARD_DISABLED:
		return false
	if mi.get_child_count() > 0:
		return false
	return true
