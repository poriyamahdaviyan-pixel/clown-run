class_name VirtualStick
extends Control
## آنالوگ شناور: هر جای نیمه‌ی چپ صفحه را لمس کنی همان‌جا ظاهر می‌شود (کیبورد WASD/فلش هم کار می‌کند)

var value := Vector2.ZERO        # x راست، y پایین (مثل صفحه)؛ طول ≤ ۱
var _touch := -1
var _origin := Vector2.ZERO
var _pos := Vector2.ZERO
const RADIUS := 110.0
var enabled := true
var left_only := true


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)


func _input(event: InputEvent) -> void:
	if not enabled:
		return
	var w := get_viewport_rect().size.x
	if event is InputEventScreenTouch:
		if event.pressed and _touch == -1 and (not left_only or event.position.x < w * 0.6):
			_touch = event.index
			_origin = event.position
			_pos = event.position
			_update()
		elif not event.pressed and event.index == _touch:
			_release()
	elif event is InputEventScreenDrag and event.index == _touch:
		_pos = event.position
		_update()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed and _touch == -1 and (not left_only or event.position.x < w * 0.6):
			_touch = 99
			_origin = event.position
			_pos = event.position
			_update()
		elif not event.pressed and _touch == 99:
			_release()
	elif event is InputEventMouseMotion and _touch == 99:
		_pos = event.position
		_update()


func _release() -> void:
	_touch = -1
	value = Vector2.ZERO
	queue_redraw()


func _update() -> void:
	var d := _pos - _origin
	if d.length() > RADIUS:
		d = d.normalized() * RADIUS
		_origin = _pos - d     # آنالوگ دنبال انگشت می‌آید
	value = d / RADIUS
	queue_redraw()


func get_vector() -> Vector2:
	if _touch != -1:
		return value
	var k := Vector2(
		float(Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)) - float(Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT)),
		float(Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN)) - float(Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)))
	return k.limit_length(1.0)


func _draw() -> void:
	if _touch == -1:
		return
	draw_circle(_origin, RADIUS, Color(1, 1, 1, 0.10))
	draw_arc(_origin, RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.45), 4.0)
	draw_circle(_origin + value * RADIUS, 46.0, Color(1, 1, 1, 0.55))
