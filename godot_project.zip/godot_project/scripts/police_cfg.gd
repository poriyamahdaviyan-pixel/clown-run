extends Node
## مدل و تنظیمات «تعقیب‌کننده» (پلیسِ نمادین؛ در بازی همان دلقک).
## مدل را خودِ مالک می‌گذارد:
##   • ثابت برای همه (نسخه‌ی عمومی هم): فایل  assets/police.glb  داخل پروژه
##   • فقط روی دستگاهِ مالک (آزمایش): انتخاب فایل در تنظیمات ← پنل مالک
## تنظیمات بدن/حرکت (scale, off_y, speed, swing, lean, proc, map, yaw) به ترتیب از این‌ها ساخته می‌شود:
##   پیش‌فرض GlbModel ← assets/police.cfg.json ← تنظیم سرور (کلید police) ← تغییرات محلیِ مالک
## تغییرات محلی فقط در نسخه‌ی مالک اعمال می‌شود.

signal changed

const GlbModel := preload("res://scripts/glb_model.gd")
const DEFAULT_MODEL := "res://assets/police.glb"
const DEFAULT_CFG_JSON := "res://assets/police.cfg.json"
const USER_DIR := "user://police/"
const USER_MODEL := "user://police/police.glb"
const USER_CFG := "user://police.cfg"
const BOUGHT_MODEL := "user://police/bought.glb"   # ظاهر خریداری‌شده از فروشگاه (برای همه‌ی نسخه‌ها)

var remote: Dictionary = {}
var _file_defaults: Dictionary = {}
var _local: Dictionary = {}       # {yaw:int, cfg:Dictionary}


func _ready() -> void:
	if FileAccess.file_exists(DEFAULT_CFG_JSON):
		var j = JSON.parse_string(FileAccess.get_file_as_string(DEFAULT_CFG_JSON))
		if j is Dictionary:
			_file_defaults = j
	var c := ConfigFile.new()
	if c.load(USER_CFG) == OK:
		_local = {"yaw": int(c.get_value("p", "yaw", -1)), "cfg": c.get_value("p", "cfg", {}), "bought_yaw": int(c.get_value("p", "bought_yaw", 0))}
	Edition.changed.connect(func(): changed.emit())


func _save() -> void:
	var c := ConfigFile.new()
	c.set_value("p", "yaw", int(_local.get("yaw", -1)))
	c.set_value("p", "cfg", _local.get("cfg", {}))
	c.set_value("p", "bought_yaw", int(_local.get("bought_yaw", 0)))
	c.save(USER_CFG)


func _owner_local() -> bool:
	return Edition.is_owner()


func has_user_model() -> bool:
	return FileAccess.file_exists(USER_MODEL)


## مسیر مدلی که باید بارگذاری شود ("" = مدلی نیست → جایگزین ساده‌ی داخلی)
func model_path() -> String:
	if _owner_local() and has_user_model():
		return USER_MODEL
	if FileAccess.file_exists(BOUGHT_MODEL):
		return BOUGHT_MODEL
	if FileAccess.file_exists(DEFAULT_MODEL):
		return DEFAULT_MODEL
	return ""


func has_model() -> bool:
	return model_path() != ""


func yaw() -> int:
	if _owner_local() and int(_local.get("yaw", -1)) >= 0:
		return int(_local["yaw"]) % 4
	if FileAccess.file_exists(BOUGHT_MODEL):
		return int(_local.get("bought_yaw", 0)) % 4
	return int(remote.get("yaw", _file_defaults.get("yaw", 0))) % 4


func cfg() -> Dictionary:
	var out: Dictionary = GlbModel.DEFAULT_CFG.duplicate(true)
	for src in [_file_defaults, remote, (_local.get("cfg", {}) if _owner_local() else {})]:
		for k in out:
			if (src as Dictionary).has(k):
				out[k] = (src as Dictionary)[k]
	return out


## به شکل «ورودی کاراکتر» تا صفحه‌ی تنظیمات همان کدِ کاراکتر را برای پلیس هم استفاده کند
func as_entry() -> Dictionary:
	return {"id": "chaser", "glb": model_path(), "glb_yaw": yaw(), "glb_cfg": cfg(), "name": "تعقیب‌کننده"}


func apply_remote(d) -> void:
	if d is Dictionary:
		remote = d
		changed.emit()


# ------------------------- فقط مالک -------------------------
func set_cfg(key: String, value) -> void:
	var c: Dictionary = _local.get("cfg", {})
	c[key] = value
	_local["cfg"] = c
	_save()
	changed.emit()


func set_map(state: String, clip: String) -> void:
	var c: Dictionary = _local.get("cfg", {})
	var m: Dictionary = (cfg().get("map", {}) as Dictionary).duplicate()
	if clip == "":
		m.erase(state)
	else:
		m[state] = clip
	c["map"] = m
	_local["cfg"] = c
	_save()
	changed.emit()


func reset_cfg() -> void:
	_local = {"yaw": -1, "cfg": {}, "bought_yaw": int(_local.get("bought_yaw", 0))}
	_save()
	changed.emit()


func cycle_yaw() -> void:
	_local["yaw"] = (yaw() + 1) % 4
	_save()
	changed.emit()


## فایل GLB انتخاب‌شده را روی همین دستگاه ذخیره می‌کند. خروجی: "" یا پیام خطا
func choose_model(src: String) -> String:
	if not Edition.is_owner():
		return "فقط نسخه‌ی مالک"
	if src.get_extension().to_lower() != "glb":
		var tmp := "user://police_convert.glb"
		var cerr := ModelImport.to_glb(src, tmp)
		if cerr != "":
			return cerr
		src = tmp
	var t := GlbModel.new()
	add_child(t)
	var ok: bool = t.load_from_file(src, 0)
	var err: String = t.load_error
	t.queue_free()
	if not ok:
		return err
	DirAccess.make_dir_recursive_absolute(USER_DIR)
	if DirAccess.copy_absolute(src, USER_MODEL) != OK:
		return "ذخیره‌ی فایل ناموفق بود"
	_local["yaw"] = -1
	_local["cfg"] = {}
	_save()
	changed.emit()
	return ""


## ظاهر خریداری‌شده (هر نسخه‌ای). خروجی: "" یا پیام خطا
func set_bought_model(src: String, yaw_steps: int) -> String:
	var t := GlbModel.new()
	add_child(t)
	var ok: bool = t.load_from_file(src, 0)
	var err: String = t.load_error
	t.queue_free()
	if not ok:
		return err
	DirAccess.make_dir_recursive_absolute(USER_DIR)
	if DirAccess.copy_absolute(src, BOUGHT_MODEL) != OK:
		return "ذخیره‌ی فایل ناموفق بود"
	_local["bought_yaw"] = yaw_steps % 4
	_save()
	changed.emit()
	return ""


func clear_bought() -> void:
	if FileAccess.file_exists(BOUGHT_MODEL):
		DirAccess.remove_absolute(BOUGHT_MODEL)
	changed.emit()


func clear_model() -> void:
	if has_user_model():
		DirAccess.remove_absolute(USER_MODEL)
	changed.emit()


## متنی که باید در assets/police.cfg.json گذاشت تا برای نسخه‌ی عمومی هم همین تنظیمات باشد
func export_json() -> String:
	var d := cfg()
	d["yaw"] = yaw()
	return JSON.stringify(d, "\t")
