extends RefCounted
## قطعه‌های ویژه‌ی مسیر برای هر محیط (0 شهر، 1 صحرا، 2 جنگل، 3 برف، 4 بندر، 5 آتشفشان):
##  • platform : سطح بالاآمده با رمپ؛ می‌شود رویش دوید (کامیون بار، تپه‌ی شنی، پلکان معبد، ...)
##  • closure  : بسته‌شدن دو لِین (مسیر را مجبور به عوض‌کردن می‌کند) + تابلوی راه‌انحرافی
##  • pit      : چاله/شکاف که باید پرید
##  • tunnel   : عبور کم‌ارتفاع که باید سُر خورد (و سکه‌ی کف دارد)
##  • switcher : وسیله‌ای که با چراغ چشمک‌زن لِینش را عوض می‌کند
##  • roller   : جسم غلتان که با سرعت اضافه به سمت بازیکن می‌آید

const Gfx := preload("res://scripts/gfx.gd")
const P := preload("res://scripts/props.gd")
const X := preload("res://scripts/obstacles_ext.gd")

const ZONE_ACCENT: Array[String] = ["ffc400", "f2b632", "9be04a", "9edcff", "ff9a2a", "ff5a14"]


static func _box(n: Node3D, s: Vector3, p: Vector3, m: Material, r: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	return Gfx.box(n, s, p, m, r)


static func _cyl(n: Node3D, rt: float, rb: float, h: float, p: Vector3, m: Material, r: Vector3 = Vector3.ZERO, seg: int = 12) -> MeshInstance3D:
	return Gfx.cyl(n, rt, rb, h, p, m, r, seg)


static func _sph(n: Node3D, r: float, p: Vector3, m: Material, sc: Vector3 = Vector3.ONE, seg: int = 10) -> MeshInstance3D:
	var s := Gfx.sphere(n, r, p, m, seg)
	s.scale = sc
	return s


## گوه‌ی مثلثی: ارتفاع h، عرض w، طول len؛ سمت بلند به‌سوی −Z. مرکز پایه در pos.
static func wedge(n: Node3D, w: float, h: float, len: float, pos: Vector3, m: Material) -> MeshInstance3D:
	var pm := PrismMesh.new()
	pm.size = Vector3(len, h, w)
	pm.left_to_right = 1.0
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	mi.material_override = m
	mi.position = pos + Vector3(0, h * 0.5, 0)
	mi.rotation_degrees = Vector3(0, 90, 0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	n.add_child(mi)
	return mi


# =============================================================
#                      سکوی سوارشدنی
# =============================================================
## گره در مرکز سکو: z از +L/2 (ابتدای رمپ) تا −L/2 (انتها). T ارتفاع، r طول رمپ، rd طول رمپِ پایین (۰ = افتادن)
static func platform(n: Node3D, zone: int, L: float, T: float, r: float, rd: float) -> void:
	var zr := L * 0.5
	var plat_len := L - r - rd
	var zc_plat := zr - r - plat_len * 0.5
	var ramp_mat: Material
	var top_mat: Material
	match zone:
		0:
			ramp_mat = P.m("6a727c", 0.0, 0.5, 0.6)
			top_mat = P.m("454b53", 0.0, 0.55, 0.5)
		1:
			ramp_mat = P.m("dcb878", 0.0, 1.0)
			top_mat = P.m("c98f5a", 0.0, 1.0)
		2:
			ramp_mat = P.m("7d8576", 0.0, 0.95)
			top_mat = P.m("6a7260", 0.0, 0.95)
		3:
			ramp_mat = P.m("a9e3ff", 0.25, 0.15, 0.1)
			top_mat = P.m("f1f6ff", 0.1, 0.95)
		4:
			ramp_mat = P.m("9a6a3a", 0.0, 0.9)
			top_mat = P.m("8a5a30", 0.0, 0.9)
		_:
			ramp_mat = P.m("2c2a30", 0.0, 0.8, 0.1)
			top_mat = P.m("37343d", 0.0, 0.8, 0.1)
	# بدنه
	wedge(n, 2.0, T, r, Vector3(0, 0, zr - r * 0.5), ramp_mat)
	_box(n, Vector3(2.0, T, plat_len), Vector3(0, T * 0.5, zc_plat), top_mat)
	if rd > 0.0:
		var w2 := wedge(n, 2.0, T, rd, Vector3(0, 0, -zr + rd * 0.5), ramp_mat)
		w2.rotation_degrees = Vector3(0, -90, 0)
	_box(n, Vector3(2.04, 0.08, plat_len), Vector3(0, T + 0.03, zc_plat), top_mat)
	Gfx.shadow(n, Vector2(3.0, L + 1.0), 0.45)
	var acc := Color(ZONE_ACCENT[zone])
	match zone:
		0: _plat_city(n, L, T, r, rd, zr, zc_plat, plat_len)
		1: _plat_desert(n, L, T, r, zr, zc_plat, plat_len)
		2: _plat_jungle(n, L, T, r, zr, zc_plat, plat_len)
		3: _plat_snow(n, L, T, r, zr, zc_plat, plat_len)
		4: _plat_harbor(n, L, T, r, zr, zc_plat, plat_len)
		_: _plat_lava(n, L, T, r, zr, zc_plat, plat_len)
	_ramp_cues(n, T, r, zr, zone)
	# چراغ‌های لبه‌ی ابتدای رمپ (راهنمای بازیکن)
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.12, 0.12, 0.12), Vector3(s * 0.98, 0.1, zr + 0.05), P.m(ZONE_ACCENT[zone], 2.6))
		Gfx.glow(n, Vector3(s * 0.98, 0.25, zr + 0.1), 0.9, Color(acc.r, acc.g, acc.b, 0.5))


## رمپ باید «راه داشتن» را نشان بدهد: خط‌های شورون روی شیب، ریل‌های کناری، و لبه‌ی روشن
static func _ramp_cues(n: Node3D, T: float, r: float, zr: float, zone: int) -> void:
	var hz := Gfx.mat(Color.WHITE, 0.3, Gfx.hazard_tex(), 0.6)
	var ang := atan2(T, r)
	var slope_len := sqrt(r * r + T * T)
	var cz := zr - r * 0.5
	# نوار هشدار کنار رمپ (دو طرف) روی سطح شیب
	for sx in [-0.93, 0.93]:
		var strip := _box(n, Vector3(0.16, 0.05, slope_len), Vector3(sx, T * 0.5 + 0.03, cz), hz)
		strip.rotation = Vector3(ang, 0.0, 0.0)
	# پله‌ای/شورون‌های سفید روی شیب (جهت حرکت را نشان می‌دهد)
	var chev := P.m("f4f4f4", 0.5, 0.6)
	var k := 4
	for i in k:
		var f := (float(i) + 0.5) / float(k)
		var zz := zr - r * f
		var yy := T * f + 0.04
		var a := _box(n, Vector3(0.55, 0.03, 0.12), Vector3(-0.2, yy, zz), chev)
		a.rotation = Vector3(ang, 0.0, 0.5)
		var b := _box(n, Vector3(0.55, 0.03, 0.12), Vector3(0.2, yy, zz), chev)
		b.rotation = Vector3(ang, 0.0, -0.5)
	# ریل کناری فلزی با پایه (۳بعدی)
	var steel := P.m("c9ced6", 0.0, 0.3, 0.9)
	for sx in [-1.02, 1.02]:
		var rail := _box(n, Vector3(0.06, 0.06, slope_len), Vector3(sx, T * 0.5 + 0.55, cz), steel)
		rail.rotation = Vector3(ang, 0.0, 0.0)
		for i in 3:
			var f2 := float(i) / 2.0
			_box(n, Vector3(0.06, 0.55 + T * f2 * 0.0, 0.06), Vector3(sx, T * f2 + 0.27, zr - r * f2 - (0.03 if i == 0 else 0.0)), steel)
	# لبه‌ی بالای رمپ: خط روشن که معلوم باشد سکو شروع می‌شود
	_box(n, Vector3(2.0, 0.05, 0.1), Vector3(0, T + 0.1, zr - r), P.m(ZONE_ACCENT[zone], 2.0))


static func _plat_city(n: Node3D, L: float, T: float, r: float, rd: float, zr: float, zc: float, pl: float) -> void:
	# کفِ کامیون/تریلر: لبه‌ی زرد-مشکی، چرخ‌ها، چراغ‌های ترمز در انتها، قفسه‌ی بار
	_box(n, Vector3(2.08, 0.1, pl), Vector3(0, T - 0.02, zc), Gfx.mat(Color.WHITE, 0.0, Gfx.hazard_tex(), 0.7))
	_box(n, Vector3(1.7, 0.06, pl - 0.3), Vector3(0, T + 0.07, zc), P.m("3a3f46", 0.0, 0.45, 0.6))
	for k in 12:
		_box(n, Vector3(1.4, 0.03, 0.05), Vector3(0, T + 0.1, zc + pl * 0.5 - 0.6 - k * (pl - 1.2) / 11.0), P.m("565d66", 0.0, 0.4, 0.7))
	var wz := zc - pl * 0.5 + 2.0
	for sx in [-1.12, 1.12]:
		for dz in [0.0, 1.3]:
			_cyl(n, 0.5, 0.5, 0.3, Vector3(sx, 0.5, wz + dz), P.m("151517", 0.0, 0.9), Vector3(0, 0, 90), 14)
			_cyl(n, 0.26, 0.26, 0.32, Vector3(sx, 0.5, wz + dz), P.m("b5bcc4", 0.0, 0.3, 0.9), Vector3(0, 0, 90), 8)
		_box(n, Vector3(0.1, 0.35, 0.1), Vector3(sx * 0.9, T + 0.3, zc - pl * 0.5 + 0.1), P.m("d93a2f", 2.4))
	for sx in [-1.04, 1.04]:
		_box(n, Vector3(0.08, 0.5, pl), Vector3(sx, T + 0.25, zc), P.m("ffcf00", 0.1, 0.5))
	var crate := Gfx.mat(Color.WHITE, 0.0, Gfx.crate_tex(), 0.85)
	_box(n, Vector3(0.8, 0.8, 0.8), Vector3(-1.4, T + 0.4, zc - pl * 0.5 + 1.0), crate)


static func _plat_desert(n: Node3D, L: float, T: float, r: float, zr: float, zc: float, pl: float) -> void:
	var strata := P.m("b9835e", 0.0, 1.0)
	for k in 3:
		_box(n, Vector3(2.08, 0.08, pl), Vector3(0, T * (0.3 + k * 0.3), zc), P.m("a2704d" if k % 2 == 0 else "d8a878", 0.0, 1.0))
	for s in [-1.0, 1.0]:
		_sph(n, 0.5, Vector3(s * 1.05, T + 0.15, zc + pl * 0.3), P.m("b9835e", 0.0, 1.0), Vector3(0.9, 0.7, 1.4), 8)
		_sph(n, 0.4, Vector3(s * 1.1, T + 0.1, zc - pl * 0.3), P.m("a2704d", 0.0, 1.0), Vector3(0.9, 0.7, 1.2), 8)
	_cyl(n, 0.14, 0.17, 1.4, Vector3(1.15, T + 0.7, zc - pl * 0.4), P.m("5f8a3a", 0.0, 0.9), Vector3.ZERO, 8)
	_cyl(n, 0.1, 0.1, 0.5, Vector3(1.4, T + 0.7, zc - pl * 0.4), P.m("5f8a3a", 0.0, 0.9), Vector3(0, 0, 90), 8)
	_box(n, Vector3(0.05, 0.7, 0.05), Vector3(-1.1, T + 0.45, zc + pl * 0.2), P.m("5a3a1c"))
	_box(n, Vector3(0.45, 0.28, 0.02), Vector3(-0.9, T + 0.65, zc + pl * 0.2), P.m("e8503a", 0.15))


static func _plat_jungle(n: Node3D, L: float, T: float, r: float, zr: float, zc: float, pl: float) -> void:
	var st := P.m("8c9183", 0.0, 0.95)
	var moss := P.m("4f7d3c", 0.0, 1.0)
	# پله‌های تزئینی روی رمپ
	var steps := 9
	for k in steps:
		var h := T * float(k + 1) / float(steps)
		_box(n, Vector3(2.0, 0.06, r / steps + 0.02), Vector3(0, h + 0.015, zr - (k + 0.5) * r / steps), P.m("9aa090", 0.0, 0.95))
		_box(n, Vector3(2.04, 0.1, 0.05), Vector3(0, h - 0.04, zr - (k) * r / steps - 0.02), P.m("5f6a58", 0.0, 0.95))
	for s in [-1.0, 1.0]:
		for dz in [-0.3, 0.3]:
			var h := 1.6
			_cyl(n, 0.22, 0.26, h, Vector3(s * 1.0, T + h * 0.5, zc + dz * pl), st, Vector3.ZERO, 8)
			_box(n, Vector3(0.6, 0.18, 0.6), Vector3(s * 1.0, T + h + 0.08, zc + dz * pl), st)
			_box(n, Vector3(0.05, 0.7, 0.3), Vector3(s * 0.77, T + 0.8, zc + dz * pl), P.m("ffcf5a", 1.2, 0.8))
	_sph(n, 0.8, Vector3(0, T + 0.1, zc - pl * 0.45), moss, Vector3(1.2, 0.15, 1.0), 8)
	Gfx.glow(n, Vector3(0, T + 1.2, zc), 3.0, Color(1.0, 0.9, 0.5, 0.18))


static func _plat_snow(n: Node3D, L: float, T: float, r: float, zr: float, zc: float, pl: float) -> void:
	var snow := P.m("f4f8ff", 0.1, 0.95)
	var ice := P.m("9edcff", 0.35, 0.12, 0.15)
	_sph(n, 0.5, Vector3(0, T + 0.04, zc), snow, Vector3(2.0, 0.12, pl * 0.97), 12)
	for s in [-1.0, 1.0]:
		for k in 4:
			_box(n, Vector3(0.35, 0.5 + (k % 2) * 0.3, 0.35), Vector3(s * 1.05, T + 0.25, zc + pl * (0.35 - k * 0.22)), ice, Vector3(5 * k, 20 * k, 4))
	for p in [Vector3(1.4, 0, -0.35), Vector3(-1.4, 0, 0.1)]:
		_cyl(n, 0.05, 0.08, 0.8, Vector3(p.x, T + 0.4, zc + p.z * pl), P.m("4a3524"), Vector3.ZERO, 6)
		for j in 3:
			X._cone(n, 0.55 - j * 0.14, 0.7, Vector3(p.x, T + 0.7 + j * 0.45, zc + p.z * pl), P.m("1f5a35", 0.0, 1.0), 8)
	Gfx.glow(n, Vector3(0, T + 0.3, zc), 3.2, Color(0.7, 0.9, 1.0, 0.15))


static func _plat_harbor(n: Node3D, L: float, T: float, r: float, zr: float, zc: float, pl: float) -> void:
	var plank := P.m("a97a3e", 0.0, 0.9)
	var plank2 := P.m("8a5a30", 0.0, 0.9)
	for k in int(pl / 0.6):
		_box(n, Vector3(1.94, 0.04, 0.5), Vector3(0, T + 0.06, zc + pl * 0.5 - 0.3 - k * 0.6), plank if k % 2 == 0 else plank2)
	for k in int(r / 0.6):
		_box(n, Vector3(2.0, 0.03, 0.01), Vector3(0, T * (float(k) * 0.6 / r) + 0.02, zr - float(k) * 0.6), plank2).visible = false
	# شمع‌های چوبی زیر اسکله و بولارد/فانوس
	for s in [-1.0, 1.0]:
		for k in 4:
			_cyl(n, 0.13, 0.15, T + 0.4, Vector3(s * 1.0, (T + 0.4) * 0.5 - 0.2, zc + pl * (0.4 - k * 0.26)), P.m("4a3220", 0.0, 1.0), Vector3.ZERO, 8)
		_cyl(n, 0.12, 0.17, 0.5, Vector3(s * 0.95, T + 0.3, zc - pl * 0.4), P.m("ffcc00", 0.0, 0.45, 0.4), Vector3.ZERO, 10)
		_cyl(n, 0.03, 0.03, 1.4, Vector3(s * 1.0, T + 0.7, zc + pl * 0.1), P.m("22262b"), Vector3.ZERO, 5)
		_box(n, Vector3(0.18, 0.22, 0.18), Vector3(s * 1.0, T + 1.45, zc + pl * 0.1), P.m("ffcf5a", 2.6))
		Gfx.glow(n, Vector3(s * 1.0, T + 1.45, zc + pl * 0.1 + 0.2), 2.0, Color(1.0, 0.8, 0.4, 0.5))
	_box(n, Vector3(0.04, 0.04, pl), Vector3(-1.0, T + 0.5, zc), P.m("c9b27a"))


static func _plat_lava(n: Node3D, L: float, T: float, r: float, zr: float, zc: float, pl: float) -> void:
	var lava := P.m("ff5a14", 2.8, 0.5)
	for k in 6:
		var x := -0.7 + (k % 3) * 0.7
		_box(n, Vector3(0.05, 0.03, pl * 0.3), Vector3(x + fmod(k * 0.13, 0.3), T + 0.07, zc + pl * (0.38 - k * 0.15)), lava, Vector3(0, (k * 23) % 40 - 20, 0))
	for s in [-1.0, 1.0]:
		for k in 3:
			var h := 1.2 + k * 0.5
			_cyl(n, 0.28, 0.3, h, Vector3(s * 1.08, T + h * 0.5, zc + pl * (0.3 - k * 0.3)), P.m("1c1a20", 0.0, 0.7, 0.2), Vector3.ZERO, 6)
	Gfx.pool(n, Vector3(0, T + 0.1, zc), Vector2(2.6, pl), Color(1.0, 0.4, 0.1, 0.22))
	Gfx.glow(n, Vector3(0, T + 0.4, zc), 3.0, Color(1.0, 0.4, 0.1, 0.25))
	_box(n, Vector3(0.05, T * 0.95, 0.05), Vector3(0.9, T * 0.5, zr - r * 0.5), lava)


# =============================================================
#                  بستن لِین (راه انحرافی)
# =============================================================
## یک تکه‌ی تک‌لِین به طول len (+Z = ابتدای مانع که بازیکن می‌بیند)
static func closure(n: Node3D, zone: int, len: float, seed_v: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_v
	var zf := len * 0.5
	match zone:
		0:
			# حصار چوبی «راه بسته» با چراغ‌های چشمک‌زن، کپه‌ی خاک و بیل مکانیکی
			var hoard := Gfx.mat(Color.WHITE, 0.0, Gfx.hazard_tex(), 0.7)
			_box(n, Vector3(2.0, 2.4, 0.16), Vector3(0, 1.2, zf - 0.2), P.m("e8e4d8", 0.0, 0.85))
			_box(n, Vector3(2.02, 0.5, 0.18), Vector3(0, 0.55, zf - 0.2), hoard)
			_box(n, Vector3(2.02, 0.5, 0.18), Vector3(0, 2.0, zf - 0.2), hoard)
			Gfx.label(n, "ROAD WORK", Vector3(0, 1.3, zf - 0.09), 34, Color("d93a2f"), 0.0055)
			for sx in [-0.85, 0.85]:
				_box(n, Vector3(0.16, 0.16, 0.16), Vector3(sx, 2.55, zf - 0.2), P.m("ff8a00", 3.0))
				Gfx.glow(n, Vector3(sx, 2.6, zf - 0.1), 1.2, Color(1.0, 0.65, 0.1, 0.5))
				_cyl(n, 0.04, 0.2, 0.7, Vector3(sx, 0.35, zf + 0.5), P.m("ff6a1a", 0.0, 0.6), Vector3.ZERO, 8)
			_sph(n, 1.4, Vector3(0, 0.4, 0.0), P.m("7a5a3a", 0.0, 1.0), Vector3(0.75, 0.9, 3.0), 10)
			# بیل مکانیکی
			_box(n, Vector3(1.4, 0.7, 2.2), Vector3(0, 0.55, -zf + 2.6), P.m("f5c518", 0.0, 0.45, 0.3))
			_box(n, Vector3(1.5, 0.45, 2.4), Vector3(0, 0.25, -zf + 2.6), P.m("22262b", 0.0, 0.8))
			_box(n, Vector3(1.0, 0.9, 0.9), Vector3(0, 1.4, -zf + 3.1), P.m("f5c518", 0.0, 0.45, 0.3))
			_box(n, Vector3(0.9, 0.5, 0.05), Vector3(0, 1.5, -zf + 3.56), P.m("1c2a38", 0.1, 0.1, 0.5))
			_box(n, Vector3(0.22, 0.22, 2.4), Vector3(0, 2.3, -zf + 1.4), P.m("f5c518", 0.0, 0.45, 0.3), Vector3(-20, 0, 0))
			_box(n, Vector3(0.5, 0.5, 0.6), Vector3(0, 1.4, -zf + 0.2), P.m("5a5f66", 0.0, 0.5, 0.7))
		1:
			var rock := P.m("b9835e", 0.0, 1.0)
			var rock2 := P.m("a2704d", 0.0, 1.0)
			for k in 14:
				var s := rng.randf_range(0.55, 1.15)
				_sph(n, s, Vector3(rng.randf_range(-0.7, 0.7), s * 0.7 + rng.randf_range(0.0, 1.3), rng.randf_range(-zf + 1.0, zf - 0.8)), rock if k % 2 == 0 else rock2, Vector3(1, 0.85, 1), 7)
			_sph(n, 1.4, Vector3(0, 0.3, zf - 0.8), P.m("e8cfa0", 0.0, 1.0), Vector3(0.75, 0.4, 1.4), 8)
			for k in 3:
				_box(n, Vector3(0.1, 1.1, 0.1), Vector3(-0.8 + k * 0.8, 0.5, zf - 0.2), P.m("6a4426", 0.0, 0.95), Vector3(0, 0, rng.randf_range(-25, 25)))
		2:
			var bark := P.m("5a3d22", 0.0, 1.0)
			var moss := P.m("4f7d3c", 0.0, 1.0)
			var leaf := P.m("3f8d38", 0.0, 1.0)
			for k in 4:
				var z := zf - 1.2 - k * (len - 2.4) / 3.0
				_cyl(n, 0.62, 0.62, 2.3, Vector3(0, 0.6, z), bark, Vector3(0, 90, 90), 10)
				_cyl(n, 0.55, 0.55, 2.2, Vector3(0.0, 1.55, z + 0.3), bark, Vector3(0, 82, 90), 10)
				_sph(n, 0.5, Vector3(0.2, 1.75, z), moss, Vector3(1.8, 0.35, 1.0), 6)
			for k in 8:
				_sph(n, 0.55, Vector3(rng.randf_range(-0.7, 0.7), 1.5 + rng.randf_range(0, 1.0), rng.randf_range(-zf + 1, zf - 1)), leaf, Vector3(1.2, 0.7, 1.0), 6)
			for k in 4:
				_cyl(n, 0.015, 0.015, 1.2, Vector3(-0.7 + k * 0.5, 2.4, zf - 1.2), P.m("5fa84a"), Vector3.ZERO, 4)
		3:
			var snow := P.m("f4f8ff", 0.1, 0.95)
			var rock := P.m("6d7078", 0.0, 0.95)
			_sph(n, 1.0, Vector3(0, 0.3, 0), snow, Vector3(1.0, 1.9, len * 0.5), 12)
			_sph(n, 0.9, Vector3(0, 0.2, zf - 1.5), snow, Vector3(1.1, 1.1, 1.8), 12)
			for k in 6:
				_sph(n, rng.randf_range(0.3, 0.5), Vector3(rng.randf_range(-0.7, 0.7), rng.randf_range(1.0, 2.2), rng.randf_range(-zf + 1, zf - 1)), rock, Vector3(1, 0.8, 1), 6)
			for k in 3:
				_cyl(n, 0.1, 0.12, 2.0, Vector3(-0.6 + k * 0.6, 1.6, zf - 2.0 - k), P.m("4a3524"), Vector3(70, rng.randf_range(-40, 40), 0), 6)
		4:
			var cols := ["d6502d", "2f7fc0", "3b9a58", "e0a82a"]
			var rib := Gfx.ribs_tex()
			var k := 0
			var z := zf - 1.3
			while z > -zf + 1.0:
				_box(n, Vector3(2.0, 1.35, 2.6), Vector3(0, 0.68, z), Gfx.mat(Color(cols[(k + seed_v) % 4]), 0.0, rib, 0.55))
				_box(n, Vector3(2.0, 1.35, 2.6), Vector3(0, 2.05, z), Gfx.mat(Color(cols[(k + seed_v + 2) % 4]), 0.0, rib, 0.55))
				z -= 2.6
				k += 1
			_box(n, Vector3(2.0, 0.05, 0.05), Vector3(0, 1.3, zf + 0.02), P.m("ff8a00", 1.5))
			for sx in [-0.8, 0.8]:
				_box(n, Vector3(0.16, 0.16, 0.16), Vector3(sx, 2.9, zf - 0.2), P.m("ff3030", 3.0))
				Gfx.glow(n, Vector3(sx, 2.95, zf - 0.1), 1.2, Color(1.0, 0.2, 0.2, 0.5))
		_:
			var rock := P.m("26232a", 0.0, 0.95)
			var lava := P.m("ff5a14", 2.8, 0.5)
			for k in 12:
				var s := rng.randf_range(0.5, 1.1)
				_sph(n, s, Vector3(rng.randf_range(-0.7, 0.7), s * 0.7 + rng.randf_range(0.0, 1.5), rng.randf_range(-zf + 1.0, zf - 1.0)), rock, Vector3(1, 0.9, 1), 6)
			_box(n, Vector3(2.0, 0.06, 1.4), Vector3(0, 0.05, zf + 0.7), lava)
			for k in 5:
				_box(n, Vector3(0.05, rng.randf_range(0.6, 1.6), 0.05), Vector3(-0.8 + k * 0.4, 1.0, zf - 0.8), lava, Vector3(0, 0, rng.randf_range(-15, 15)))
			Gfx.glow(n, Vector3(0, 1.0, zf), 3.4, Color(1.0, 0.4, 0.1, 0.4))
	Gfx.shadow(n, Vector2(2.8, len + 0.8), 0.5)


## تابلوی راه انحرافی بالای لِین باز؛ local_x فاصله‌ی افقی تا لِین باز است
static func detour_sign(n: Node3D, zone: int, local_x: float, zf: float) -> void:
	var acc := ZONE_ACCENT[zone]
	var post := P.m("3a3f46", 0.0, 0.5, 0.6)
	_cyl(n, 0.05, 0.05, 3.4, Vector3(local_x, 1.7, zf + 0.3), post, Vector3.ZERO, 6)
	_box(n, Vector3(1.5, 0.9, 0.08), Vector3(local_x, 3.3, zf + 0.3), P.m("1f2a38", 0.0, 0.5))
	var chev := P.m(acc, 2.6)
	for s in [-1.0, 1.0]:
		_box(n, Vector3(0.62, 0.14, 0.05), Vector3(local_x + s * 0.24, 3.3, zf + 0.36), chev, Vector3(0, 0, -s * 35))
	Gfx.glow(n, Vector3(local_x, 3.3, zf + 0.5), 2.4, Color(Color(acc).r, Color(acc).g, Color(acc).b, 0.35))


# =============================================================
#                          چاله
# =============================================================
static func pit(n: Node3D, zone: int, len: float) -> void:
	var w := 2.1
	var dark := P.m("050507", 0.0, 0.9)
	var rim := P.m("3b3f45", 0.0, 0.9)
	match zone:
		0:
			_box(n, Vector3(w, 0.03, len), Vector3(0, 0.02, 0), dark)
			rim = P.m("55595f", 0.0, 0.95)
			for k in 7:
				_box(n, Vector3(0.45, 0.14, 0.4), Vector3(-0.95 + (k % 2) * 1.9, 0.07, -len * 0.4 + k * len * 0.14), rim, Vector3(0, k * 37, (k % 3 - 1) * 12))
			_cyl(n, 0.12, 0.12, 2.0, Vector3(0, 0.3, -0.3), P.m("8a96a3", 0.0, 0.35, 0.8), Vector3(0, 0, 90), 8)   # لوله‌ی شکسته
			Gfx.glow(n, Vector3(0, 0.5, 0), 1.8, Color(0.9, 0.9, 1.0, 0.18))
			for sz in [-0.5, 0.5]:
				_cyl(n, 0.04, 0.2, 0.7, Vector3(1.05, 0.35, sz * len), P.m("ff6a1a", 0.0, 0.6), Vector3.ZERO, 8)
		1:
			for k in 5:
				var s := 1.0 - k * 0.17
				var disc := _cyl(n, 1.0, 1.0, 0.03, Vector3(0, 0.02 + k * 0.004, 0), P.m(["d6b07a", "b8905a", "8f6a3e", "5f4426", "241a10"][k], 0.0, 1.0), Vector3.ZERO, 20)
				disc.scale = Vector3(w * 0.5 * s, 1.0, len * 0.5 * s)
		2:
			_box(n, Vector3(w, 0.03, len), Vector3(0, 0.02, 0), P.m("1e2a1a", 0.15, 0.1, 0.4))
			for k in 6:
				_sph(n, 0.25, Vector3(-0.8 + (k % 3) * 0.8, 0.05, -len * 0.3 + (k / 3) * len * 0.5), P.m("3f8d38", 0.0, 1.0), Vector3(1.2, 0.1, 1.0), 6)
			for sx in [-1.0, 1.0]:
				for k in 3:
					_cyl(n, 0.02, 0.02, 0.9, Vector3(sx * 1.05, 0.45, -len * 0.4 + k * len * 0.4), P.m("5a7a3a"), Vector3(0, 0, sx * 8), 4)
			_box(n, Vector3(0.18, 0.04, 1.2), Vector3(0.4, 0.06, 0.2), P.m("6a4426", 0.0, 0.95), Vector3(0, 30, 0))
		3:
			_box(n, Vector3(w, 0.03, len), Vector3(0, 0.02, 0), P.m("06223a", 0.2, 0.1, 0.2))
			Gfx.pool(n, Vector3(0, 0.05, 0), Vector2(w * 1.3, len * 1.2), Color(0.3, 0.7, 1.0, 0.4))
			for k in 8:
				var x := -0.95 + (k % 2) * 1.9
				X._cone(n, 0.2, 0.55, Vector3(x, 0.0, -len * 0.4 + k * len * 0.12), P.m("b6e8ff", 0.35, 0.12), 5).rotation_degrees = Vector3(0, 0, (-14 if x < 0 else 14))
			_box(n, Vector3(w + 0.4, 0.06, len + 0.3), Vector3(0, 0.0, 0), P.m("f4f8ff", 0.1, 0.95))
		4:
			_box(n, Vector3(w, 0.03, len), Vector3(0, 0.02, 0), P.m("07131f", 0.25, 0.05, 0.3))
			for k in 4:
				_box(n, Vector3(w * 0.8, 0.02, 0.05), Vector3(0, 0.05, -len * 0.4 + k * len * 0.27), P.m("e8f4ff", 0.5, 0.5))
			for sx in [-1.0, 1.0]:
				_cyl(n, 0.12, 0.14, 0.7, Vector3(sx * 1.1, 0.35, -len * 0.5), P.m("ffcc00", 0.0, 0.45, 0.4), Vector3.ZERO, 8)
				_cyl(n, 0.12, 0.14, 0.7, Vector3(sx * 1.1, 0.35, len * 0.5), P.m("ffcc00", 0.0, 0.45, 0.4), Vector3.ZERO, 8)
				_box(n, Vector3(0.3, 0.16, 0.05), Vector3(sx * 1.1, 0.8, len * 0.5), P.m("ff3030", 3.0))
			_box(n, Vector3(0.2, 0.04, 1.4), Vector3(-0.3, 0.06, 0.4), P.m("8a5a30", 0.0, 0.9), Vector3(0, 20, 0))
		_:
			_box(n, Vector3(w, 0.03, len), Vector3(0, 0.025, 0), P.m("ff5a14", 3.2, 0.5))
			for k in 5:
				_box(n, Vector3(w * 0.5, 0.032, 0.14), Vector3((k % 2 - 0.5) * 0.6, 0.04, -len * 0.4 + k * len * 0.2), P.m("ffd23a", 3.4, 0.5))
			for sx in [-1.0, 1.0]:
				for k in 3:
					_sph(n, 0.32, Vector3(sx * 1.05, 0.12, -len * 0.4 + k * len * 0.4), P.m("26232a", 0.0, 0.95), Vector3(1.1, 0.6, 1.0), 6)
			Gfx.glow(n, Vector3(0, 0.4, 0), 3.2, Color(1.0, 0.45, 0.1, 0.55))
			Gfx.pool(n, Vector3(0, 0.05, 0), Vector2(w * 1.8, len * 1.6), Color(1.0, 0.4, 0.1, 0.3))


# =============================================================
#                   تونل کم‌ارتفاع (سُرخوردن)
# =============================================================
static func tunnel(n: Node3D, zone: int, len: float) -> void:
	var frame: Material
	var roof: Material
	match zone:
		0: frame = P.m("9aa3ad", 0.0, 0.35, 0.9); roof = P.m("b98a4a", 0.0, 0.9)
		1: frame = P.m("6a4426", 0.0, 0.95); roof = P.m("8a5a30", 0.0, 0.95)
		2: frame = P.m("5a3d22", 0.0, 1.0); roof = P.m("3f8d38", 0.0, 1.0)
		3: frame = P.m("8fd6ff", 0.3, 0.12, 0.1); roof = P.m("dff2ff", 0.2, 0.2, 0.1)
		4: frame = P.m("5a6670", 0.0, 0.4, 0.8); roof = Gfx.mat(Color("2f7fc0"), 0.0, Gfx.ribs_tex(), 0.55)
		_: frame = P.m("1c1a20", 0.0, 0.7, 0.2); roof = P.m("2f2d35", 0.0, 0.8, 0.2)
	var count := int(len / 2.0) + 1
	for k in count:
		var z := len * 0.5 - 0.3 - k * (len - 0.6) / maxf(1.0, count - 1.0)
		for s in [-1.0, 1.0]:
			_box(n, Vector3(0.16, 1.5, 0.16), Vector3(s * 1.02, 0.75, z), frame)
		_box(n, Vector3(2.3, 0.18, 0.2), Vector3(0, 1.1, z), frame)
	_box(n, Vector3(2.3, 0.2, len), Vector3(0, 1.3, 0), roof)
	_box(n, Vector3(2.4, 0.5, len), Vector3(0, 1.75, 0), roof if zone != 2 else P.m("2f6a2c", 0.0, 1.0))
	match zone:
		0:
			for k in 3:
				_box(n, Vector3(2.3, 0.04, 0.5), Vector3(0, 1.43, -len * 0.3 + k * len * 0.3), Gfx.mat(Color.WHITE, 0.0, Gfx.hazard_tex(), 0.7))
			for s in [-1.0, 1.0]:
				_box(n, Vector3(0.14, 0.14, 0.14), Vector3(s * 0.9, 1.0, len * 0.5), P.m("ff8a00", 3.0))
		1:
			for k in 4:
				_box(n, Vector3(0.14, 0.14, 0.14), Vector3(0, 1.0, len * 0.5 - 0.6 - k * (len - 1.2) / 3.0), P.m("ffcf5a", 2.4))
		2:
			for k in 8:
				_cyl(n, 0.012, 0.012, 0.35 + (k % 3) * 0.1, Vector3(-0.9 + (k % 4) * 0.6, 1.0, len * 0.5 - 0.5 - (k / 4) * (len - 1.0)), P.m("5fa84a"), Vector3.ZERO, 4)
		3:
			for k in 9:
				X._cone(n, 0.05, 0.3, Vector3(-0.95 + (k % 3) * 0.95, 1.0 - 0.3, len * 0.5 - 0.6 - (k / 3) * (len - 1.2) * 0.5), P.m("b6e8ff", 0.35, 0.12), 5).rotation_degrees = Vector3(180, 0, 0)
		4:
			for k in 2:
				_box(n, Vector3(0.5, 0.08, 0.2), Vector3(0, 1.18, len * 0.5 - 1.0 - k * (len - 2.0)), P.m("fff5cf", 3.0))
			Gfx.pool(n, Vector3(0, 0.03, 0), Vector2(2.4, len), Color(1.0, 0.95, 0.7, 0.14))
		_:
			for k in 3:
				_cyl(n, 0.04, 0.07, 0.4, Vector3(-0.7 + k * 0.7, 1.0, 0.0), P.m("ff5a14", 3.0), Vector3.ZERO, 6)
			Gfx.glow(n, Vector3(0, 0.9, 0), 3.0, Color(1.0, 0.4, 0.1, 0.35))
	Gfx.shadow(n, Vector2(2.8, len + 0.8), 0.4)


# =============================================================
#               وسیله‌ی تغییردهنده‌ی لِین
# =============================================================
## خروجی: {"blinkers": [MeshInstance3D...], "y1": ارتفاع برخورد}
static func switcher(n: Node3D, zone: int, seed_v: int) -> Dictionary:
	var amber_a := Gfx.mat(Color("ffb000"), 0.0, null, 0.4)
	var amber_b := Gfx.mat(Color("ffb000"), 0.0, null, 0.4)
	var blink: Array = []
	var glows: Array = []
	var cols := ["d1432f", "2f7dd1", "e8b21c", "3b9a58", "f2f2ee", "7a4fd0"]
	var col: String = cols[seed_v % 6]
	var y1 := 1.7
	match zone:
		0:
			var body := P.m(col, 0.0, 0.3, 0.4)
			_box(n, Vector3(1.75, 0.6, 2.9), Vector3(0, 0.62, 0), body)
			_box(n, Vector3(1.6, 0.55, 1.5), Vector3(0, 1.17, -0.15), body)
			_box(n, Vector3(1.62, 0.45, 1.52), Vector3(0, 1.17, -0.15), P.m("1c2a38", 0.1, 0.1, 0.5)).scale = Vector3(1.0, 0.85, 0.96)
			_box(n, Vector3(1.64, 0.1, 1.6), Vector3(0, 1.48, -0.15), body)
			_box(n, Vector3(1.8, 0.2, 0.12), Vector3(0, 0.38, 1.46), P.m("c9cfd6", 0.0, 0.3, 0.9))
			X._lights(n, 1.46, 0.7, 0.62)
			_wheels2(n, 0.35, 0.86, 0.95)
			_box(n, Vector3(0.6, 0.18, 0.04), Vector3(0, 1.58, -0.15), P.m("f2f2ee"))
			Gfx.label(n, "TAXI", Vector3(0, 1.58, 0.65), 30, Color("2a2d31"), 0.0045, Vector3(-60, 0, 0)).double_sided = true
		1:
			var body := P.m(col, 0.0, 0.4, 0.3)
			var cage := P.m("2a2d31", 0.0, 0.4, 0.7)
			_box(n, Vector3(1.4, 0.45, 2.4), Vector3(0, 0.75, 0), body)
			for s in [-1.0, 1.0]:
				_box(n, Vector3(0.06, 1.0, 0.06), Vector3(s * 0.62, 1.3, 0.5), cage)
				_box(n, Vector3(0.06, 1.0, 0.06), Vector3(s * 0.62, 1.3, -0.6), cage)
				_box(n, Vector3(0.06, 0.06, 1.2), Vector3(s * 0.62, 1.8, -0.05), cage)
			_box(n, Vector3(1.3, 0.06, 1.2), Vector3(0, 1.8, -0.05), cage)
			_box(n, Vector3(0.5, 0.4, 0.5), Vector3(0, 1.1, -0.2), P.m("5a3a1c", 0.0, 0.9))
			for sx in [-0.95, 0.95]:
				for sz in [0.85, -0.9]:
					_cyl(n, 0.5, 0.5, 0.45, Vector3(sx, 0.5, sz), P.m("151517", 0.0, 0.95), Vector3(0, 0, 90), 14)
					_cyl(n, 0.22, 0.22, 0.47, Vector3(sx, 0.5, sz), P.m("b5bcc4", 0.0, 0.3, 0.9), Vector3(0, 0, 90), 8)
			X._lights(n, 1.22, 0.85, 0.5)
			y1 = 1.9
		2:
			var body := P.m("5f7a3a", 0.0, 0.5, 0.2)
			_box(n, Vector3(1.75, 0.75, 2.7), Vector3(0, 0.85, 0), body)
			_box(n, Vector3(1.7, 0.55, 1.0), Vector3(0, 1.5, 0.6), body)
			_box(n, Vector3(1.6, 0.4, 0.05), Vector3(0, 1.55, 1.12), P.m("1c2a38", 0.1, 0.1, 0.5), Vector3(-14, 0, 0))
			_box(n, Vector3(1.7, 0.08, 1.4), Vector3(0, 1.85, -0.3), P.m("d6c79a", 0.0, 0.95))
			for s in [-1.0, 1.0]:
				_box(n, Vector3(0.06, 0.9, 0.06), Vector3(s * 0.82, 1.4, -0.8), P.m("2a2d31", 0.0, 0.4, 0.7))
			_cyl(n, 0.34, 0.34, 0.2, Vector3(0, 1.1, -1.4), P.m("151517", 0.0, 0.95), Vector3(90, 0, 0), 14)
			X._lights(n, 1.37, 0.95, 0.65)
			_wheels2(n, 0.42, 0.88, 0.9)
		3:
			var body := P.m(col, 0.0, 0.3, 0.3)
			_box(n, Vector3(0.9, 0.55, 2.0), Vector3(0, 0.6, 0), body)
			_box(n, Vector3(0.7, 0.3, 0.9), Vector3(0, 0.98, -0.3), P.m("1e2024", 0.0, 0.7))
			_box(n, Vector3(0.7, 0.45, 0.05), Vector3(0, 1.15, 0.2), P.m("a9d8ff", 0.2, 0.1, 0.1), Vector3(-30, 0, 0))
			for s in [-1.0, 1.0]:
				_box(n, Vector3(0.14, 0.06, 2.2), Vector3(s * 0.45, 0.22, 0.1), P.m("1e2024", 0.0, 0.5, 0.6))
				_box(n, Vector3(0.14, 0.1, 0.5), Vector3(s * 0.45, 0.3, 1.2), P.m("1e2024", 0.0, 0.5, 0.6), Vector3(-25, 0, 0))
			_box(n, Vector3(1.1, 0.1, 0.1), Vector3(0, 1.0, 0.45), P.m("2a2d31"))
			X._lights(n, 1.0, 0.65, 0.3)
			y1 = 1.4
		4:
			var body := P.m("f5a31a", 0.0, 0.4, 0.3)
			var dark := P.m("2a2d31", 0.0, 0.6)
			_box(n, Vector3(1.4, 0.8, 1.8), Vector3(0, 0.7, -0.5), body)
			_box(n, Vector3(1.4, 0.12, 1.2), Vector3(0, 1.25, -0.7), body)
			for s in [-1.0, 1.0]:
				_box(n, Vector3(0.07, 0.9, 0.07), Vector3(s * 0.65, 1.7, -0.2), dark)
				_box(n, Vector3(0.07, 0.9, 0.07), Vector3(s * 0.65, 1.7, -1.1), dark)
				_box(n, Vector3(0.12, 2.0, 0.12), Vector3(s * 0.42, 1.0, 0.95), P.m("8a96a3", 0.0, 0.4, 0.8))
				_box(n, Vector3(0.12, 0.08, 1.1), Vector3(s * 0.42, 0.12, 1.55), P.m("8a96a3", 0.0, 0.4, 0.8))
			_box(n, Vector3(1.4, 0.08, 1.2), Vector3(0, 2.2, -0.65), dark)
			_box(n, Vector3(0.5, 0.4, 0.45), Vector3(0, 1.5, -0.6), dark)
			_wheels2(n, 0.34, 0.75, 0.55, -0.5)
			y1 = 2.3
		_:
			var cart := P.m("3a3f46", 0.0, 0.5, 0.7)
			_box(n, Vector3(1.5, 0.8, 2.2), Vector3(0, 0.85, 0), cart)
			_box(n, Vector3(1.4, 0.1, 2.1), Vector3(0, 1.3, 0), P.m("26232a", 0.0, 0.9))
			for k in 6:
				_sph(n, 0.32, Vector3(-0.5 + (k % 3) * 0.5, 1.4 + (k / 3) * 0.1, -0.5 + (k / 3) * 1.0), P.m("ff5a14", 2.6, 0.5), Vector3(1, 0.8, 1), 6)
			for s in [-1.0, 1.0]:
				_cyl(n, 0.28, 0.28, 0.1, Vector3(s * 0.8, 0.3, 0.7), cart, Vector3(0, 0, 90), 12)
				_cyl(n, 0.28, 0.28, 0.1, Vector3(s * 0.8, 0.3, -0.7), cart, Vector3(0, 0, 90), 12)
				_box(n, Vector3(0.08, 0.5, 2.4), Vector3(s * 0.74, 1.0, 0), P.m("5a6670", 0.0, 0.4, 0.8))
			Gfx.glow(n, Vector3(0, 1.6, 0.2), 2.8, Color(1.0, 0.4, 0.1, 0.45))
			y1 = 1.7
	# راهنماهای چشمک‌زن (روشن می‌شوند وقتی وسیله می‌خواهد لِین عوض کند)
	for s in [-1.0, 1.0]:
		var mat := amber_a if s < 0 else amber_b
		var b := _box(n, Vector3(0.2, 0.16, 0.12), Vector3(s * 0.8, 1.0 if zone != 3 else 0.8, 1.35), mat)
		blink.append(b)
		var g := Gfx.glow(n, Vector3(s * 0.8, 1.0, 1.45), 1.3, Color(1.0, 0.65, 0.1, 0.6))
		g.visible = false
		glows.append(g)
	return {"blinkers": blink, "glows": glows, "y1": y1}


static func _wheels2(n, r: float, x: float, z: float, zoff: float = 0.0) -> void:
	for sx in [-x, x]:
		for sz in [z + zoff, -z + zoff]:
			_cyl(n, r, r, 0.26, Vector3(sx, r, sz), P.m("151517", 0.0, 0.95), Vector3(0, 0, 90), 14)
			_cyl(n, r * 0.5, r * 0.5, 0.28, Vector3(sx, r, sz), P.m("b5bcc4", 0.0, 0.3, 0.9), Vector3(0, 0, 90), 8)


# =============================================================
#                       جسم غلتان
# =============================================================
## خروجی: {"spin": Node3D (برای چرخاندن حول X), "r": شعاع, "y1": ارتفاع}
static func roller(n: Node3D, zone: int) -> Dictionary:
	var spin := Node3D.new()
	var r := 0.5
	match zone:
		0, 4:
			var c := "c8322a" if zone == 0 else "2a6fb0"
			r = 0.45
			spin.position.y = r
			_cyl(spin, r, r, 0.95, Vector3.ZERO, P.m(c, 0.0, 0.5, 0.5), Vector3(0, 0, 90), 16)
			for k in 3:
				_cyl(spin, r + 0.012, r + 0.012, 0.06, Vector3((k - 1) * 0.3, 0, 0), P.m("2e2a28", 0.0, 0.6, 0.6), Vector3(0, 0, 90), 16)
			_cyl(spin, r * 0.85, r * 0.85, 0.99, Vector3.ZERO, P.m("f5c518", 0.5), Vector3(0, 0, 90), 4).visible = false
			_box(spin, Vector3(0.9, 0.12, 0.05), Vector3(0, 0.0, r + 0.01), P.m("f5c518", 0.8))
		1:
			r = 0.6
			spin.position.y = r
			var tw := P.m("8a6a3a", 0.0, 1.0)
			_sph(spin, 0.3, Vector3.ZERO, P.m("5a3d22", 0.0, 1.0))
			for k in 7:
				P.torus(spin, r, r - 0.04, Vector3.ZERO, tw, Vector3(k * 26.0, k * 51.0, k * 17.0), 14)
			for k in 10:
				var a := float(k) * 2.4
				_box(spin, Vector3(0.02, 0.5, 0.02), Vector3(sin(a) * 0.35, cos(a * 1.3) * 0.35, cos(a) * 0.35), tw, Vector3(k * 33.0, k * 21.0, k * 47.0))
		2:
			r = 0.9
			spin.position.y = r
			_sph(spin, r, Vector3.ZERO, P.m("7d8576", 0.0, 0.95), Vector3.ONE, 14)
			for k in 6:
				var d := Vector3(sin(k * 1.1), cos(k * 1.7), sin(k * 2.3)).normalized()
				_sph(spin, 0.3, d * r * 0.88, P.m("4f7d3c", 0.0, 1.0), Vector3(1.2, 0.5, 1.2), 6)
		3:
			r = 0.85
			spin.position.y = r
			_sph(spin, r, Vector3.ZERO, P.m("f4f8ff", 0.12, 0.95), Vector3.ONE, 14)
			for k in 5:
				var d := Vector3(sin(k * 1.3), cos(k * 1.9), sin(k * 2.7)).normalized()
				_sph(spin, 0.14, d * r * 0.97, P.m("6d7078", 0.0, 0.95), Vector3.ONE, 5)
		_:
			r = 0.8
			spin.position.y = r
			_sph(spin, r, Vector3.ZERO, P.m("ff5a14", 2.8, 0.5), Vector3.ONE, 14)
			for k in 7:
				var d := Vector3(sin(k * 1.2), cos(k * 1.5), sin(k * 2.1)).normalized()
				_sph(spin, 0.34, d * r * 0.85, P.m("1c1a20", 0.0, 0.9), Vector3(1.1, 0.7, 1.1), 6)
			Gfx.glow(n, Vector3(0, r, 0), 3.2, Color(1.0, 0.4, 0.1, 0.5))
	n.add_child(spin)
	Gfx.shadow(n, Vector2(r * 3.0, r * 3.0), 0.5)
	return {"spin": spin, "r": r, "y1": r * 2.0}
