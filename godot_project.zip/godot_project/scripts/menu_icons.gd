class_name MenuIcons
extends RefCounted
## آیکن‌های ساده‌ی منو که از صفر با کد کشیده می‌شوند (بدون وابستگی به فونت/ایموجی)

const S := 56
static var _cache := {}


static func tex(id: String) -> Texture2D:
	if _cache.has(id):
		return _cache[id]
	var img := Image.create(S, S, false, Image.FORMAT_RGBA8)
	for y in S:
		for x in S:
			var p := (Vector2(x, y) + Vector2(0.5, 0.5)) / float(S) * 2.0 - Vector2.ONE   # -1..1
			var d := _sdf(id, p)
			var a := clampf(0.5 - d * S * 0.5, 0.0, 1.0)
			img.set_pixel(x, y, Color(1, 1, 1, a))
	var t := ImageTexture.create_from_image(img)
	_cache[id] = t
	return t


static func _circle(p: Vector2, c: Vector2, r: float) -> float:
	return p.distance_to(c) - r


static func _box(p: Vector2, c: Vector2, h: Vector2) -> float:
	var q := (p - c).abs() - h
	return maxf(q.x, q.y) if (q.x <= 0.0 and q.y <= 0.0) else Vector2(maxf(q.x, 0.0), maxf(q.y, 0.0)).length()


static func _tri(p: Vector2) -> float:
	# مثلث پخش (به راست)
	var a := Vector2(-0.45, -0.7)
	var b := Vector2(-0.45, 0.7)
	var c := Vector2(0.75, 0.0)
	var s1 := (b - a).cross(p - a)
	var s2 := (c - b).cross(p - b)
	var s3 := (a - c).cross(p - c)
	var inside := (s1 >= 0 and s2 >= 0 and s3 >= 0) or (s1 <= 0 and s2 <= 0 and s3 <= 0)
	var dd := minf(minf(absf(s1) / (b - a).length(), absf(s2) / (c - b).length()), absf(s3) / (a - c).length())
	return -dd if inside else dd


static func _poly(p: Vector2, pts: Array) -> float:
	var n := pts.size()
	var inside := false
	var dmin := 1e9
	for i in n:
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[(i + 1) % n]
		if (a.y > p.y) != (b.y > p.y) and p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x:
			inside = not inside
		var ab := b - a
		var t := clampf((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
		dmin = minf(dmin, p.distance_to(a + ab * t))
	return -dmin if inside else dmin


static func _ring(p: Vector2, c: Vector2, r: float, w: float) -> float:
	return absf(p.distance_to(c) - r) - w


static func _sdf(id: String, p: Vector2) -> float:
	match id:
		"play":
			return _tri(p)
		"coin":
			return minf(_ring(p, Vector2.ZERO, 0.75, 0.12), _circle(p, Vector2.ZERO, 0.3))
		"person":
			return minf(_circle(p, Vector2(0, -0.35), 0.32), _box(p, Vector2(0, 0.5), Vector2(0.55, 0.35)) - 0.05)
		"bag":
			return minf(_box(p, Vector2(0, 0.2), Vector2(0.6, 0.5)) - 0.08, _ring(p, Vector2(0, -0.4), 0.3, 0.07))
		"star":
			var a := atan2(p.y, p.x)
			var r := 0.78 * (0.55 + 0.45 * absf(cos(2.5 * (a + PI * 0.5))))
			return p.length() - r
		"trophy":
			var cup := _poly(p, [Vector2(-0.5, -0.7), Vector2(0.5, -0.7), Vector2(0.42, -0.05), Vector2(0.15, 0.2), Vector2(-0.15, 0.2), Vector2(-0.42, -0.05)])
			var hand := minf(_ring(p, Vector2(-0.58, -0.4), 0.2, 0.07), _ring(p, Vector2(0.58, -0.4), 0.2, 0.07))
			return minf(minf(cup, hand), minf(_box(p, Vector2(0, 0.35), Vector2(0.09, 0.2)), _box(p, Vector2(0, 0.65), Vector2(0.4, 0.1))))
		"gear":
			var a2 := atan2(p.y, p.x)
			var r2: float = 0.62 + (0.14 if sin(a2 * 8.0) > 0.0 else 0.0)
			return maxf(p.length() - r2, -(p.length() - 0.25))
		"bolt":
			return _poly(p, [Vector2(0.25, -0.85), Vector2(-0.45, 0.1), Vector2(-0.02, 0.1), Vector2(-0.25, 0.85), Vector2(0.45, -0.1), Vector2(0.02, -0.1)])
		"list":
			return minf(minf(_box(p, Vector2(0, -0.5), Vector2(0.7, 0.12)), _box(p, Vector2(0, 0.0), Vector2(0.7, 0.12))), _box(p, Vector2(0, 0.5), Vector2(0.7, 0.12)))
		"note":
			return minf(_circle(p, Vector2(-0.25, 0.5), 0.3), _box(p, Vector2(0.0, -0.1), Vector2(0.09, 0.7)))
		"pencil":
			return maxf(absf(p.x + p.y) - 0.2, absf(p.x - p.y) - 0.95)
		_:
			return _circle(p, Vector2.ZERO, 0.6)


## شناسه‌ی آیکن بر اساس عمل دکمه‌ی منو
static func for_act(act: String) -> String:
	match act:
		"play": return "play"
		"screen:CHALLENGE": return "trophy"
		"screen:CHARACTER": return "person"
		"screen:COIN": return "coin"
		"studio", "item_studio": return "pencil"
		"screen:SHOP": return "bolt"
		"screen:ONLINE_STORE": return "bag"
		"screen:MISSIONS": return "star"
		"screen:BOARD": return "list"
		"screen:CHOOSER": return "note"
		"screen:SETTINGS": return "gear"
		"screen:ACCOUNT": return "person"
	return ""
