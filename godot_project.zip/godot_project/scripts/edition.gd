extends Node
## نسخه‌ی بازی: «مالک» (همه‌چیز باز، پنل کنترل کامل) یا «عمومی» (فقط حالت‌های ماینکرفتی؛
## مدل‌های GLB دیگر قفل‌اند و فقط از فروشگاه آنلاین باز می‌شوند).
##
## نسخه‌ی مالک می‌شود وقتی یکی از این‌ها برقرار باشد:
##   ۱) اجرا از داخل ادیتور Godot (F5)
##   ۲) خروجی با پریست «Android Owner» (ویژگی سفارشی owner)
##   ۳) واردشدن به حسابی که در سرور is_admin دارد (حتی روی APK عمومی)
## برای آزمودن نسخه‌ی عمومی داخل خود ادیتور، در تنظیمات ← پنل مالک «شبیه‌سازی نسخه‌ی عمومی» را روشن کن.

signal changed

const PREF := "user://edition.cfg"

var simulate_public := false


func _ready() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PREF) == OK:
		simulate_public = bool(cfg.get_value("edition", "simulate_public", false))
	Online.auth_changed.connect(func(): changed.emit())


func set_simulate_public(v: bool) -> void:
	simulate_public = v
	var cfg := ConfigFile.new()
	cfg.set_value("edition", "simulate_public", v)
	cfg.save(PREF)
	changed.emit()


func has_owner_rights() -> bool:
	return OS.has_feature("owner") or OS.has_feature("editor") or Online.is_admin


func is_owner() -> bool:
	return has_owner_rights() and not simulate_public


## آیا کاربر می‌تواند فایل GLB دلخواه خودش را اضافه کند؟
func can_import_glb() -> bool:
	return is_owner()


func label() -> String:
	return "نسخه‌ی مالک" if is_owner() else "نسخه‌ی عمومی"
