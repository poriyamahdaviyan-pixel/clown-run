extends Node3D

const Props := preload("res://scripts/props.gd")
## دنیای بازی با سه محیط گرم و رنگی که هر ۴۵۰ متر عوض می‌شوند:
##   ۰) شهر در غروب   ۱) صحرای طلایی   ۲) جنگل و معبد
## بازیکن همیشه در z=0 می‌ماند و دنیا به سمت او می‌آید (جلوگیری از خطای دقت اعشاری).
## آسمان، مه، نور و رنگ زمین به‌صورت نرم بین محیط‌ها عوض می‌شود.

const Gfx := preload("res://scripts/gfx.gd")

const TILE_LENGTH := 24.0
const TILE_COUNT := 8
const ROAD_WIDTH := 8.4
const RECYCLE_Z := 24.0
const SHOULDER_W := 2.2

# ظاهر هر محیط (ایندکس = شماره‌ی محیط)
const SKY_TOP: Array[Color] = [Color("46508f"), Color("4f9bd6"), Color("2f7a86"), Color("5b8fc9"), Color("0a1030"), Color("2a0a0a")]
const SKY_HOR: Array[Color] = [Color("ff9d5c"), Color("ffe0a8"), Color("e6e79a"), Color("dcecf8"), Color("2a3a6a"), Color("ff5a22")]
const SKY_GND: Array[Color] = [Color("c2705a"), Color("e8c98f"), Color("7aa05a"), Color("c8d8e6"), Color("10182e"), Color("30100c")]
const FOG_COL: Array[Color] = [Color("f0985f"), Color("f6d6a0"), Color("a8cf80"), Color("dfeaf5"), Color("1a2650"), Color("5a1c10")]
const FOG_DEN: Array[float] = [0.0125, 0.010, 0.0145, 0.012, 0.014, 0.016]
const AMB_COL: Array[Color] = [Color("ffd2a6"), Color("ffe6c0"), Color("c8e8a8"), Color("dfeaff"), Color("6f86c8"), Color("ff8a5a")]
const AMB_E: Array[float] = [0.9, 0.95, 0.9, 1.0, 0.8, 0.85]
const LIGHT_COL: Array[Color] = [Color("ffb575"), Color("fff1cf"), Color("ffeab0"), Color("fff6e6"), Color("9fb4ff"), Color("ff9a60")]
const LIGHT_E: Array[float] = [1.2, 1.3, 1.1, 1.25, 0.8, 1.1]
const ROAD_TINT: Array[Color] = [Color("b9a89c"), Color("e8cca0"), Color("94805f"), Color("e8f0ff"), Color("9aa4b8"), Color("6e5a5a")]
const GROUND_COL: Array[Color] = [Color("5a4540"), Color("d9b074"), Color("3d6b34"), Color("eef4fa"), Color("0e1426"), Color("1a1210")]
const SUN_COL: Array[Color] = [Color("ffa850"), Color("fff2c0"), Color("fff0a0"), Color("fff6d8"), Color("dfe8ff"), Color("ff6a2a")]
const SUN_POS: Array[Vector3] = [Vector3(-26, 15, -175), Vector3(-30, 42, -175), Vector3(-22, 30, -175), Vector3(-20, 30, -175), Vector3(30, 28, -175), Vector3(-10, 10, -175)]
const SUN_SIZE: Array[float] = [9.0, 5.5, 7.0, 5.0, 4.5, 12.0]

const SIGN_WORDS: Array[String] = ["CAFE", "PIZZA", "HOTEL", "24H", "کافه", "نان", "SHOP", "BAKERY"]
const WALL_COLORS: Array[Color] = [Color("d8825f"), Color("e8cfa0"), Color("e3806a"), Color("5fb0a4"), Color("e8b552"), Color("d99aa8"), Color("b9835e")]
const AWNING_COLORS: Array[Color] = [Color("e8503a"), Color("2fa89a"), Color("f2b632"), Color("7a4fd0"), Color("f27aa0")]

var _tiles: Array[Node3D] = []
var _rng := RandomNumberGenerator.new()
var _time := 0.0

var _road_mat: StandardMaterial3D
var _ground_mat: StandardMaterial3D
var _sky_mat: ProceduralSkyMaterial
var _env: Environment
var _light: DirectionalLight3D
var _sun: MeshInstance3D
var _sun_halo: MeshInstance3D
var _sun_mat: StandardMaterial3D
var _sun_halo_mat: StandardMaterial3D
var _motes: CPUParticles3D
var _weather: Dictionary = {}   # نام → CPUParticles3D (آب‌وهوای هر محیط)
var _weather_zone := -1
var _far_groups: Array[Node3D] = []
var _far_zone := -1

var _facades: Array[StandardMaterial3D] = []
var _walk_mats: Array[StandardMaterial3D] = []
var _curb_mat: StandardMaterial3D
var _cap_mat: StandardMaterial3D
var _pole_mat: StandardMaterial3D
var _lamp_mat: StandardMaterial3D
var _blink_mat: StandardMaterial3D
var _tank_mat: StandardMaterial3D
var _glass_shop_mat: StandardMaterial3D
var _trunk_mat: StandardMaterial3D
var _leaf_mats: Array[StandardMaterial3D] = []
var _tree_city_mats: Array[StandardMaterial3D] = []
var _stone_mat: StandardMaterial3D
var _moss_mat: StandardMaterial3D
var _strata_mats: Array[StandardMaterial3D] = []
var _boulder_mat: StandardMaterial3D
var _cactus_mat: StandardMaterial3D
var _wood_mat: StandardMaterial3D
var _glyph_mat: StandardMaterial3D

# مقادیر فعلی (به‌صورت نرم به مقصد می‌رسند)
var _cur := {}


func _ready() -> void:
	_rng.randomize()
	_build_materials()
	_build_environment()
	_build_ground()
	_build_sun()
	_build_far()
	_build_far_ext()
	_build_motes()
	_build_weather()
	_build_weather_ext()
	_init_cur(0)
	for i in TILE_COUNT:
		var tile := _make_tile()
		tile.position.z = 12.0 - float(i) * TILE_LENGTH
		add_child(tile)
		_tiles.append(tile)
	rebuild_all()


## بعد از شروع بازی تازه: همه‌ی تایل‌ها دوباره بر اساس مسافت فعلی ساخته می‌شوند
func rebuild_all() -> void:
	_init_cur(Game.zone_at(Game.distance + 40.0))
	_apply_cur()
	for t in _tiles:
		_randomize_tile(t)
	_show_far(Game.zone_at(Game.distance + 120.0))


func scroll(delta: float, speed: float) -> void:
	_time += delta
	_blink_mat.emission_energy_multiplier = 3.0 if fmod(_time, 1.3) < 0.25 else 0.2
	var dz := speed * delta
	for tile in _tiles:
		tile.position.z += dz
		while tile.position.z > RECYCLE_Z:
			tile.position.z -= float(TILE_COUNT) * TILE_LENGTH
			_randomize_tile(tile)
	_update_env(delta)


# ------------------------- محیط، آسمان، مه (گذار نرم) -------------------------
func _init_cur(z: int) -> void:
	_cur = {
		"top": SKY_TOP[z], "hor": SKY_HOR[z], "gnd": SKY_GND[z], "fog": FOG_COL[z], "den": FOG_DEN[z],
		"amb": AMB_COL[z], "ambe": AMB_E[z], "lcol": LIGHT_COL[z], "le": LIGHT_E[z], "road": ROAD_TINT[z],
		"ground": GROUND_COL[z], "sun": SUN_COL[z], "sunpos": SUN_POS[z], "sunsize": SUN_SIZE[z],
	}


func _update_env(delta: float) -> void:
	var z := Game.zone_at(Game.distance + 40.0)
	var k := 1.0 - exp(-0.9 * delta)
	var tgt := {
		"top": SKY_TOP[z], "hor": SKY_HOR[z], "gnd": SKY_GND[z], "fog": FOG_COL[z], "den": FOG_DEN[z],
		"amb": AMB_COL[z], "ambe": AMB_E[z], "lcol": LIGHT_COL[z], "le": LIGHT_E[z], "road": ROAD_TINT[z],
		"ground": GROUND_COL[z], "sun": SUN_COL[z], "sunpos": SUN_POS[z], "sunsize": SUN_SIZE[z],
	}
	for key in tgt:
		_cur[key] = lerp(_cur[key], tgt[key], k)
	_apply_cur()
	var fz := Game.zone_at(Game.distance + 120.0)
	if fz != _far_zone:
		_show_far(fz)
	if z != _weather_zone:
		_weather_zone = z
		_set_weather(z)


func _apply_cur() -> void:
	_sky_mat.sky_top_color = _cur["top"]
	_sky_mat.sky_horizon_color = _cur["hor"]
	_sky_mat.ground_horizon_color = _cur["hor"]
	_sky_mat.ground_bottom_color = _cur["gnd"]
	_env.fog_light_color = _cur["fog"]
	_env.fog_density = _cur["den"]
	_env.ambient_light_color = _cur["amb"]
	_env.ambient_light_energy = _cur["ambe"]
	_light.light_color = _cur["lcol"]
	_light.light_energy = _cur["le"]
	_road_mat.albedo_color = _cur["road"]
	_ground_mat.albedo_color = _cur["ground"]
	var sc: Color = _cur["sun"]
	_sun_mat.albedo_color = sc
	_sun_halo_mat.albedo_color = Color(sc.r, sc.g, sc.b, 0.55)
	_sun.position = _cur["sunpos"]
	_sun.scale = Vector3.ONE * float(_cur["sunsize"])
	_sun_halo.position = (_cur["sunpos"] as Vector3) + Vector3(0, 0, 2)
	_sun_halo.scale = Vector3.ONE * float(_cur["sunsize"]) * 5.0
	if _motes != null:
		_motes.color = Color(sc.r, sc.g, sc.b, 0.6)


func _build_environment() -> void:
	_sky_mat = ProceduralSkyMaterial.new()
	_sky_mat.sky_curve = 0.2
	_sky_mat.ground_curve = 0.05
	var sky := Sky.new()
	sky.sky_material = _sky_mat

	_env = Environment.new()
	_env.background_mode = Environment.BG_SKY
	_env.sky = sky
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	_env.fog_enabled = true
	_env.fog_sky_affect = 0.35
	_env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	_env.tonemap_exposure = 1.05

	var we := WorldEnvironment.new()
	we.environment = _env
	add_child(we)

	_light = DirectionalLight3D.new()
	_light.rotation_degrees = Vector3(-48.0, -28.0, 0.0)
	_light.shadow_enabled = false
	_light.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY
	add_child(_light)


func _build_ground() -> void:
	var g := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(600.0, 600.0)
	g.mesh = pm
	_ground_mat = Gfx.mat(Color("5a4540"), 0.0, Gfx.noise_tex(Color.WHITE, 0.08, 64, 77), 1.0)
	_ground_mat.uv1_triplanar = true
	_ground_mat.uv1_scale = Vector3(0.12, 0.12, 0.12)
	g.material_override = _ground_mat
	g.position = Vector3(0.0, -0.08, -150.0)
	add_child(g)


func _build_sun() -> void:
	_sun_mat = StandardMaterial3D.new()
	_sun_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_sun_mat.albedo_color = Color("ffa850")
	_sun_mat.disable_fog = true
	_sun = Gfx.sphere(self, 1.0, Vector3(-26, 15, -175), _sun_mat, 24)
	var halo := Gfx.glow(self, Vector3(-26, 15, -173), 1.0, Color(1, 0.7, 0.4, 0.55))
	_sun_halo = halo
	_sun_halo_mat = (halo.material_override as StandardMaterial3D).duplicate() as StandardMaterial3D
	_sun_halo_mat.disable_fog = true
	halo.material_override = _sun_halo_mat


## ذرات معلق نورانی (گرد و غبار طلایی / گرده / جرقه‌ی غروب)
func _build_motes() -> void:
	_motes = CPUParticles3D.new()
	_motes.amount = 70
	_motes.lifetime = 4.0
	_motes.preprocess = 4.0
	_motes.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_motes.emission_box_extents = Vector3(10.0, 3.0, 22.0)
	_motes.direction = Vector3(0.0, 1.0, 0.0)
	_motes.spread = 60.0
	_motes.initial_velocity_min = 0.2
	_motes.initial_velocity_max = 0.9
	_motes.gravity = Vector3(0.0, 0.1, 0.0)
	_motes.scale_amount_min = 0.5
	_motes.scale_amount_max = 1.4
	var sm := SphereMesh.new()
	sm.radius = 0.05
	sm.height = 0.1
	sm.radial_segments = 6
	sm.rings = 3
	var mm := StandardMaterial3D.new()
	mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mm.vertex_color_use_as_albedo = true
	mm.albedo_color = Color.WHITE
	sm.material = mm
	_motes.mesh = sm
	_motes.position = Vector3(0.0, 3.0, -12.0)
	_motes.visibility_aabb = AABB(Vector3(-14, -6, -30), Vector3(28, 14, 60))
	add_child(_motes)


# ------------------------- آب‌وهوا: هر محیط جلوه‌ی خودش را دارد -------------------------
func _make_emitter(nm: String, amount: int, life: float, ext: Vector3, mesh: Mesh, pos: Vector3) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.amount = amount
	p.lifetime = life
	p.preprocess = life
	p.emitting = false
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = ext
	p.mesh = mesh
	p.position = pos
	p.visibility_aabb = AABB(Vector3(-20, -8, -40), Vector3(40, 20, 80))
	add_child(p)
	_weather[nm] = p
	return p


func _unshaded(c: Color, additive: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = c
	m.vertex_color_use_as_albedo = true
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if additive:
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.disable_fog = additive
	return m


func _build_weather() -> void:
	# شهر: جرقه‌ها و گرده‌های گرم که بالا می‌روند
	var sp := SphereMesh.new()
	sp.radius = 0.04
	sp.height = 0.08
	sp.radial_segments = 6
	sp.rings = 3
	sp.material = _unshaded(Color(1.0, 0.75, 0.3, 0.9), true)
	var emb := _make_emitter("embers", 60, 3.5, Vector3(9.0, 1.0, 20.0), sp, Vector3(0.0, 0.5, -12.0))
	emb.direction = Vector3(0, 1, 0)
	emb.spread = 35.0
	emb.initial_velocity_min = 0.8
	emb.initial_velocity_max = 2.0
	emb.gravity = Vector3(0.0, 0.2, 0.0)
	emb.scale_amount_min = 0.6
	emb.scale_amount_max = 1.6
	# صحرا: خطوط شنِ باد
	var bm := BoxMesh.new()
	bm.size = Vector3(0.9, 0.012, 0.012)
	bm.material = _unshaded(Color(0.95, 0.82, 0.55, 0.55))
	var sand := _make_emitter("sand", 90, 1.6, Vector3(2.0, 2.5, 22.0), bm, Vector3(10.0, 2.5, -12.0))
	sand.direction = Vector3(-1, 0, 0.15)
	sand.spread = 4.0
	sand.initial_velocity_min = 11.0
	sand.initial_velocity_max = 17.0
	sand.gravity = Vector3.ZERO
	sand.scale_amount_min = 0.7
	sand.scale_amount_max = 2.0
	# جنگل: برگ‌های در حال افتادن
	var qm := QuadMesh.new()
	qm.size = Vector2(0.14, 0.09)
	var lm := _unshaded(Color(0.55, 0.85, 0.3, 0.95))
	lm.cull_mode = BaseMaterial3D.CULL_DISABLED
	qm.material = lm
	var leaves := _make_emitter("leaves", 45, 5.0, Vector3(9.0, 0.5, 20.0), qm, Vector3(0.0, 7.0, -12.0))
	leaves.direction = Vector3(0.3, -1, 0.2)
	leaves.spread = 25.0
	leaves.initial_velocity_min = 0.6
	leaves.initial_velocity_max = 1.5
	leaves.gravity = Vector3(0.0, -0.7, 0.0)
	leaves.angle_min = 0.0
	leaves.angle_max = 360.0
	leaves.angular_velocity_min = -120.0
	leaves.angular_velocity_max = 120.0
	var lg := Gradient.new()
	lg.set_color(0, Color("7fd23a"))
	lg.set_color(1, Color("e8a23a"))
	leaves.color_initial_ramp = lg
	# جنگل: کرم شب‌تاب
	var fm := SphereMesh.new()
	fm.radius = 0.06
	fm.height = 0.12
	fm.radial_segments = 6
	fm.rings = 3
	fm.material = _unshaded(Color(0.85, 1.0, 0.4, 0.95), true)
	var ff := _make_emitter("fireflies", 36, 4.0, Vector3(8.0, 1.2, 18.0), fm, Vector3(0.0, 1.6, -12.0))
	ff.direction = Vector3(0, 1, 0)
	ff.spread = 180.0
	ff.initial_velocity_min = 0.2
	ff.initial_velocity_max = 0.7
	ff.gravity = Vector3.ZERO
	ff.scale_amount_min = 0.8
	ff.scale_amount_max = 1.8
	var fg := Gradient.new()
	fg.set_color(0, Color(0.85, 1.0, 0.4, 0.0))
	fg.add_point(0.3, Color(0.85, 1.0, 0.4, 1.0))
	fg.set_color(1, Color(0.85, 1.0, 0.4, 0.0))
	ff.color_ramp = fg


func _build_weather_ext() -> void:
	# برف: دانه‌های نرم که کج می‌افتند
	var sm := SphereMesh.new()
	sm.radius = 0.035
	sm.height = 0.07
	sm.radial_segments = 6
	sm.rings = 3
	sm.material = _unshaded(Color(1.0, 1.0, 1.0, 0.9))
	var snow := _make_emitter("snow", 220, 5.0, Vector3(10.0, 0.5, 22.0), sm, Vector3(0.0, 8.0, -12.0))
	snow.direction = Vector3(0.15, -1, 0.05)
	snow.spread = 14.0
	snow.initial_velocity_min = 1.4
	snow.initial_velocity_max = 2.6
	snow.gravity = Vector3(0.0, -0.4, 0.0)
	snow.scale_amount_min = 0.6
	snow.scale_amount_max = 1.8
	# باران بندر: رگه‌های باریک سریع
	var rm := BoxMesh.new()
	rm.size = Vector3(0.012, 0.55, 0.012)
	rm.material = _unshaded(Color(0.75, 0.85, 1.0, 0.45))
	var rain := _make_emitter("rain", 260, 0.9, Vector3(11.0, 0.5, 22.0), rm, Vector3(0.0, 9.0, -12.0))
	rain.direction = Vector3(-0.12, -1, 0.0)
	rain.spread = 3.0
	rain.initial_velocity_min = 16.0
	rain.initial_velocity_max = 20.0
	rain.gravity = Vector3(0.0, -6.0, 0.0)
	# آتشفشان: خاکستر و جرقه‌ی داغ
	var am := QuadMesh.new()
	am.size = Vector2(0.1, 0.07)
	var amat := _unshaded(Color(0.55, 0.52, 0.5, 0.7))
	amat.cull_mode = BaseMaterial3D.CULL_DISABLED
	am.material = amat
	var ash := _make_emitter("ash", 90, 6.0, Vector3(10.0, 0.5, 22.0), am, Vector3(0.0, 8.0, -12.0))
	ash.direction = Vector3(0.3, -1, 0.1)
	ash.spread = 25.0
	ash.initial_velocity_min = 0.5
	ash.initial_velocity_max = 1.4
	ash.gravity = Vector3(0.0, -0.5, 0.0)
	ash.angle_max = 360.0
	ash.angular_velocity_min = -90.0
	ash.angular_velocity_max = 90.0
	var em := SphereMesh.new()
	em.radius = 0.05
	em.height = 0.1
	em.radial_segments = 6
	em.rings = 3
	em.material = _unshaded(Color(1.0, 0.5, 0.15, 0.95), true)
	var lav := _make_emitter("lava_embers", 80, 4.0, Vector3(10.0, 0.5, 22.0), em, Vector3(0.0, 0.3, -12.0))
	lav.direction = Vector3(0, 1, 0)
	lav.spread = 30.0
	lav.initial_velocity_min = 1.5
	lav.initial_velocity_max = 4.0
	lav.gravity = Vector3(0.0, 0.3, 0.0)
	lav.scale_amount_min = 0.5
	lav.scale_amount_max = 1.8


func _set_weather(z: int) -> void:
	var on := {0: ["embers"], 1: ["sand"], 2: ["leaves", "fireflies"], 3: ["snow"], 4: ["rain"], 5: ["ash", "lava_embers"]}
	for k in _weather:
		(_weather[k] as CPUParticles3D).emitting = (on[z] as Array).has(k)


# ------------------------- مصالح -------------------------
func _build_materials() -> void:
	_road_mat = Gfx.mat(Color.WHITE, 0.0, Gfx.road_tex(), 1.0)
	_road_mat.roughness_texture = Gfx.road_rough_tex()
	_road_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC

	# شهر: نمای رنگی گرم با پنجره‌های روشن
	var palette: Array = [Color("ffd27a"), Color("ffb347"), Color("fff0b8"), Color("ff9a6a")]
	for i in WALL_COLORS.size():
		for v in 2:
			var tex: Array = Gfx.facade_tex(200 + i * 2 + v, 0.3 + v * 0.18, palette, WALL_COLORS[i], Color("3d4d7a"))
			var m := StandardMaterial3D.new()
			m.albedo_texture = tex[0]
			m.uv1_triplanar = true
			m.uv1_scale = Vector3(0.125, 0.0625, 0.125)
			m.emission_enabled = true
			m.emission = Color.BLACK
			m.emission_texture = tex[1]
			m.emission_energy_multiplier = 1.1
			m.roughness = 0.9
			m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
			_facades.append(m)

	var walk_city := Gfx.mat(Color("d9c6b4"), 0.0, Gfx.paving_tex(), 0.9)
	walk_city.uv1_triplanar = true
	walk_city.uv1_scale = Vector3(0.35, 0.35, 0.35)
	var walk_sand := Gfx.mat(Color("e6c487"), 0.0, Gfx.noise_tex(Color.WHITE, 0.08, 32, 5), 1.0)
	walk_sand.uv1_triplanar = true
	walk_sand.uv1_scale = Vector3(0.3, 0.3, 0.3)
	var walk_moss := Gfx.mat(Color("5a8a3c"), 0.0, Gfx.noise_tex(Color.WHITE, 0.14, 32, 6), 1.0)
	walk_moss.uv1_triplanar = true
	walk_moss.uv1_scale = Vector3(0.3, 0.3, 0.3)
	var walk_snow := Gfx.mat(Color("f2f6ff"), 0.05, Gfx.noise_tex(Color.WHITE, 0.05, 32, 15), 0.95)
	walk_snow.uv1_triplanar = true
	walk_snow.uv1_scale = Vector3(0.3, 0.3, 0.3)
	var walk_dock := Gfx.mat(Color("8a95a6"), 0.0, Gfx.paving_tex(), 0.5)
	walk_dock.uv1_triplanar = true
	walk_dock.uv1_scale = Vector3(0.35, 0.35, 0.35)
	var walk_rock := Gfx.mat(Color("2c2830"), 0.0, Gfx.noise_tex(Color.WHITE, 0.18, 32, 16), 0.95)
	walk_rock.uv1_triplanar = true
	walk_rock.uv1_scale = Vector3(0.3, 0.3, 0.3)
	_walk_mats = [walk_city, walk_sand, walk_moss, walk_snow, walk_dock, walk_rock]

	_curb_mat = Gfx.mat(Color("ffb05a"), 1.3, null, 0.4)
	_cap_mat = Gfx.mat(Color("4a3a40"), 0.0, null, 0.9)
	_pole_mat = Gfx.mat(Color("5a4a50"), 0.0, null, 0.5)
	_pole_mat.metallic = 0.4
	_lamp_mat = Gfx.mat(Color("ffd79a"), 2.4, null, 0.3)
	_blink_mat = Gfx.mat(Color("ff3a2a"), 3.0, null, 0.3)
	_tank_mat = Gfx.mat(Color("7a6a62"), 0.0, null, 0.7)
	_glass_shop_mat = Gfx.mat(Color("ffd890"), 1.4, null, 0.3)
	for c in [Color("6f9a3a"), Color("e0a030"), Color("4e8a45")]:
		_tree_city_mats.append(Gfx.mat(c, 0.0, null, 0.9))

	# صحرا
	_strata_mats = [
		_tri(Gfx.mat(Color.WHITE, 0.0, Gfx.strata_tex(Color("d98a52"), Color("a64f33"), 3), 1.0), 0.09),
		_tri(Gfx.mat(Color.WHITE, 0.0, Gfx.strata_tex(Color("e8b070"), Color("c9783f"), 4), 1.0), 0.09),
		_tri(Gfx.mat(Color.WHITE, 0.0, Gfx.strata_tex(Color("cf7a4a"), Color("8f3f2a"), 5), 1.0), 0.09),
	]
	_boulder_mat = Gfx.mat(Color("b88a5a"), 0.0, Gfx.noise_tex(Color.WHITE, 0.12, 32, 8), 1.0)
	_cactus_mat = Gfx.mat(Color("4f9a50"), 0.0, null, 0.8)
	_wood_mat = Gfx.mat(Color("8a5f3a"), 0.0, Gfx.bark_tex(), 0.9)

	# جنگل و معبد
	_trunk_mat = Gfx.mat(Color.WHITE, 0.0, Gfx.bark_tex(), 0.95)
	for c in [Color("3f9a3a"), Color("5db04a"), Color("2f7f3f")]:
		_leaf_mats.append(Gfx.mat(c, 0.0, Gfx.noise_tex(Color.WHITE, 0.1, 32, 12), 0.9))
	_stone_mat = Gfx.mat(Color.WHITE, 0.0, Gfx.stone_tex(), 0.95)
	_stone_mat.uv1_triplanar = true
	_stone_mat.uv1_scale = Vector3(0.4, 0.4, 0.4)
	_moss_mat = Gfx.mat(Color("5a9a3a"), 0.0, null, 1.0)
	_glyph_mat = Gfx.mat(Color("ffb040"), 2.2, null, 0.4)


func _tri(m: StandardMaterial3D, s: float) -> StandardMaterial3D:
	m.uv1_triplanar = true
	m.uv1_scale = Vector3(s, s, s)
	return m


# ------------------------- افق دور (برای هر محیط یک مجموعه) -------------------------
func _build_far() -> void:
	for z in 6:
		var g := Node3D.new()
		g.position = Vector3(0.0, 0.0, -215.0)
		g.visible = false
		add_child(g)
		_far_groups.append(g)
	# شهر: برج‌های سیلوئت گرم
	var cm := Gfx.mat(Color("8a5a72"), 0.0, null, 1.0)
	var x := -160.0
	while x < 160.0:
		var w := _rng.randf_range(10.0, 22.0)
		var h := _rng.randf_range(20.0, 70.0)
		Gfx.box(_far_groups[0], Vector3(w, h, 14.0), Vector3(x + w * 0.5, h * 0.5, _rng.randf_range(-10.0, 10.0)), cm)
		x += w + _rng.randf_range(0.0, 5.0)
	# صحرا: کوه‌های میزی و تپه‌های شنی
	x = -170.0
	while x < 170.0:
		var w := _rng.randf_range(18.0, 40.0)
		var h := _rng.randf_range(10.0, 34.0)
		Gfx.box(_far_groups[1], Vector3(w, h, 20.0), Vector3(x + w * 0.5, h * 0.5, _rng.randf_range(-8.0, 8.0)), _strata_mats[_rng.randi() % 3])
		var d := Gfx.sphere(_far_groups[1], 1.0, Vector3(x + w * 0.5 + _rng.randf_range(-10, 10), 0.0, 14.0), _walk_mats[1], 12)
		d.scale = Vector3(w * 0.9, _rng.randf_range(5.0, 11.0), 16.0)
		x += w + _rng.randf_range(0.0, 8.0)
	# جنگل: تپه‌های سبز و یک معبد پله‌ای
	x = -170.0
	while x < 170.0:
		var w := _rng.randf_range(24.0, 50.0)
		var s := Gfx.sphere(_far_groups[2], 1.0, Vector3(x + w * 0.5, 0.0, _rng.randf_range(-6.0, 6.0)), _leaf_mats[_rng.randi() % 3], 14)
		s.scale = Vector3(w * 0.6, _rng.randf_range(14.0, 34.0), 22.0)
		x += w * 0.8
	for i in 5:
		Gfx.box(_far_groups[2], Vector3(30.0 - i * 5.0, 5.0, 30.0 - i * 5.0), Vector3(30.0, 2.5 + i * 5.0, 10.0), _stone_mat)


func _build_far_ext() -> void:
	# برف: کوه‌های قله‌سفید
	var rock := Gfx.mat(Color("7f8da3"), 0.0, null, 1.0)
	var snow := Gfx.mat(Color("f4f8ff"), 0.1, null, 0.95)
	var x := -190.0
	while x < 190.0:
		var h := _rng.randf_range(35.0, 80.0)
		var r := h * _rng.randf_range(0.6, 0.9)
		var zz := _rng.randf_range(-12.0, 12.0)
		Gfx.cyl(_far_groups[3], 0.001, r, h, Vector3(x, h * 0.5, zz), rock, Vector3.ZERO, 7)
		Gfx.cyl(_far_groups[3], 0.001, r * 0.45, h * 0.42, Vector3(x, h * 0.79, zz), snow, Vector3.ZERO, 7)
		x += r * 1.1
	# بندر شبانه: جرثقیل‌ها، انبارها با پنجره‌ی روشن و کشتی‌ها
	var dark := Gfx.mat(Color("141b33"), 0.0, null, 0.9)
	var lit := Gfx.mat(Color("ffd27a"), 2.2, null, 0.5)
	var red := Gfx.mat(Color("ff3a2a"), 3.0, null, 0.5)
	x = -170.0
	while x < 170.0:
		var w := _rng.randf_range(12.0, 26.0)
		var h := _rng.randf_range(8.0, 22.0)
		Gfx.box(_far_groups[4], Vector3(w, h, 12.0), Vector3(x + w * 0.5, h * 0.5, _rng.randf_range(-6.0, 6.0)), dark)
		for k in _rng.randi_range(2, 6):
			Gfx.box(_far_groups[4], Vector3(1.2, 1.0, 0.3), Vector3(x + _rng.randf_range(1.0, w - 1.0), _rng.randf_range(2.0, h - 1.0), 6.3), lit)
		x += w + _rng.randf_range(2.0, 14.0)
	for cx in [-90.0, -20.0, 70.0, 130.0]:
		var ch := _rng.randf_range(34.0, 48.0)
		Gfx.box(_far_groups[4], Vector3(1.6, ch, 1.6), Vector3(cx, ch * 0.5, 16.0), dark)
		Gfx.box(_far_groups[4], Vector3(1.6, ch, 1.6), Vector3(cx + 7.0, ch * 0.5, 16.0), dark)
		Gfx.box(_far_groups[4], Vector3(34.0, 1.6, 1.6), Vector3(cx + 3.0, ch, 16.0), dark)
		Gfx.box(_far_groups[4], Vector3(0.5, 0.5, 0.5), Vector3(cx + 3.0, ch + 1.4, 16.0), red)
	for sx in [-120.0, 40.0]:
		Gfx.box(_far_groups[4], Vector3(40.0, 7.0, 10.0), Vector3(sx, 3.5, 22.0), dark)
		Gfx.box(_far_groups[4], Vector3(10.0, 8.0, 8.0), Vector3(sx + 10.0, 10.0, 22.0), dark)
		Gfx.box(_far_groups[4], Vector3(1.0, 0.8, 0.3), Vector3(sx + 10.0, 10.0, 26.2), lit)
	# آتشفشان: مخروط بزرگ با دهانه‌ی درخشان
	var vrock := Gfx.mat(Color("2a1c1c"), 0.0, null, 1.0)
	var vlava := Gfx.mat(Color("ff5a14"), 3.0, null, 0.5)
	Gfx.cyl(_far_groups[5], 14.0, 70.0, 70.0, Vector3(-30.0, 35.0, 0.0), vrock, Vector3.ZERO, 12)
	Gfx.cyl(_far_groups[5], 11.0, 11.0, 3.0, Vector3(-30.0, 70.0, 0.0), vlava, Vector3.ZERO, 12)
	Gfx.glow(_far_groups[5], Vector3(-30.0, 78.0, 6.0), 80.0, Color(1.0, 0.4, 0.1, 0.7))
	for k in 4:
		var px := -30.0 + 12.0 + k * 3.0
		Gfx.box(_far_groups[5], Vector3(1.6, 40.0 - k * 5.0, 1.6), Vector3(px, 38.0 - k * 4.0, 36.0), vlava).rotation_degrees = Vector3(0, 0, -28 + k * 6)
	x = -190.0
	while x < 190.0:
		var h2 := _rng.randf_range(10.0, 30.0)
		var r2 := h2 * _rng.randf_range(1.0, 1.6)
		Gfx.cyl(_far_groups[5], 0.001, r2, h2, Vector3(x, h2 * 0.5, _rng.randf_range(8.0, 24.0)), vrock, Vector3.ZERO, 6)
		x += r2 * 1.3
	for k in 7:
		Gfx.box(_far_groups[5], Vector3(_rng.randf_range(10, 30), 0.3, 0.3), Vector3(_rng.randf_range(-150, 150), 0.2, _rng.randf_range(20.0, 40.0)), vlava)


func _show_far(z: int) -> void:
	_far_zone = z
	for i in _far_groups.size():
		_far_groups[i].visible = i == z


# ------------------------- تایل‌ها -------------------------
func _make_tile() -> Node3D:
	var tile := Node3D.new()
	var road := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(ROAD_WIDTH, TILE_LENGTH)
	road.mesh = pm
	road.material_override = _road_mat
	tile.add_child(road)

	var half := ROAD_WIDTH * 0.5
	var walks: Array[MeshInstance3D] = []
	var curbs: Array[MeshInstance3D] = []
	var lamps := Node3D.new()
	tile.add_child(lamps)
	for side: int in [-1, 1]:
		var w := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(SHOULDER_W, 0.2, TILE_LENGTH)
		w.mesh = bm
		w.position = Vector3(side * (half + SHOULDER_W * 0.5), 0.1, 0.0)
		tile.add_child(w)
		walks.append(w)
		curbs.append(Gfx.box(tile, Vector3(0.1, 0.06, TILE_LENGTH), Vector3(side * (half + 0.05), 0.23, 0.0), _curb_mat))
		_make_lamp(lamps, side, -6.0 if side < 0 else 6.0)
	tile.set_meta("walks", walks)
	tile.set_meta("curbs", curbs)
	tile.set_meta("lamps", lamps)
	var decor := Node3D.new()
	decor.name = "decor"
	tile.add_child(decor)
	return tile


func _make_lamp(parent: Node3D, side: int, z: float) -> void:
	var lamp := Node3D.new()
	lamp.position = Vector3(side * (ROAD_WIDTH * 0.5 + 0.7), 0.0, z)
	parent.add_child(lamp)
	Gfx.cyl(lamp, 0.07, 0.1, 5.4, Vector3(0.0, 2.7, 0.0), _pole_mat, Vector3.ZERO, 8)
	Gfx.box(lamp, Vector3(1.5, 0.08, 0.1), Vector3(-side * 0.7, 5.35, 0.0), _pole_mat)
	Gfx.box(lamp, Vector3(0.5, 0.1, 0.22), Vector3(-side * 1.4, 5.3, 0.0), _lamp_mat)
	Gfx.glow(lamp, Vector3(-side * 1.4, 5.2, 0.2), 2.6, Color(1.0, 0.75, 0.4, 0.35))
	Gfx.pool(lamp, Vector3(-side * 1.5, -0.15, 0.0), Vector2(5.5, 7.5), Color(1.0, 0.7, 0.35, 0.22))


func _randomize_tile(tile: Node3D) -> void:
	var z := Game.zone_at(Game.distance - tile.position.z)
	var walks: Array = tile.get_meta("walks")
	for w in walks:
		var mi := w as MeshInstance3D
		var bm := mi.mesh as BoxMesh
		var hgt := 0.2 if (z == 0 or z == 4) else 0.06
		bm.size = Vector3(SHOULDER_W, hgt, TILE_LENGTH)
		mi.position.y = hgt * 0.5
		mi.material_override = _walk_mats[z]
	for c in tile.get_meta("curbs"):
		(c as MeshInstance3D).visible = z == 0 or z == 4
	(tile.get_meta("lamps") as Node3D).visible = z == 0 or z == 4

	var old := tile.get_node("decor")
	tile.remove_child(old)
	old.queue_free()
	var decor := Node3D.new()
	decor.name = "decor"
	tile.add_child(decor)
	match z:
		0:
			_decor_city(decor)
		1:
			_decor_desert(decor)
		2:
			_decor_jungle(decor)
		3:
			_decor_snow(decor)
		4:
			_decor_harbor(decor)
		_:
			_decor_volcano(decor)


# ------------------------- تزئینات شهر -------------------------
func _decor_city(parent: Node3D) -> void:
	for side: int in [-1, 1]:
		for slot in 2:
			var width := _rng.randf_range(5.0, 9.5)
			var depth := _rng.randf_range(8.5, 11.0)
			var height := _rng.randf_range(8.0, 30.0)
			var inner := ROAD_WIDTH * 0.5 + SHOULDER_W + 0.3 + _rng.randf_range(0.0, 2.2)
			var b := Node3D.new()
			b.position = Vector3(side * (inner + width * 0.5), 0.0, (-6.0 if slot == 0 else 6.0) + _rng.randf_range(-1.5, 1.5))
			parent.add_child(b)
			var dir := -float(side)
			Gfx.box(b, Vector3(width, height, depth), Vector3(0.0, height * 0.5 - 0.05, 0.0), _facades[_rng.randi() % _facades.size()])
			Gfx.box(b, Vector3(width + 0.4, 0.5, depth + 0.4), Vector3(0.0, height + 0.2, 0.0), _cap_mat)
			# پشت‌بام
			var r := _rng.randi() % 4
			if r == 0:
				Gfx.box(b, Vector3(1.6, 0.9, 1.2), Vector3(_rng.randf_range(-1, 1), height + 0.9, 0.0), _tank_mat)
				Gfx.box(b, Vector3(1.0, 0.7, 1.0), Vector3(_rng.randf_range(-2, 2), height + 0.8, _rng.randf_range(-2, 2)), _tank_mat)
			elif r == 1:
				Gfx.cyl(b, 0.9, 0.9, 1.5, Vector3(0.0, height + 1.2, 0.0), _tank_mat, Vector3.ZERO, 10)
			elif r == 2:
				Gfx.cyl(b, 0.05, 0.08, 6.0, Vector3(0.0, height + 3.2, 0.0), _pole_mat, Vector3.ZERO, 6)
				Gfx.sphere(b, 0.16, Vector3(0.0, height + 6.2, 0.0), _blink_mat, 6)
			# مغازه‌ی طبقه‌ی همکف: ویترین گرم و سایبان رنگی
			Gfx.box(b, Vector3(0.06, 2.2, depth * 0.62), Vector3(dir * (width * 0.5 + 0.03), 1.6, 0.0), _glass_shop_mat)
			var awn := Gfx.mat(AWNING_COLORS[_rng.randi() % AWNING_COLORS.size()], 0.15, null, 0.8)
			Gfx.box(b, Vector3(1.1, 0.14, depth * 0.7), Vector3(dir * (width * 0.5 + 0.5), 3.1, 0.0), awn, Vector3(0.0, 0.0, -dir * 18.0))
			if _rng.randf() < 0.55:
				var lbl := Gfx.label(b, SIGN_WORDS[_rng.randi() % SIGN_WORDS.size()], Vector3(dir * (width * 0.5 + 0.1), 4.2 + _rng.randf_range(0.0, 2.0), _rng.randf_range(-1.5, 1.5)), 52, AWNING_COLORS[_rng.randi() % AWNING_COLORS.size()].lightened(0.3), 0.014, Vector3(0.0, 90.0 if dir > 0.0 else -90.0, 0.0))
				lbl.double_sided = false
			# درخت پیاده‌رو
			if _rng.randf() < 0.55:
				var tx := side * (ROAD_WIDTH * 0.5 + 1.1)
				var tz := (-6.0 if slot == 0 else 6.0) + _rng.randf_range(-4.0, 4.0)
				var t := Node3D.new()
				t.position = Vector3(tx - b.position.x, 0.0, tz - b.position.z)
				b.add_child(t)
				Gfx.cyl(t, 0.1, 0.14, 1.8, Vector3(0.0, 1.0, 0.0), _wood_mat, Vector3.ZERO, 6)
				var lm := _tree_city_mats[_rng.randi() % _tree_city_mats.size()]
				Gfx.sphere(t, 1.0, Vector3(0.0, 2.5, 0.0), lm, 8)
				Gfx.sphere(t, 0.7, Vector3(0.5, 3.1, 0.2), lm, 8)


# ------------------------- تزئینات صحرا -------------------------
func _decor_desert(parent: Node3D) -> void:
	for side: int in [-1, 1]:
		for slot in 2:
			var z0 := (-6.0 if slot == 0 else 6.0) + _rng.randf_range(-1.5, 1.5)
			var width := _rng.randf_range(6.0, 12.0)
			var height := _rng.randf_range(5.0, 18.0)
			var depth := _rng.randf_range(8.0, 11.0)
			var x := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 2.0 + _rng.randf_range(0.5, 6.0) + width * 0.5)
			var sm := _strata_mats[_rng.randi() % _strata_mats.size()]
			Gfx.box(parent, Vector3(width, height, depth), Vector3(x, height * 0.5 - 0.05, z0), sm)
			Gfx.box(parent, Vector3(width * 0.55, height * 0.45, depth * 0.7), Vector3(x - side * width * 0.3, height + height * 0.22, z0), sm)
			Gfx.box(parent, Vector3(width + 0.3, 0.4, depth + 0.3), Vector3(x, height * 0.55, z0), sm)
			# نزدیک جاده
			var nx := side * (ROAD_WIDTH * 0.5 + 1.2 + _rng.randf_range(0.0, 1.2))
			var nz := z0 + _rng.randf_range(-4.0, 4.0)
			var r := _rng.randf()
			if r < 0.45:
				_cactus(parent, Vector3(nx, 0.0, nz))
			elif r < 0.8:
				for i in _rng.randi_range(1, 3):
					var s := Gfx.sphere(parent, 1.0, Vector3(nx + _rng.randf_range(-0.8, 0.8), 0.3, nz + _rng.randf_range(-0.8, 0.8)), _boulder_mat, 8)
					var k := _rng.randf_range(0.4, 0.9)
					s.scale = Vector3(k * 1.2, k * 0.8, k)
			else:
				Gfx.cyl(parent, 0.1, 0.12, 4.5, Vector3(nx, 2.25, nz), _wood_mat, Vector3.ZERO, 6)
				Gfx.box(parent, Vector3(1.3, 0.1, 0.1), Vector3(nx, 4.2, nz), _wood_mat)


func _cactus(parent: Node3D, p: Vector3) -> void:
	var h := _rng.randf_range(1.6, 2.6)
	Gfx.cyl(parent, 0.22, 0.26, h, p + Vector3(0.0, h * 0.5, 0.0), _cactus_mat, Vector3.ZERO, 8)
	Gfx.sphere(parent, 0.22, p + Vector3(0.0, h, 0.0), _cactus_mat, 8)
	for s in [-1.0, 1.0]:
		if _rng.randf() < 0.75:
			var ay := h * _rng.randf_range(0.4, 0.65)
			Gfx.cyl(parent, 0.14, 0.14, 0.6, p + Vector3(s * 0.45, ay, 0.0), _cactus_mat, Vector3(0.0, 0.0, 90.0), 8)
			Gfx.cyl(parent, 0.14, 0.14, 0.7, p + Vector3(s * 0.72, ay + 0.35, 0.0), _cactus_mat, Vector3.ZERO, 8)


# ------------------------- تزئینات جنگل و معبد -------------------------
func _decor_jungle(parent: Node3D) -> void:
	for side: int in [-1, 1]:
		for slot in 2:
			var z0 := (-6.0 if slot == 0 else 6.0) + _rng.randf_range(-2.0, 2.0)
			# درخت‌های بزرگ
			for layer in 2:
				var x := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 1.0 + layer * 5.0 + _rng.randf_range(0.0, 3.0))
				var h := _rng.randf_range(8.0, 15.0) + layer * 3.0
				var rad := _rng.randf_range(0.5, 0.9)
				var tz := z0 + _rng.randf_range(-3.0, 3.0)
				Gfx.cyl(parent, rad * 0.75, rad, h, Vector3(x, h * 0.5, tz), _trunk_mat, Vector3.ZERO, 8)
				for k in 3:
					var a := _rng.randf() * TAU
					Gfx.box(parent, Vector3(0.35, 0.9, 1.1), Vector3(x + cos(a) * rad, 0.4, tz + sin(a) * rad), _trunk_mat, Vector3(0.0, -rad_to_deg(a), 0.0))
				for k in _rng.randi_range(3, 5):
					var cr := _rng.randf_range(2.2, 3.6)
					Gfx.sphere(parent, cr, Vector3(x + _rng.randf_range(-2.0, 2.0), h + _rng.randf_range(-1.5, 1.0), tz + _rng.randf_range(-2.0, 2.0)), _leaf_mats[_rng.randi() % 3], 9)
			# بوته‌ها و سرخس کنار جاده
			for i in _rng.randi_range(1, 3):
				var bx := side * (ROAD_WIDTH * 0.5 + 1.0 + _rng.randf_range(0.0, 1.8))
				var b := Gfx.sphere(parent, 1.0, Vector3(bx, 0.35, z0 + _rng.randf_range(-6.0, 6.0)), _leaf_mats[_rng.randi() % 3], 8)
				var s := _rng.randf_range(0.5, 1.0)
				b.scale = Vector3(s * 1.1, s * 0.7, s)
			# خرابه‌ی معبد
			if _rng.randf() < 0.4:
				var px := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 0.9)
				var pz := z0 + _rng.randf_range(-4.0, 4.0)
				var ph := _rng.randf_range(2.5, 5.0)
				Gfx.box(parent, Vector3(1.1, ph, 1.1), Vector3(px, ph * 0.5, pz), _stone_mat)
				Gfx.box(parent, Vector3(1.4, 0.3, 1.4), Vector3(px, ph + 0.15, pz), _stone_mat)
				Gfx.sphere(parent, 0.7, Vector3(px, ph + 0.2, pz), _moss_mat, 8).scale = Vector3(1.2, 0.5, 1.2)
				Gfx.box(parent, Vector3(0.06, 0.6, 0.5), Vector3(px - side * 0.56, ph * 0.6, pz), _glyph_mat)
			if _rng.randf() < 0.3:
				Gfx.glow(parent, Vector3(side * 7.0, 8.0, z0), 9.0, Color(1.0, 0.92, 0.5, 0.16))


# ------------------------- کوهستان برفی -------------------------
func _pine(parent: Node3D, p: Vector3, h: float) -> void:
	var bark := Props.m("4a3524", 0.0, 1.0)
	var pine := Props.m("1f5a35", 0.0, 1.0)
	var snow := Props.m("f2f7ff", 0.1, 0.95)
	Gfx.cyl(parent, 0.12 * h * 0.2, 0.18 * h * 0.2, h * 0.25, p + Vector3(0, h * 0.12, 0), bark, Vector3.ZERO, 6)
	for k in 4:
		var r := h * (0.34 - k * 0.07)
		var y := h * (0.2 + k * 0.2)
		Gfx.cyl(parent, 0.001, r, h * 0.3, p + Vector3(0, y + h * 0.15, 0), pine, Vector3.ZERO, 8)
		Gfx.cyl(parent, 0.001, r * 0.8, h * 0.14, p + Vector3(0, y + h * 0.26, 0), snow, Vector3.ZERO, 8)


func _decor_snow(parent: Node3D) -> void:
	var rock := Props.m("6d7078", 0.0, 0.95)
	var snow := Props.m("f2f7ff", 0.1, 0.95)
	var wood := Props.m("7a5230", 0.0, 0.9)
	for side: int in [-1, 1]:
		for slot in 2:
			var z0 := (-6.0 if slot == 0 else 6.0) + _rng.randf_range(-2.0, 2.0)
			# کوه‌ها و تپه‌های برفی نزدیک
			var w := _rng.randf_range(8.0, 16.0)
			var h := _rng.randf_range(6.0, 16.0)
			var x := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 4.0 + _rng.randf_range(0.0, 6.0) + w * 0.5)
			Gfx.cyl(parent, 0.001, w * 0.8, h, Vector3(x, h * 0.5, z0), rock, Vector3.ZERO, 6)
			Gfx.cyl(parent, 0.001, w * 0.4, h * 0.45, Vector3(x, h * 0.78, z0), snow, Vector3.ZERO, 6)
			# کاج‌ها
			for i in _rng.randi_range(2, 4):
				var px := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 0.8 + _rng.randf_range(0.0, 7.0))
				_pine(parent, Vector3(px, 0.0, z0 + _rng.randf_range(-5.0, 5.0)), _rng.randf_range(3.5, 8.5))
			# صخره و تپه‌ی برف کنار جاده
			var bx := side * (ROAD_WIDTH * 0.5 + 1.0 + _rng.randf_range(0.0, 1.6))
			var bz := z0 + _rng.randf_range(-5.0, 5.0)
			var m := Gfx.sphere(parent, 1.0, Vector3(bx, 0.2, bz), snow, 8)
			var k := _rng.randf_range(0.5, 1.1)
			m.scale = Vector3(k * 1.3, k * 0.5, k)
			if _rng.randf() < 0.5:
				var r := Gfx.sphere(parent, 1.0, Vector3(bx + 0.3, 0.4, bz + 0.2), rock, 7)
				r.scale = Vector3(0.45, 0.4, 0.4)
			# تیر برق چوبی / کلبه
			if _rng.randf() < 0.35:
				var tx := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 0.7)
				Gfx.cyl(parent, 0.08, 0.1, 5.0, Vector3(tx, 2.5, z0 + 2.0), wood, Vector3.ZERO, 6)
				Gfx.box(parent, Vector3(1.4, 0.08, 0.08), Vector3(tx, 4.7, z0 + 2.0), wood)
				Gfx.box(parent, Vector3(0.1, 0.1, 0.1), Vector3(tx, 4.6, z0 + 2.0), _lamp_mat)
			elif _rng.randf() < 0.3:
				var cx := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 3.0)
				var cz := z0 - 2.0
				Gfx.box(parent, Vector3(4.0, 2.4, 3.6), Vector3(cx, 1.2, cz), wood)
				Gfx.box(parent, Vector3(4.6, 0.3, 4.2), Vector3(cx, 2.8, cz), snow, Vector3(0, 0, 0))
				Gfx.box(parent, Vector3(0.06, 0.8, 0.7), Vector3(cx - side * 2.02, 1.4, cz), _glass_shop_mat)
				Gfx.box(parent, Vector3(0.7, 1.0, 0.7), Vector3(cx + 0.6, 3.1, cz + 0.4), rock)
				Gfx.glow(parent, Vector3(cx - side * 2.2, 1.4, cz), 3.0, Color(1.0, 0.8, 0.4, 0.4))


# ------------------------- بندر شبانه -------------------------
func _decor_harbor(parent: Node3D) -> void:
	var cols := ["d6502d", "2f7fc0", "3b9a58", "e0a82a", "7a4fd0", "2fa89a"]
	var rib := Gfx.ribs_tex()
	var steel := Props.m("5a6670", 0.0, 0.4, 0.8)
	for side: int in [-1, 1]:
		for slot in 2:
			var z0 := (-6.0 if slot == 0 else 6.0) + _rng.randf_range(-1.5, 1.5)
			var inner := ROAD_WIDTH * 0.5 + SHOULDER_W + 0.6 + _rng.randf_range(0.0, 1.8)
			var r := _rng.randi() % 3
			if r == 0:
				# انبار با پنجره‌های روشن
				var w := _rng.randf_range(7.0, 11.0)
				var h := _rng.randf_range(6.0, 10.0)
				var b := Node3D.new()
				b.position = Vector3(side * (inner + w * 0.5), 0.0, z0)
				parent.add_child(b)
				Gfx.box(b, Vector3(w, h, 9.0), Vector3(0, h * 0.5, 0), _facades[_rng.randi() % _facades.size()])
				Gfx.box(b, Vector3(w + 0.4, 0.4, 9.4), Vector3(0, h + 0.2, 0), _cap_mat)
				Gfx.box(b, Vector3(0.1, h * 0.7, 6.0), Vector3(-side * (w * 0.5 + 0.02), h * 0.4, 0), Props.m("2a3140", 0.0, 0.6, 0.4))
			elif r == 1:
				# پشته‌ی کانتینر
				var cnt := _rng.randi_range(1, 3)
				for k in cnt:
					var m := Gfx.mat(Color(cols[_rng.randi() % 6]), 0.0, rib, 0.55)
					Gfx.box(parent, Vector3(2.6, 2.6, 6.0), Vector3(side * (inner + 1.4 + (k % 2) * 0.05), 1.3 + (k / 2) * 2.7, z0 + (k % 2) * 0.0 - 1.0), m)
				for k in 2:
					Gfx.box(parent, Vector3(2.6, 2.6, 6.0), Vector3(side * (inner + 4.2), 1.3, z0 + k * 0.0), Gfx.mat(Color(cols[_rng.randi() % 6]), 0.0, rib, 0.55))
			else:
				# جرثقیل بندری
				var cx := side * (inner + 2.0)
				Gfx.box(parent, Vector3(0.5, 16.0, 0.5), Vector3(cx, 8.0, z0 - 2.0), steel)
				Gfx.box(parent, Vector3(0.5, 16.0, 0.5), Vector3(cx, 8.0, z0 + 2.0), steel)
				Gfx.box(parent, Vector3(0.4, 0.4, 4.4), Vector3(cx, 8.0, z0), steel)
				Gfx.box(parent, Vector3(9.0, 0.6, 0.6), Vector3(cx - side * 3.5, 16.0, z0), Props.m("f5c518", 0.0, 0.5, 0.3))
				Gfx.box(parent, Vector3(0.3, 0.3, 0.3), Vector3(cx - side * 7.8, 16.4, z0), _blink_mat)
			# بولارد و طناب کنار جاده
			var bx := side * (ROAD_WIDTH * 0.5 + 0.7)
			for k in 3:
				Gfx.cyl(parent, 0.14, 0.18, 0.5, Vector3(bx, 0.45, z0 - 4.0 + k * 4.0), Props.m("ffcc00", 0.0, 0.45, 0.4), Vector3.ZERO, 8)
			# چراغ‌های دریایی قرمز/سبز
			if _rng.randf() < 0.35:
				Gfx.glow(parent, Vector3(side * 9.0, 4.0, z0), 3.0, Color(1.0, 0.25, 0.2, 0.5) if side < 0 else Color(0.2, 1.0, 0.4, 0.5))


# ------------------------- آتشفشان -------------------------
func _decor_volcano(parent: Node3D) -> void:
	var rock := Props.m("26232a", 0.0, 0.95)
	var rock2 := Props.m("3a363e", 0.0, 0.9)
	var lava := Props.m("ff5a14", 2.8, 0.5)
	for side: int in [-1, 1]:
		for slot in 2:
			var z0 := (-6.0 if slot == 0 else 6.0) + _rng.randf_range(-2.0, 2.0)
			# تیغه‌های سنگی
			for i in _rng.randi_range(2, 4):
				var x := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 1.5 + _rng.randf_range(0.0, 8.0))
				var h := _rng.randf_range(3.0, 12.0)
				var c := Gfx.cyl(parent, 0.001, _rng.randf_range(1.0, 2.6), h, Vector3(x, h * 0.5, z0 + _rng.randf_range(-5.0, 5.0)), rock if i % 2 == 0 else rock2, Vector3(_rng.randf_range(-6, 6), 0, _rng.randf_range(-6, 6)), 5)
			# رودخانه‌ی گدازه‌ی دور
			var lx := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 6.0 + _rng.randf_range(0.0, 3.0))
			Gfx.box(parent, Vector3(1.8, 0.05, 9.0), Vector3(lx, 0.04, z0), lava)
			Gfx.pool(parent, Vector3(lx, 0.12, z0), Vector2(9.0, 14.0), Color(1.0, 0.4, 0.1, 0.3))
			# ترک‌های درخشان کنار جاده + صخره‌ها
			for i in _rng.randi_range(1, 3):
				var bx := side * (ROAD_WIDTH * 0.5 + 1.0 + _rng.randf_range(0.0, 2.0))
				var bz := z0 + _rng.randf_range(-5.0, 5.0)
				var s := _rng.randf_range(0.4, 0.9)
				var b := Gfx.sphere(parent, 1.0, Vector3(bx, s * 0.4, bz), rock, 7)
				b.scale = Vector3(s * 1.2, s * 0.8, s)
				Gfx.box(parent, Vector3(0.08, 0.03, _rng.randf_range(1.0, 2.5)), Vector3(bx + side * 0.9, 0.08, bz), lava, Vector3(0, _rng.randf_range(-30, 30), 0))
			# درخت سوخته
			if _rng.randf() < 0.4:
				var tx := side * (ROAD_WIDTH * 0.5 + SHOULDER_W + 1.0)
				var tz := z0 + _rng.randf_range(-4.0, 4.0)
				Gfx.cyl(parent, 0.08, 0.16, 3.4, Vector3(tx, 1.7, tz), Props.m("1b1512", 0.0, 1.0), Vector3(0, 0, side * 6), 6)
				Gfx.cyl(parent, 0.04, 0.07, 1.4, Vector3(tx - side * 0.5, 2.8, tz), Props.m("1b1512", 0.0, 1.0), Vector3(0, 0, -side * 55), 5)
			if _rng.randf() < 0.3:
				Gfx.glow(parent, Vector3(side * 8.0, 2.0, z0), 7.0, Color(1.0, 0.4, 0.1, 0.18))
