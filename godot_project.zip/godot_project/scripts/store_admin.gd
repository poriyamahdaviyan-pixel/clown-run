extends Node
## مدیریت آیتم‌های فروشگاه (فقط حساب مدیر): افزودن آیتم به هر بخش، ویرایش، تخفیف، قیمت، تایمر، تعداد محدود،
## ویژه کردن، پنهان کردن، ترتیب و حذف. فایل و پیش‌نمایش هر دو از گوشی (هر فرمتی) انتخاب می‌شوند.
## ترتیب: بخش (kind) ← لیست آیتم‌ها ← فرم آیتم.

const RARITIES := [["common", "معمولی"], ["rare", "کمیاب"], ["epic", "حماسی"], ["legendary", "افسانه‌ای"]]
const UNITS := [["m", "دقیقه", 60], ["h", "ساعت", 3600], ["d", "روز", 86400]]
const ThumbMaker := preload("res://scripts/thumb_maker.gd")
const PREVIEWABLE := ["glb", "police", "voice", "chaser_voice", "music", "anim_clip", "anim", "chaser_anim"]
const CTYPES := {
	"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "webp": "image/webp", "bmp": "image/bmp",
	"glb": "model/gltf-binary", "gltf": "model/gltf+json", "ogg": "audio/ogg", "mp3": "audio/mpeg", "wav": "audio/wav",
	"json": "application/json", "zip": "application/zip", "ttf": "font/ttf", "otf": "font/otf",
}

var ui
var item_studio               # استودیوی آیتم‌ها (پیش‌نویس‌ها)
var scr                       # online_screens.gd
var _over: Control
var _body: VBoxContainer
var _note: Label
var _kind := ""               # بخشِ در حال مدیریت ("" = همه)
var _list: Array = []
var _item: Dictionary = {}    # آیتمِ در حال ویرایش
var _is_new := false
var _dirs_box: HBoxContainer
var _file_local := ""         # فایل تازه‌انتخاب‌شده (هنوز آپلود نشده)
var _prev_local := ""
var _pv_local := ""            # فایل پیش‌نمایش جدا (اختیاری)
var _pv_copy := true           # کپی عمومیِ همین فایل برای پیش‌نمایش
var _timer_on := false
var _timer_val := "24"
var _timer_unit := 1
var _ends_unix := 0
var _del_confirm := ""
var _busy := false
var _view := ""
var _f: Dictionary = {}       # فیلدهای فرم


func setup(owner_ui, screens) -> void:
	ui = owner_ui
	scr = screens


# ------------------------- کمکی‌ها -------------------------
func _lbl(t: String, size: int = 24, color: Color = Color("c9d6e6")) -> Label:
	var l: Label = ui._label(t, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(560, 0)
	return l


func _edit(text: String, numeric: bool = false, hint: String = "") -> LineEdit:
	var e := LineEdit.new()
	e.text = text
	e.placeholder_text = hint
	e.add_theme_font_size_override("font_size", 26)
	e.custom_minimum_size = Vector2(0, 66)
	e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if numeric:
		e.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	return e


func _chips(options: Array, current: String, cb: Callable) -> HFlowContainer:
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 8)
	fl.add_theme_constant_override("v_separation", 8)
	for o in options:
		var id: String = o[0]
		var on := id == current
		fl.add_child(ui._button(("✓ " if on else "") + String(o[1]), func(): cb.call(id), Vector2(0, 62), 22, "Gold" if on else "Dark"))
	return fl


func _check(text: String, on: bool, cb: Callable) -> CheckBox:
	var c := CheckBox.new()
	c.text = text
	c.button_pressed = on
	c.add_theme_font_size_override("font_size", 26)
	c.custom_minimum_size = Vector2(0, 64)
	c.toggled.connect(func(v: bool): cb.call(v))
	return c


func _say(t: String) -> void:
	if _note != null and is_instance_valid(_note):
		_note.text = t


func _kinds() -> Array:
	var out: Array = []
	for sec: Dictionary in Content.store_all():
		var k := String(sec.kind)
		if k != "" and not k.begins_with("@") and not out.any(func(o): return o[0] == k):
			out.append([k, String(sec.text)])
	return out


func _uuid() -> String:
	var b := PackedByteArray()
	for i in 16:
		b.append(randi() % 256)
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	var h := b.hex_encode()
	return "%s-%s-%s-%s-%s" % [h.substr(0, 8), h.substr(8, 4), h.substr(12, 4), h.substr(16, 4), h.substr(20, 12)]


static func ends_text(ends_iso: String) -> String:
	if ends_iso == "":
		return ""
	var left := int(Time.get_unix_time_from_datetime_string(ends_iso.left(19)) - Time.get_unix_time_from_system())
	if left <= 0:
		return "تمام شده"
	if left >= 86400:
		return "%d روز و %d ساعت" % [left / 86400, (left % 86400) / 3600]
	if left >= 3600:
		return "%d ساعت و %d دقیقه" % [left / 3600, (left % 3600) / 60]
	return "%d دقیقه" % maxi(1, left / 60)


func _iso(unix: int) -> String:
	return Time.get_datetime_string_from_unix_time(unix, false) + "Z"


func _overlay(title: String) -> VBoxContainer:
	if _over != null and is_instance_valid(_over):
		_over.queue_free()
	_over = Control.new()
	ui._add_full(scr.store, _over)
	var bg := ColorRect.new()
	bg.color = Color("1d0c36")
	ui._add_full(_over, bg)
	var m := MarginContainer.new()
	ui._add_full(_over, m)
	for k in ["left", "right", "bottom"]:
		m.add_theme_constant_override("margin_" + k, 22)
	m.add_theme_constant_override("margin_top", 56)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	m.add_child(col)
	var t: Label = ui._label(title, 40, Color.WHITE)
	t.set_meta("ct_skip", true)
	col.add_child(t)
	_note = _lbl("", 24, Color("ffd27a"))
	col.add_child(_note)
	return col


# ------------------------- لیست آیتم‌های یک بخش -------------------------
func open_manager(kind: String) -> void:
	if not Online.is_admin:
		scr.toast("برای مدیریت فروشگاه باید با حساب مدیر وارد شوی")
		return
	_kind = kind
	_view = "list"
	_del_confirm = ""
	var title := "مدیریت آیتم‌ها"
	for sec: Dictionary in Content.store_all():
		if String(sec.kind) == kind:
			title += " — " + String(sec.text)
			break
	var col := _overlay(title)
	var top := HFlowContainer.new()
	top.add_theme_constant_override("h_separation", 8)
	top.add_theme_constant_override("v_separation", 8)
	col.add_child(top)
	top.add_child(ui._button("+ آیتم جدید", func(): open_form({}), Vector2(250, 68), 26, "Gold"))
	top.add_child(ui._button("تازه‌سازی", func(): _reload(), Vector2(220, 68), 24, "Teal"))
	top.add_child(ui._button("بستن", func(): _close(), Vector2(160, 68), 24, "Dark"))
	_body = ui.make_scroll_view(col)
	_reload()


func _close() -> void:
	if _over != null and is_instance_valid(_over):
		_over.queue_free()
	scr.refresh_store()


func _reload() -> void:
	_say("در حال دریافت…")
	var q := "/rest/v1/items?select=*&order=sort.asc,created_at.desc"
	if _kind != "":
		q += "&kind=eq." + _kind.uri_encode()
	var r: Dictionary = await Online._req(HTTPClient.METHOD_GET, q)
	_list = []
	if r.ok and r.data is Array:
		for it in r.data:
			var p = it.get("payload", {})
			if p is Dictionary and String(p.get("char", "")) != "":
				continue        # آیتم‌های مخصوص کاراکتر در صفحه‌ی همان کاراکتر مدیریت می‌شوند
			_list.append(it)
		_say("")
	else:
		_say("دریافت نشد: " + String(r.error))
	_render_list()


func _render_list() -> void:
	if _view != "list" or _body == null or not is_instance_valid(_body):
		return
	for c in _body.get_children():
		c.queue_free()
	# تخفیف یک‌جای کل بخش
	if not _list.is_empty():
		var bulk := HFlowContainer.new()
		bulk.add_theme_constant_override("h_separation", 8)
		bulk.add_theme_constant_override("v_separation", 8)
		_body.add_child(bulk)
		bulk.add_child(_lbl("تخفیف همه‌ی آیتم‌های این بخش (٪):", 24, Color.WHITE))
		var be := _edit("0", true)
		be.custom_minimum_size = Vector2(120, 66)
		be.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		bulk.add_child(be)
		bulk.add_child(ui._button("اعمال", func(): _bulk_discount(clampi(int(be.text), 0, 90)), Vector2(160, 66), 24, "Gold"))
	if _list.is_empty():
		_body.add_child(_lbl("هنوز آیتمی در این بخش نیست. «+ آیتم جدید» را بزن."))
	for i in _list.size():
		var it: Dictionary = _list[i]
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel", scr._frame(Online.s(it.get("rarity", "common"))))
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 6)
		card.add_child(v)
		var hidden := Online.s(it.get("status", "approved")) == "hidden"
		var nm: Label = ui._label(String(it.name) + ("   (پنهان)" if hidden else ""), 30, Color(1, 1, 1, 0.5) if hidden else Color.WHITE)
		nm.set_meta("ct_skip", true)
		v.add_child(nm)
		var info: Array[String] = ["قیمت %d" % int(it.get("price", 0))]
		if int(it.get("discount_percent", 0)) > 0:
			info.append("تخفیف %d٪ ← %d" % [int(it.discount_percent), Online.price_of(it)])
		if it.get("stock") != null:
			info.append("موجودی %d" % int(it.stock))
		var et := ends_text(Online.s(it.get("ends_at", "")))
		if et != "":
			info.append("تایمر: " + et)
		if bool(it.get("featured", false)):
			info.append("★ ویژه")
		info.append("فروش %d" % int(it.get("sales", 0)))
		if _kind == "":
			info.append(scr._kind_name(String(it.kind)))
		v.add_child(_lbl("  •  ".join(info), 22, Color("ffd27a")))
		var row := HFlowContainer.new()
		row.add_theme_constant_override("h_separation", 6)
		row.add_theme_constant_override("v_separation", 6)
		v.add_child(row)
		row.add_child(ui._button("ویرایش", func(): open_form(it), Vector2(150, 60), 22, "Teal"))
		row.add_child(ui._button("نمایش" if hidden else "پنهان", func(): _patch(it, {"status": "approved" if hidden else "hidden"}), Vector2(130, 60), 22, "Dark"))
		row.add_child(ui._button("▲", func(): _move(i, -1), Vector2(70, 60), 22, "Dark"))
		row.add_child(ui._button("▼", func(): _move(i, 1), Vector2(70, 60), 22, "Dark"))
		var iid := String(it.id)
		row.add_child(ui._button("مطمئنی؟ حذف" if _del_confirm == iid else "حذف", func(): _delete(iid), Vector2(170, 60), 22, "Red"))
		_body.add_child(card)
	Content.apply_tree.call_deferred(_body)


func _patch(it: Dictionary, patch: Dictionary) -> void:
	var r: Dictionary = await Online.admin_patch_item(String(it.id), patch)
	_say("" if r.ok else "خطا: " + String(r.error))
	await _reload()
	await Online.load_items()


func _bulk_discount(pct: int) -> void:
	_say("در حال اعمال…")
	var q := "/rest/v1/items?id=not.is.null"
	if _kind != "":
		q = "/rest/v1/items?kind=eq." + _kind.uri_encode()
	var r: Dictionary = await Online._req(HTTPClient.METHOD_PATCH, q, {"discount_percent": pct}, true, false, PackedStringArray(["Prefer: return=minimal"]))
	_say("تخفیف %d٪ برای همه‌ی آیتم‌های این بخش اعمال شد" % pct if r.ok else "خطا: " + String(r.error))
	await _reload()
	await Online.load_items()


func _move(i: int, dir: int) -> void:
	var j := i + dir
	if j < 0 or j >= _list.size():
		return
	var arr := _list.duplicate()
	var t = arr[i]
	arr[i] = arr[j]
	arr[j] = t
	for k in arr.size():
		if int(arr[k].get("sort", 0)) != k * 10:
			await Online.admin_patch_item(String(arr[k].id), {"sort": k * 10})
	await _reload()
	await Online.load_items()


func _delete(id: String) -> void:
	if _del_confirm != id:
		_del_confirm = id
		_render_list()
		return
	_del_confirm = ""
	var r: Dictionary = await Online._req(HTTPClient.METHOD_DELETE, "/rest/v1/items?id=eq." + id, null, true, false, PackedStringArray(["Prefer: return=minimal"]))
	_say("حذف شد (خریدهای قبلی بازیکن‌ها هم پاک می‌شود؛ برای نگه‌داشتن آنها «پنهان» را بزن)" if r.ok else "خطا: " + String(r.error))
	await _reload()
	await Online.load_items()


# ------------------------- فرم آیتم -------------------------
## مستقیم فرم را باز می‌کند (از کارت فروشگاه یا دکمه‌ی «آیتم جدید»)
## برای همه‌ی آیتم‌هایی که عکس کارت ندارند، پیش‌نمایش خودکار می‌سازد و آپلود می‌کند
func backfill_previews() -> void:
	var todo: Array = Online.items.filter(func(i): return Online.s(i.get("preview_path", "")) == "")
	if todo.is_empty():
		scr.toast("همه‌ی آیتم‌ها پیش‌نمایش دارند ✓")
		return
	var done := 0
	for it: Dictionary in todo:
		scr._store_msg.text = "ساخت پیش‌نمایش %d از %d…" % [done + 1, todo.size()]
		var pl: Dictionary = it.get("payload", {}) if it.get("payload") is Dictionary else {}
		var src: String = await Online.preview_file(it)
		var png: PackedByteArray = await ThumbMaker.make(ui, scr, String(it.kind), src, pl, int(it.get("glb_yaw", 0)))
		if png.is_empty():
			continue
		var ppath := "%s_%s.png" % [String(it.id), str(Time.get_ticks_msec())]
		var pu: Dictionary = await Online.admin_upload(ppath, png, "image/png", "previews")
		if pu.ok:
			var r: Dictionary = await Online.admin_patch_item(String(it.id), {"preview_path": ppath})
			if r.ok:
				done += 1
	await Online.load_items()
	scr.toast("%d پیش‌نمایش ساخته شد" % done)


## پیش‌نویسِ استودیو را در فرم آیتم‌ِ تازه می‌گذارد (فایل و نام و قیمت از پیش پر می‌شوند)
func open_form_with_draft(d: Dictionary) -> void:
	_kind = String(d.kind)
	open_form({})
	_apply_draft(d)
	_render_form()


func _apply_draft(d: Dictionary) -> void:
	_item["kind"] = String(d.kind)
	_item["name"] = String(d.name)
	_item["description"] = String(d.get("desc", ""))
	_item["price"] = int(d.get("price", 100))
	_item["rarity"] = String(d.get("rarity", "common"))
	_file_local = String(d.get("file", ""))
	_pv_local = ""


func open_form_for(kind: String, it: Dictionary) -> void:
	if not Online.is_admin:
		scr.toast("برای مدیریت فروشگاه باید با حساب مدیر وارد شوی")
		return
	_kind = kind
	open_form(it)


func open_form(it: Dictionary) -> void:
	_view = "form"
	_is_new = it.is_empty()
	_item = it.duplicate(true)
	if _is_new:
		_item = {"kind": _kind if _kind != "" else "skin", "name": "", "description": "", "price": 100, "rarity": "common",
			"discount_percent": 0, "stock": null, "ends_at": null, "featured": false, "status": "approved", "glb_yaw": 0, "payload": {}}
	_file_local = ""
	_prev_local = ""
	_pv_local = ""
	var pl0 = _item.get("payload", {})
	_pv_copy = not (pl0 is Dictionary and pl0.has("pv") == false and not _is_new)
	var ends := Online.s(_item.get("ends_at", ""))
	_ends_unix = int(Time.get_unix_time_from_datetime_string(ends.left(19))) if ends != "" else 0
	_timer_on = _ends_unix > 0
	_timer_val = "24"
	_timer_unit = 1
	var col := _overlay("آیتم جدید" if _is_new else "ویرایش: " + String(_item.get("name", "")))
	var act := HFlowContainer.new()
	act.add_theme_constant_override("h_separation", 8)
	col.add_child(act)
	act.add_child(ui._button("ذخیره", func(): _save(), Vector2(240, 68), 28, "Gold"))
	act.add_child(ui._button("انصراف", func(): open_manager(_kind), Vector2(200, 68), 26, "Dark"))
	_body = ui.make_scroll_view(col)
	_render_form()


func _render_form() -> void:
	for c in _body.get_children():
		c.queue_free()
	_f.clear()
	var B := _body
	# --- مشخصات
	B.add_child(ui._label("مشخصات", 32, Color("ffb02e")))
	_f.name = _edit(String(_item.get("name", "")), false, "نام آیتم")
	B.add_child(_f.name)
	_f.desc = _edit(Online.s(_item.get("description", "")), false, "توضیح کوتاه (اختیاری)")
	B.add_child(_f.desc)
	B.add_child(ui._label("بخش فروشگاه", 26, Color.WHITE))
	var ks := _kinds()
	if not ks.any(func(o): return o[0] == String(_item.kind)):
		ks.append([String(_item.kind), String(_item.kind)])
	B.add_child(_chips(ks, String(_item.kind), func(k): _keep(); _item["kind"] = k; _render_form()))
	B.add_child(ui._label("نوع نادر بودن", 26, Color.WHITE))
	B.add_child(_chips(RARITIES, Online.s(_item.get("rarity", "common")), func(r): _keep(); _item["rarity"] = r; _render_form()))
	# --- قیمت و تخفیف
	B.add_child(ui._label("قیمت و تخفیف", 32, Color("ffb02e")))
	B.add_child(ui._label("قیمت (سکه؛ ۰ = رایگان)", 24, Color.WHITE))
	_f.price = _edit(str(int(_item.get("price", 0))), true)
	B.add_child(_f.price)
	B.add_child(ui._label("تخفیف (٪، ۰ تا ۹۰)", 24, Color.WHITE))
	_f.disc = _edit(str(int(_item.get("discount_percent", 0))), true)
	B.add_child(_f.disc)
	_f.final = _lbl("", 24, Color("ffd27a"))
	B.add_child(_f.final)
	_f.price.text_changed.connect(func(_t): _upd_final())
	_f.disc.text_changed.connect(func(_t): _upd_final())
	_upd_final()
	# --- محدودیت
	B.add_child(ui._label("محدودیت (نسخه‌ی ویژه)", 32, Color("ffb02e")))
	var has_stock: bool = _item.get("stock") != null
	_f.stock_on = _check("تعداد محدود", has_stock, func(v): _keep(); _item["stock"] = 50 if v else null; _render_form())
	B.add_child(_f.stock_on)
	if has_stock:
		_f.stock = _edit(str(int(_item.stock)), true, "تعداد")
		B.add_child(_f.stock)
		B.add_child(_lbl("با هر خرید یکی کم می‌شود و در صفر «ناموجود» می‌شود.", 20))
	_f.timer_on = _check("فروش زمان‌دار (تایمر)", _timer_on, func(v): _keep(); _timer_on = v; if v and _ends_unix == 0: _start_timer(); _render_form())
	B.add_child(_f.timer_on)
	if _timer_on:
		var tr := HBoxContainer.new()
		tr.add_theme_constant_override("separation", 8)
		B.add_child(tr)
		_f.tval = _edit(_timer_val, true, "مدت")
		_f.tval.custom_minimum_size = Vector2(140, 66)
		_f.tval.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		tr.add_child(_f.tval)
		var uo: Array = []
		for i in UNITS.size():
			uo.append([str(i), UNITS[i][1]])
		tr.add_child(_chips(uo, str(_timer_unit), func(i): _keep(); _timer_unit = int(i); _render_form()))
		B.add_child(ui._button("شروع تایمر از همین الان", func(): _keep(); _start_timer(); _render_form(), Vector2(0, 66), 24, "Teal"))
		B.add_child(_lbl("پایان فروش: " + (ends_text(_iso(_ends_unix)) + " دیگر" if _ends_unix > Time.get_unix_time_from_system() else "هنوز شروع نشده یا تمام شده"), 22, Color("ffd27a")))
	_f.feat = _check("★ آیتم ویژه (اول لیست و با برچسب)", bool(_item.get("featured", false)), func(v): _item["featured"] = v)
	B.add_child(_f.feat)
	_f.vis = _check("نمایش برای بازیکن‌ها (تیک نخورده = پنهان)", Online.s(_item.get("status", "approved")) != "hidden", func(v): _item["status"] = "approved" if v else "hidden")
	B.add_child(_f.vis)
	# --- فایل‌ها
	B.add_child(ui._label("فایل‌ها (از حافظه‌ی گوشی، هر فرمتی)", 32, Color("ffb02e")))
	B.add_child(_lbl("پیش‌نمایشِ کارت خودکار از خودِ آیتم ساخته می‌شود (سکه = خودِ سکه، مدل = رندر مدل، صدا/انیمیشن = کاراکتر…). لازم نیست عکسی انتخاب کنی.", 21, Color("9dffb4")))
	var has_file := Online.s(_item.get("file_path", "")) != ""
	B.add_child(_lbl("فایل آیتم: " + (_file_local.get_file() + "  (آپلود می‌شود)" if _file_local != "" else (Online.s(_item.get("file_path", "")).get_file() + " ✓" if has_file else "ندارد")), 24, Color.WHITE))
	B.add_child(ui._button("انتخاب فایل آیتم (عکس، مدل، صدا، zip، bin، …)", func(): _keep(); ui.pick_file("item_file", func(p): _file_local = String(p); _render_form()), Vector2(0, 72), 24, "Teal"))
	if item_studio != null and String(_item.kind) != "":
		B.add_child(item_studio.picker(String(_item.kind), func(d: Dictionary): _keep(); _apply_draft(d); _render_form()))
	if _file_local != "":
		B.add_child(LocalPreview.make(ui, _file_local, int(_item.get("glb_yaw", 0))))
	B.add_child(_lbl(_file_hint(String(_item.kind)), 20))
	if String(_item.kind) in PREVIEWABLE:
		B.add_child(ui._label("پیش‌نمایش قفل‌شده (مدل، صدا، آهنگ، انیمیشن)", 28, Color("ffb02e")))
		B.add_child(_check("نسخه‌ی عمومی همین فایل برای پیش‌نمایش (بازیکن قبل از خرید روی کاراکتر می‌بیند/می‌شنود)", _pv_copy, func(v): _keep(); _pv_copy = v; _render_form()))
		if _pv_copy:
			B.add_child(_lbl("پیش‌نمایش: " + (_pv_local.get_file() + "  (آپلود می‌شود)" if _pv_local != "" else "همان فایل آیتم (یا فایل قبلی)"), 22, Color.WHITE))
			B.add_child(ui._button("انتخاب فایل پیش‌نمایشِ جدا (اختیاری؛ مثلاً نسخه‌ی کوتاه یا سبک)", func(): _keep(); ui.pick_file("item_file", func(p): _pv_local = String(p); _render_form()), Vector2(0, 66), 22, "Dark"))
			B.add_child(_lbl("توجه: نسخه‌ی پیش‌نمایش در باکت عمومی است؛ هرکس آدرسش را بداند می‌تواند بدون خرید ببیندش. برای محافظت، فایل پیش‌نمایشِ جدا و کوتاه بده.", 20, Color("ff9a9a")))
		else:
			B.add_child(_lbl("بدون پیش‌نمایش: بازیکن فقط عکس را می‌بیند و فایل کاملاً قفل می‌ماند.", 20))
	if String(_item.kind) in ["glb", "police"]:
		B.add_child(ui._button("چرخش مدل: %d°  — اگر کاراکتر از پشت دیده می‌شود بزن (پیش‌نمایش همین‌جا عوض می‌شود)" % (int(_item.get("glb_yaw", 0)) * 90), func(): _keep(); _item["glb_yaw"] = (int(_item.get("glb_yaw", 0)) + 1) % 4; _render_form(), Vector2(0, 66), 24, "Dark"))
		B.add_child(ui._button("نمایش ۴ جهت و انتخاب سمتِ جلوی مدل", func(): _keep(); _show_dirs(), Vector2(0, 66), 24, "Teal"))
		_dirs_box = HBoxContainer.new()
		_dirs_box.add_theme_constant_override("separation", 8)
		B.add_child(_dirs_box)
	Content.apply_tree.call_deferred(_body)


func _show_dirs() -> void:
	if _dirs_box == null or not is_instance_valid(_dirs_box):
		return
	for c in _dirs_box.get_children():
		c.queue_free()
	var src := _file_local if _file_local != "" else _pv_local
	if src == "" and not _is_new:
		src = await Online.preview_file(_item)
	var any := false
	for y in 4:
		var png: PackedByteArray = await ThumbMaker.make(ui, scr, String(_item.kind), src, {}, y)
		if png.is_empty() or not is_instance_valid(_dirs_box):
			continue
		var img := Image.new()
		if img.load_png_from_buffer(png) != OK:
			continue
		any = true
		var b := TextureButton.new()
		b.texture_normal = ImageTexture.create_from_image(img)
		b.ignore_texture_size = true
		b.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
		b.custom_minimum_size = Vector2(120, 120)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var yy := y
		b.pressed.connect(func(): _item["glb_yaw"] = yy; _render_form())
		_dirs_box.add_child(b)
	if not any and is_instance_valid(_dirs_box):
		_dirs_box.add_child(_lbl("پیش‌نمایش روی این دستگاه ساخته نشد؛ با دکمهٔ «چرخش مدل» دستی تنظیم کن.", 20, Color("ffd36b")))


func _file_hint(kind: String) -> String:
	match kind:
		"skin", "coin": return "برای این بخش فایل باید عکس باشد (png، jpg، webp)."
		"glb", "police": return "مدل: glb، gltf، vrm، fbx، obj یا zip (مدل + تکسچر داخلش). بازیکن هنگام نصب خودکار تبدیل می‌شود."
		"voice", "chaser_voice", "music": return "صدا: ogg، mp3 یا wav."
		"anim", "chaser_anim": return "بسته‌ی انیمیشن (json) که از ویرایشگر قوانین خروجی گرفته‌ای."
	return "هر فایلی ذخیره می‌شود؛ برای نوع‌های تازه نصب خودکار ندارد."


func _upd_final() -> void:
	var p := int(_f.price.text)
	var d := clampi(int(_f.disc.text), 0, 90)
	var fin := p * (100 - d) / 100
	_f.final.text = "قیمت نهایی برای بازیکن: %s" % ("رایگان" if fin == 0 else "%d سکه" % fin) + ("   (به‌جای %d)" % p if d > 0 else "")


func _start_timer() -> void:
	var n := maxi(1, int(_timer_val))
	_ends_unix = int(Time.get_unix_time_from_system()) + n * int(UNITS[_timer_unit][2])


## مقدار فیلدها را قبل از بازسازی فرم در _item نگه می‌دارد
func _keep() -> void:
	if _f.has("name"):
		_item["name"] = (_f.name as LineEdit).text
		_item["description"] = (_f.desc as LineEdit).text
		_item["price"] = maxi(0, int((_f.price as LineEdit).text))
		_item["discount_percent"] = clampi(int((_f.disc as LineEdit).text), 0, 90)
	if _f.has("stock") and is_instance_valid(_f.stock):
		_item["stock"] = maxi(0, int((_f.stock as LineEdit).text))
	if _f.has("tval") and is_instance_valid(_f.tval):
		_timer_val = (_f.tval as LineEdit).text


func _save() -> void:
	if _busy:
		return
	_keep()
	var nm := String(_item.get("name", "")).strip_edges()
	if nm == "":
		_say("نام آیتم را بنویس")
		return
	var kind := String(_item.kind)
	if _is_new and _file_local == "" and not kind in ["anim_clip"]:
		_say("برای آیتم تازه باید فایل انتخاب کنی")
		return
	if _timer_on and _ends_unix <= Time.get_unix_time_from_system():
		_say("تایمر شروع نشده یا گذشته است؛ «شروع تایمر از همین الان» را بزن")
		return
	_busy = true
	var id := String(_item.get("id", ""))
	if id == "":
		id = _uuid()
	var d := {"kind": kind, "name": nm, "description": String(_item.get("description", "")),
		"price": int(_item.get("price", 0)), "rarity": Online.s(_item.get("rarity", "common")),
		"discount_percent": int(_item.get("discount_percent", 0)),
		"stock": _item.get("stock"), "ends_at": _iso(_ends_unix) if _timer_on else null,
		"featured": bool(_item.get("featured", false)), "status": Online.s(_item.get("status", "approved")),
		"glb_yaw": int(_item.get("glb_yaw", 0))}
	var stamp := str(Time.get_ticks_msec())
	var pl_for_thumb: Dictionary = _item.get("payload", {}).duplicate() if _item.get("payload", {}) is Dictionary else {}
	var need_thumb: bool = _file_local != "" or _pv_local != "" or Online.s(_item.get("preview_path", "")) == ""
	if need_thumb:
		_say("در حال ساخت پیش‌نمایش خودکار…")
		var src := _file_local if _file_local != "" else _pv_local
		if src == "" and not _is_new:
			src = await Online.preview_file(_item)
		var png: PackedByteArray = await ThumbMaker.make(ui, scr, kind, src, pl_for_thumb, int(_item.get("glb_yaw", 0)))
		if not png.is_empty():
			var ppath := "%s_%s.png" % [id, stamp]
			var pu: Dictionary = await Online.admin_upload(ppath, png, "image/png", "previews")
			if pu.ok:
				d["preview_path"] = ppath
			else:
				_say("پیش‌نمایش آپلود نشد (%s)؛ ادامه می‌دهم." % String(pu.error))
	if _file_local != "":
		var size_mb := FileAccess.get_file_as_bytes(_file_local).size() / 1048576.0
		_say("در حال آپلود فایل (%.1f مگابایت)…" % size_mb)
		var fb := FileAccess.get_file_as_bytes(_file_local)
		if fb.is_empty():
			_say("فایل خوانده نشد؛ مجوز دسترسی به فایل‌ها را بده")
			_busy = false
			return
		var fext := _file_local.get_extension().to_lower()
		var fpath := "%s/%s_%s.%s" % [kind, id, stamp, fext if fext != "" else "dat"]
		var fu: Dictionary = await Online.admin_upload(fpath, fb, String(CTYPES.get(fext, "application/octet-stream")))
		if not fu.ok:
			_say("خطا: " + String(fu.error) + " — اگر فایل بزرگ است، سقف آپلود Supabase (۵۰ مگابایت در طرح رایگان) را ببین")
			_busy = false
			return
		d["file_path"] = fpath
	var payload: Dictionary = _item.get("payload", {}).duplicate() if _item.get("payload", {}) is Dictionary else {}
	if kind in PREVIEWABLE:
		if not _pv_copy:
			payload.erase("pv")
		else:
			var pv_src := _pv_local if _pv_local != "" else _file_local
			if pv_src != "":
				var pb2 := FileAccess.get_file_as_bytes(pv_src)
				var pe := pv_src.get_extension().to_lower()
				var pvp := "pv/%s_%s.%s" % [id, stamp, pe if pe != "" else "dat"]
				_say("در حال آپلود نسخه‌ی پیش‌نمایش…")
				var pvu: Dictionary = await Online.admin_upload(pvp, pb2, String(CTYPES.get(pe, "application/octet-stream")), "previews")
				if not pvu.ok:
					_say("خطا: " + String(pvu.error))
					_busy = false
					return
				payload["pv"] = pvp
	d["payload"] = payload
	var r: Dictionary
	if _is_new:
		d["id"] = id
		r = await Online.admin_save_item(d)
	else:
		r = await Online.admin_patch_item(id, d)
	_busy = false
	if not r.ok:
		_say("خطا: " + String(r.error))
		return
	await Online.load_items()
	scr.toast("ذخیره شد ✓")
	open_manager(_kind)
