class_name LocalPreview
extends VBoxContainer
## پیش‌نمایش زنده‌ی فایلی که تازه از گوشی انتخاب شده (قبل از آپلود): عکس، مدل سه‌بعدی (glb/gltf/vrm/fbx/obj/zip)، صدا.
## نسبت تصویر همیشه حفظ می‌شود و عرض هیچ‌وقت از صفحه بیشتر نمی‌شود.

const GlbModel := preload("res://scripts/glb_model.gd")
const IMG_EXT := ["png", "jpg", "jpeg", "webp", "bmp", "svg", "tga"]
const AUDIO_EXT := ["ogg", "mp3", "wav"]
const MAX_IMG_SIDE := 1024
const MAX_MODEL_BYTES := 60 * 1048576

var ui
var _path := ""
var _key := ""
var _audio: AudioStreamPlayer
var _status: Label


static func make(owner_ui, path: String) -> Control:
	var lp := LocalPreview.new()
	lp.ui = owner_ui
	lp._path = path
	return lp


func _ready() -> void:
	add_theme_constant_override("separation", 6)
	_key = "lp%d" % get_instance_id()
	_status = ui._label("", 20, Color("ffd27a"))
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.custom_minimum_size = Vector2(10, 0)
	add_child(_status)
	_build.call_deferred()


func _exit_tree() -> void:
	if ui != null and ui._pv.has(_key):
		ui._pv.erase(_key)
	if _audio != null and is_instance_valid(_audio):
		_audio.stop()


func _build() -> void:
	var ext := _path.get_extension().to_lower()
	if ext in IMG_EXT:
		_image()
	elif ext in AUDIO_EXT:
		_sound()
	elif ModelImport.is_model(_path) and ext != "bin":
		await _model(ext)
	else:
		var sz := 0
		var f := FileAccess.open(_path, FileAccess.READ)
		if f != null:
			sz = int(f.get_length())
			f.close()
		_status.text = "«%s» (%s): این نوع فایل پیش‌نمایش مستقیم ندارد؛ بعد از آپلود در فروشگاه بازیکن آن را می‌بیند." % [_path.get_file(), String.humanize_size(sz)]


func _image() -> void:
	var img := Image.new()
	if img.load(_path) != OK or img.is_empty():
		_status.text = "عکس خوانده نشد."
		return
	var w := img.get_width()
	var h := img.get_height()
	var sc := float(MAX_IMG_SIDE) / float(maxi(w, h))
	if sc < 1.0:
		img.resize(maxi(1, int(w * sc)), maxi(1, int(h * sc)), Image.INTERPOLATE_BILINEAR)
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, 340)
	holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var tr := TextureRect.new()
	tr.texture = ImageTexture.create_from_image(img)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ui._add_full(holder, tr)
	add_child(holder)
	_status.text = "پیش‌نمایش عکس — %d×%d" % [w, h]


func _sound() -> void:
	var st: AudioStream = Rules.stream_from_path(_path)
	if st == null:
		_status.text = "فایل صوتی خوانده نشد."
		return
	_status.text = "پیش‌نمایش صدا"
	var b: Button = ui._button("▶ پخش", func(): pass, Vector2(0, 76), 28, "Teal")
	b.pressed.connect(func():
		if _audio == null:
			_audio = AudioStreamPlayer.new()
			add_child(_audio)
		Music.hold = true
		if _audio.playing:
			_audio.stop()
			b.text = "▶ پخش"
		else:
			_audio.stream = st
			_audio.volume_db = linear_to_db(maxf(float(Game.vol.get("master", 1.0)) * float(Game.vol.get("sfx", 1.0)), 0.3))
			_audio.play()
			b.text = "■ توقف"
			get_tree().create_timer(15.0).timeout.connect(func():
				if is_instance_valid(_audio) and _audio.playing:
					_audio.stop()
				if is_instance_valid(b):
					b.text = "▶ پخش"))
	add_child(b)


func _model(ext: String) -> void:
	var f := FileAccess.open(_path, FileAccess.READ)
	if f == null:
		_status.text = "فایل باز نشد. مجوز دسترسی به فایل‌ها را بررسی کن."
		return
	var sz := int(f.get_length())
	f.close()
	if sz > MAX_MODEL_BYTES:
		_status.text = "مدل بزرگ است (%s)؛ پیش‌نمایش بعد از آپلود در فروشگاه دیده می‌شود." % String.humanize_size(sz)
		return
	_status.text = "در حال ساخت پیش‌نمایش…"
	await get_tree().process_frame
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://lp_tmp"))
	var dst := "user://lp_tmp/%s.glb" % _key
	var err := ModelImport.to_glb(_path, dst)
	if err != "":
		_status.text = "مدل خوانده نشد: " + err
		return
	var gm := GlbModel.new()
	var holder: Control = ui._make_preview(_key, 400, gm, false)
	add_child(holder)
	if not gm.load_from_file(dst, 0):
		_status.text = "مدل بارگذاری نشد: " + gm.load_error
		return
	_status.text = "پیش‌نمایش مدل (با انگشت بچرخانش)"
