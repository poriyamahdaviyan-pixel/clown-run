extends Node3D
## مدیر مسیر: ساخت تصادفی ردیف‌های مانع، سکه و قدرت، حرکت آن‌ها به سمت بازیکن و تشخیص برخورد.
## تشخیص برخورد کاملاً محاسباتی است (بدون موتور فیزیک) تا همیشه قابل‌پیش‌بینی و بدون باگ باشد.
## ظاهر موانع به محیط بستگی دارد (شهر / صحرا / جنگل و معبد) ولی ابعاد برخورد هر نوع ثابت است.

const Gfx := preload("res://scripts/gfx.gd")
const Props := preload("res://scripts/props.gd")
const Ext := preload("res://scripts/obstacles_ext.gd")
const SP := preload("res://scripts/setpieces.gd")

enum Kind { COIN, POWER, LOW, OVERHEAD, FULL }

const SPAWN_AHEAD := 95.0
const PORTAL_HIT_X := 1.45         # نیم‌عرض ورودی پرتال تک‌لِین
const PORTAL_SCALE := 0.42
const FIRST_ROW_Z := -38.0
const DESPAWN_Z := 11.0
const PLAYER_HALF_WIDTH := 0.4
const PLAYER_HALF_DEPTH := 0.3
const GRAZE_DEPTH := 1.0
const COIN_STEP := 2.0
const JET_COIN_Y := 4.3
const STEP_UP := 0.45
const LEDGE_GRAB := 0.9   # تا این اختلاف ارتفاع، لبه‌ی سکو را می‌گیرد و نمی‌میرد
const SWITCH_TRIGGER_Z := -48.0
const SWITCH_SPEED := 3.6
const MAGNET_RADIUS := 6.0
const MAGNET_REACH := 18.0

const POWER_COLORS: Array[Color] = [Color("ff4a4a"), Color("38d6ff"), Color("ffd23a"), Color("ff8a2a"), Color("8aff3a"), Color("b07aff")]
const POWER_LETTERS: Array[String] = ["M", "S", "×2", "J", "↑", "◔"]
const POWER_WEIGHTS: Array[float] = [0.21, 0.21, 0.18, 0.1, 0.16, 0.14]

class Ent:
	var node: Node3D
	var spin_node: Node3D
	var kind: int = 0
	var power := -1
	var x := 0.0
	var y0 := 0.0
	var y1 := 0.0
	var half_w := 0.5
	var half_d := 0.5
	var done := false
	var pulling := false
	var near_done := false
	# سطح سوارشدنی (رمپ/سکو): ارتفاع بالا، طول کل، طول رمپ ورودی و رمپ خروجی
	var ride := false
	var portal := ""          # «در:id» یا «خروج»
	var crate := false
	var ride_top := 0.0
	var ride_len := 0.0
	var ride_up := 0.0
	var ride_down := 0.0
	var crashed := false
	# موانع متحرک: "switch" (عوض‌کردن لِین با چراغ) یا "roll" (غلتیدن با سرعت اضافه)
	var mv := ""
	var mv_state := 0
	var mv_timer := 0.0
	var mv_to_x := 0.0
	var mv_extra := 0.0
	var mv_r := 0.5
	var blinkers: Array = []
	var glows: Array = []

var player  # از بیرون (main.gd) مقداردهی می‌شود
var ents: Array[Ent] = []

var _cursor := FIRST_ROW_Z
var _last_open_lane := 0
var _rng := RandomNumberGenerator.new()
var _time := 0.0
var _since_power := 0.0
var _since_piece := 0.0
var _skip := 0.0
var _next_power_gap := 260.0
var _fx: Array[Node3D] = []

var _mat_concrete: StandardMaterial3D
var _mat_hazard: StandardMaterial3D
var _mat_steel: StandardMaterial3D
var _mat_dark: StandardMaterial3D
var _mat_rubber: StandardMaterial3D
var _mat_crate: StandardMaterial3D
var _mat_cone: StandardMaterial3D
var _mat_white: StandardMaterial3D
var _mat_glass: StandardMaterial3D
var _mat_head: StandardMaterial3D
var _mat_tail: StandardMaterial3D
var _mat_amber: StandardMaterial3D
var _mat_led: StandardMaterial3D
var _mat_cable: StandardMaterial3D
var _mat_wood: StandardMaterial3D
var _mat_stone: StandardMaterial3D
var _mat_moss: StandardMaterial3D
var _mat_leaf: Array[StandardMaterial3D] = []
var _mat_cloth: StandardMaterial3D
var _mat_cactus: StandardMaterial3D
var _mat_glyph: StandardMaterial3D
var _mat_bark: StandardMaterial3D
var _mat_vine: StandardMaterial3D
var _mat_rock: StandardMaterial3D
var _mat_red: StandardMaterial3D
var _strata: Array[StandardMaterial3D] = []
var _ribs: Texture2D
var _blink_amber: StandardMaterial3D


func _ready() -> void:
	_rng.randomize()
	_ribs = Gfx.ribs_tex()
	_mat_concrete = Gfx.mat(Color("c9c0b4"), 0.0, Gfx.noise_tex(Color.WHITE, 0.12, 32, 3), 0.95)
	_mat_hazard = Gfx.mat(Color.WHITE, 0.2, Gfx.hazard_tex(), 0.7)
	_mat_steel = Gfx.mat(Color("7a7288"), 0.0, null, 0.45)
	_mat_steel.metallic = 0.5
	_mat_dark = Gfx.mat(Color("2a2430"), 0.0, null, 0.8)
	_mat_rubber = Gfx.mat(Color("141018"), 0.0, null, 1.0)
	_mat_crate = Gfx.mat(Color.WHITE, 0.0, Gfx.crate_tex(), 0.9)
	_mat_cone = Gfx.mat(Color("ff6a1f"), 0.3, null, 0.6)
	_mat_white = Gfx.mat(Color("f6f1ea"), 0.15, null, 0.6)
	_mat_glass = Gfx.mat(Color("68d8ff"), 0.0, null, 0.1)
	_mat_glass.emission_enabled = true
	_mat_glass.emission = Color("1a4a62")
	_mat_head = Gfx.mat(Color("fff2b0"), 2.0, null, 0.3)
	_mat_tail = Gfx.mat(Color("ff3030"), 1.8, null, 0.3)
	_mat_amber = Gfx.mat(Color("ffb020"), 2.4, null, 0.3)
	_blink_amber = Gfx.mat(Color("ffb020"), 2.4, null, 0.3)
	_mat_led = Gfx.mat(Color("ff8a3a"), 1.6, null, 0.4)
	_mat_cable = Gfx.mat(Color("2a2438"), 0.0, null, 0.7)
	_mat_wood = Gfx.mat(Color("9a6a3a"), 0.0, Gfx.bark_tex(), 0.9)
	_mat_bark = Gfx.mat(Color.WHITE, 0.0, Gfx.bark_tex(), 0.95)
	_mat_stone = Gfx.mat(Color.WHITE, 0.0, Gfx.stone_tex(), 0.95)
	_mat_stone.uv1_triplanar = true
	_mat_stone.uv1_scale = Vector3(0.45, 0.45, 0.45)
	_mat_moss = Gfx.mat(Color("5a9a3a"), 0.0, null, 1.0)
	for c in [Color("3f9a3a"), Color("5db04a"), Color("2f7f3f")]:
		_mat_leaf.append(Gfx.mat(c, 0.0, Gfx.noise_tex(Color.WHITE, 0.1, 32, 12), 0.9))
	_mat_cloth = Gfx.mat(Color("f0e2c0"), 0.0, null, 0.9)
	_mat_cactus = Gfx.mat(Color("4f9a50"), 0.0, null, 0.8)
	_mat_glyph = Gfx.mat(Color("ffb040"), 2.2, null, 0.4)
	_mat_vine = Gfx.mat(Color("2f7a35"), 0.0, null, 0.9)
	_mat_rock = Gfx.mat(Color("b88a5a"), 0.0, Gfx.noise_tex(Color.WHITE, 0.12, 32, 8), 1.0)
	_mat_red = Gfx.mat(Color("d6402e"), 0.0, null, 0.8)
	for p in [[Color("d98a52"), Color("a64f33"), 3], [Color("e8b070"), Color("c9783f"), 4], [Color("cf7a4a"), Color("8f3f2a"), 5]]:
		var m := Gfx.mat(Color.WHITE, 0.0, Gfx.strata_tex(p[0], p[1], p[2]), 1.0)
		m.uv1_triplanar = true
		m.uv1_scale = Vector3(0.18, 0.18, 0.18)
		_strata.append(m)
	Game.power_collected.connect(_on_power_collected)


func reset() -> void:
	# رقابت: همه‌ی بازیکنان با یک seed مشترک می‌دوند (چیدمان یکسان)؛ بازی عادی: تصادفی
	if Game.challenge_room > 0:
		_rng.seed = Game.challenge_room * 7919 + 13
	else:
		_rng.randomize()
	for e in ents:
		if is_instance_valid(e.node):
			e.node.queue_free()
	ents.clear()
	for f in _fx:
		if is_instance_valid(f):
			f.queue_free()
	_fx.clear()
	_cursor = FIRST_ROW_Z
	_last_open_lane = 0
	_since_power = 0.0
	_since_piece = 0.0
	_skip = 0.0
	_next_power_gap = 220.0


## بعد از زنده‌شدن دوباره: موانع نزدیک پاک می‌شوند تا بازیکن بلافاصله نخورد
func clear_obstacles_near() -> void:
	for e in ents:
		if e.kind >= Kind.LOW and not e.ride and is_instance_valid(e.node) and e.node.position.z > -45.0 and e.node.position.z < 12.0:
			e.done = true
			e.node.queue_free()


# ------------------------- حلقه‌ی اصلی -------------------------
func advance(delta: float, speed: float) -> void:
	var dz := speed * delta
	_time += delta
	_cursor += dz
	_blink_amber.emission_energy_multiplier = 3.0 if fmod(_time, 0.7) < 0.35 else 0.4
	var magnet := Game.is_active and Game.has_power(Game.Power.MAGNET)
	var py := 0.0
	var px := 0.0
	if player != null:
		px = player.position.x
		py = player.jump_y + 1.0
	for e in ents:
		if not is_instance_valid(e.node):
			continue
		e.node.position.z += dz
		if e.mv != "" and not e.done:
			_move_entity(e, delta, speed)
		if e.spin_node and e.mv == "" and not e.done:
			e.spin_node.rotate_y(delta * (3.2 if e.kind == Kind.COIN else 2.2))
			if e.kind == Kind.POWER:
				e.spin_node.position.y = sin(_time * 3.0) * 0.1
		if magnet and e.kind == Kind.COIN and not e.done:
			var p := e.node.position
			if not e.pulling and p.z > -MAGNET_REACH and p.z < 3.0 and absf(p.x - px) < MAGNET_RADIUS:
				e.pulling = true
			if e.pulling:
				var target := Vector3(px, py, 0.0)
				e.node.position = p.move_toward(target, (14.0 + speed) * delta)
				e.x = e.node.position.x
				e.y0 = e.node.position.y - 0.5
				e.y1 = e.node.position.y + 0.5
	for i in range(_fx.size() - 1, -1, -1):
		if is_instance_valid(_fx[i]):
			_fx[i].position.z += dz
		else:
			_fx.remove_at(i)

	if Game.is_active:
		while _cursor > -SPAWN_AHEAD:
			_spawn_row(_cursor)
			_cursor -= _row_gap() + _skip
			_skip = 0.0
		_check_collisions(delta, speed)
	if player != null:
		player.ground_h = ground_at(px, player.jump_y)

	_cleanup()


func _row_gap() -> float:
	return maxf(12.0, Game.run_speed * 1.05)


# ------------------------- برخورد -------------------------
func _check_collisions(delta: float, speed: float) -> void:
	var yr: Vector2 = player.get_y_range()
	var px: float = player.position.x
	var reach := PLAYER_HALF_DEPTH + speed * delta
	# داخل تونل کم‌ارتفاع سُرخوردن تا خروج ادامه پیدا می‌کند
	for e in ents:
		if e.kind == Kind.OVERHEAD and e.half_d > 1.2 and is_instance_valid(e.node) and absf(e.node.position.z) < e.half_d + 0.6 and absf(e.x - px) < e.half_w:
			player.hold_slide()
	for e in ents:
		if e.done or not is_instance_valid(e.node):
			continue
		if e.portal != "":
			# پرتال روی یک لِین است: فقط اگر بازیکن از همان لِین رد شود وارد می‌شود
			if absf(e.node.position.z) <= 0.9 + speed * delta:
				if absf(px - e.x) <= PORTAL_HIT_X:
					e.done = true
					_burst(Vector3(px, 1.2, 0.0), Color.WHITE, 40, 8.0, 0.9)
					_pop_free(e.node)
					if e.portal == "exit":
						Game.exit_mode()
					else:
						Game.enter_mode(e.portal)
					return
			elif e.node.position.z > 1.6:
				# رد شد: انتخاب بازیکن بود
				e.done = true
				if e.portal == "exit":
					Game.exit_missed()
				else:
					Game.schedule_portal()
			continue
		if e.ride:
			_check_ride_crash(e, px, yr)
			continue
		if e.kind >= Kind.LOW and not e.near_done and e.node.position.z > e.half_d + PLAYER_HALF_DEPTH:
			# مانع از کنار بازیکن گذشت؛ اگر خیلی نزدیک بود جایزه بده
			e.near_done = true
			var gap := absf(e.x - px) - e.half_w - PLAYER_HALF_WIDTH
			if gap > 0.0 and gap < 0.35 and e.y1 > yr.x and e.y0 < yr.y and player.invuln <= 0.0:
				Game.register_near_miss()
				_burst(Vector3(px, yr.x + 1.0, 0.0), Color("fff2a0"), 10, 3.5, 0.4)
		if absf(e.node.position.z) > e.half_d + reach:
			continue
		if absf(e.x - px) > e.half_w + PLAYER_HALF_WIDTH:
			continue
		if e.y1 < yr.x or e.y0 > yr.y:
			continue
		if e.kind == Kind.LOW and e.y0 > -0.5 and e.y1 >= 0.6 and e.y1 - yr.x <= STEP_UP + 0.05:
			continue   # از بالا/لبه‌ی مانع رد می‌شود یا روی آن می‌ایستد

		if e.crate and e.kind >= Kind.LOW and player.is_sliding():
			# حالت کراش: سُرخوردن = چرخش؛ جعبه می‌شکند
			e.done = true
			Game.run_bonus += 60
			Game.popup.emit("جعبه شکست! +60", true)
			_burst(e.node.position + Vector3(0, 0.8, 0), Color("ffb347"), 26, 6.0, 0.6)
			_pop_free(e.node)
			continue
		e.done = true
		if e.kind == Kind.COIN:
			Game.register_coin()
			_burst(e.node.position, Color("ffd84a"), 8, 3.0, 0.45)
			_pop_free(e.node)
		elif e.kind == Kind.POWER:
			Game.register_power(e.power)
			_burst(e.node.position, POWER_COLORS[e.power], 22, 5.0, 0.7)
			_pop_free(e.node)
		else:
			# در حالت شکست‌ناپذیری از مانع رد می‌شود
			if player.invuln <= 0.0:
				# فقط لبه‌ی مانع (نفوذ کم) = خراش؛ برخورد روبه‌رو = دستگیری
				var pen := e.half_w + PLAYER_HALF_WIDTH - absf(e.x - px)
				var graze := pen < GRAZE_DEPTH
				var res := Game.register_obstacle_hit(graze)
				if res != "ignored":
					player.on_hit()
					if graze and res == "stumble":
						player.bounce_from(e.x)
					var hp := Vector3(px, clampf(yr.x + 0.6, 0.4, 2.0), e.node.position.z + e.half_d)
					_burst(hp, Color("ffb020") if res != "shield" else Color("38d6ff"), 26, 6.0, 0.7)
		if not Game.is_active:
			return


# ------------------------- سطح‌های سوارشدنی -------------------------
## ارتفاع سطح در فاصله‌ی d از ابتدای رمپ (طول مسیر از سمت بازیکن)
func _ride_h(e: Ent, zl: float) -> float:
	var d := e.ride_len * 0.5 - zl
	if d < 0.0 or d > e.ride_len:
		return 0.0
	var h := clampf(d / maxf(e.ride_up, 0.01), 0.0, 1.0)
	if e.ride_down > 0.0:
		h = minf(h, clampf((e.ride_len - d) / e.ride_down, 0.0, 1.0))
	return h * e.ride_top


## بالاترین سطحی که پای بازیکن (با پله‌ی کوچک) به آن می‌رسد
func ground_at(px: float, feet: float) -> float:
	var best := 0.0
	for e in ents:
		if not is_instance_valid(e.node):
			continue
		if not e.ride:
			# مانع‌های کوتاه از بالا سوارشدنی‌اند (فقط برخورد از پایین کشنده است)
			if e.kind == Kind.LOW and e.y0 > -0.5 and e.y1 >= 0.6 and not e.done and absf(e.x - px) <= e.half_w - 0.1 and absf(e.node.position.z) <= e.half_d + 0.05 and e.y1 <= feet + STEP_UP:
				best = maxf(best, e.y1)
			continue
		if absf(e.x - px) > e.half_w - 0.1:
			continue
		var h := _ride_h(e, -e.node.position.z)
		if h <= feet + STEP_UP:
			best = maxf(best, h)
	return best


## برخورد با دیواره‌ی سکو (وقتی پایین‌تر از سطح وارد شوی)
func _check_ride_crash(e: Ent, px: float, yr: Vector2) -> void:
	if e.crashed or absf(e.x - px) > e.half_w + 0.05:
		return
	var h := _ride_h(e, -e.node.position.z)
	if h - yr.x > STEP_UP + 0.05 and h > 0.0 and player.invuln <= 0.0:
		e.crashed = true
		if h - yr.x <= LEDGE_GRAB:
			# لبه‌ی خیلی نزدیک: بازیکن خودکار بالا می‌پرد (کمبو می‌شکند ولی جان نمی‌رود)
			player.mantle(h)
			Game.reset_combo()
			Game.popup.emit("بالا رفتی!", false)
			_burst(Vector3(px, clampf(yr.x + 0.4, 0.3, 1.5), e.node.position.z + e.ride_len * 0.5), Color("ffe08a"), 14, 4.0, 0.5)
			return
		# برخورد از پایین با دیواره‌ی سکو = برخورد واقعی
		var res := Game.register_obstacle_hit(e.half_w + PLAYER_HALF_WIDTH - absf(e.x - px) < GRAZE_DEPTH)
		if res != "ignored":
			player.on_hit()
			if res == "stumble":
				player.bounce_from(e.x)
			_burst(Vector3(px, clampf(yr.x + 0.6, 0.4, 2.0), e.node.position.z + e.ride_len * 0.5), Color("ffb020") if res != "shield" else Color("38d6ff"), 26, 6.0, 0.7)


# ------------------------- موانع متحرک -------------------------
func _move_entity(e: Ent, delta: float, speed: float) -> void:
	var n := e.node
	if e.mv == "roll":
		n.position.z += e.mv_extra * delta
		if e.spin_node:
			e.spin_node.rotate_x(-(speed + e.mv_extra) * delta / maxf(e.mv_r, 0.2))
		return
	# switch: صبر ← چشمک ← حرکت جانبی
	match e.mv_state:
		0:
			if n.position.z > SWITCH_TRIGGER_Z:
				e.mv_state = 1
				e.mv_timer = 0.7
		1:
			e.mv_timer -= delta
			var on := fmod(e.mv_timer, 0.2) > 0.1
			for b in e.blinkers:
				var bm := (b as MeshInstance3D).material_override as StandardMaterial3D
				bm.emission_enabled = true
				bm.emission = Color("ffb000")
				bm.emission_energy_multiplier = 4.0 if on else 0.1
			for g in e.glows:
				(g as Node3D).visible = on
			if e.mv_timer <= 0.0:
				e.mv_state = 2
		2:
			e.x = move_toward(e.x, e.mv_to_x, SWITCH_SPEED * delta)
			n.position.x = e.x
			n.rotation.y = clampf((e.mv_to_x - e.x) * -0.18, -0.3, 0.3)
			if absf(e.x - e.mv_to_x) < 0.01:
				e.mv_state = 3
				n.rotation.y = 0.0
				for g in e.glows:
					(g as Node3D).visible = false


func _pop_free(n: Node3D) -> void:
	var tw := n.create_tween()
	tw.tween_property(n, "scale", Vector3.ZERO, 0.1)
	tw.tween_callback(n.queue_free)


func _cleanup() -> void:
	for i in range(ents.size() - 1, -1, -1):
		var e := ents[i]
		if not is_instance_valid(e.node):
			ents.remove_at(i)
		elif e.node.position.z - e.half_d > DESPAWN_Z:
			e.node.queue_free()
			ents.remove_at(i)


## انفجار جرقه‌ها (جمع‌کردن / برخورد)
var _burst_cache := {}


## مش/متریال جرقه برای هر رنگ فقط یک‌بار ساخته می‌شود (ساختن در لحظه‌ی برداشتن سکه لگ می‌انداخت)
func _burst_mesh(color: Color) -> Mesh:
	var key := color.to_html()
	if _burst_cache.has(key):
		return _burst_cache[key]
	var m := SphereMesh.new()
	m.radius = 0.07
	m.height = 0.14
	m.radial_segments = 6
	m.rings = 3
	var mm := StandardMaterial3D.new()
	mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mm.albedo_color = color
	m.material = mm
	_burst_cache[key] = m
	return m


func _burst(pos: Vector3, color: Color, amount: int, vel: float, life: float) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = amount
	p.lifetime = life
	p.explosiveness = 1.0
	p.direction = Vector3(0, 1, 0.4)
	p.spread = 180.0
	p.initial_velocity_min = vel * 0.5
	p.initial_velocity_max = vel
	p.gravity = Vector3(0, -7.0, 0)
	p.scale_amount_min = 0.6
	p.scale_amount_max = 1.2
	p.mesh = _burst_mesh(color)
	p.position = pos
	add_child(p)
	p.emitting = true
	_fx.append(p)
	get_tree().create_timer(life + 0.3).timeout.connect(p.queue_free)


# ------------------------- ساخت ردیف‌ها -------------------------
func _spawn_row(z: float) -> void:
	var d := Game.difficulty()
	# پرتال ورود (در جاده‌ی عادی) یا پرتال خروج (در پایان جهان)
	if Game.mode == "" and Game.portals_on and Content.feature("portals") and Game.distance + SPAWN_AHEAD >= Game.next_portal_at and Game.distance > 150.0 and _since_piece > 40.0 and Game.portal_due():
		var ids := Modes.enabled_ids()
		if not ids.is_empty():
			Game.next_portal_at = Game.distance + 100000.0   # تا ورود/نرسیدن، دوباره نساز
			var dest := ids[_rng.randi() % ids.size()]
			if Game.portal_dest != "" and ids.has(Game.portal_dest):
				dest = Game.portal_dest
			_spawn_portal(z, dest, float(_rng.randi_range(-1, 1)) * Game.LANE_WIDTH)
			return
	if Game.mode != "" and Game.ret_due(SPAWN_AHEAD):
		Game.exit_spawned = true
		_spawn_portal(z, "", float(_rng.randi_range(-1, 1)) * Game.LANE_WIDTH)
		return
	_since_piece += _row_gap()
	if Game.distance > 90.0 and _since_piece > 70.0 and not Content.enabled_pieces().is_empty() and _rng.randf() < lerpf(0.3, 0.5, d):
		_since_piece = 0.0
		_since_power += _row_gap()
		_spawn_piece(z)
		return
	var open_lane := _next_open_lane()
	_since_power += _row_gap()

	if _rng.randf() < lerpf(0.10, 0.30, d) and (Content.feature("obs_low") or Content.feature("obs_over")):
		# ردیف «دروازه»: دو لِین یک نوع مانع دارند و لِین سوم باز است
		var gate_kind: int = Kind.LOW if _rng.randf() < 0.5 else Kind.OVERHEAD
		if not Content.feature("obs_low"):
			gate_kind = Kind.OVERHEAD
		elif not Content.feature("obs_over"):
			gate_kind = Kind.LOW
		var variant := _rng.randi_range(0, 11)
		var arc_lane := open_lane
		for lane in [-1, 0, 1]:
			if lane == open_lane:
				continue          # هیچ‌وقت هر سه لِین با هم بسته نمی‌شود
			_spawn_obstacle(gate_kind, lane, z, variant)
		if gate_kind == Kind.LOW and _rng.randf() < 0.6:
			_spawn_arc(arc_lane, z)
	else:
		var p_obstacle := lerpf(0.45, 0.9, d)
		for lane in [-1, 0, 1]:
			if lane == open_lane:
				continue  # این لِین همیشه خالی می‌ماند تا بازی هیچ‌وقت غیرقابل‌عبور نشود
			if _rng.randf() < p_obstacle:
				var k := _random_obstacle_kind()
				if k < 0:
					continue
				_spawn_obstacle(k, lane, z, _rng.randi_range(0, 11))
				if k == Kind.LOW and _rng.randf() < 0.4:
					_spawn_arc(lane, z)
		if _rng.randf() < lerpf(0.05, 0.14, d) and Game.distance > 150.0 and Content.feature("rollers"):
			var rl := (open_lane + _rng.randi_range(1, 2) + 1) % 3 - 1     # لِینی غیر از لِین باز
			if rl != open_lane:
				_spawn_roller(rl, z - 3.0)
		var pw := _random_power() if Content.any_power() else -1
		if _since_power >= _next_power_gap and pw >= 0:
			_since_power = 0.0
			_next_power_gap = _rng.randf_range(260.0, 420.0)
			_spawn_power(pw, float(open_lane) * Game.LANE_WIDTH, z)
		elif _rng.randf() < 0.4:
			_spawn_coin(float(open_lane) * Game.LANE_WIDTH, 1.0, z)

	_spawn_trail(z - 4.2)


# ------------------------- قطعه‌های ویژه -------------------------
func _spawn_piece(z: float) -> void:
	var zone := Game.zone_at(Game.distance + SPAWN_AHEAD)
	var en := Content.enabled_pieces()
	if en.is_empty():
		return
	match en[_rng.randi() % en.size()]:
		"platform": _spawn_platform(z, zone)
		"closure": _spawn_closure(z, zone)
		"pits": _spawn_pits(z, zone)
		"tunnel": _spawn_tunnel(z, zone)
		_: _spawn_switcher(z, zone)


func _new_ent(kind: int, x: float, y0: float, y1: float, hw: float, hd: float) -> Ent:
	var e := Ent.new()
	e.kind = kind
	e.x = x
	e.y0 = y0
	e.y1 = y1
	e.half_w = hw
	e.half_d = hd
	return e


func _register(e: Ent, node: Node3D, zc: float) -> void:
	node.position = Vector3(e.x, 0.0, zc)
	add_child(node)
	e.node = node
	ents.append(e)
	if e.kind >= Kind.LOW:
		_clear_coins_in(e)


## سکوی سوارشدنی روی یک لِین؛ لِین‌های دیگر مانع‌های معمولی دارند و سکه‌ها بالای سکو هستند
func _spawn_platform(z: float, zone: int, lane_force: int = -9) -> void:
	var lane := _rng.randi_range(-1, 1) if lane_force == -9 else lane_force
	var T := _rng.randf_range(1.6, 1.95)
	var up := 7.0
	var down := 5.0 if (zone == 1 or zone == 3) and _rng.randf() < 0.6 else 0.0
	var L := up + _rng.randf_range(10.0, 15.0) + down
	var e := _new_ent(Kind.FULL, float(lane) * Game.LANE_WIDTH, 0.0, T, 1.0, L * 0.5)
	e.ride = true
	e.ride_top = T
	e.ride_len = L
	e.ride_up = up
	e.ride_down = down
	var node := Node3D.new()
	SP.platform(node, zone, L, T, up, down)
	_register(e, node, z - L * 0.5)
	# سکه‌های روی سکو (پاداش بالا رفتن)
	var plat_start := z - up
	var plat_end := z - L + down
	var cz := plat_start - 1.0
	while cz > plat_end + 1.0:
		_spawn_coin(e.x, T + 1.0, cz)
		cz -= 1.8
	if _rng.randf() < 0.3:
		_spawn_power(_random_power(), e.x, (plat_start + plat_end) * 0.5, T + 1.2)
	# لِین‌های کناری
	var gz := z - 4.0
	while gz > z - L + 2.0:
		for l2 in [-1, 0, 1]:
			if l2 == lane:
				continue
			if _rng.randf() < 0.5:
				_spawn_obstacle(_random_obstacle_kind(), l2, gz, _rng.randi_range(0, 11))
		gz -= maxf(12.0, Game.run_speed * 1.05)
	_last_open_lane = lane
	_skip = L + 3.0


## پرتال روی یک لِین (x)؛ id خالی = دروازه‌ی بازگشت به جهان اصلی
func _spawn_portal(z: float, id: String, x: float = 0.0) -> void:
	var e := Ent.new()
	e.kind = Kind.COIN
	e.portal = id if id != "" else "exit"
	e.x = x
	e.y0 = -1.0
	e.y1 = 8.0
	e.half_w = 1.2
	e.half_d = 0.6
	var col := Color("9d5cff")
	var label := "جهان اصلی"
	if id != "":
		col = Modes.def(id).get("tint", col)
		label = String(Modes.def(id).get("name", ""))
	var skin := Game.pick_portal_skin(_rng)
	if id == "":
		var st: Array = PortalSkins.return_style(Game.mode)
		skin = int(st[0])
		label = String(st[1])
		col = Modes.def(Game.mode).get("tint", col)
	var node := Modes.portal_model(col, label, skin)
	node.scale = Vector3.ONE * PORTAL_SCALE
	node.position = Vector3(x, 0, z)
	add_child(node)
	PortalSkins.animate(node)
	e.node = node
	ents.append(e)
	# جاده‌ی جلوی پرتال خالی بماند
	_skip = 10.0
	_since_piece = 0.0


## دو لِین بسته می‌شود؛ باید به لِین باز رفت (تابلوی راه انحرافی روی آن است)
func _spawn_closure(z: float, zone: int) -> void:
	var open_l := _rng.randi_range(-1, 1)
	var len := 12.0
	var sv := _rng.randi()
	var first := true
	for lane in [-1, 0, 1]:
		if lane == open_l:
			continue
		var e := _new_ent(Kind.FULL, float(lane) * Game.LANE_WIDTH, 0.0, 3.6, 0.98, len * 0.5)
		var node := Node3D.new()
		SP.closure(node, zone, len, sv)
		if first:
			first = false
			SP.detour_sign(node, zone, float(open_l - lane) * Game.LANE_WIDTH, len * 0.5)
		_register(e, node, z - len * 0.5)
	for k in 6:
		_spawn_coin(float(open_l) * Game.LANE_WIDTH, 1.0, z - 1.5 - k * 1.8)
	_last_open_lane = open_l
	_skip = len + 2.0


## چاله: یا هر سه لِین (پرش اجباری، کمان سکه) یا یک/دو لِین
func _spawn_pits(z: float, zone: int, force_all: int = -1) -> void:
	var len := 2.6
	var all_lanes := false if force_all < 0 else force_all == 1
	var open_l := _rng.randi_range(-1, 1)
	for lane in [-1, 0, 1]:
		if not all_lanes and lane == open_l:
			continue
		var e := _new_ent(Kind.LOW, float(lane) * Game.LANE_WIDTH, -3.0, 0.2, 0.98, len * 0.5)
		var node := Node3D.new()
		SP.pit(node, zone, len)
		_register(e, node, z - len * 0.5)
	if all_lanes:
		_spawn_arc(_rng.randi_range(-1, 1), z - len * 0.5)
	else:
		_spawn_coin(float(open_l) * Game.LANE_WIDTH, 1.0, z - 1.7)
	_last_open_lane = open_l
	_skip = 6.0


## تونل کم‌ارتفاع: باید سُرخورد؛ سکه‌ها کف تونل‌اند (فقط با سُرخوردن جمع می‌شوند)
func _spawn_tunnel(z: float, zone: int, lane_force: int = -9) -> void:
	var len := 5.0
	var lane := _rng.randi_range(-1, 1) if lane_force == -9 else lane_force
	var two := _rng.randf() < 0.4 and lane_force == -9
	var lanes: Array[int] = [lane]
	if two:
		lanes.append(clampi(lane + (1 if lane < 1 else -1), -1, 1))
	for l in lanes:
		var e := _new_ent(Kind.OVERHEAD, float(l) * Game.LANE_WIDTH, 1.0, 3.2, 0.98, len * 0.5)
		var node := Node3D.new()
		SP.tunnel(node, zone, len)
		_register(e, node, z - len * 0.5)
		for k in 4:
			_spawn_coin(e.x, 0.45, z - 0.9 - k * 1.1)
	_last_open_lane = lane
	_skip = len + 2.0


## وسیله‌ای که چراغ می‌زند و لِینش را عوض می‌کند (لِین سوم همیشه خالی است)
func _spawn_switcher(z: float, zone: int) -> void:
	var opts := [[-1, 0, 1], [0, 1, -1], [0, -1, 1], [1, 0, -1]]
	var o: Array = opts[_rng.randi() % 4]
	var a: int = o[0]
	var b: int = o[1]
	var open_l: int = o[2]
	var node := Node3D.new()
	var info := SP.switcher(node, zone, _rng.randi())
	var e := _new_ent(Kind.FULL, float(a) * Game.LANE_WIDTH, 0.0, float(info["y1"]), 0.9, 1.35)
	e.mv = "switch"
	e.mv_to_x = float(b) * Game.LANE_WIDTH
	e.blinkers = info["blinkers"]
	e.glows = info["glows"]
	Gfx.shadow(node, Vector2(2.4, 3.6), 0.45)
	_register(e, node, z)
	for k in 4:
		_spawn_coin(float(open_l) * Game.LANE_WIDTH, 1.0, z - 2.0 - k * 1.8)
	_last_open_lane = open_l
	_skip = 6.0


func _spawn_roller(lane: int, z: float) -> void:
	var zone := Game.zone_at(Game.distance + SPAWN_AHEAD)
	var node := Node3D.new()
	var info := SP.roller(node, zone)
	var rr: float = info["r"]
	var e := _new_ent(Kind.FULL, float(lane) * Game.LANE_WIDTH, 0.0, float(info["y1"]), minf(0.95, rr + 0.1), rr)
	e.mv = "roll"
	e.mv_extra = 4.0 if rr < 0.7 else 3.0
	e.mv_r = rr
	e.spin_node = info["spin"]
	_register(e, node, z)


func _next_open_lane() -> int:
	# لِین آزاد ردیف بعدی حداکثر یک خط با قبلی فاصله دارد → همیشه فرصت تغییر لِین هست
	_last_open_lane = clampi(_last_open_lane + _rng.randi_range(-1, 1), -1, 1)
	return _last_open_lane


func _random_obstacle_kind() -> int:
	var opts: Array[int] = []
	var w: Array[float] = []
	if Content.feature("obs_low"):
		opts.append(Kind.LOW); w.append(0.35)
	if Content.feature("obs_over"):
		opts.append(Kind.OVERHEAD); w.append(0.30)
	if Content.feature("obs_full"):
		opts.append(Kind.FULL); w.append(0.35)
	if opts.is_empty():
		return -1
	var tot := 0.0
	for x in w:
		tot += x
	var r := _rng.randf() * tot
	for i in opts.size():
		r -= w[i]
		if r <= 0.0:
			return opts[i]
	return opts[opts.size() - 1]


func _random_power() -> int:
	var tot := 0.0
	for i in POWER_WEIGHTS.size():
		if Content.feature("power_%d" % i):
			tot += POWER_WEIGHTS[i]
	if tot <= 0.0:
		return -1
	var r := _rng.randf() * tot
	var last := -1
	for i in POWER_WEIGHTS.size():
		if not Content.feature("power_%d" % i):
			continue
		last = i
		r -= POWER_WEIGHTS[i]
		if r <= 0.0:
			return i
	return last


## ردیف سکه (صاف یا مایل به لِین کناری)
func _spawn_trail(z_start: float) -> void:
	var count := _rng.randi_range(5, 8)
	# ردیف سکه باید قبل از ردیف مانعِ بعدی تمام شود (سکه‌ی داخل مانع یعنی غیرقابل‌گرفتن)
	count = mini(count, maxi(3, int((_row_gap() - 7.0) / COIN_STEP) + 1))
	var lane_a := _rng.randi_range(-1, 1)
	var lane_b := lane_a
	if _rng.randf() < 0.4:
		lane_b = clampi(lane_a + (1 if _rng.randf() < 0.5 else -1), -1, 1)
	for i in count:
		var t := float(i) / float(count - 1)
		var x := lerpf(float(lane_a), float(lane_b), t) * Game.LANE_WIDTH
		_spawn_coin(x, 1.0, z_start - float(i) * COIN_STEP)


## کمانی از سکه‌ها بالای مانع کوتاه (پاداشِ پریدن)
func _spawn_arc(lane: int, z: float) -> void:
	var offsets: Array[float] = [-2.4, -1.2, 0.0, 1.2, 2.4]
	var heights: Array[float] = [1.1, 2.0, 2.7, 2.0, 1.1]
	for i in offsets.size():
		_spawn_coin(float(lane) * Game.LANE_WIDTH, heights[i], z + offsets[i])


func _on_power_collected(id: int) -> void:
	if id == Game.Power.JET:
		_spawn_jet_coins()


## مسیر طولانی سکه در ارتفاع برای زمان جت‌پک
func _spawn_jet_coins() -> void:
	var length := Game.run_speed * Game.power_total[Game.Power.JET] * 1.05
	var lane: int = player.lane
	var z := -10.0
	var i := 0
	while z > -length - 10.0:
		if i % 9 == 8:
			lane = clampi(lane + (1 if _rng.randf() < 0.5 else -1), -1, 1)
		_spawn_coin(float(lane) * Game.LANE_WIDTH, JET_COIN_Y + sin(float(i) * 0.4) * 0.35, z)
		z -= 2.0
		i += 1


# ------------------------- سکه و قدرت -------------------------
## آیا این نقطه داخل (یا چسبیده به) یک مانع جامد است؟ (سکه‌ی آن‌جا قابل‌گرفتن نیست)
func _point_blocked(x: float, y: float, z: float) -> bool:
	for o in ents:
		if o.kind < Kind.LOW or not is_instance_valid(o.node):
			continue
		if absf(o.node.position.z - z) > o.half_d + 0.5:
			continue
		if absf(o.x - x) > o.half_w + 0.35:
			continue
		if y + 0.5 < o.y0 - 0.2 or y - 0.5 > o.y1 + 0.2:
			continue
		return true
	return false


## بعد از ساخت مانع، سکه‌هایی که داخلش افتاده‌اند حذف می‌شوند
func _clear_coins_in(o: Ent) -> void:
	for c in ents:
		if c.kind != Kind.COIN or c.done or not is_instance_valid(c.node):
			continue
		if absf(o.node.position.z - c.node.position.z) > o.half_d + 0.5:
			continue
		if absf(o.x - c.x) > o.half_w + 0.35:
			continue
		var cy: float = c.node.position.y
		if cy + 0.5 < o.y0 - 0.2 or cy - 0.5 > o.y1 + 0.2:
			continue
		c.done = true
		c.node.queue_free()


func _spawn_coin(x: float, y: float, z: float) -> void:
	if _point_blocked(x, y, z):
		return
	var e := Ent.new()
	e.kind = Kind.COIN
	e.x = x
	e.y0 = y - 0.5
	e.y1 = y + 0.5
	e.half_w = 0.5
	e.half_d = 0.5
	var root := Node3D.new()
	var spin := Node3D.new()
	root.add_child(spin)
	if Game.mode != "":
		spin.add_child(Modes.coin_model(Game.mode))
		Gfx.glow(root, Vector3.ZERO, 1.3, (Modes.def(Game.mode).get("tint", Color(1, 0.8, 0.3)) as Color) * Color(1, 1, 1, 0.25))
	else:
		var coin := CoinSkin.make_coin()
		coin.scale = Vector3.ONE * 1.15
		spin.add_child(coin)
		Gfx.glow(root, Vector3.ZERO, 1.3, Color(1.0, 0.8, 0.3, 0.2))
	Batcher.merge(spin)
	root.position = Vector3(x, y, z)
	add_child(root)
	e.node = root
	e.spin_node = spin
	ents.append(e)


func _spawn_power(id: int, x: float, z: float, y: float = 1.15) -> void:
	var e := Ent.new()
	e.kind = Kind.POWER
	e.power = id
	e.x = x
	e.y0 = y - 0.75
	e.y1 = y + 0.75
	e.half_w = 0.7
	e.half_d = 0.6
	var col: Color = POWER_COLORS[id]
	var root := Node3D.new()
	var spin := Node3D.new()
	root.add_child(spin)
	# مدل سه‌بعدی واقعی آیتم (آهنربا، سپر، ×۲، جت‌پک، فنر، ساعت) + هاله و حلقه‌ی نور روی زمین
	var model := Node3D.new()
	model.scale = Vector3.ONE * 1.15
	spin.add_child(model)
	Props.power_model(model, id)
	Gfx.glow(root, Vector3.ZERO, 2.8, Color(col.r, col.g, col.b, 0.38))
	Gfx.pool(root, Vector3(0.0, -(y - 0.05), 0.0), Vector2(2.4, 2.4), Color(col.r, col.g, col.b, 0.45))
	Gfx.shadow(root, Vector2(1.4, 1.4), 0.35, -(y - 0.03))
	Batcher.merge(spin)
	root.position = Vector3(x, y, z)
	add_child(root)
	e.node = root
	e.spin_node = spin
	ents.append(e)


# ------------------------- موانع -------------------------
## «زیرش سر بخور»: دیوار کامل تا بالا + ستون‌ها + نوار هشدار؛ هیچ‌کس فکر نمی‌کند می‌شود از رویش پرید
func _overhead_frame(node: Node3D, zone: int) -> void:
	var wall_cols := ["6d675f", "9a7c4a", "3b3a2b", "7d93aa", "3a4450", "2a1f22"]
	var wm := Gfx.mat(Color(wall_cols[zone % 6]), 0.0, Gfx.noise_tex(Color.WHITE, 0.14, 32, 3), 0.95)
	var half := Game.LANE_WIDTH * 0.5 - 0.06
	var hz := Gfx.mat(Color.WHITE, 0.25, Gfx.hazard_tex(), 0.6)
	for sx in [-1.0, 1.0]:
		var post := MeshInstance3D.new()
		var pm := BoxMesh.new()
		pm.size = Vector3(0.4, 3.0, 0.9)
		post.mesh = pm
		post.material_override = wm
		post.position = Vector3(sx * (half - 0.2), 1.5, -0.45)
		node.add_child(post)
	var top := MeshInstance3D.new()
	var tm := BoxMesh.new()
	tm.size = Vector3(half * 2.0, 2.0, 0.9)
	top.mesh = tm
	top.material_override = wm
	top.position = Vector3(0.0, 2.0, -0.45)
	node.add_child(top)
	# نوار هشدار زرد/مشکی پایین دیوار، دقیقاً هم‌ارتفاع با لبه‌ی برخورد
	var bar := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(half * 2.0 - 0.8, 0.5, 0.96)
	bar.mesh = bm
	bar.material_override = hz
	bar.position = Vector3(0.0, 1.25, -0.45)
	node.add_child(bar)
	# فلش‌های رو به پایین روی پایه‌ی ستون‌ها: خم‌شو!
	for sx in [-1.0, 1.0]:
		var lamp := MeshInstance3D.new()
		var lm := BoxMesh.new()
		lm.size = Vector3(0.22, 0.22, 0.1)
		lamp.mesh = lm
		lamp.material_override = Gfx.mat(Color("ffb000"), 2.5, null, 0.4)
		lamp.position = Vector3(sx * (half - 0.2), 1.25, 0.02)
		node.add_child(lamp)


func _spawn_obstacle(kind: int, lane: int, z: float, variant: int) -> void:
	var e := Ent.new()
	e.kind = kind
	e.x = float(lane) * Game.LANE_WIDTH
	e.half_w = 0.98
	var zone := Game.zone_at(Game.distance + SPAWN_AHEAD)
	var node := Node3D.new()
	var themed: bool = Game.mode != "" and Modes.obstacle(Game.mode, kind, variant, e, node)
	if themed:
		e.crate = Game.mode == "crate"
		pass
	else:
		match kind:
			Kind.LOW:
				e.y0 = 0.0
				e.y1 = 0.9
				e.half_d = 0.45
				var v := variant % 6
				if zone < 3 and v < 4:
					match zone:
						0:
							match v:
								0: _city_barrier(node)
								1: _city_crates(node)
								2: _city_cones(node)
								_: _city_hydrants(node)
						1:
							match v:
								0: _desert_rocks(node)
								1: _desert_cacti(node)
								2: _desert_fence(node)
								_: _desert_bones(node)
						_:
							match v:
								0: _jungle_log(node)
								1: _jungle_bush(node)
								2: _jungle_idols(node)
								_: _jungle_mushrooms(node)
				else:
					Ext.low(zone, v, node)
			Kind.OVERHEAD:
				e.y0 = 1.0
				e.y1 = 3.2
				e.half_d = 0.3
				var v := variant % 5
				if zone < 3 and v < 3:
					match zone:
						0:
							if v == 0:
								_city_gantry(node)
							elif v == 1:
								e.half_d = 0.5
								_city_hanging_container(node)
							else:
								_city_neon_sign(node)
						1:
							if v == 0:
								_desert_arch(node)
							elif v == 1:
								_desert_gate(node)
							else:
								_desert_awning(node)
						_:
							if v == 0:
								_jungle_vines(node)
							elif v == 1:
								_jungle_lintel(node)
							else:
								_jungle_totems(node)
				else:
					Ext.over(zone, v, node)
				_overhead_frame(node, zone)
				e.half_d = 0.9
				e.y1 = 6.0
			_:
				e.y0 = 0.0
				e.y1 = 2.8
				e.half_d = 1.3
				var v := variant % 6
				if zone < 3 and v < 4:
					match zone:
						0:
							match v:
								0: _city_bus(node)
								1: _city_truck(node)
								2: _city_containers(node)
								_: _city_taxi(node)
						1:
							match v:
								0: _desert_wall(node)
								1: _desert_wagon(node)
								2: _desert_boulders(node)
								_: _desert_obelisk(node)
						_:
							match v:
								0: _jungle_ruin(node)
								1: _jungle_trunk(node)
								2: _jungle_statue(node)
								_: _jungle_stairs(node)
				else:
					Ext.full(zone, v, node)
	# مانع بلند پشتش را نمی‌پوشاند: ارتفاع دیده‌شده سقف دارد
	if kind != Kind.OVERHEAD and e.y1 > 2.3:
		node.scale.y = 2.3 / e.y1
		e.y1 = 2.3
	Batcher.merge(node)
	Gfx.shadow(node, Vector2(2.6, maxf(1.4, e.half_d * 2.0 + 0.8)), 0.45)
	node.position = Vector3(e.x, 0.0, z)
	add_child(node)
	e.node = node
	ents.append(e)
	_clear_coins_in(e)


# ===================== شهر =====================
func _city_barrier(n: Node3D) -> void:
	Gfx.box(n, Vector3(1.9, 0.5, 0.8), Vector3(0.0, 0.25, 0.0), _mat_concrete)
	Gfx.box(n, Vector3(1.9, 0.4, 0.55), Vector3(0.0, 0.7, 0.0), _mat_concrete)
	Gfx.box(n, Vector3(1.92, 0.3, 0.04), Vector3(0.0, 0.62, 0.42), _mat_hazard)
	Gfx.box(n, Vector3(1.92, 0.3, 0.04), Vector3(0.0, 0.62, -0.42), _mat_hazard)
	for sx in [-0.8, 0.8]:
		Gfx.box(n, Vector3(0.14, 0.14, 0.14), Vector3(sx, 0.97, 0.0), _blink_amber)
		Gfx.glow(n, Vector3(sx, 1.0, 0.1), 0.9, Color(1.0, 0.65, 0.1, 0.4))


func _city_crates(n: Node3D) -> void:
	Gfx.box(n, Vector3(0.9, 0.9, 0.8), Vector3(-0.48, 0.45, 0.0), _mat_crate)
	Gfx.box(n, Vector3(0.9, 0.9, 0.8), Vector3(0.48, 0.45, 0.0), _mat_crate, Vector3(0.0, 4.0, 0.0))
	Gfx.box(n, Vector3(0.12, 0.12, 0.12), Vector3(0.48, 0.96, 0.0), _blink_amber)
	Gfx.glow(n, Vector3(0.48, 1.0, 0.1), 0.8, Color(1.0, 0.65, 0.1, 0.4))


func _city_cones(n: Node3D) -> void:
	Gfx.box(n, Vector3(1.8, 0.06, 0.7), Vector3(0.0, 0.03, 0.0), _mat_dark)
	for sx in [-0.62, 0.0, 0.62]:
		Gfx.box(n, Vector3(0.5, 0.05, 0.5), Vector3(sx, 0.08, 0.0), _mat_dark)
		Gfx.cyl(n, 0.04, 0.24, 0.8, Vector3(sx, 0.48, 0.0), _mat_cone, Vector3.ZERO, 10)
		Gfx.cyl(n, 0.115, 0.15, 0.1, Vector3(sx, 0.5, 0.0), _mat_white, Vector3.ZERO, 10)
		Gfx.cyl(n, 0.075, 0.095, 0.08, Vector3(sx, 0.7, 0.0), _mat_white, Vector3.ZERO, 10)


func _city_gantry(n: Node3D) -> void:
	var words: Array[String] = ["MAX 1.0m", "LOW", "CLEARANCE", "H 1.0 m"]
	Gfx.box(n, Vector3(2.1, 2.2, 0.4), Vector3(0.0, 2.1, 0.0), _mat_dark)
	Gfx.box(n, Vector3(2.14, 0.16, 0.44), Vector3(0.0, 1.08, 0.0), _mat_hazard)
	Gfx.box(n, Vector3(1.84, 1.0, 0.04), Vector3(0.0, 2.3, 0.22), _mat_led)
	Gfx.label(n, words[_rng.randi() % words.size()], Vector3(0.0, 2.3, 0.26), 72, Color.WHITE, 0.0095)
	for sx in [-1.0, 1.0]:
		Gfx.box(n, Vector3(0.16, 3.2, 0.16), Vector3(sx, 1.6, 0.0), _mat_steel)
		Gfx.box(n, Vector3(0.4, 0.1, 0.4), Vector3(sx, 0.05, 0.0), _mat_steel)


func _city_hanging_container(n: Node3D) -> void:
	var cols: Array[Color] = [Color("d6502d"), Color("2f7fc0"), Color("3b9a58")]
	var m := Gfx.mat(cols[_rng.randi() % cols.size()], 0.0, _ribs, 0.6)
	Gfx.box(n, Vector3(2.0, 1.15, 1.0), Vector3(0.0, 1.6, 0.0), m)
	Gfx.box(n, Vector3(2.04, 0.1, 1.04), Vector3(0.0, 1.07, 0.0), _mat_hazard)
	for sx in [-0.9, 0.9]:
		Gfx.cyl(n, 0.025, 0.025, 1.5, Vector3(sx, 2.9, 0.0), _mat_cable, Vector3.ZERO, 6)
	Gfx.box(n, Vector3(2.2, 0.16, 0.3), Vector3(0.0, 3.62, 0.0), _mat_steel)
	Gfx.box(n, Vector3(0.12, 0.12, 0.12), Vector3(0.0, 1.05, 0.54), _blink_amber)


func _wheels(n: Node3D, xs: Array, zs: Array, r: float) -> void:
	for sx in xs:
		for sz in zs:
			Gfx.cyl(n, r, r, 0.26, Vector3(sx, r, sz), _mat_rubber, Vector3(0.0, 0.0, 90.0), 12)
			Gfx.cyl(n, r * 0.5, r * 0.5, 0.28, Vector3(sx, r, sz), _mat_steel, Vector3(0.0, 0.0, 90.0), 8)


func _lights(n: Node3D, z: float, y: float, dx: float) -> void:
	for sx in [-dx, dx]:
		Gfx.box(n, Vector3(0.32, 0.2, 0.06), Vector3(sx, y, z), _mat_head)


func _city_bus(n: Node3D) -> void:
	var cols: Array[Color] = [Color("e8b21c"), Color("2f7dd1"), Color("d1432f")]
	var body := Gfx.mat(cols[_rng.randi() % cols.size()], 0.0, null, 0.5)
	Gfx.box(n, Vector3(2.0, 2.2, 2.6), Vector3(0.0, 1.5, 0.0), body)
	Gfx.box(n, Vector3(2.04, 0.5, 2.64), Vector3(0.0, 0.55, 0.0), _mat_dark)
	Gfx.box(n, Vector3(1.9, 0.9, 0.06), Vector3(0.0, 2.1, 1.31), _mat_glass)
	Gfx.box(n, Vector3(2.04, 0.7, 2.0), Vector3(0.0, 2.1, 0.0), _mat_glass)
	Gfx.box(n, Vector3(1.96, 0.1, 2.5), Vector3(0.0, 2.62, 0.0), _mat_white)
	Gfx.box(n, Vector3(1.0, 0.22, 0.05), Vector3(0.0, 2.52, 1.32), _mat_led)
	Gfx.label(n, "42", Vector3(0.0, 2.52, 1.36), 40, Color.WHITE, 0.006)
	_lights(n, 1.32, 0.95, 0.7)
	_wheels(n, [-0.98, 0.98], [-0.85, 0.85], 0.38)


## کامیون غذا (به‌جای قطار): سایبان رنگی و پنجره‌ی سرو
func _city_truck(n: Node3D) -> void:
	var cols: Array[Color] = [Color("2fa89a"), Color("e8503a"), Color("f2b632")]
	var body := Gfx.mat(cols[_rng.randi() % cols.size()], 0.0, null, 0.5)
	Gfx.box(n, Vector3(2.0, 2.0, 2.6), Vector3(0.0, 1.35, 0.0), body)
	Gfx.box(n, Vector3(2.04, 0.45, 2.64), Vector3(0.0, 0.45, 0.0), _mat_dark)
	Gfx.box(n, Vector3(1.5, 0.7, 0.06), Vector3(0.0, 1.9, 1.31), _mat_glass)
	Gfx.box(n, Vector3(2.04, 0.1, 2.64), Vector3(0.0, 2.38, 0.0), _mat_white)
	Gfx.box(n, Vector3(1.9, 0.5, 0.5), Vector3(0.0, 2.15, 1.5), Gfx.mat(Color("f2b632"), 0.2, null, 0.7), Vector3(25.0, 0.0, 0.0))
	Gfx.box(n, Vector3(1.9, 0.12, 0.5), Vector3(0.0, 2.52, 1.5), _mat_red, Vector3(25.0, 0.0, 0.0))
	Gfx.label(n, "FOOD", Vector3(0.0, 1.25, 1.35), 46, Color.WHITE, 0.0075)
	Gfx.box(n, Vector3(0.9, 0.4, 0.06), Vector3(0.0, 0.95, 1.33), _mat_white)
	_lights(n, 1.32, 0.6, 0.7)
	_wheels(n, [-0.98, 0.98], [-0.85, 0.85], 0.36)


func _city_containers(n: Node3D) -> void:
	var cols: Array[Color] = [Color("d6502d"), Color("2f7fc0"), Color("3b9a58"), Color("e0a82a")]
	var a := Gfx.mat(cols[_rng.randi() % cols.size()], 0.0, _ribs, 0.6)
	var b := Gfx.mat(cols[_rng.randi() % cols.size()], 0.0, _ribs, 0.6)
	Gfx.box(n, Vector3(2.0, 1.4, 2.6), Vector3(0.0, 0.7, 0.0), a)
	Gfx.box(n, Vector3(2.0, 1.4, 2.6), Vector3(0.0, 2.1, 0.0), b)
	for y in [0.0, 1.4, 2.8]:
		Gfx.box(n, Vector3(2.06, 0.08, 2.66), Vector3(0.0, y + 0.02, 0.0), _mat_steel)
	for sx in [-0.95, 0.95]:
		Gfx.box(n, Vector3(0.08, 2.8, 0.08), Vector3(sx, 1.4, 1.31), _mat_steel)
	Gfx.box(n, Vector3(0.9, 0.35, 0.04), Vector3(0.0, 0.7, 1.32), _mat_white)
	Gfx.label(n, "CARGO", Vector3(0.0, 0.7, 1.35), 30, Color("2a2430"), 0.005)


# ===================== صحرا =====================
func _rock(n: Node3D, pos: Vector3, size: Vector3, m: Material) -> void:
	var s := Gfx.sphere(n, 1.0, pos, m, 8)
	s.scale = size
	s.rotation_degrees = Vector3(0.0, _rng.randf_range(0.0, 180.0), 0.0)


func _desert_rocks(n: Node3D) -> void:
	_rock(n, Vector3(-0.6, 0.3, 0.0), Vector3(0.52, 0.34, 0.45), _mat_rock)
	_rock(n, Vector3(0.1, 0.4, 0.05), Vector3(0.55, 0.45, 0.5), _strata[1])
	_rock(n, Vector3(0.68, 0.27, -0.05), Vector3(0.42, 0.3, 0.4), _mat_rock)
	_rock(n, Vector3(-0.1, 0.12, 0.35), Vector3(0.9, 0.14, 0.3), _strata[0])


func _desert_cacti(n: Node3D) -> void:
	_rock(n, Vector3(0.0, 0.05, 0.0), Vector3(1.0, 0.18, 0.5), _mat_rock)
	for sx in [-0.62, 0.0, 0.62]:
		var s := Gfx.sphere(n, 1.0, Vector3(sx, 0.4, 0.0), _mat_cactus, 10)
		s.scale = Vector3(0.36, 0.38, 0.36)
		Gfx.sphere(n, 0.09, Vector3(sx, 0.8, 0.0), Gfx.mat(Color("f2709a"), 0.5, null, 0.6), 6)
		for k in 4:
			var a := float(k) * PI * 0.5
			Gfx.box(n, Vector3(0.025, 0.7, 0.025), Vector3(sx + cos(a) * 0.35, 0.4, sin(a) * 0.35), _mat_cloth)


func _desert_fence(n: Node3D) -> void:
	for sx in [-0.85, 0.0, 0.85]:
		Gfx.box(n, Vector3(0.14, 0.95, 0.14), Vector3(sx, 0.47, 0.0), _mat_wood)
	for y in [0.35, 0.72]:
		Gfx.box(n, Vector3(1.95, 0.1, 0.08), Vector3(0.0, y, 0.12), _mat_wood)
	Gfx.box(n, Vector3(0.5, 0.3, 0.02), Vector3(0.4, 0.55, 0.2), _mat_red)
	Gfx.box(n, Vector3(0.3, 0.4, 0.02), Vector3(-0.5, 0.5, 0.2), _mat_cloth)


func _desert_arch(n: Node3D) -> void:
	var sm := _strata[_rng.randi() % 3]
	for sx in [-0.95, 0.95]:
		Gfx.box(n, Vector3(0.5, 3.3, 0.8), Vector3(sx, 1.65, 0.0), sm)
	Gfx.box(n, Vector3(2.4, 2.2, 0.8), Vector3(0.0, 2.1, 0.0), sm)
	Gfx.box(n, Vector3(2.5, 0.2, 0.9), Vector3(0.0, 3.2, 0.0), _mat_rock)
	for i in 5:
		var c: Color = [Color("e8503a"), Color("f2b632"), Color("2fa89a")][i % 3]
		Gfx.box(n, Vector3(0.1, 0.5, 0.03), Vector3(-0.8 + i * 0.4, 1.25, 0.42), Gfx.mat(c, 0.2, null, 0.8))
	Gfx.label(n, "!", Vector3(0.0, 2.3, 0.43), 100, Color("2a1a10"), 0.012)


func _desert_gate(n: Node3D) -> void:
	for sx in [-1.0, 1.0]:
		Gfx.cyl(n, 0.13, 0.15, 3.4, Vector3(sx, 1.7, 0.0), _mat_wood, Vector3.ZERO, 8)
	Gfx.cyl(n, 0.22, 0.22, 2.5, Vector3(0.0, 3.05, 0.0), _mat_wood, Vector3(0.0, 0.0, 90.0), 10)
	Gfx.box(n, Vector3(1.9, 1.2, 0.14), Vector3(0.0, 1.6, 0.0), _mat_wood)
	Gfx.box(n, Vector3(1.9, 0.12, 0.16), Vector3(0.0, 1.05, 0.0), _mat_hazard)
	Gfx.label(n, "STOP", Vector3(0.0, 1.65, 0.09), 60, Color("fff0d0"), 0.01)
	for sx in [-0.9, 0.9]:
		Gfx.cyl(n, 0.02, 0.02, 0.5, Vector3(sx, 2.6, 0.0), _mat_cable, Vector3.ZERO, 6)
		Gfx.sphere(n, 0.16, Vector3(sx, 2.3, 0.0), _blink_amber, 8)


func _desert_wall(n: Node3D) -> void:
	var sm := _strata[_rng.randi() % 3]
	Gfx.box(n, Vector3(2.0, 2.6, 2.6), Vector3(0.0, 1.3, 0.0), sm)
	Gfx.box(n, Vector3(2.1, 0.25, 2.7), Vector3(0.0, 2.7, 0.0), _mat_rock)
	for sx in [-0.7, 0.0, 0.7]:
		Gfx.box(n, Vector3(0.4, 0.3, 0.5), Vector3(sx, 2.95, 1.0), sm)
	Gfx.box(n, Vector3(0.8, 1.3, 0.05), Vector3(0.0, 1.0, 1.31), _mat_dark)
	Gfx.box(n, Vector3(0.6, 0.12, 0.08), Vector3(0.0, 1.7, 1.33), _mat_glyph)
	_rock(n, Vector3(0.8, 0.2, 1.5), Vector3(0.35, 0.25, 0.3), _mat_rock)


func _desert_wagon(n: Node3D) -> void:
	Gfx.box(n, Vector3(2.0, 0.9, 2.3), Vector3(0.0, 1.05, 0.0), _mat_wood)
	Gfx.box(n, Vector3(2.06, 0.1, 2.36), Vector3(0.0, 1.55, 0.0), _mat_dark)
	var c := Gfx.cyl(n, 0.98, 0.98, 2.5, Vector3(0.0, 1.85, 0.0), _mat_cloth, Vector3(90.0, 0.0, 0.0), 14)
	c.scale = Vector3(1.0, 1.0, 0.9)
	Gfx.cyl(n, 0.7, 0.7, 0.06, Vector3(0.0, 1.85, 1.25), _mat_dark, Vector3(90.0, 0.0, 0.0), 12).scale = Vector3(1.0, 1.0, 0.9)
	for sx in [-1.02, 1.02]:
		for sz in [-0.8, 0.8]:
			Gfx.cyl(n, 0.6, 0.6, 0.14, Vector3(sx, 0.6, sz), _mat_wood, Vector3(0.0, 0.0, 90.0), 14)
			Gfx.cyl(n, 0.12, 0.12, 0.2, Vector3(sx, 0.6, sz), _mat_steel, Vector3(0.0, 0.0, 90.0), 8)
	Gfx.box(n, Vector3(0.9, 0.5, 0.5), Vector3(0.0, 0.5, 1.5), _mat_wood)
	Gfx.sphere(n, 0.14, Vector3(0.0, 2.55, 1.0), _blink_amber, 8)


func _desert_boulders(n: Node3D) -> void:
	_rock(n, Vector3(0.0, 1.25, 0.0), Vector3(1.0, 1.3, 1.2), _mat_rock)
	_rock(n, Vector3(0.1, 2.15, -0.3), Vector3(0.8, 0.8, 0.85), _strata[1])
	_rock(n, Vector3(-0.5, 0.7, 1.0), Vector3(0.6, 0.7, 0.6), _strata[0])
	_rock(n, Vector3(0.6, 0.6, 0.9), Vector3(0.55, 0.6, 0.55), _mat_rock)


# ===================== جنگل و معبد =====================
func _jungle_log(n: Node3D) -> void:
	Gfx.cyl(n, 0.42, 0.42, 1.95, Vector3(0.0, 0.42, 0.0), _mat_bark, Vector3(0.0, 0.0, 90.0), 12)
	for sx in [-0.98, 0.98]:
		Gfx.cyl(n, 0.36, 0.36, 0.03, Vector3(sx, 0.42, 0.0), _mat_wood, Vector3(0.0, 0.0, 90.0), 12)
	var m := Gfx.sphere(n, 1.0, Vector3(0.1, 0.8, 0.0), _mat_moss, 8)
	m.scale = Vector3(0.7, 0.14, 0.32)
	for sx in [-0.5, 0.45]:
		Gfx.cyl(n, 0.02, 0.02, 0.18, Vector3(sx, 0.88, 0.12), _mat_cloth, Vector3.ZERO, 6)
		Gfx.sphere(n, 0.1, Vector3(sx, 0.97, 0.12), _mat_red, 8).scale = Vector3(1.0, 0.6, 1.0)


func _jungle_bush(n: Node3D) -> void:
	for i in 5:
		var s := Gfx.sphere(n, 1.0, Vector3(_rng.randf_range(-0.7, 0.7), 0.4 + _rng.randf_range(0.0, 0.2), _rng.randf_range(-0.2, 0.2)), _mat_leaf[i % 3], 9)
		var k := _rng.randf_range(0.4, 0.6)
		s.scale = Vector3(k, k * 0.85, k)
	for i in 4:
		var c: Color = [Color("f27aa0"), Color("ffd23a"), Color("ffffff"), Color("c068ff")][i]
		Gfx.sphere(n, 0.08, Vector3(-0.6 + i * 0.4, 0.82 + (i % 2) * 0.05, 0.3), Gfx.mat(c, 0.5, null, 0.6), 6)


func _jungle_idols(n: Node3D) -> void:
	for sx in [-0.5, 0.5]:
		Gfx.box(n, Vector3(0.8, 0.9, 0.7), Vector3(sx, 0.45, 0.0), _mat_stone)
		Gfx.box(n, Vector3(0.14, 0.1, 0.04), Vector3(sx - 0.18, 0.62, 0.36), _mat_glyph)
		Gfx.box(n, Vector3(0.14, 0.1, 0.04), Vector3(sx + 0.18, 0.62, 0.36), _mat_glyph)
		Gfx.box(n, Vector3(0.3, 0.08, 0.04), Vector3(sx, 0.3, 0.36), _mat_dark)
	var m := Gfx.sphere(n, 1.0, Vector3(-0.4, 0.92, 0.0), _mat_moss, 8)
	m.scale = Vector3(0.4, 0.1, 0.3)


func _jungle_vines(n: Node3D) -> void:
	for sx in [-1.0, 1.0]:
		Gfx.cyl(n, 0.16, 0.2, 3.3, Vector3(sx, 1.65, 0.0), _mat_bark, Vector3.ZERO, 8)
	Gfx.cyl(n, 0.3, 0.3, 2.4, Vector3(0.0, 3.0, 0.0), _mat_bark, Vector3(0.0, 0.0, 90.0), 10)
	for i in 3:
		var s := Gfx.sphere(n, 1.0, Vector3(-0.8 + i * 0.8, 3.3, 0.0), _mat_leaf[i % 3], 8)
		s.scale = Vector3(0.55, 0.35, 0.5)
	for i in 8:
		var x := -0.95 + float(i) * 0.27
		var len := _rng.randf_range(1.6, 2.0)
		Gfx.cyl(n, 0.03, 0.03, len, Vector3(x, 3.0 - len * 0.5, _rng.randf_range(-0.1, 0.1)), _mat_vine, Vector3.ZERO, 5)
		Gfx.sphere(n, 0.09, Vector3(x, 3.0 - len, 0.0), _mat_leaf[i % 3], 6)


func _jungle_lintel(n: Node3D) -> void:
	for sx in [-0.95, 0.95]:
		Gfx.box(n, Vector3(0.5, 3.4, 0.6), Vector3(sx, 1.7, 0.0), _mat_stone)
	Gfx.box(n, Vector3(2.4, 2.2, 0.7), Vector3(0.0, 2.1, 0.0), _mat_stone)
	Gfx.box(n, Vector3(1.6, 0.14, 0.04), Vector3(0.0, 2.35, 0.37), _mat_glyph)
	Gfx.box(n, Vector3(0.14, 0.9, 0.04), Vector3(0.0, 2.0, 0.37), _mat_glyph)
	Gfx.box(n, Vector3(0.9, 0.14, 0.04), Vector3(0.0, 1.6, 0.37), _mat_glyph)
	var m := Gfx.sphere(n, 1.0, Vector3(0.4, 3.22, 0.0), _mat_moss, 8)
	m.scale = Vector3(0.9, 0.18, 0.4)
	for x in [-0.6, 0.7]:
		Gfx.cyl(n, 0.03, 0.03, 0.9, Vector3(x, 1.5, 0.4), _mat_vine, Vector3.ZERO, 5)


func _jungle_ruin(n: Node3D) -> void:
	Gfx.box(n, Vector3(2.0, 2.6, 2.6), Vector3(0.0, 1.3, 0.0), _mat_stone)
	Gfx.box(n, Vector3(2.1, 0.2, 2.7), Vector3(0.0, 2.7, 0.0), _mat_stone)
	for sx in [-0.4, 0.4]:
		Gfx.box(n, Vector3(0.3, 0.2, 0.06), Vector3(sx, 1.8, 1.32), _mat_glyph)
	Gfx.box(n, Vector3(0.6, 0.28, 0.06), Vector3(0.0, 1.1, 1.32), _mat_dark)
	for i in 4:
		var s := Gfx.sphere(n, 1.0, Vector3(-0.7 + i * 0.5, 2.85, _rng.randf_range(-0.8, 0.8)), _mat_leaf[i % 3], 8)
		s.scale = Vector3(0.4, 0.22, 0.4)


func _jungle_trunk(n: Node3D) -> void:
	Gfx.cyl(n, 0.85, 1.0, 2.8, Vector3(0.0, 1.4, 0.0), _mat_bark, Vector3.ZERO, 12)
	for k in 5:
		var a := float(k) * TAU / 5.0
		Gfx.box(n, Vector3(0.3, 1.0, 0.9), Vector3(cos(a) * 0.95, 0.45, sin(a) * 0.95), _mat_bark, Vector3(0.0, -rad_to_deg(a), 0.0))
	var m := Gfx.sphere(n, 1.0, Vector3(0.0, 2.8, 0.0), _mat_leaf[0], 9)
	m.scale = Vector3(1.0, 0.3, 1.0)
	Gfx.sphere(n, 0.5, Vector3(0.0, 1.4, 1.0), _mat_moss, 8).scale = Vector3(1.0, 0.8, 0.5)


func _jungle_statue(n: Node3D) -> void:
	Gfx.box(n, Vector3(2.0, 1.0, 2.6), Vector3(0.0, 0.5, 0.0), _mat_stone)
	Gfx.box(n, Vector3(1.6, 1.0, 2.0), Vector3(0.0, 1.5, 0.0), _mat_stone)
	Gfx.box(n, Vector3(1.2, 0.8, 1.4), Vector3(0.0, 2.4, 0.0), _mat_stone)
	for sx in [-0.28, 0.28]:
		Gfx.box(n, Vector3(0.2, 0.14, 0.05), Vector3(sx, 2.5, 0.72), _mat_glyph)
	Gfx.box(n, Vector3(0.5, 0.1, 0.05), Vector3(0.0, 2.2, 0.72), _mat_dark)
	Gfx.box(n, Vector3(1.0, 0.12, 0.05), Vector3(0.0, 1.5, 1.02), _mat_glyph)
	var m := Gfx.sphere(n, 1.0, Vector3(-0.5, 1.02, 0.5), _mat_moss, 8)
	m.scale = Vector3(0.6, 0.12, 0.5)


# ===================== موانع تازه =====================
## شهر: شیر آتش‌نشانی + کیسه‌های شن + نوار هشدار
func _city_hydrants(n: Node3D) -> void:
	var red := Gfx.mat(Color("d8352a"), 0.1, null, 0.45)
	for sx in [-0.55, 0.55]:
		Gfx.cyl(n, 0.2, 0.24, 0.62, Vector3(sx, 0.31, 0.0), red, Vector3.ZERO, 12)
		Gfx.sphere(n, 0.22, Vector3(sx, 0.66, 0.0), red, 10)
		Gfx.cyl(n, 0.07, 0.07, 0.5, Vector3(sx, 0.42, 0.0), _mat_steel, Vector3(0.0, 0.0, 90.0), 8)
		Gfx.cyl(n, 0.09, 0.09, 0.08, Vector3(sx, 0.9, 0.0), _mat_steel, Vector3.ZERO, 8)
	for i in 5:
		var sb := Gfx.box(n, Vector3(0.5, 0.2, 0.34), Vector3(-0.5 + i * 0.25, 0.1 + (i % 2) * 0.01, 0.38), _mat_cloth, Vector3(0.0, _rng.randf_range(-8.0, 8.0), 0.0))
		sb.scale = Vector3(1.0, 1.0, 1.0)
	Gfx.box(n, Vector3(1.9, 0.07, 0.04), Vector3(0.0, 0.72, 0.6), _mat_hazard)
	Gfx.box(n, Vector3(0.05, 0.7, 0.05), Vector3(-0.95, 0.35, 0.6), _mat_steel)
	Gfx.box(n, Vector3(0.05, 0.7, 0.05), Vector3(0.95, 0.35, 0.6), _mat_steel)
	Gfx.glow(n, Vector3(0.0, 0.8, 0.5), 0.8, Color(1.0, 0.3, 0.2, 0.3))


## شهر: تابلوی نئونی آویزان بین دو تیر
func _city_neon_sign(n: Node3D) -> void:
	for sx in [-1.05, 1.05]:
		Gfx.cyl(n, 0.07, 0.09, 3.3, Vector3(sx, 1.65, 0.0), _mat_steel, Vector3.ZERO, 8)
	Gfx.box(n, Vector3(2.3, 1.0, 0.16), Vector3(0.0, 2.45, 0.0), _mat_dark)
	var pink := Gfx.mat(Color("ff2fd2"), 3.0, null, 0.3)
	var cyan := Gfx.mat(Color("27f3ff"), 3.0, null, 0.3)
	Gfx.box(n, Vector3(2.1, 0.06, 0.06), Vector3(0.0, 2.9, 0.1), pink)
	Gfx.box(n, Vector3(2.1, 0.06, 0.06), Vector3(0.0, 2.0, 0.1), cyan)
	var shop: String = ["CAFE", "HOTEL", "PIZZA", "BAR"][_rng.randi() % 4]
	Gfx.label(n, shop, Vector3(0.0, 2.45, 0.1), 90, Color("fff7c0"), 0.012)
	Gfx.label(n, shop, Vector3(0.0, 2.45, -0.1), 90, Color("fff7c0"), 0.012, Vector3(0.0, 180.0, 0.0))
	Gfx.glow(n, Vector3(0.0, 2.45, 0.3), 3.2, Color(1.0, 0.2, 0.8, 0.28))
	for sx in [-0.7, 0.7]:
		Gfx.cyl(n, 0.015, 0.015, 0.4, Vector3(sx, 3.05, 0.0), _mat_cable, Vector3.ZERO, 5)


## شهر: تاکسی زرد با چراغ سقف و نوار شطرنجی
func _city_taxi(n: Node3D) -> void:
	var yellow := Gfx.mat(Color("ffcc1f"), 0.1, null, 0.4)
	Gfx.box(n, Vector3(2.0, 0.9, 2.6), Vector3(0.0, 0.85, 0.0), yellow)
	Gfx.box(n, Vector3(1.8, 0.75, 1.5), Vector3(0.0, 1.62, -0.1), yellow)
	Gfx.box(n, Vector3(1.84, 0.5, 1.2), Vector3(0.0, 1.66, -0.1), _mat_glass)
	Gfx.box(n, Vector3(2.04, 0.1, 2.64), Vector3(0.0, 0.62, 0.0), _mat_hazard)
	Gfx.box(n, Vector3(0.5, 0.2, 0.25), Vector3(0.0, 2.1, -0.1), _mat_white)
	Gfx.label(n, "TAXI", Vector3(0.0, 2.1, 0.04), 36, Color("2a2430"), 0.006)
	_lights(n, 1.31, 0.78, 0.7)
	_wheels(n, [-0.98, 0.98], [-0.85, 0.85], 0.36)
	Gfx.box(n, Vector3(1.0, 0.3, 0.04), Vector3(0.0, 1.0, 1.31), _mat_dark)


## صحرا: جمجمه‌ی گاو، استخوان و بوته‌ی خشک
func _desert_bones(n: Node3D) -> void:
	var bone := Gfx.mat(Color("efe6d0"), 0.1, null, 0.8)
	Gfx.sphere(n, 0.34, Vector3(-0.35, 0.34, 0.0), bone, 10).scale = Vector3(1.0, 0.8, 1.2)
	Gfx.cyl(n, 0.04, 0.06, 0.9, Vector3(-0.35, 0.42, 0.0), bone, Vector3(0.0, 0.0, 90.0), 6)
	Gfx.sphere(n, 0.06, Vector3(-0.8, 0.42, 0.0), bone, 6)
	Gfx.sphere(n, 0.06, Vector3(0.1, 0.42, 0.0), bone, 6)
	Gfx.sphere(n, 0.08, Vector3(-0.45, 0.4, 0.3), _mat_dark, 6)
	Gfx.sphere(n, 0.08, Vector3(-0.25, 0.4, 0.3), _mat_dark, 6)
	for i in 4:
		Gfx.cyl(n, 0.035, 0.035, 0.6, Vector3(0.4 + i * 0.12, 0.3, -0.1 + i * 0.1), bone, Vector3(0.0, _rng.randf_range(0.0, 180.0), _rng.randf_range(60.0, 100.0)), 6)
	for i in 7:
		Gfx.cyl(n, 0.012, 0.012, 0.7, Vector3(0.65, 0.32, 0.2), Gfx.mat(Color("8a6a3a"), 0.0, null, 1.0), Vector3(0.0, i * 25.0, 50.0 + i * 8.0), 4)
	_rock(n, Vector3(0.0, 0.14, -0.3), Vector3(0.5, 0.28, 0.4), _mat_rock)


## صحرا: سایبان بازار با راه‌راه رنگی
func _desert_awning(n: Node3D) -> void:
	for sx in [-1.0, 1.0]:
		Gfx.cyl(n, 0.07, 0.07, 3.4, Vector3(sx, 1.7, 0.0), _mat_wood, Vector3.ZERO, 8)
	var cols: Array[Color] = [Color("e8503a"), Color("fff0d0"), Color("2fa89a"), Color("f2b632")]
	for i in 8:
		var m := Gfx.mat(cols[i % 4], 0.1, null, 0.9)
		Gfx.box(n, Vector3(0.3, 0.06, 1.3), Vector3(-0.98 + i * 0.28, 3.1 - absf(i - 3.5) * 0.0, 0.0), m, Vector3(0.0, 0.0, 0.0))
	for i in 8:
		Gfx.box(n, Vector3(0.28, 0.4, 0.04), Vector3(-0.98 + i * 0.28, 2.85, 0.65), Gfx.mat(cols[i % 4], 0.1, null, 0.9))
	for i in 3:
		Gfx.cyl(n, 0.015, 0.015, 0.6, Vector3(-0.6 + i * 0.6, 2.6, 0.0), _mat_cable, Vector3.ZERO, 5)
		Gfx.sphere(n, 0.12, Vector3(-0.6 + i * 0.6, 2.25, 0.0), Gfx.mat(Color("ffb040"), 1.8, null, 0.4), 8)


## صحرا: ستون یادبود سنگی با خط‌نوشته‌ی نورانی
func _desert_obelisk(n: Node3D) -> void:
	var sm := _strata[_rng.randi() % 3]
	Gfx.box(n, Vector3(2.0, 0.5, 2.4), Vector3(0.0, 0.25, 0.0), sm)
	Gfx.box(n, Vector3(1.6, 0.3, 2.0), Vector3(0.0, 0.65, 0.0), _mat_rock)
	Gfx.cyl(n, 0.28, 0.55, 2.0, Vector3(0.0, 1.8, 0.0), sm, Vector3.ZERO, 4)
	Gfx.cyl(n, 0.01, 0.28, 0.4, Vector3(0.0, 2.95, 0.0), Gfx.mat(Color("ffd36a"), 0.8, null, 0.3), Vector3.ZERO, 4)
	for i in 5:
		Gfx.box(n, Vector3(0.14 + (i % 2) * 0.1, 0.07, 0.04), Vector3(0.0, 1.2 + i * 0.3, 0.45 - i * 0.04), _mat_glyph)
	Gfx.glow(n, Vector3(0.0, 1.9, 0.55), 1.4, Color(1.0, 0.7, 0.2, 0.25))
	for sx in [-0.7, 0.7]:
		Gfx.cyl(n, 0.1, 0.12, 0.5, Vector3(sx, 0.9, 0.8), _mat_stone, Vector3.ZERO, 6)
		Gfx.sphere(n, 0.1, Vector3(sx, 1.2, 0.8), Gfx.mat(Color("ff7a1f"), 3.0, null, 0.4), 8)
		Gfx.glow(n, Vector3(sx, 1.25, 0.8), 0.9, Color(1.0, 0.5, 0.1, 0.4))


## جنگل: قارچ‌های غول‌پیکر شب‌تاب
func _jungle_mushrooms(n: Node3D) -> void:
	var caps: Array[Color] = [Color("ff4a8a"), Color("a86bff"), Color("2fe0c0")]
	for i in 3:
		var x := -0.6 + i * 0.6
		var h := 0.5 + (i % 2) * 0.22
		Gfx.cyl(n, 0.09, 0.13, h, Vector3(x, h * 0.5, 0.0), _mat_cloth, Vector3.ZERO, 8)
		var cap := Gfx.sphere(n, 0.4, Vector3(x, h + 0.04, 0.0), Gfx.mat(caps[i], 0.9, null, 0.5), 10)
		cap.scale = Vector3(1.0, 0.55, 1.0)
		for k in 4:
			var a := float(k) * TAU / 4.0 + float(i)
			Gfx.sphere(n, 0.05, Vector3(x + cos(a) * 0.22, h + 0.18, sin(a) * 0.22), _mat_white, 5)
		Gfx.glow(n, Vector3(x, h + 0.1, 0.0), 0.9, Color(caps[i].r, caps[i].g, caps[i].b, 0.3))


## جنگل: دروازه‌ی توتم‌های حکاکی‌شده
func _jungle_totems(n: Node3D) -> void:
	for sx in [-1.0, 1.0]:
		for k in 4:
			var m := Gfx.box(n, Vector3(0.5, 0.82, 0.5), Vector3(sx, 0.41 + k * 0.82, 0.0), _mat_wood)
			Gfx.box(n, Vector3(0.28, 0.1, 0.04), Vector3(sx, 0.5 + k * 0.82, 0.26), _mat_glyph)
			Gfx.box(n, Vector3(0.16, 0.08, 0.04), Vector3(sx, 0.3 + k * 0.82, 0.26), _mat_dark)
			m.rotation_degrees.y = k * 4.0
		Gfx.sphere(n, 0.25, Vector3(sx, 3.45, 0.0), _mat_red, 8)
	Gfx.box(n, Vector3(2.8, 0.34, 0.4), Vector3(0.0, 3.0, 0.0), _mat_wood)
	for i in 6:
		Gfx.box(n, Vector3(0.12, 0.5, 0.05), Vector3(-1.0 + i * 0.4, 2.6, 0.2), Gfx.mat([Color("e8503a"), Color("f2b632"), Color("2fa89a")][i % 3], 0.1, null, 0.9))
	for x in [-0.4, 0.5]:
		Gfx.cyl(n, 0.025, 0.025, 1.0, Vector3(x, 2.4, 0.0), _mat_vine, Vector3.ZERO, 5)


## جنگل: پلکان هرمی معبد با مشعل
func _jungle_stairs(n: Node3D) -> void:
	for k in 4:
		var w := 2.0 - k * 0.2
		Gfx.box(n, Vector3(w, 0.65, 2.6 - k * 0.5), Vector3(0.0, 0.33 + k * 0.65, -k * 0.1), _mat_stone)
	for sx in [-0.7, 0.7]:
		Gfx.cyl(n, 0.07, 0.09, 0.9, Vector3(sx, 1.0, 1.4), _mat_wood, Vector3.ZERO, 6)
		Gfx.sphere(n, 0.14, Vector3(sx, 1.5, 1.4), Gfx.mat(Color("ff7a1f"), 3.2, null, 0.4), 8)
		Gfx.glow(n, Vector3(sx, 1.55, 1.4), 1.2, Color(1.0, 0.55, 0.1, 0.45))
	Gfx.box(n, Vector3(0.7, 0.1, 0.05), Vector3(0.0, 2.2, 0.6), _mat_glyph)
	var m := Gfx.sphere(n, 1.0, Vector3(-0.3, 2.95, -0.3), _mat_moss, 8)
	m.scale = Vector3(0.6, 0.12, 0.5)
