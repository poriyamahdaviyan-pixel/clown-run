extends Node
## صداها (Autoload با نام «Sfx»)
## همه‌ی افکت‌های صوتی با کد ساخته می‌شوند، پس نیازی به هیچ فایل صوتی نیست.
## اگر خواستی فایل واقعی بذاری: در _ready مقدار _streams["plus"] و ... را با load("res://...ogg") عوض کن.

const RATE := 22050

enum Wave { SINE, SQUARE, TRIANGLE, NOISE }

var _streams: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _next := 0


## دسته‌ی هر صدا (برای تنظیم جداگانه‌ی صدا در نسخه‌ی مدیر)
const CAT := {
	"step": "player", "jump": "player", "land": "player", "slide": "player", "swish": "player",
	"heart": "player", "crash": "player", "graze": "player", "near": "player", "shield_break": "player",
	"step_p": "police", "siren": "police", "horn": "police", "laugh": "police", "caught": "police",
	"plus": "world", "p0": "world", "p1": "world", "p2": "world", "p3": "world", "p4": "world", "p5": "world",
	"boost": "world", "zone": "world", "go": "world", "lose": "world", "win": "world", "hit": "world",
	"wind": "ambient", "music": "music", "start_a": "world", "start_b": "world", "start_c": "world",
}
const LOOPS := ["siren", "wind", "heart"]       # موسیقی را حالا Music پخش می‌کند
## صدای مخصوص هر کاراکتر: نام، فرکانس پایه، نوع موج، ضریب زیر/بمی قدم
const VOICES := [
	["بم و سنگین", 130.0, 1, 0.8],
	["معمولی", 200.0, 2, 1.0],
	["نازک و شاد", 330.0, 0, 1.2],
	["رباتی", 180.0, 1, 0.9],
	["جیرجیری", 460.0, 0, 1.4],
	["غرّان", 90.0, 1, 0.7],
]
const VOICE_ACTIONS := ["jump", "land", "slide", "hit", "coin"]

var _loops: Dictionary = {}       # name -> AudioStreamPlayer
var _loop_level: Dictionary = {}  # name -> 0..1
var _thread: Thread


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 12:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)

	_streams["click"] = _wav(_tone(900.0, 700.0, 0.05, 0.35, Wave.SQUARE))
	_streams["plus"] = _wav(_mix(_seq([
		[1318.0, 1318.0, 0.07, 0.4, Wave.SINE],
		[1976.0, 1976.0, 0.16, 0.4, Wave.SINE],
	]), _seq([[2637.0, 2637.0, 0.1, 0.12, Wave.SINE]])))
	_streams["minus"] = _wav(_tone(260.0, 110.0, 0.22, 0.45, Wave.SQUARE))
	_streams["hit"] = _wav(_mix(_tone(200.0, 50.0, 0.3, 0.7, Wave.SINE), _lp(_tone(0.0, 0.0, 0.3, 0.6, Wave.NOISE), 0.25)))
	_streams["crash"] = _wav(_mix(_mix(_tone(150.0, 40.0, 0.55, 0.8, Wave.SINE), _lp(_tone(0.0, 0.0, 0.55, 0.9, Wave.NOISE), 0.35)), _seq([[0.0, 0.0, 0.05, 0.0, Wave.SINE], [90.0, 45.0, 0.3, 0.5, Wave.SQUARE]])))
	_streams["graze"] = _wav(_mix(_lp(_tone(0.0, 0.0, 0.32, 0.8, Wave.NOISE), 0.5), _tone(120.0, 70.0, 0.2, 0.5, Wave.SINE)))
	_streams["jump"] = _wav(_mix(_tone(300.0, 650.0, 0.16, 0.3, Wave.SINE), _lp(_tone(0.0, 0.0, 0.12, 0.25, Wave.NOISE), 0.15)))
	_streams["land"] = _wav(_mix(_tone(130.0, 55.0, 0.14, 0.7, Wave.SINE), _lp(_tone(0.0, 0.0, 0.1, 0.4, Wave.NOISE), 0.12)))
	_streams["slide"] = _wav(_lp(_tone(0.0, 0.0, 0.45, 0.5, Wave.NOISE), 0.3))
	_streams["swish"] = _wav(_lp(_tone(0.0, 0.0, 0.1, 0.35, Wave.NOISE), 0.4))
	_streams["near"] = _wav(_lp(_tone(0.0, 0.0, 0.22, 0.55, Wave.NOISE), 0.6))
	_streams["step"] = _wav(_mix(_tone(95.0, 60.0, 0.07, 0.55, Wave.SINE), _lp(_tone(0.0, 0.0, 0.05, 0.35, Wave.NOISE), 0.2)))
	_streams["step_p"] = _wav(_mix(_tone(70.0, 45.0, 0.1, 0.8, Wave.SINE), _lp(_tone(0.0, 0.0, 0.08, 0.5, Wave.NOISE), 0.15)))
	_streams["boost"] = _wav(_tone(300.0, 1000.0, 0.4, 0.4, Wave.SQUARE))
	# صدای مخصوص هر قدرت
	_streams["p0"] = _wav(_seq([[500.0, 900.0, 0.1, 0.4, Wave.SINE], [900.0, 1500.0, 0.2, 0.4, Wave.SINE]]))                   # آهنربا
	_streams["p1"] = _wav(_mix(_tone(420.0, 420.0, 0.35, 0.3, Wave.TRIANGLE), _tone(630.0, 630.0, 0.35, 0.25, Wave.TRIANGLE)))   # سپر
	_streams["p2"] = _wav(_seq([[880.0, 880.0, 0.07, 0.4, Wave.TRIANGLE], [1175.0, 1175.0, 0.07, 0.4, Wave.TRIANGLE], [1568.0, 1568.0, 0.2, 0.4, Wave.TRIANGLE]]))
	_streams["p3"] = _wav(_mix(_tone(200.0, 1400.0, 0.6, 0.35, Wave.SQUARE), _lp(_tone(0.0, 0.0, 0.6, 0.5, Wave.NOISE), 0.5)))   # جت
	_streams["p4"] = _wav(_seq([[660.0, 660.0, 0.06, 0.4, Wave.SQUARE], [990.0, 990.0, 0.06, 0.4, Wave.SQUARE], [1320.0, 1320.0, 0.14, 0.4, Wave.SQUARE]]))
	_streams["p5"] = _wav(_seq([[700.0, 400.0, 0.2, 0.4, Wave.SINE], [400.0, 250.0, 0.3, 0.4, Wave.SINE]]))                    # کُند
	_streams["shield_break"] = _wav(_mix(_tone(1800.0, 300.0, 0.4, 0.4, Wave.TRIANGLE), _lp(_tone(0.0, 0.0, 0.3, 0.6, Wave.NOISE), 0.8)))
	_streams["zone"] = _wav(_seq([[523.0, 523.0, 0.1, 0.4, Wave.TRIANGLE], [659.0, 659.0, 0.1, 0.4, Wave.TRIANGLE], [880.0, 880.0, 0.25, 0.4, Wave.TRIANGLE]]))
	_streams["win"] = _wav(_seq([
		[523.0, 523.0, 0.12, 0.5, Wave.TRIANGLE],
		[659.0, 659.0, 0.12, 0.5, Wave.TRIANGLE],
		[784.0, 784.0, 0.12, 0.5, Wave.TRIANGLE],
		[1047.0, 1047.0, 0.3, 0.5, Wave.TRIANGLE],
	]))
	_streams["lose"] = _wav(_seq([
		[392.0, 330.0, 0.2, 0.5, Wave.TRIANGLE],
		[294.0, 196.0, 0.4, 0.5, Wave.TRIANGLE],
	]))
	_streams["buy"] = _wav(_seq([
		[880.0, 880.0, 0.06, 0.4, Wave.SINE],
		[1320.0, 1320.0, 0.1, 0.4, Wave.SINE],
	]))
	_streams["error"] = _wav(_tone(160.0, 140.0, 0.16, 0.4, Wave.SQUARE))
	_streams["tick"] = _wav(_tone(800.0, 800.0, 0.07, 0.4, Wave.SINE))
	_streams["go"] = _wav(_seq([[880.0, 880.0, 0.08, 0.4, Wave.SINE], [1760.0, 1760.0, 0.3, 0.45, Wave.SINE]]))
	# پلیس/دلقک: بوق دلقکی و خنده
	_streams["horn"] = _wav(_seq([[420.0, 520.0, 0.14, 0.45, Wave.SQUARE], [0.0, 0.0, 0.04, 0.0, Wave.SINE], [440.0, 560.0, 0.22, 0.45, Wave.SQUARE]]))
	var laugh: Array = []
	for i in 5:
		laugh.append([520.0 + i * 30.0, 380.0 + i * 20.0, 0.1, 0.4, Wave.TRIANGLE])
		laugh.append([0.0, 0.0, 0.06, 0.0, Wave.SINE])
	_streams["laugh"] = _wav(_seq(laugh))
	_streams["caught"] = _wav(_mix(_seq([[392.0, 330.0, 0.2, 0.5, Wave.TRIANGLE], [294.0, 196.0, 0.45, 0.5, Wave.TRIANGLE]]), _tone(110.0, 40.0, 0.65, 0.6, Wave.SINE)))
	# صدای مخصوص هر کاراکتر برای هر حرکت
	for vi in VOICES.size():
		var f: float = VOICES[vi][1]
		var w: int = VOICES[vi][2]
		_streams["v%d_jump" % vi] = _wav(_tone(f, f * 1.7, 0.16, 0.5, w))
		_streams["v%d_land" % vi] = _wav(_mix(_tone(f * 0.8, f * 0.45, 0.13, 0.55, w), _lp(_tone(0.0, 0.0, 0.08, 0.2, Wave.NOISE), 0.2)))
		_streams["v%d_slide" % vi] = _wav(_mix(_tone(f * 1.3, f * 0.8, 0.3, 0.35, w), _lp(_tone(0.0, 0.0, 0.3, 0.3, Wave.NOISE), 0.35)))
		_streams["v%d_hit" % vi] = _wav(_seq([[f * 1.4, f * 0.9, 0.12, 0.6, w], [f * 0.9, f * 0.45, 0.28, 0.55, w]]))
		_streams["v%d_coin" % vi] = _wav(_tone(f * 2.4, f * 3.2, 0.09, 0.3, w))
	for sn in ["start_a", "start_b", "start_c"]:
		_streams[sn] = load("res://assets/music/%s.ogg" % sn)
	# حلقه‌ها
	_streams["siren"] = _loopw(_wav(_siren_wave()))
	_streams["wind"] = _loopw(_wav(_lp(_tone(0.0, 0.0, 1.5, 0.5, Wave.NOISE), 0.08, false)))
	var hb := _seq([[70.0, 45.0, 0.1, 0.9, Wave.SINE], [0.0, 0.0, 0.1, 0.0, Wave.SINE], [60.0, 40.0, 0.12, 0.7, Wave.SINE], [0.0, 0.0, 0.5, 0.0, Wave.SINE]])
	_streams["heart"] = _loopw(_wav(hb))
	for n in LOOPS:
		var lp := AudioStreamPlayer.new()
		lp.bus = "Master"
		add_child(lp)
		_loops[n] = lp
		_loop_level[n] = 0.0
	# موسیقی در یک رشته‌ی جدا ساخته می‌شود تا شروع بازی کند نشود
	_thread = Thread.new()
	_thread.start(_build_music)


func get_stream(n: String) -> AudioStream:
	return _streams.get(n)


func _exit_tree() -> void:
	if _thread != null and _thread.is_started():
		_thread.wait_to_finish()


func _build_music() -> void:
	var bpm_step := 0.19
	var bass := [110.0, 110.0, 131.0, 110.0, 98.0, 98.0, 117.0, 98.0, 87.0, 87.0, 104.0, 87.0, 98.0, 98.0, 117.0, 130.0]
	var arp := [440.0, 523.0, 659.0, 523.0, 392.0, 466.0, 587.0, 466.0, 349.0, 415.0, 523.0, 415.0, 392.0, 466.0, 587.0, 698.0]
	var out := PackedFloat32Array()
	for i in 16:
		var b := _tone(bass[i], bass[i], bpm_step, 0.3, Wave.TRIANGLE)
		var a := _tone(arp[i], arp[i], bpm_step, 0.1, Wave.SQUARE)
		var hat := _lp(_tone(0.0, 0.0, bpm_step, 0.12 if i % 2 == 1 else 0.05, Wave.NOISE), 0.9)
		out.append_array(_mix(_mix(b, a), hat))
	call_deferred("_music_ready", out)


func _music_ready(samples: PackedFloat32Array) -> void:
	_streams["music"] = _loopw(_wav(samples))
	refresh_loops()


func _siren_wave() -> PackedFloat32Array:
	var n := int(RATE * 1.2)
	var out := PackedFloat32Array()
	out.resize(n)
	var ph := 0.0
	for i in n:
		var t := float(i) / float(n)
		var f := 760.0 + 260.0 * sin(TAU * t)
		ph += TAU * f / float(RATE)
		out[i] = (sin(ph) * 0.6 + sin(ph * 2.0) * 0.15) * 0.5
	return out


func _loopw(w: AudioStreamWAV) -> AudioStreamWAV:
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = w.data.size() / 2
	return w


func _mix(a: PackedFloat32Array, b: PackedFloat32Array) -> PackedFloat32Array:
	var n := maxi(a.size(), b.size())
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		var v := 0.0
		if i < a.size():
			v += a[i]
		if i < b.size():
			v += b[i]
		out[i] = clampf(v, -1.0, 1.0)
	return out


## فیلتر پایین‌گذر ساده (k کوچک = صدای خفه‌تر)
func _lp(a: PackedFloat32Array, k: float, gain_fix: bool = true) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(a.size())
	var y := 0.0
	for i in a.size():
		y += (a[i] - y) * k
		out[i] = y * (1.0 / maxf(k, 0.05) * 0.35 if gain_fix else 2.2)
	return out


func _level(cat: String) -> float:
	return float(Game.vol.get("master", 1.0)) * float(Game.vol.get(cat, 1.0))


## هر صدایی: نام داخلی (مثل "laugh" یا "v2_jump") یا فایل واردشده ("file:نام.ogg")
func play_any(arg: String, volume_db: float = 0.0) -> void:
	if arg.begins_with("file:"):
		var st: AudioStream = Rules.load_voice(arg)
		if st == null or not Game.sound_on:
			return
		var lv := _level("player")
		if lv <= 0.001:
			return
		var p: AudioStreamPlayer = _players[_next]
		_next = (_next + 1) % _players.size()
		p.stream = st
		p.volume_db = volume_db + linear_to_db(lv)
		p.pitch_scale = 1.0
		p.play()
	else:
		play(arg, volume_db)


## نام همه‌ی صداهای داخلی که می‌شود در قانون‌ها انتخاب کرد
func builtin_names() -> Array:
	var out: Array = ["plus", "jump", "land", "slide", "swish", "near", "horn", "laugh", "caught", "crash", "graze", "boost", "zone", "go", "start_a", "start_b", "start_c", "win", "lose", "buy", "error", "tick", "click"]
	for vi in VOICES.size():
		for a in VOICE_ACTIONS:
			out.append("v%d_%s" % [vi, a])
	return out


## صدای مخصوص کاراکترِ انتخاب‌شده برای یک حرکت (jump/land/slide/hit/coin)
func voice(action: String, volume_db: float = 0.0) -> void:
	play("v%d_%s" % [Game.voice_of(Skins.current_id), action], volume_db)


func play(sound_name: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	if not Game.sound_on or not _streams.has(sound_name):
		return
	var cat: String = "player" if sound_name.begins_with("v") and sound_name.length() > 2 and sound_name[1].is_valid_int() else CAT.get(sound_name, "ui")
	var lv := _level(cat)
	if lv <= 0.001:
		return
	var p: AudioStreamPlayer = _players[_next]
	_next = (_next + 1) % _players.size()
	p.stream = _streams[sound_name]
	p.volume_db = volume_db + linear_to_db(lv)
	p.pitch_scale = pitch
	p.play()


## حلقه‌ها (آژیر، باد، ضربان، موسیقی) با شدت ۰..۱
func set_loop(loop_name: String, level: float) -> void:
	_loop_level[loop_name] = clampf(level, 0.0, 1.0)
	_apply_loop(loop_name)


func refresh_loops() -> void:
	for n in LOOPS:
		_apply_loop(n)


func _apply_loop(n: String) -> void:
	var lp: AudioStreamPlayer = _loops.get(n)
	if lp == null or not _streams.has(n):
		return
	var cat: String = CAT.get(n, "ui")
	var lv: float = float(_loop_level[n]) * _level(cat)
	if not Game.sound_on or lv <= 0.003:
		if lp.playing:
			lp.stop()
		return
	lp.volume_db = linear_to_db(lv) - 6.0
	if lp.stream != _streams[n]:
		lp.stream = _streams[n]
	if not lp.playing:
		lp.play()


func _tone(f0: float, f1: float, dur: float, vol: float, wave: int) -> PackedFloat32Array:
	var n := int(RATE * dur)
	var out := PackedFloat32Array()
	out.resize(n)
	var phase := 0.0
	for i in n:
		var t := float(i) / float(n)
		var f := lerpf(f0, f1, t)
		phase += TAU * f / float(RATE)
		var s := 0.0
		match wave:
			Wave.SINE:
				s = sin(phase)
			Wave.SQUARE:
				s = 1.0 if sin(phase) >= 0.0 else -1.0
			Wave.TRIANGLE:
				s = asin(sin(phase)) * 2.0 / PI
			Wave.NOISE:
				s = randf_range(-1.0, 1.0)
		var attack := minf(1.0, float(i) / 120.0)
		out[i] = s * attack * (1.0 - t) * vol
	return out


func _seq(notes: Array) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	for n in notes:
		out.append_array(_tone(float(n[0]), float(n[1]), float(n[2]), float(n[3]), int(n[4])))
	return out


func _wav(samples: PackedFloat32Array) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		bytes.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = bytes
	return w
