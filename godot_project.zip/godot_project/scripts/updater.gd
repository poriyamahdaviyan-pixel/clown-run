extends Node
## بروزرسانی بدون نصب دوباره‌ی APK
##  • «وصله» (patch.pck امضادار): کدها و صحنه‌های بازی را عوض می‌کند. از صفحه‌ی شروع دانلود می‌شود و با باز کردن دوباره‌ی بازی اعمال می‌شود.
##  • «نسخه‌ی جدید APK»: برای تغییرهای عمیق‌تر (افزونه، تنظیمات پروژه، نسخه‌ی Godot)؛ لینک دانلود باز می‌شود.
## این اسکریپت باید «اولین» Autoload باشد تا وصله قبل از بارگذاری بقیه‌ی اسکریپت‌ها خوانده شود.
## امنیت: وصله فقط وقتی اجرا می‌شود که امضای RSA آن با کلید عمومی داخل بازی (res://update_key.pub) بخواند.
## اگر بازی با وصله‌ای دو بار پشت‌سرهم بالا نیامد، وصله خودکار کنار گذاشته می‌شود (بازگشت امن).

const BUILD := 1                        # شماره‌ی ساخت APK (هم‌مقدار version/code در پریست‌های خروجی)
const PUB_KEY := "res://update_key.pub"
const DIR := "user://patch"
const ACTIVE := "user://patch/active.json"
const MAX_TRIES := 2
const RECHECK_SECONDS := 300

signal changed

var key_ok := false
var active: Dictionary = {}              # وصله‌ی نصب‌شده روی دستگاه {version, base, sha, sig, file, notes}
var loaded_version := 0                  # وصله‌ای که در همین اجرا بارگذاری شده
var patch_info: Dictionary = {}          # وصله‌ی جدیدتر روی سرور
var apk_info: Dictionary = {}            # APK جدیدتر روی سرور
var busy := false
var message := ""
var _last_check := 0


func _init() -> void:
	key_ok = FileAccess.file_exists(PUB_KEY) or FileAccess.file_exists(PUB_KEY + ".txt")
	_load_active()


func _ready() -> void:
	var t := Timer.new()
	t.wait_time = 12.0
	t.one_shot = true
	t.timeout.connect(mark_good)
	add_child(t)
	t.start()
	_delayed_check.call_deferred()


func _delayed_check() -> void:
	await get_tree().create_timer(2.0).timeout
	check()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_RESUMED and Time.get_unix_time_from_system() - _last_check > RECHECK_SECONDS:
		check()


# ------------------------- بارگذاری وصله‌ی نصب‌شده در شروع -------------------------
static func signed_message(base: int, version: int, sha: String) -> String:
	return "clownrun-patch|%d|%d|%s" % [base, version, sha]


static func _read_key_text() -> String:
	if FileAccess.file_exists(PUB_KEY):
		return FileAccess.get_file_as_string(PUB_KEY)
	if FileAccess.file_exists(PUB_KEY + ".txt"):
		return FileAccess.get_file_as_string(PUB_KEY + ".txt")
	return ""


## امضا (base64) را با کلید عمومیِ داخل بازی (یا کلید داده‌شده) بررسی می‌کند
static func verify(base: int, version: int, sha: String, sig_b64: String, pub_pem: String = "") -> bool:
	var pem := pub_pem if pub_pem != "" else _read_key_text()
	if pem.strip_edges() == "" or sig_b64 == "":
		return false
	var key := CryptoKey.new()
	if key.load_from_string(pem, true) != OK:
		return false
	var sig := Marshalls.base64_to_raw(sig_b64)
	return Crypto.new().verify(HashingContext.HASH_SHA256, signed_message(base, version, sha).sha256_buffer(), sig, key)


static func sign(base: int, version: int, sha: String, priv_pem: String) -> String:
	var key := CryptoKey.new()
	if key.load_from_string(priv_pem, false) != OK:
		return ""
	var sig := Crypto.new().sign(HashingContext.HASH_SHA256, signed_message(base, version, sha).sha256_buffer(), key)
	return Marshalls.raw_to_base64(sig) if sig.size() > 0 else ""


func _save_active() -> void:
	DirAccess.make_dir_recursive_absolute(DIR)
	var f := FileAccess.open(ACTIVE, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(active))
		f.close()


func _drop_active(reason: String) -> void:
	push_warning("وصله کنار گذاشته شد: " + reason)
	if active.has("file") and FileAccess.file_exists(String(active.file)):
		DirAccess.remove_absolute(String(active.file))
	if active.has("version"):
		var bad := FileAccess.open(DIR + "/bad_%d" % int(active.version), FileAccess.WRITE)
		if bad != null:
			bad.close()
	active = {}
	if FileAccess.file_exists(ACTIVE):
		DirAccess.remove_absolute(ACTIVE)


func _load_active() -> void:
	if not FileAccess.file_exists(ACTIVE):
		return
	var d = JSON.parse_string(FileAccess.get_file_as_string(ACTIVE))
	if not d is Dictionary:
		_drop_active("فایل وضعیت خراب")
		return
	active = d
	var file := String(active.get("file", ""))
	if int(active.get("base", -1)) != BUILD or not FileAccess.file_exists(file):
		_drop_active("مخصوص نسخه‌ی دیگری از APK است")
		return
	if int(active.get("tries", 0)) >= MAX_TRIES:
		_drop_active("دو بار پشت‌سرهم بالا نیامد")
		return
	var sha := FileAccess.get_sha256(file)
	if sha != String(active.get("sha", "")) or not verify(BUILD, int(active.get("version", 0)), sha, String(active.get("sig", ""))):
		_drop_active("امضا یا هش نمی‌خواند")
		return
	active["tries"] = int(active.get("tries", 0)) + 1
	_save_active()
	if ProjectSettings.load_resource_pack(file, true):
		loaded_version = int(active.get("version", 0))
		_reload_scripts()
	else:
		_drop_active("بارگذاری نشد")


## گودو اسکریپت Autoloadها را «قبل از» اجرای این فایل می‌خواند. پس بعد از بارگذاری وصله، اسکریپت‌هایی که از قبل
## در حافظه‌اند در همان شیء با متن تازه دوباره ساخته می‌شوند (مثل Hot Reload ادیتور). برای کار کردن، اسکریپت‌های
## APK باید به‌صورت متن خروجی شوند (script_export_mode=0 در پریست‌ها). نکته: متغیر تازه‌ی Autoload با مقدار اولیه
## در همین اجرا مقدار null دارد؛ برای Autoloadها از const و تابع استفاده کن.
func _reload_scripts() -> void:
	var d := DirAccess.open("res://scripts")
	if d == null:
		return
	for f in d.get_files():
		var n := String(f).trim_suffix(".remap")
		if not n.ends_with(".gd") or n == "updater.gd":
			continue
		var path := "res://scripts/" + n
		if not ResourceLoader.has_cached(path):
			continue                      # هنوز خوانده نشده؛ بعداً مستقیم از وصله می‌آید
		var cur = load(path)
		if cur is GDScript:
			var src := FileAccess.get_file_as_string(path)
			if src != "" and src != (cur as GDScript).source_code:
				(cur as GDScript).source_code = src
				(cur as GDScript).reload(true)


## یعنی بازی با این وصله سالم بالا آمده
func mark_good() -> void:
	if active.is_empty():
		return
	active["tries"] = 0
	_save_active()


# ------------------------- بررسی سرور -------------------------
func _is_bad(version: int) -> bool:
	return FileAccess.file_exists(DIR + "/bad_%d" % version)


func check() -> void:
	if busy or not Online.enabled():
		return
	_last_check = int(Time.get_unix_time_from_system())
	var r: Dictionary = await Online._req(HTTPClient.METHOD_GET, "/rest/v1/app_releases?published=eq.true&order=version_code.desc&limit=40", null, false)
	if not r.ok or not r.data is Array:
		return
	patch_info = {}
	apk_info = {}
	var have := maxi(int(active.get("version", 0)), loaded_version)
	var ed := "owner" if Edition.is_owner() else "public"
	for row in r.data:
		var kind := String(row.get("kind", ""))
		var code := int(row.get("version_code", 0))
		if kind == "patch" and patch_info.is_empty() and int(row.get("base_code", -1)) == BUILD and code > have and key_ok and not _is_bad(code) and String(row.get("sig", "")) != "":
			patch_info = row
		elif kind == "apk" and apk_info.is_empty() and code > BUILD and String(row.get("edition", "all")) in ["all", ed]:
			apk_info = row
	changed.emit()


func has_update() -> bool:
	return not patch_info.is_empty() or not apk_info.is_empty()


func is_mandatory() -> bool:
	return bool(apk_info.get("mandatory", false)) or bool(patch_info.get("mandatory", false))


## وصله را می‌گیرد، امضا را می‌سنجد و برای اجرا در بار بعدی ذخیره می‌کند
func download_patch() -> Dictionary:
	if patch_info.is_empty() or busy:
		return {"ok": false, "error": "وصله‌ای نیست"}
	busy = true
	var info := patch_info
	var ver := int(info.version_code)
	DirAccess.make_dir_recursive_absolute(DIR)
	var local := "%s/patch_%d.pck" % [DIR, ver]
	var rr: Dictionary = await Online.fetch_object_to_file("releases", String(info.file_path), local, true)
	busy = false
	if not rr.ok:
		return {"ok": false, "error": String(rr.error)}
	var sha := FileAccess.get_sha256(local)
	if String(info.get("sha256", "")) != "" and sha != String(info.sha256):
		DirAccess.remove_absolute(local)
		return {"ok": false, "error": "فایل دانلودشده خراب است"}
	if not verify(BUILD, ver, sha, String(info.get("sig", ""))):
		DirAccess.remove_absolute(local)
		return {"ok": false, "error": "امضای وصله معتبر نیست؛ نصب نشد"}
	var old := String(active.get("file", ""))
	active = {"version": ver, "base": BUILD, "sha": sha, "sig": String(info.sig), "file": local, "tries": 0, "notes": String(info.get("notes", "")), "name": String(info.get("version_name", ""))}
	_save_active()
	if old != "" and old != local and FileAccess.file_exists(old):
		DirAccess.remove_absolute(old)
	patch_info = {}
	changed.emit()
	return {"ok": true, "error": ""}


func apk_link() -> String:
	if apk_info.is_empty():
		return ""
	return link_of(apk_info)


static func link_of(row: Dictionary) -> String:
	var u := String(row.get("url", ""))
	if u != "":
		return u
	var p := String(row.get("file_path", ""))
	if p == "":
		return ""
	return Online.url + "/storage/v1/object/public/releases/" + p.uri_encode().replace("%2F", "/")


## وصله‌ی دانلودشده منتظر باز شدن دوباره‌ی بازی است
func pending_restart() -> bool:
	return not active.is_empty() and int(active.get("version", 0)) > loaded_version
