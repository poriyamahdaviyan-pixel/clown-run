extends Control
## جلوه‌های بصری فروشگاه: پس‌زمینه‌ی زنده، بنر متحرک، آیکون‌های دسته‌ها و گرادیان‌ها. همه با کد کشیده می‌شوند (بدون فایل تصویر).
const COL_GOLD := Color("ffb02e")

var mode := "backdrop"            # backdrop | banner | icon
var kind := ""
var tint := Color.WHITE
var _t := 0.0
var _sparks: Array = []


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if mode == "backdrop":
		for i in 46:
			_sparks.append({"x": randf(), "y": randf(), "s": randf_range(0.4, 1.6), "v": randf_range(0.015, 0.06), "ph": randf() * 6.28, "c": randi() % 3})
	set_process(true)


func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	_t += delta
	if mode == "backdrop":
		for sp in _sparks:
			sp.y = fmod(float(sp.y) - float(sp.v) * delta + 1.0, 1.0)
	queue_redraw()


# ------------------------- گرادیان -------------------------
static func gradient_tex(c1: Color, c2: Color, vertical: bool = true, radial: bool = false) -> GradientTexture2D:
	var g := Gradient.new()
	g.set_color(0, c1)
	g.set_color(1, c2)
	var t := GradientTexture2D.new()
	t.gradient = g
	t.width = 128
	t.height = 128
	if radial:
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
	else:
		t.fill_from = Vector2(0.5, 0.0) if vertical else Vector2(0.0, 0.5)
		t.fill_to = Vector2(0.5, 1.0) if vertical else Vector2(1.0, 0.5)
	return t


## رنگ‌های هر کمیابی: [بالای کارت، پایین کارت، نور لبه]
static func rarity_colors(r: String) -> Array:
	match r:
		"rare": return [Color("1d3f7a"), Color("0a1433"), Color("4aa3ff")]
		"epic": return [Color("5b1d86"), Color("1a0733"), Color("c15bff")]
		"legendary": return [Color("8a5a08"), Color("2b1202"), Color("ffc43a")]
	return [Color("34264f"), Color("120a24"), Color("b8b8c8")]


static func card_style(r: String) -> StyleBoxFlat:
	var c := rarity_colors(r)
	var sb := StyleBoxFlat.new()
	sb.bg_color = (c[0] as Color).lerp(c[1], 0.45)
	sb.set_corner_radius_all(22)
	sb.set_border_width_all(3 if r == "common" else 4)
	sb.border_color = c[2]
	sb.shadow_color = Color(c[2].r, c[2].g, c[2].b, 0.0 if r == "common" else 0.5)
	sb.shadow_size = 0 if r == "common" else 14
	sb.shadow_offset = Vector2(0, 4)
	sb.set_content_margin_all(10)
	return sb


# ------------------------- رسم -------------------------
func _draw() -> void:
	match mode:
		"backdrop": _draw_backdrop()
		"banner": _draw_banner()
		"icon": _draw_icon()


func _draw_backdrop() -> void:
	var w := size.x
	var h := size.y
	draw_texture_rect(gradient_tex(Color("3a1668"), Color("0b0420")), Rect2(Vector2.ZERO, size), false)
	# نورهای بزرگ و نرم
	var orbs := [[0.15, 0.12, 360.0, Color(0.75, 0.2, 0.9, 0.22)], [0.9, 0.35, 420.0, Color(0.2, 0.5, 1.0, 0.18)], [0.3, 0.85, 380.0, Color(1.0, 0.6, 0.1, 0.16)]]
	for o in orbs:
		var p := Vector2(w * (float(o[0]) + 0.05 * sin(_t * 0.3 + float(o[2]))), h * (float(o[1]) + 0.04 * cos(_t * 0.25 + float(o[2]))))
		draw_texture_rect(gradient_tex(o[3], Color(o[3].r, o[3].g, o[3].b, 0.0), true, true), Rect2(p - Vector2(o[2], o[2]), Vector2(o[2], o[2]) * 2), false)
	# جرقه‌های شناور
	for sp in _sparks:
		var pos := Vector2(float(sp.x) * w + 14.0 * sin(_t * 0.7 + float(sp.ph)), float(sp.y) * h)
		var a := 0.25 + 0.35 * (0.5 + 0.5 * sin(_t * 2.0 + float(sp.ph)))
		var col: Color = [Color(1, 0.8, 0.3, a), Color(0.8, 0.5, 1, a), Color(0.5, 0.8, 1, a)][int(sp.c)]
		var r := 3.0 * float(sp.s)
		draw_circle(pos, r, col)
		draw_circle(pos, r * 2.4, Color(col.r, col.g, col.b, a * 0.18))


func _draw_banner() -> void:
	var r := Rect2(Vector2.ZERO, size)
	# بدنه‌ی گرادیانی با گوشه‌های گرد (چندضلعی)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color("ff9d1a")
	sb.set_corner_radius_all(30)
	sb.shadow_color = Color(1, 0.6, 0.1, 0.45)
	sb.shadow_size = 16
	draw_style_box(sb, r)
	var q := r.grow(-3)
	var cl := Color(1.0, 0.6, 0.1)
	var cr := Color(0.8, 0.12, 0.6)
	draw_polygon(PackedVector2Array([q.position + Vector2(20, 0), Vector2(q.end.x - 20, q.position.y), Vector2(q.end.x, q.position.y + 20), Vector2(q.end.x, q.end.y - 20), Vector2(q.end.x - 20, q.end.y), Vector2(q.position.x + 20, q.end.y), Vector2(q.position.x, q.end.y - 20), Vector2(q.position.x, q.position.y + 20)]), PackedColorArray([cl, cr, cr, cr, cr, cl, cl, cl]))
	# موج‌ها
	var wave := PackedVector2Array()
	for i in 41:
		var x := size.x * float(i) / 40.0
		wave.append(Vector2(x, size.y * 0.78 + 8.0 * sin(_t * 1.6 + float(i) * 0.45)))
	wave.append(Vector2(size.x, size.y))
	wave.append(Vector2(0, size.y))
	draw_colored_polygon(wave, Color(0.2, 0.05, 0.35, 0.55))
	# سکه‌های شناور
	for i in 6:
		var cx := size.x * (0.1 + 0.16 * float(i)) + 10.0 * sin(_t * 0.8 + float(i))
		var cy := size.y * 0.5 + 18.0 * sin(_t * 1.3 + float(i) * 1.7)
		var rad := 15.0 + 6.0 * float(i % 3)
		var squash := absf(cos(_t * 1.4 + float(i)))
		_coin(Vector2(cx, cy), rad, maxf(squash, 0.15), 0.9)
	# درخشش عبوری
	var sx := fmod(_t * 220.0, size.x + 400.0) - 200.0
	var poly := PackedVector2Array([Vector2(sx, 0), Vector2(sx + 60, 0), Vector2(sx - 20, size.y), Vector2(sx - 80, size.y)])
	draw_colored_polygon(poly, Color(1, 1, 1, 0.14))


func _coin(c: Vector2, r: float, sq: float, a: float) -> void:
	var pts := PackedVector2Array()
	for i in 24:
		var an := TAU * float(i) / 24.0
		pts.append(c + Vector2(cos(an) * r * sq, sin(an) * r))
	draw_colored_polygon(pts, Color(1.0, 0.82, 0.2, a))
	var pts2 := PackedVector2Array()
	for i in 24:
		var an2 := TAU * float(i) / 24.0
		pts2.append(c + Vector2(cos(an2) * r * 0.68 * sq, sin(an2) * r * 0.68))
	draw_colored_polygon(pts2, Color(1.0, 0.62, 0.1, a))
	draw_polyline(PackedVector2Array(pts + PackedVector2Array([pts[0]])), Color(0.6, 0.35, 0.0, a), 2.0)


## آیکون دسته‌ها (کد کشیده)
func _draw_icon() -> void:
	var c := size * 0.5
	var u := minf(size.x, size.y) * 0.5
	var col: Color = tint
	match kind:
		"coin":
			_coin(c, u * 0.8, 1.0, 1.0)
		"skin":
			draw_rect(Rect2(c + Vector2(-u * 0.32, -u * 0.8), Vector2(u * 0.64, u * 0.6)), col)
			draw_rect(Rect2(c + Vector2(-u * 0.5, -u * 0.12), Vector2(u * 1.0, u * 0.62)), col.darkened(0.2))
			draw_rect(Rect2(c + Vector2(-u * 0.4, u * 0.5), Vector2(u * 0.3, u * 0.35)), col.darkened(0.4))
			draw_rect(Rect2(c + Vector2(u * 0.1, u * 0.5), Vector2(u * 0.3, u * 0.35)), col.darkened(0.4))
		"glb", "police":
			var top := PackedVector2Array([c + Vector2(0, -u * 0.8), c + Vector2(u * 0.75, -u * 0.4), c + Vector2(0, 0), c + Vector2(-u * 0.75, -u * 0.4)])
			var left := PackedVector2Array([c + Vector2(-u * 0.75, -u * 0.4), c + Vector2(0, 0), c + Vector2(0, u * 0.85), c + Vector2(-u * 0.75, u * 0.4)])
			var right := PackedVector2Array([c + Vector2(u * 0.75, -u * 0.4), c + Vector2(0, 0), c + Vector2(0, u * 0.85), c + Vector2(u * 0.75, u * 0.4)])
			draw_colored_polygon(top, col.lightened(0.25))
			draw_colored_polygon(left, col)
			draw_colored_polygon(right, col.darkened(0.3))
		"voice", "chaser_voice":
			for i in 5:
				var hh := u * (0.35 + 0.5 * absf(sin(_t * 3.0 + float(i))))
				draw_rect(Rect2(c + Vector2(-u * 0.8 + float(i) * u * 0.36, -hh * 0.5), Vector2(u * 0.22, hh)), col)
		"music":
			draw_circle(c + Vector2(-u * 0.25, u * 0.5), u * 0.3, col)
			draw_rect(Rect2(c + Vector2(u * 0.0, -u * 0.8), Vector2(u * 0.12, u * 1.35)), col)
			draw_colored_polygon(PackedVector2Array([c + Vector2(u * 0.12, -u * 0.8), c + Vector2(u * 0.7, -u * 0.5), c + Vector2(u * 0.12, -u * 0.35)]), col)
		"anim", "anim_clip", "chaser_anim":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-u * 0.5, -u * 0.7), c + Vector2(u * 0.75, 0), c + Vector2(-u * 0.5, u * 0.7)]), col)
		"@chars":
			var pts := PackedVector2Array()
			for i in 10:
				var rr := u * (0.85 if i % 2 == 0 else 0.4)
				var an := -PI / 2.0 + TAU * float(i) / 10.0 + _t * 0.4
				pts.append(c + Vector2(cos(an), sin(an)) * rr)
			draw_colored_polygon(pts, col)
		_:
			var d := PackedVector2Array([c + Vector2(0, -u * 0.85), c + Vector2(u * 0.7, 0), c + Vector2(0, u * 0.85), c + Vector2(-u * 0.7, 0)])
			draw_colored_polygon(d, col)
