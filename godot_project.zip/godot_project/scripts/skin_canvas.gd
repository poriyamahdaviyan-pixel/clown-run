extends Control
## بوم نقاشی مستقیم روی اسکین ۶۴×۶۴ (چیدمان استاندارد ماینکرفت).
## ابزارها: قلم، پاک‌کن، پرکردن، قطره‌چکان، دست (جابه‌جایی). اندازه‌ی قلم ۱ تا ۴. زوم و جابه‌جایی.
## تقارن هوشمند: دست‌ها و پاها آینه می‌شوند (حالت «کامل» همه‌ی بدن را). واگرد/بازگرد تا ۲۵ مرحله.
## تصویر و تکسچر یک‌بار ساخته می‌شوند؛ مدل سه‌بعدی همین تکسچر را می‌گیرد و هنگام نقاشی زنده به‌روز می‌شود.

signal edited                                  # بعد از هر تغییر کامل (برای پیش‌نویس)
signal history_changed(undo_count: int, redo_count: int)
signal color_picked(color: Color)
signal hover_info(text: String)
signal notice(text: String)
signal tool_changed(tool: int)
signal layout_changed(slim: bool)              # بازوی باریک/کلاسیک عوض شد

const SkinLib := preload("res://scripts/skin_lib.gd")

enum Tool { PEN, ERASER, FILL, PICKER, HAND }

const MAX_UNDO := 25
const PART_NAMES: Array[String] = [
	"سر", "کلاه", "تنه", "ژاکت", "دست راست", "آستین راست",
	"دست چپ", "آستین چپ", "پای راست", "شلوار راست", "پای چپ", "شلوار چپ",
]
const FACE_NAMES: Array[String] = ["بالا", "پایین", "راست", "جلو", "چپ", "پشت"]
const SYM_NAMES: Array[String] = ["خاموش", "هوشمند (دست و پا)", "کامل (همه‌ی بدن)"]

var image: Image
var texture: ImageTexture
var slim := false
var tool: int = Tool.PEN
var brush := 1
var sym := 1
var color := Color("e0243c")
var zoom := 1.0
var origin := Vector2.ZERO
var show_grid := true

var _parts: Array = []
var _loc := PackedInt32Array()
var _mask_tex: ImageTexture
var _checker: ImageTexture
var _undo: Array[Dictionary] = []
var _redo: Array[Dictionary] = []
var _dragging := false
var _panning := false
var _last := Vector2i(-1, -1)
var _hover := Vector2i(-1, -1)
var _stroke_pushed := false
var _changed_now := false
var _dirty := false
var _warned := false
var _prev_tool: int = Tool.PEN


func _ready() -> void:
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	custom_minimum_size = Vector2(300, 300)
	resized.connect(func():
		_clamp_origin()
		queue_redraw())
	var ck := Image.create(128, 128, false, Image.FORMAT_RGBA8)
	for y in 128:
		for x in 128:
			var light := ((x + y) % 2) == 0
			ck.set_pixel(x, y, Color(0.80, 0.80, 0.82) if light else Color(0.62, 0.62, 0.66))
	_checker = ImageTexture.create_from_image(ck)
	image = SkinLib.preset(4)
	texture = ImageTexture.create_from_image(image)
	_rebuild_layout()


# ------------------------- چیدمان و تبدیل مختصات -------------------------
func _rebuild_layout() -> void:
	_parts = SkinLib.parts(slim)
	_loc.resize(4096)
	_loc.fill(-1)
	var mask := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	mask.fill(Color(0.05, 0.03, 0.1, 0.72))
	for i in _parts.size():
		var box: Array = _parts[i]["box"]
		for f in 6:
			var r := SkinLib.face_rect(box, f)
			for y in range(r.position.y, r.end.y):
				for x in range(r.position.x, r.end.x):
					_loc[y * 64 + x] = i * 6 + f
					mask.set_pixel(x, y, Color(0, 0, 0, 0))
	_mask_tex = ImageTexture.create_from_image(mask)
	queue_redraw()


func _side() -> float:
	return maxf(1.0, minf(size.x, size.y))


func _cell() -> float:
	return _side() / 64.0 * zoom


func _clamp_origin() -> void:
	var span := _cell() * 64.0
	var s := _side()
	origin.x = clampf(origin.x, minf(0.0, s - span), 0.0)
	origin.y = clampf(origin.y, minf(0.0, s - span), 0.0)


func _to_px(p: Vector2) -> Vector2i:
	var c := _cell()
	return Vector2i(floori((p.x - origin.x) / c), floori((p.y - origin.y) / c))


func _in_img(p: Vector2i) -> bool:
	return p.x >= 0 and p.y >= 0 and p.x < 64 and p.y < 64


func face_id(p: Vector2i) -> int:
	if not _in_img(p):
		return -1
	return _loc[p.y * 64 + p.x]


func is_base_layer(p: Vector2i) -> bool:
	var id := face_id(p)
	return id >= 0 and (id / 6) % 2 == 0


func describe(p: Vector2i) -> String:
	var id := face_id(p)
	if id < 0:
		return ""
	var layer := "لایه‌ی اول" if (id / 6) % 2 == 0 else "روکش"
	return "%s — %s — %s" % [PART_NAMES[id / 6], FACE_NAMES[id % 6], layer]


# ------------------------- رسم -------------------------
func _draw() -> void:
	var c := _cell()
	var span := c * 64.0
	var rect := Rect2(origin, Vector2(span, span))
	draw_texture_rect(_checker, rect, false)
	draw_texture_rect(texture, rect, false)
	draw_texture_rect(_mask_tex, rect, false)
	if show_grid and c >= 8.0:
		var gc := Color(0, 0, 0, 0.2)
		for i in 65:
			var x := origin.x + float(i) * c
			if x >= -1.0 and x <= size.x + 1.0:
				draw_line(Vector2(x, maxf(origin.y, 0.0)), Vector2(x, minf(origin.y + span, size.y)), gc, 1.0)
			var y := origin.y + float(i) * c
			if y >= -1.0 and y <= size.y + 1.0:
				draw_line(Vector2(maxf(origin.x, 0.0), y), Vector2(minf(origin.x + span, size.x), y), gc, 1.0)
	for i in _parts.size():
		var col := Color(1, 1, 1, 0.5) if i % 2 == 0 else Color(1.0, 0.7, 0.2, 0.8)
		var box: Array = _parts[i]["box"]
		for f in 6:
			var r := SkinLib.face_rect(box, f)
			draw_rect(Rect2(origin + Vector2(r.position) * c, Vector2(r.size) * c), col, false, 1.0)
	# مکان‌نما
	if _in_img(_hover) and tool != Tool.HAND and face_id(_hover) >= 0:
		var fp := _footprint(_hover)
		for q in fp:
			draw_rect(Rect2(origin + Vector2(q) * c, Vector2(c, c)), Color(1, 1, 1, 0.95), false, 2.0)
		if sym > 0 and tool != Tool.PICKER:
			for q in fp:
				var m := SkinLib.mirror_of(q, slim, sym)
				if m.x >= 0:
					draw_rect(Rect2(origin + Vector2(m) * c, Vector2(c, c)), Color(0.3, 1.0, 1.0, 0.95), false, 2.0)


# ------------------------- ورودی -------------------------
func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			zoom_by(1.25, mb.position)
			accept_event()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			zoom_by(0.8, mb.position)
			accept_event()
		elif mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_begin(mb.position)
			else:
				_end()
			accept_event()
		elif mb.button_index == MOUSE_BUTTON_MIDDLE or mb.button_index == MOUSE_BUTTON_RIGHT:
			_panning = mb.pressed
			accept_event()
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		var p := _to_px(mm.position)
		if p != _hover:
			_hover = p
			hover_info.emit(describe(p))
			queue_redraw()
		if _panning or (_dragging and tool == Tool.HAND):
			origin += mm.relative
			_clamp_origin()
			queue_redraw()
		elif _dragging:
			_move(p)
		accept_event()
	_flush()


func _begin(pos: Vector2) -> void:
	_dragging = true
	_stroke_pushed = false
	_warned = false
	_last = Vector2i(-1, -1)
	var p := _to_px(pos)
	_hover = p
	match tool:
		Tool.PEN, Tool.ERASER:
			_move(p)
		Tool.FILL:
			_do_fill(p)
		Tool.PICKER:
			_do_pick(p)


func _end() -> void:
	if _dragging and _dirty:
		_dirty = false
		edited.emit()
	_dragging = false
	_last = Vector2i(-1, -1)


func _move(p: Vector2i) -> void:
	if tool != Tool.PEN and tool != Tool.ERASER:
		return
	if face_id(p) < 0 and not _in_img(_last):
		_last = Vector2i(-1, -1)
		return
	var from := _last if _in_img(_last) else p
	for q in _line(from, p):
		if face_id(q) >= 0:
			_stamp(q, tool == Tool.ERASER)
	_last = p


## خط بین دو پیکسل (برسنهام) تا هنگام کشیدن سریع سوراخ نیفتد
func _line(a: Vector2i, b: Vector2i) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var x0 := a.x
	var y0 := a.y
	var dx := absi(b.x - x0)
	var dy := -absi(b.y - y0)
	var sx := 1 if x0 < b.x else -1
	var sy := 1 if y0 < b.y else -1
	var err := dx + dy
	var guard := 0
	while guard < 400:
		guard += 1
		out.append(Vector2i(x0, y0))
		if x0 == b.x and y0 == b.y:
			break
		var e2 := 2 * err
		if e2 >= dy:
			err += dy
			x0 += sx
		if e2 <= dx:
			err += dx
			y0 += sy
	return out


# ------------------------- ابزارها -------------------------
## پیکسل‌هایی که قلم روی آن‌ها می‌نشیند (فقط روی همان وجه، تا به وجه‌های دیگر نشت نکند)
func _footprint(p: Vector2i) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var id := face_id(p)
	if id < 0:
		return out
	if tool == Tool.FILL or tool == Tool.PICKER or brush <= 1:
		out.append(p)
		return out
	var lo := -((brush - 1) / 2)
	for dy in range(lo, lo + brush):
		for dx in range(lo, lo + brush):
			var q := Vector2i(p.x + dx, p.y + dy)
			if face_id(q) == id:
				out.append(q)
	return out


func _stamp(p: Vector2i, erase: bool) -> void:
	for q in _footprint(p):
		_put(q, erase)
		if sym > 0:
			var m := SkinLib.mirror_of(q, slim, sym)
			if m.x >= 0:
				_put(m, erase)


func _put(q: Vector2i, erase: bool) -> void:
	if face_id(q) < 0:
		return
	var cur := image.get_pixelv(q)
	var target := Color(0, 0, 0, 0) if erase else Color(color.r, color.g, color.b, 1.0)
	if erase:
		if is_base_layer(q):
			if not _warned:
				_warned = true
				notice.emit("لایه‌ی اول پاک نمی‌شود؛ رویش رنگ بکش یا روکش را پاک کن")
			return
		if cur.a < 0.01:
			return
	elif cur.a > 0.99 and cur.is_equal_approx(target):
		return
	_push_undo_once()
	image.set_pixelv(q, target)
	_changed_now = true
	_dirty = true


func _same(a: Color, b: Color) -> bool:
	if a.a < 0.01 and b.a < 0.01:
		return true
	return a.a > 0.99 and b.a > 0.99 and a.is_equal_approx(b)


func _do_fill(p: Vector2i) -> void:
	if face_id(p) < 0:
		return
	var new_col := Color(color.r, color.g, color.b, 1.0)
	_flood(p, new_col)
	if sym > 0:
		var m := SkinLib.mirror_of(p, slim, sym)
		if m.x >= 0:
			_flood(m, new_col)


func _flood(seed_p: Vector2i, new_col: Color) -> void:
	var id := face_id(seed_p)
	if id < 0:
		return
	var box: Array = _parts[id / 6]["box"]
	var r := SkinLib.face_rect(box, id % 6)
	var target := image.get_pixelv(seed_p)
	if _same(target, new_col):
		return
	_push_undo_once()
	var stack: Array[Vector2i] = [seed_p]
	var seen := {}
	seen[seed_p] = true
	while not stack.is_empty():
		var q: Vector2i = stack.pop_back()
		image.set_pixelv(q, new_col)
		for d: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var n := q + d
			if r.has_point(n) and not seen.has(n) and _same(image.get_pixelv(n), target):
				seen[n] = true
				stack.append(n)
	_changed_now = true
	_dirty = true


func _do_pick(p: Vector2i) -> void:
	if face_id(p) < 0:
		return
	var c := image.get_pixelv(p)
	if c.a < 0.5:
		notice.emit("این نقطه شفاف است")
		return
	color = Color(c.r, c.g, c.b, 1.0)
	color_picked.emit(color)
	set_tool(_prev_tool)


func set_tool(t: int) -> void:
	if t == Tool.PICKER and (tool == Tool.PEN or tool == Tool.ERASER or tool == Tool.FILL):
		_prev_tool = tool
	tool = t
	tool_changed.emit(tool)
	queue_redraw()


func set_brush(n: int) -> void:
	brush = clampi(n, 1, 4)
	queue_redraw()


func set_sym(m: int) -> void:
	sym = clampi(m, 0, 2)
	queue_redraw()


func set_color(c: Color) -> void:
	color = Color(c.r, c.g, c.b, 1.0)


# ------------------------- زوم -------------------------
func zoom_by(f: float, anchor: Vector2 = Vector2(-1, -1)) -> void:
	var a := anchor if anchor.x >= 0.0 else size * 0.5
	var before := (a - origin) / _cell()
	zoom = clampf(zoom * f, 1.0, 12.0)
	origin = a - before * _cell()
	_clamp_origin()
	queue_redraw()


func reset_view() -> void:
	zoom = 1.0
	origin = Vector2.ZERO
	queue_redraw()


# ------------------------- تاریخچه -------------------------
func _snapshot() -> Dictionary:
	return {"d": image.get_data(), "s": slim}


func _push_snapshot() -> void:
	_undo.append(_snapshot())
	if _undo.size() > MAX_UNDO:
		_undo.pop_front()
	_redo.clear()
	history_changed.emit(_undo.size(), _redo.size())


func _push_undo_once() -> void:
	if _stroke_pushed:
		return
	_stroke_pushed = true
	_push_snapshot()


func _restore(s: Dictionary) -> void:
	image.set_data(64, 64, false, Image.FORMAT_RGBA8, s["d"])
	var ns: bool = s["s"]
	if ns != slim:
		slim = ns
		_rebuild_layout()
		layout_changed.emit(slim)
	texture.update(image)
	queue_redraw()
	edited.emit()


func undo() -> void:
	if _undo.is_empty():
		return
	_redo.append(_snapshot())
	_restore(_undo.pop_back())
	history_changed.emit(_undo.size(), _redo.size())


func redo() -> void:
	if _redo.is_empty():
		return
	_undo.append(_snapshot())
	_restore(_redo.pop_back())
	history_changed.emit(_undo.size(), _redo.size())


func clear_history() -> void:
	_undo.clear()
	_redo.clear()
	history_changed.emit(0, 0)


func undo_count() -> int:
	return _undo.size()


func _flush() -> void:
	if _changed_now:
		_changed_now = false
		texture.update(image)
		queue_redraw()


# ------------------------- بارگذاری / خروجی -------------------------
## تصویر ۶۴×۶۴ را جایگزین می‌کند (قابل واگرد). لایه‌ی اول سوراخ‌دار پر می‌شود.
func load_image(img: Image, p_slim: bool, push: bool = true) -> void:
	var im := img.duplicate() as Image
	im.convert(Image.FORMAT_RGBA8)
	if im.get_width() != 64 or im.get_height() != 64:
		im.resize(64, 64, Image.INTERPOLATE_NEAREST)
	SkinLib.flatten_base(im, p_slim)
	if push:
		_push_snapshot()
	image.set_data(64, 64, false, Image.FORMAT_RGBA8, im.get_data())
	if p_slim != slim:
		slim = p_slim
		_rebuild_layout()
	layout_changed.emit(slim)
	texture.update(image)
	queue_redraw()
	_dirty = false
	edited.emit()


## بازوی باریک/کلاسیک؛ محتوای بازوها جابه‌جا می‌شود
func set_slim(v: bool) -> void:
	if v == slim:
		return
	_push_snapshot()
	SkinLib.convert_arms(image, slim, v)
	slim = v
	SkinLib.flatten_base(image, slim)
	_rebuild_layout()
	texture.update(image)
	layout_changed.emit(slim)
	edited.emit()


func export_image() -> Image:
	return SkinLib.finalize_for_export(image, slim)
