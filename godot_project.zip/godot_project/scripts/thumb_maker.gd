extends RefCounted
## ساخت خودکار پیش‌نمایشِ کارت برای هر آیتم (مالک عکس انتخاب نمی‌کند):
##  سکه = خودِ سکه، مدل = رندر همان مدل، اسکین = کاراکتر با آن اسکین، صدا/انیمیشن = کاراکتر در حال پرش/حرکت،
##  عکس/کارت = خودِ عکس. نتیجه PNG مربع ۵۱۲ است. اگر رندر ممکن نباشد (مثلاً حالت بدون‌صفحه) آرایه‌ی خالی برمی‌گردد.
const ItemPreview := preload("res://scripts/item_preview.gd")
const SIZE := 512
const IMAGE_EXT := ["png", "jpg", "jpeg", "webp", "bmp", "svg"]


static func _square(im: Image) -> PackedByteArray:
	if im == null or im.is_empty():
		return PackedByteArray()
	im.convert(Image.FORMAT_RGBA8)
	var s := mini(im.get_width(), im.get_height())
	var crop := im.get_region(Rect2i((im.get_width() - s) / 2, (im.get_height() - s) / 2, s, s))
	if s != SIZE:
		crop.resize(SIZE, SIZE, Image.INTERPOLATE_LANCZOS)
	return crop.save_png_to_buffer()


static func _find_viewport(n: Node) -> SubViewport:
	if n is SubViewport:
		return n
	for c in n.get_children():
		var r := _find_viewport(c)
		if r != null:
			return r
	return null


## kind، مسیر محلی فایل (یا ""), payload آیتم؛ host نودی داخل درخت صحنه
static func make(ui, host: Node, kind: String, local: String, payload: Dictionary, glb_yaw: int = 0) -> PackedByteArray:
	# عکس‌های ساده: خودِ فایل (به‌جز سکه/اسکین که رندر سه‌بعدی بهترند)
	if local != "" and local.get_extension().to_lower() in IMAGE_EXT and not kind in ["coin", "skin"]:
		var im := Image.new()
		if im.load(local) == OK:
			return _square(im)
	var root := Control.new()
	root.position = Vector2(-4000, 0)
	root.size = Vector2(600, 700)
	host.add_child(root)
	var ipv = ItemPreview.new()
	root.add_child(ipv)
	var it := {"id": "thumb", "kind": kind, "name": "", "payload": payload, "_local": local, "glb_yaw": glb_yaw, "price": 0}
	ipv.setup(ui, it)
	var tree := host.get_tree()
	var vp: SubViewport = null
	for i in 240:                         # تا ~۴ ثانیه صبر برای بارگذاری مدل
		await tree.process_frame
		if not is_instance_valid(ipv):
			break
		if ui._pv.has(ipv._key):
			vp = _find_viewport(ui._pv[ipv._key]["holder"])
			if vp != null:
				break
		elif i > 20 and _find_viewport(ipv) == null and ipv.get_child_count() > 2:
			break
	var out := PackedByteArray()
	if vp != null and is_instance_valid(vp):
		var d: Dictionary = ui._pv[ipv._key]
		d["auto"] = false
		d["yaw"] = 0.45 if not bool(d["spin"]) else 0.0     # کمی از روبه‌رو و کج، قشنگ‌تر
		d["pitch"] = 0.12
		d["cd"] = 99.0
		for i in 12:
			await tree.process_frame
		var tex := vp.get_texture()
		if tex != null:
			out = _square(tex.get_image())
	elif is_instance_valid(ipv):
		# حالت «تصویر»: اولین TextureRect
		var stack: Array = [ipv]
		while not stack.is_empty():
			var n: Node = stack.pop_back()
			if n is TextureRect and n.texture != null:
				out = _square(n.texture.get_image())
				break
			stack.append_array(n.get_children())
	root.queue_free()
	return out
