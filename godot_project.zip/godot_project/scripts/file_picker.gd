extends Control
## انتخابگر فایل مناسب موبایل: شبکه‌ی بزرگ با پیش‌نمایش، میان‌برِ پوشه‌ها و جدیدترین‌ها اول.
## روی اندروید ابتدا انتخابگر بومیِ سیستم (اگر موتور پشتیبانی کند) و در غیر این صورت همین صفحه.
signal picked(path: String)
signal canceled

const IMG_EXT := ["png", "jpg", "jpeg", "webp", "bmp"]
const MAX_FILES := 90
const SCAN_BUDGET_MS := 700
const MAX_THUMB_BYTES := 30 * 1048576
const THUMB := 190

var _exts: Array = IMG_EXT
var _grid: GridContainer
var _msg: Label
var _title: Label
var _folder_btns: HBoxContainer
var _scroll: ScrollContainer
var _loading_gen := 0
var _cache := {}
var _threads: Array = []
var _scan_t0 := 0


static func folders() -> Array:
	var base := "/storage/emulated/0/"
	if OS.get_name() != "Android":
		return [
			["دانلودها", OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)],
			["تصاویر", OS.get_system_dir(OS.SYSTEM_DIR_PICTURES)],
			["اسناد", OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)],
		]
	return [
		["دانلودها", base + "Download"],
		["دوربین", base + "DCIM"],
		["تصاویر", base + "Pictures"],
		["اسناد", base + "Documents"],
		["تلگرام", base + "Telegram"],
		["واتس‌اپ", base + "Android/media/com.whatsapp/WhatsApp/Media"],
	]


static func root_dir() -> String:
	if OS.get_name() == "Android":
		return "/storage/emulated/0"
	return OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS).get_base_dir()


## مرور پوشه‌به‌پوشه مثل فایل‌منیجر: فقط یک سطح، پوشه‌ها اول
func _browse(path: String) -> void:
	_current = path
	_browse_mode = true
	var items: Array = []
	var d := DirAccess.open(path)
	if d != null:
		var dirs: Array = []
		var files: Array = []
		d.list_dir_begin()
		var n := d.get_next()
		var count := 0
		while n != "" and count < 3000:
			count += 1
			if not n.begins_with("."):
				var fp := path.path_join(n)
				if d.current_is_dir():
					dirs.append([fp, 0, true])
				elif _exts.is_empty() or _exts.has(n.get_extension().to_lower()):
					files.append([fp, FileAccess.get_modified_time(fp), false])
			n = d.get_next()
		d.list_dir_end()
		dirs.sort_custom(func(a, b): return String(a[0]).get_file().to_lower() < String(b[0]).get_file().to_lower())
		files.sort_custom(func(a, b): return a[1] > b[1])
		items = dirs + files
	var parent := path.get_base_dir()
	var stop := "/storage" if OS.get_name() == "Android" else ""
	if path != stop and path != "/" and parent != path and (OS.get_name() != "Android" or path.length() > 8):
		items.push_front([parent, 0, true, "⬆  بالا"])
	_found = items
	_render()
	_msg.text = path + (" — پوشه خالی است یا اجازه لازم است" if items.size() <= 1 and d == null else "")


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.09, 0.05, 0.16, 1.0)
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var margin := MarginContainer.new()
	for k in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + k, 24)
	add_child(margin)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	margin.add_child(col)
	var top := HBoxContainer.new()
	col.add_child(top)
	var close := Button.new()
	close.text = "✕"
	close.custom_minimum_size = Vector2(90, 90)
	close.add_theme_font_size_override("font_size", 40)
	close.pressed.connect(func(): canceled.emit(); queue_free())
	top.add_child(close)
	_title = Label.new()
	_title.text = "انتخاب فایل"
	_title.add_theme_font_size_override("font_size", 42)
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(_title)
	var chips_scroll := ScrollContainer.new()
	chips_scroll.custom_minimum_size = Vector2(0, 84)
	chips_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(chips_scroll)
	_folder_btns = HBoxContainer.new()
	_folder_btns.add_theme_constant_override("separation", 10)
	chips_scroll.add_child(_folder_btns)
	_msg = Label.new()
	_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_msg.add_theme_font_size_override("font_size", 28)
	_msg.add_theme_color_override("font_color", Color("ffd27a"))
	_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(_msg)
	var search := LineEdit.new()
	search.placeholder_text = "جست‌وجوی نام فایل…"
	search.custom_minimum_size = Vector2(0, 76)
	search.add_theme_font_size_override("font_size", 30)
	search.clear_button_enabled = true
	search.text_changed.connect(func(t: String): _query = t.strip_edges().to_lower(); _render())
	col.add_child(search)
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(_scroll)
	_grid = GridContainer.new()
	_grid.columns = 3
	_grid.add_theme_constant_override("h_separation", 12)
	_grid.add_theme_constant_override("v_separation", 12)
	_scroll.add_child(_grid)
	var perm := Button.new()
	perm.text = "دادن اجازه‌ی دسترسی به فایل‌ها"
	perm.custom_minimum_size = Vector2(0, 90)
	perm.add_theme_font_size_override("font_size", 30)
	perm.pressed.connect(func(): OS.request_permissions(); _show_folder(_current))
	perm.visible = OS.get_name() == "Android"
	col.add_child(perm)
	var mem := Button.new()
	mem.text = "📂 حافظه"
	mem.custom_minimum_size = Vector2(150, 70)
	mem.add_theme_font_size_override("font_size", 28)
	mem.pressed.connect(func(): _browse(root_dir()))
	_folder_btns.add_child(mem)
	var all := Button.new()
	all.text = "جدیدترین‌ها"
	all.custom_minimum_size = Vector2(150, 70)
	all.add_theme_font_size_override("font_size", 28)
	all.pressed.connect(func(): _show_folder("*"))
	_folder_btns.add_child(all)
	for f: Array in folders():
		var b := Button.new()
		b.text = f[0]
		b.custom_minimum_size = Vector2(150, 70)
		b.add_theme_font_size_override("font_size", 28)
		var path: String = f[1]
		b.pressed.connect(func(): _show_folder(path))
		_folder_btns.add_child(b)
	_show_folder("*")


var _current := "*"
var _query := ""
var _browse_mode := false
var _found: Array = []


func setup(title: String, exts: Array) -> void:
	_exts = exts
	if _title:
		_title.text = title
		_show_folder(_current)
	else:
		call_deferred("setup", title, exts)


func _scan(dir: String, depth: int, out: Array) -> void:
	var d := DirAccess.open(dir)
	if d == null:
		return
	d.list_dir_begin()
	var n := d.get_next()
	while n != "" and out.size() < MAX_FILES * 3 and Time.get_ticks_msec() - _scan_t0 < SCAN_BUDGET_MS:
		if not n.begins_with("."):
			var p := dir.path_join(n)
			if d.current_is_dir():
				if depth > 0:
					_scan(p, depth - 1, out)
			elif _exts.is_empty() or _exts.has(n.get_extension().to_lower()):
				out.append([p, FileAccess.get_modified_time(p)])
		n = d.get_next()
	d.list_dir_end()


func _show_folder(path: String) -> void:
	_current = path
	_browse_mode = false
	_loading_gen += 1
	for c in _grid.get_children():
		c.queue_free()
	var found: Array = []
	var roots: Array = []
	if path == "*":
		for f: Array in folders():
			roots.append(f[1])
	else:
		roots.append(path)
	_scan_t0 = Time.get_ticks_msec()
	for r: String in roots:
		_scan(r, 2, found)
	found.sort_custom(func(a, b): return a[1] > b[1])
	_found = found
	_render()


static func human_size(n: int) -> String:
	if n >= 1048576:
		return "%.1f MB" % (float(n) / 1048576.0)
	return "%d KB" % maxi(1, n / 1024)


func _render() -> void:
	_loading_gen += 1
	var gen := _loading_gen
	for c in _grid.get_children():
		c.queue_free()
	var shown: Array = []
	for it: Array in _found:
		if it.size() > 3 or _query == "" or String(it[0]).get_file().to_lower().contains(_query):
			shown.append(it)
		if shown.size() >= MAX_FILES:
			break
	if shown.is_empty():
		_msg.text = "فایلی پیدا نشد. اگر فایل‌ها هست، دکمه‌ی «دادن اجازه» را بزن؛ یا فایل را در پوشه‌ی Download بگذار." if _query == "" else "فایلی با این نام نیست."
		return
	_msg.text = "%d مورد — روی فایل بزن" % shown.size()
	var is_img := _exts.has("png")
	_grid.columns = 3 if (is_img and not _browse_mode) else 1
	var btns: Array = []
	for i in shown.size():
		if gen != _loading_gen:
			return
		var p: String = shown[i][0]
		var b := Button.new()
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if shown[i].size() > 2 and bool(shown[i][2]):
			b.custom_minimum_size = Vector2(0, 96)
			b.alignment = HORIZONTAL_ALIGNMENT_LEFT
			b.add_theme_font_size_override("font_size", 30)
			b.text = String(shown[i][3]) if shown[i].size() > 3 else "📁  " + p.get_file()
			b.pressed.connect(func(): _browse(p))
			_grid.add_child(b)
			continue
		b.pressed.connect(func(): picked.emit(p); queue_free())
		if is_img and not _browse_mode:
			b.custom_minimum_size = Vector2(THUMB, THUMB + 46)
			b.clip_text = true
			b.text = p.get_file()
			b.add_theme_font_size_override("font_size", 18)
			b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
			b.vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
			b.expand_icon = true
		else:
			var fa := FileAccess.open(p, FileAccess.READ)
			var sz := 0
			if fa != null:
				sz = int(fa.get_length())
				fa.close()
			b.custom_minimum_size = Vector2(0, 110)
			b.clip_text = true
			b.alignment = HORIZONTAL_ALIGNMENT_LEFT
			b.add_theme_font_size_override("font_size", 28)
			b.text = "%s\n%s   %s" % [p.get_file(), human_size(sz), Time.get_datetime_string_from_unix_time(int(shown[i][1])).left(16).replace("T", " ")]
		_grid.add_child(b)
		btns.append([b, p])
		if i % 9 == 8:
			await get_tree().process_frame
	if is_img and not _browse_mode:
		var todo: Array = []
		for bp: Array in btns:
			var ct: Texture2D = _cache.get(bp[1])
			if ct != null:
				(bp[0] as Button).icon = ct
			else:
				todo.append(bp)
		if not todo.is_empty():
			var th := Thread.new()
			th.start(_thumb_worker.bind(todo, gen))
			_threads.append(th)


## بند‌انگشتی‌ها در یک نخ جدا ساخته می‌شوند تا صفحه هنگ نکند
func _thumb_worker(items: Array, gen: int) -> void:
	for it: Array in items:
		if gen != _loading_gen:
			return
		var p: String = it[1]
		var fa := FileAccess.open(p, FileAccess.READ)
		if fa == null:
			continue
		var len := fa.get_length()
		fa.close()
		if len > MAX_THUMB_BYTES:
			continue
		var img := Image.new()
		if img.load(p) != OK or img.is_empty():
			continue
		var sc := float(THUMB) / float(maxi(img.get_width(), img.get_height()))
		if sc < 1.0:
			img.resize(maxi(1, int(img.get_width() * sc)), maxi(1, int(img.get_height() * sc)), Image.INTERPOLATE_BILINEAR)
		_thumb_ready.call_deferred(it[0], p, img, gen)


func _thumb_ready(b: Button, p: String, img: Image, gen: int) -> void:
	if gen != _loading_gen or not is_instance_valid(b):
		return
	var tex := ImageTexture.create_from_image(img)
	_cache[p] = tex
	b.icon = tex


func _exit_tree() -> void:
	_loading_gen += 1
	for t: Thread in _threads:
		if t.is_started():
			t.wait_to_finish()
