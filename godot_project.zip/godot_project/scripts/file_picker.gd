extends Control
## انتخابگر فایل مناسب موبایل: شبکه‌ی بزرگ با پیش‌نمایش، میان‌برِ پوشه‌ها و جدیدترین‌ها اول.
## روی اندروید ابتدا انتخابگر بومیِ سیستم (اگر موتور پشتیبانی کند) و در غیر این صورت همین صفحه.
signal picked(path: String)
signal canceled

const IMG_EXT := ["png", "jpg", "jpeg", "webp", "bmp"]
const MAX_FILES := 90
const SCAN_BUDGET_MS := 700
const MAX_THUMB_BYTES := 30 * 1048576
const THUMB := 190

var _exts: Array = IMG_EXT
var _grid: GridContainer
var _msg: Label
var _title: Label
var _folder_btns: HBoxContainer
var _scroll: ScrollContainer
var _loading_gen := 0
var _cache := {}
var _threads: Array = []
var _scan_t0 := 0


static func folders() -> Array:
	var base := "/storage/emulated/0/"
	if OS.get_name() != "Android":
		return [
			["دانلودها", OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)],
			["تصاویر", OS.get_system_dir(OS.SYSTEM_DIR_PICTURES)],
			["اسناد", OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)],
		]
	return [
		["دانلودها", base + "Download"],
		["دوربین", base + "DCIM"],
		["تصاویر", base + "Pictures"],
		["اسناد", base + "Documents"],
		["تلگرام", base + "Telegram"],
		["واتس‌اپ", base + "Android/media/com.whatsapp/WhatsApp/Media"],
	]


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.09, 0.05, 0.16, 0.98)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for k in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + k, 24)
	add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	margin.add_child(col)
	var top := HBoxContainer.new()
	col.add_child(top)
	var close := Button.new()
	close.text = "✕"
	close.custom_minimum_size = Vector2(90, 90)
	close.add_theme_font_size_override("font_size", 40)
	close.pressed.connect(func(): canceled.emit(); queue_free())
	top.add_child(close)
	_title = Label.new()
	_title.text = "انتخاب فایل"
	_title.add_theme_font_size_override("font_size", 42)
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(_title)
	var chips_scroll := ScrollContainer.new()
	chips_scroll.custom_minimum_size = Vector2(0, 84)
	chips_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(chips_scroll)
	_folder_btns = HBoxContainer.new()
	_folder_btns.add_theme_constant_override("separation", 10)
	chips_scroll.add_child(_folder_btns)
	_msg = Label.new()
	_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_msg.add_theme_font_size_override("font_size", 28)
	_msg.add_theme_color_override("font_color", Color("ffd27a"))
	_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(_msg)
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(_scroll)
	_grid = GridContainer.new()
	_grid.columns = 3
	_grid.add_theme_constant_override("h_separation", 12)
	_grid.add_theme_constant_override("v_separation", 12)
	_scroll.add_child(_grid)
	var perm := Button.new()
	perm.text = "دادن اجازه‌ی دسترسی به فایل‌ها"
	perm.custom_minimum_size = Vector2(0, 90)
	perm.add_theme_font_size_override("font_size", 30)
	perm.pressed.connect(func(): OS.request_permissions(); _show_folder(_current))
	perm.visible = OS.get_name() == "Android"
	col.add_child(perm)
	var all := Button.new()
	all.text = "همه‌ی پوشه‌ها"
	all.custom_minimum_size = Vector2(150, 70)
	all.add_theme_font_size_override("font_size", 28)
	all.pressed.connect(func(): _show_folder("*"))
	_folder_btns.add_child(all)
	for f: Array in folders():
		var b := Button.new()
		b.text = f[0]
		b.custom_minimum_size = Vector2(150, 70)
		b.add_theme_font_size_override("font_size", 28)
		var path: String = f[1]
		b.pressed.connect(func(): _show_folder(path))
		_folder_btns.add_child(b)
	_show_folder("*")


var _current := "*"


func setup(title: String, exts: Array) -> void:
	_exts = exts
	if _title:
		_title.text = title
	else:
		call_deferred("setup", title, exts)


func _scan(dir: String, depth: int, out: Array) -> void:
	var d := DirAccess.open(dir)
	if d == null:
		return
	d.list_dir_begin()
	var n := d.get_next()
	while n != "" and out.size() < MAX_FILES * 3 and Time.get_ticks_msec() - _scan_t0 < SCAN_BUDGET_MS:
		if not n.begins_with("."):
			var p := dir.path_join(n)
			if d.current_is_dir():
				if depth > 0:
					_scan(p, depth - 1, out)
			elif _exts.is_empty() or _exts.has(n.get_extension().to_lower()):
				out.append([p, FileAccess.get_modified_time(p)])
		n = d.get_next()
	d.list_dir_end()


func _show_folder(path: String) -> void:
	_current = path
	_loading_gen += 1
	var gen := _loading_gen
	for c in _grid.get_children():
		c.queue_free()
	var found: Array = []
	var roots: Array = []
	if path == "*":
		for f: Array in folders():
			roots.append(f[1])
	else:
		roots.append(path)
	_scan_t0 = Time.get_ticks_msec()
	for r: String in roots:
		_scan(r, 2, found)
	found.sort_custom(func(a, b): return a[1] > b[1])
	if found.size() > MAX_FILES:
		found.resize(MAX_FILES)
	if found.is_empty():
		_msg.text = "فایلی پیدا نشد. اگر فایل‌ها هست، دکمه‌ی «دادن اجازه» را بزن؛ یا فایل را در پوشه‌ی Download بگذار."
		return
	_msg.text = "%d فایل — روی فایل بزن" % found.size()
	var is_img := _exts.has("png")
	var btns: Array = []
	for i in found.size():
		if gen != _loading_gen:
			return
		var p: String = found[i][0]
		var b := Button.new()
		b.custom_minimum_size = Vector2(THUMB, THUMB + 46)
		b.clip_text = true
		b.text = p.get_file()
		b.add_theme_font_size_override("font_size", 18)
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
		b.expand_icon = true
		b.pressed.connect(func(): picked.emit(p); queue_free())
		_grid.add_child(b)
		btns.append([b, p])
		if i % 9 == 8:
			await get_tree().process_frame
	if is_img:
		var todo: Array = []
		for bp: Array in btns:
			var ct: Texture2D = _cache.get(bp[1])
			if ct != null:
				(bp[0] as Button).icon = ct
			else:
				todo.append(bp)
		if not todo.is_empty():
			var th := Thread.new()
			th.start(_thumb_worker.bind(todo, gen))
			_threads.append(th)


## بند‌انگشتی‌ها در یک نخ جدا ساخته می‌شوند تا صفحه هنگ نکند
func _thumb_worker(items: Array, gen: int) -> void:
	for it: Array in items:
		if gen != _loading_gen:
			return
		var p: String = it[1]
		var fa := FileAccess.open(p, FileAccess.READ)
		if fa == null:
			continue
		var len := fa.get_length()
		fa.close()
		if len > MAX_THUMB_BYTES:
			continue
		var img := Image.new()
		if img.load(p) != OK or img.is_empty():
			continue
		var sc := float(THUMB) / float(maxi(img.get_width(), img.get_height()))
		if sc < 1.0:
			img.resize(maxi(1, int(img.get_width() * sc)), maxi(1, int(img.get_height() * sc)), Image.INTERPOLATE_BILINEAR)
		_thumb_ready.call_deferred(it[0], p, img, gen)


func _thumb_ready(b: Button, p: String, img: Image, gen: int) -> void:
	if gen != _loading_gen or not is_instance_valid(b):
		return
	var tex := ImageTexture.create_from_image(img)
	_cache[p] = tex
	b.icon = tex


func _exit_tree() -> void:
	_loading_gen += 1
	for t: Thread in _threads:
		if t.is_started():
			t.wait_to_finish()
