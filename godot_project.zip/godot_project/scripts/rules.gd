extends Node
## قوانین صدا و انیمیشن برای هر کاراکتر (Autoload با نام «Rules»)
## هر قانون: «وقتی [رویداد] (در [مقدار] / هر [مقدار]) → [صدا | انیمیشن | پیام]».
## مثلاً: کاراکتر X وقتی ۵۰۰ متر دوید «ha ha» بگوید؛ به‌جای صدای پرش، صدای دلخواه بگوید؛ هر ۳ پرش یک چرخش بزند.
## replace=true یعنی صدای/حرکت پیش‌فرضِ آن رویداد پخش نشود.

const PREF := "user://rules.json"
const VOICE_DIR := "user://voices"

## [شناسه، توضیح]
const EVENTS := [
	["start", "شروع دویدن"], ["distance", "رسیدن به مسافت (متر)"], ["jump", "پرش"], ["slide", "سُرخوردن"],
	["land", "فرود"], ["lane", "عوض‌کردن خط"], ["coin", "جمع‌کردن سکه"], ["graze", "خراش‌خوردن با مانع"],
	["near_miss", "ردشدن از نزدیکِ مانع"], ["score", "رسیدن به امتیاز"], ["minute", "گذشتن زمان (دقیقه)"], ["power", "برداشتن قدرت"], ["zone", "ورود به محیط جدید"], ["crash", "دستگیرشدن"],
]
## هدف‌های غیر از کاراکتر: «@chaser» = تعقیب‌کننده (فقط صدا)
const CHASER := "@chaser"
const CHASER_EVENTS := [
	["chaser_approach", "تعقیب‌کننده نزدیک می‌شود (وارد کادر)"], ["chaser_near", "تعقیب‌کننده می‌رسد (بعد از خراش)"],
	["chaser_caught", "تعقیب‌کننده بازیکن را می‌گیرد"], ["chaser_leave", "تعقیب‌کننده دور می‌شود"],
	["distance", "رسیدن به مسافت (متر)"],
]
const CHASER_SLOT_EVENTS := ["chaser_approach", "chaser_near", "chaser_caught", "chaser_leave"]
## اسلات‌هایی که در «انتخاب صدا و انیمیشن» برای هر کاراکتر هست
const SLOT_EVENTS := ["jump", "slide", "land", "lane", "coin", "graze", "near_miss", "start", "crash"]
const LIB_PREF := "user://library.json"
const ACTIONS := [["sound", "صدا"], ["anim", "انیمیشن"], ["popup", "نوشته‌ی روی صفحه"]]
const TRICKS := ["spin", "flip", "wave", "bounce", "crouch", "shake"]
const TRICK_NAMES := {"spin": "چرخش", "flip": "معلق", "wave": "تکان‌دادن", "bounce": "جهش‌های کوچک", "crouch": "خم‌شدن", "shake": "لرزش"}

var _data: Dictionary = {}           # شناسه‌ی کاراکتر -> [قانون]
var _counts: Dictionary = {}         # شمارنده‌ها در همین دوِ فعلی
var _last_fire: Dictionary = {}      # آخرین زمان اجرا برای cooldown
var _dist_hit: Dictionary = {}
var _cache: Dictionary = {}
var library: Array = []              # آیتم‌های نصب‌شده (صدا/انیمیشن): {id, kind, name, arg, rules}


func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(VOICE_DIR)
	if FileAccess.file_exists(PREF):
		var d = JSON.parse_string(FileAccess.get_file_as_string(PREF))
		if d is Dictionary:
			_data = d
	if FileAccess.file_exists(LIB_PREF):
		var l = JSON.parse_string(FileAccess.get_file_as_string(LIB_PREF))
		if l is Array:
			library = l
	Game.game_started.connect(_reset_run)


var _elapsed := 0.0


func _process(delta: float) -> void:
	if Game.is_active and not Game.over:
		_elapsed += delta


func _reset_run() -> void:
	_elapsed = 0.0
	_counts.clear()
	_last_fire.clear()
	_dist_hit.clear()


func _save() -> void:
	var f := FileAccess.open(PREF, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(_data))
		f.close()


# ------------------------- ویرایش -------------------------
func rules_of(char_id: String) -> Array:
	var a = _data.get(char_id, [])
	return a if a is Array else []


func new_rule() -> Dictionary:
	return {"event": "distance", "at": 500.0, "every": 0.0, "chance": 1.0, "action": "sound", "arg": "laugh",
		"args": [], "pick": "random", "replace": false, "max": 1, "cooldown": 0.0}


func add_rule(char_id: String, r: Dictionary = {}) -> void:
	var list := rules_of(char_id).duplicate()
	list.append(r if not r.is_empty() else new_rule())
	_data[char_id] = list
	_save()


func update_rule(char_id: String, idx: int, key: String, value) -> void:
	var list := rules_of(char_id)
	if idx < 0 or idx >= list.size():
		return
	list[idx][key] = value
	_data[char_id] = list
	_save()


func remove_rule(char_id: String, idx: int) -> void:
	var list := rules_of(char_id).duplicate()
	if idx >= 0 and idx < list.size():
		list.remove_at(idx)
	_data[char_id] = list
	_save()


# ------------------------- اجرا -------------------------
## رویداد را اعلام می‌کند؛ اگر قانونیِ replace=true اجرا شد true برمی‌گرداند
## (آن‌وقت صدای/حرکت پیش‌فرض پخش نمی‌شود).
func fire(event: String, value: float = 0.0, target: String = "") -> bool:
	var char_id: String = Skins.current_id if target == "" else target
	var replaced := false
	_counts[event] = int(_counts.get(event, 0)) + 1
	var list := rules_of(char_id)
	for i in list.size():
		var r: Dictionary = list[i]
		if String(r.get("event", "")) != event:
			continue
		var key := "%s:%d" % [char_id, i]
		if not _matches(r, event, value, key):
			continue
		if randf() > float(r.get("chance", 1.0)):
			continue
		var now := Time.get_ticks_msec() / 1000.0
		if now - float(_last_fire.get(key, -999.0)) < float(r.get("cooldown", 0.0)):
			continue
		var mx := int(r.get("max", 0))
		var done := int(_counts.get("run:" + key, 0))
		if mx > 0 and done >= mx:
			continue
		_counts["run:" + key] = done + 1
		_last_fire[key] = now
		_do(r, char_id)
		if bool(r.get("replace", false)):
			replaced = true
	return replaced


func _matches(r: Dictionary, event: String, value: float, key: String) -> bool:
	var every := float(r.get("every", 0.0))
	var at := float(r.get("at", 0.0))
	match event:
		"distance", "score", "minute":
			if every > 0.0:
				var n := int(floor(value / every))
				if n > int(_dist_hit.get(key, 0)):
					_dist_hit[key] = n
					return true
				return false
			if value >= at and not _dist_hit.has(key):
				_dist_hit[key] = 1
				return true
			return false
		"coin", "jump", "slide", "land", "lane", "near_miss", "power", "graze":
			if every > 1.0:
				return int(_counts.get(event, 0)) % int(every) == 0
			return true
		_:
			return true


## هر فریمِ بازی صدا زده می‌شود تا قانون‌های «مسافت» اجرا شوند
func tick(distance: float) -> void:
	if not rules_of(CHASER).is_empty():
		fire("distance", distance, CHASER)
	if rules_of(Skins.current_id).is_empty():
		return
	fire("distance", distance)
	fire("score", float(Game.score))
	fire("minute", _elapsed / 60.0)


func _do(r: Dictionary, target: String = "") -> void:
	var arg := String(r.get("arg", ""))
	match String(r.get("action", "")):
		"sound":
			var pool: Array = [arg]
			var extra = r.get("args", [])
			if extra is Array:
				for a in extra:
					if String(a) != "":
						pool.append(String(a))
			var mode := String(r.get("pick", "random"))
			if pool.size() == 1 or mode == "all":
				for a2 in pool:
					Sfx.play_any(String(a2), 0.0, target if target == CHASER else "")
			elif mode == "order":
				var k := "seq:%s:%s" % [target, arg]
				var n := int(_counts.get(k, 0))
				_counts[k] = n + 1
				Sfx.play_any(String(pool[n % pool.size()]), 0.0, target if target == CHASER else "")
			else:
				Sfx.play_any(String(pool[randi() % pool.size()]), 0.0, target if target == CHASER else "")
		"anim":
			var p = get_tree().root.find_child("Police" if target == CHASER else "Player", true, false)
			if p != null and p.has_method("play_trick"):
				p.play_trick(arg, 1.4)
		"popup":
			Game.popup.emit(arg, false)


func test_rule(r: Dictionary, target: String = "") -> void:
	_do(r, target)


# ------------------------- فایل صدا -------------------------
## فایل صوتی را به پوشه‌ی صداها کپی می‌کند و نام ذخیره‌شده را برمی‌گرداند ("" = ناموفق)
func import_voice(path: String, as_name: String = "") -> String:
	var ext := path.get_extension().to_lower()
	if ext not in ["ogg", "mp3", "wav"]:
		return ""
	var bytes := FileAccess.get_file_as_bytes(path)
	if bytes.is_empty():
		return ""
	var fname := path.get_file() if as_name == "" else as_name + "." + ext
	var dest := "%s/%s" % [VOICE_DIR, fname]
	var f := FileAccess.open(dest, FileAccess.WRITE)
	if f == null:
		return ""
	f.store_buffer(bytes)
	f.close()
	_cache.erase(dest)
	return "file:" + fname


## بسته‌ی قانون (JSON: آرایه‌ای از قانون‌ها یا {"rules":[...]}) را به یک کاراکتر اضافه می‌کند؛ تعداد قانون‌های معتبر را برمی‌گرداند
func parse_pack(text: String) -> Array:
	var d = JSON.parse_string(text)
	if d is Dictionary:
		d = d.get("rules", [])
	var out: Array = []
	if not d is Array:
		return out
	var ev: Array = []
	for e in EVENTS + CHASER_EVENTS:
		ev.append(e[0])
	for r in d:
		if r is Dictionary and String(r.get("event", "")) in ev and String(r.get("action", "")) in ["anim", "sound", "popup"]:
			out.append(r)
	return out


func import_pack(text: String, char_id: String) -> int:
	var d = JSON.parse_string(text)
	if d is Dictionary:
		d = d.get("rules", [])
	if not d is Array:
		return 0
	var ev: Array = []
	for e in EVENTS + CHASER_EVENTS:
		ev.append(e[0])
	var n := 0
	for r in d:
		if not r is Dictionary or String(r.get("event", "")) not in ev:
			continue
		var rule := new_rule()
		rule.merge(r, true)
		add_rule(char_id, rule)
		n += 1
	return n


func load_voice(arg: String) -> AudioStream:
	if not arg.begins_with("file:"):
		return null
	var path := "%s/%s" % [VOICE_DIR, arg.substr(5)]
	if _cache.has(path):
		return _cache[path]
	if not FileAccess.file_exists(path):
		return null
	var st := stream_from_path(path)
	_cache[path] = st
	return st


## هر فایل صوتی (ogg / mp3 / wav) را به استریم تبدیل می‌کند (برای صداها و موسیقی)
func stream_from_path(path: String) -> AudioStream:
	var bytes := FileAccess.get_file_as_bytes(path)
	var st: AudioStream = null
	match path.get_extension().to_lower():
		"ogg":
			st = AudioStreamOggVorbis.load_from_buffer(bytes)
		"mp3":
			var m := AudioStreamMP3.new()
			m.data = bytes
			st = m
		"wav":
			st = _parse_wav(bytes)
	return st


## خواندن WAV ساده‌ی PCM ۱۶بیتی (مونو یا استریو)
func _parse_wav(b: PackedByteArray) -> AudioStreamWAV:
	if b.size() < 44 or b.slice(0, 4).get_string_from_ascii() != "RIFF":
		return null
	var pos := 12
	var chan := 1
	var rate := 22050
	var bits := 16
	var data := PackedByteArray()
	while pos + 8 <= b.size():
		var id := b.slice(pos, pos + 4).get_string_from_ascii()
		var sz := b.decode_u32(pos + 4)
		if id == "fmt ":
			chan = b.decode_u16(pos + 10)
			rate = b.decode_u32(pos + 12)
			bits = b.decode_u16(pos + 22)
		elif id == "data":
			data = b.slice(pos + 8, mini(pos + 8 + sz, b.size()))
			break
		pos += 8 + sz + (sz & 1)
	if bits != 16 or data.is_empty():
		return null
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = chan == 2
	w.data = data
	return w


# ------------------------- کتابخانه و اسلات‌ها -------------------------
## کتابخانه: هر چیزی که بازیکن نصب کرده (صدا/بسته‌ی انیمیشن). فقط ذخیره می‌شود؛
## انتخاب اینکه کجا استفاده شود با «اسلات» است. «پیش‌فرض» یعنی هیچ قانونِ اسلات نباشد.
func _save_lib() -> void:
	var f := FileAccess.open(LIB_PREF, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(library))
		f.close()


func library_add(entry: Dictionary) -> void:
	for i in library.size():
		if String(library[i].get("id", "")) == String(entry.id):
			library[i] = entry
			_save_lib()
			Content.changed.emit()
			return
	library.append(entry)
	_save_lib()
	Content.changed.emit()


## for_chaser: آیتم‌های مخصوص تعقیب‌کننده فقط آنجا؛ آیتم‌های عادی در هر دو
func library_of(kind: String, for_chaser: bool = false, char_key: String = "") -> Array:
	return library.filter(func(e):
		if String(e.get("kind", "")) != kind:
			return false
		var ck := String(e.get("char", ""))
		if ck != "" and ck != char_key:
			return false
		var only: String = String(e.get("for", ""))
		return only == "" or (only == "chaser") == for_chaser)


func library_has_chaser() -> bool:
	for e in library:
		if String(e.get("for", "")) == "chaser":
			return true
	return false


func library_remove(id: String) -> void:
	library = library.filter(func(e): return String(e.get("id", "")) != id)
	for t in _data.keys():
		_data[t] = (_data[t] as Array).filter(func(r): return String(r.get("src", "")) != id)
	_save_lib()
	_save()
	Content.changed.emit()


func _slot_key(event: String, action: String) -> String:
	return "%s:%s" % [event, action]


## انتخاب فعلی یک اسلات: "" = پیش‌فرض | شناسه‌ی کتابخانه | "builtin:نام" | "trick:نام"
func slot_of(target: String, event: String, action: String) -> String:
	for r in rules_of(target):
		if String(r.get("slot", "")) == _slot_key(event, action):
			return String(r.get("src", ""))
	return ""


func set_slot(target: String, event: String, action: String, src: String) -> bool:
	var key := _slot_key(event, action)
	var list: Array = rules_of(target).filter(func(r): return String(r.get("slot", "")) != key)
	if src != "":
		var rule := new_rule()
		rule.merge({"event": event, "action": action, "replace": action == "sound", "max": 0, "slot": key, "src": src}, true)
		if src.begins_with("builtin:"):
			rule["arg"] = src.substr(8)
		elif src.begins_with("trick:"):
			rule["arg"] = src.substr(6)
		elif src.begins_with("clip:"):
			rule["arg"] = src
		else:
			var e := _lib_get(src)
			if e.is_empty():
				return false
			if action == "sound":
				rule["arg"] = String(e.get("arg", ""))
			elif String(e.get("clip", "")) != "":
				rule["arg"] = "clip:" + String(e.clip)       # انیمیشن خریداری‌شده‌ی یک کاراکتر: برای هر رویداد
			else:
				var found := false
				for pr in e.get("rules", []):
					if pr is Dictionary and String(pr.get("event", "")) == event and String(pr.get("action", "")) == "anim":
						rule["arg"] = String(pr.get("arg", ""))
						found = true
						break
				if not found:
					return false
		list.append(rule)
	_data[target] = list
	_save()
	return true


func event_name(ev: String) -> String:
	for e in EVENTS + CHASER_EVENTS:
		if e[0] == ev:
			return String(e[1])
	return ev


## کدام رویداد (اسلات) این صدای کتابخانه را دارد؟ "" = هیچ
func slot_event_of(target: String, lib_id: String, action: String = "sound") -> String:
	for ev in SLOT_EVENTS + CHASER_SLOT_EVENTS:
		if slot_of(target, String(ev), action) == lib_id:
			return String(ev)
	return ""


func _lib_get(id: String) -> Dictionary:
	for e in library:
		if String(e.get("id", "")) == id:
			return e
	return {}


## آیا این بسته‌ی انیمیشن برای این رویداد حرکتی دارد؟
func pack_has(e: Dictionary, event: String) -> bool:
	if String(e.get("clip", "")) != "":
		return true
	for pr in e.get("rules", []):
		if pr is Dictionary and String(pr.get("event", "")) == event and String(pr.get("action", "")) == "anim":
			return true
	return false
