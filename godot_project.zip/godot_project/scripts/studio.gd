extends Control
## صفحه‌ی «استودیوی اسکین»: بوم نقاشی + پیش‌نمایش زنده‌ی سه‌بعدی کنار آن + ابزارها، رنگ، پریست، عکس، PNG.

signal close_requested
signal pick_requested(target: String)
signal toast_requested(text: String)

const SkinLib := preload("res://scripts/skin_lib.gd")
const SkinCanvas := preload("res://scripts/skin_canvas.gd")
const CharacterModel := preload("res://scripts/character_model.gd")

const DRAFT_PNG := "user://studio_draft.png"
const DRAFT_CFG := "user://studio_draft.cfg"
const PRESETS := [{"name": "کلاسیک", "i": 4}, {"name": "نینجا", "i": 1}, {"name": "طلایی", "i": 5}, {"name": "نئون", "i": 6}]
const PALETTE: Array[String] = [
	"000000", "3a3a44", "7a7a86", "ffffff", "5b3a1e", "8a5a2b", "c98f68", "f0c49c",
	"e0243c", "ff6a2b", "ffb02e", "ffe14a", "9dff3c", "2aa65a", "27f3ff", "2f7bff",
	"3a46a0", "8b019d", "ff2fd2", "ff8aa8", "f2c233", "c4901c", "4a2f1c", "1f8590",
]

var ui                          # ui.gd (برای ساخت دکمه/برچسب و پیش‌نمایش)
var canvas: SkinCanvas
var model: Node3D
var editing_id := ""            # کاراکتر دلخواهی که در حال ویرایش است ("" = جدید)

var _tool_btns := {}
var _brush_btns: Array[Button] = []
var _sym_btn: Button
var _undo_btn: Button
var _redo_btn: Button
var _slim_btn: Button
var _swatch: ColorRect
var _hsv: Array[HSlider] = []
var _recent: HBoxContainer
var _recent_cols: Array[Color] = []
var _hover_lbl: Label
var _zoom_lbl: Label
var _name_edit: LineEdit
var _save_new_btn: Button
var _updating := false
var _draft_ready := false


func setup(p_ui) -> void:
	ui = p_ui
	_build()


func _build() -> void:
	ui._add_full(self, ui._dim_rect(0.9))
	var scroll := ScrollContainer.new()
	ui._add_full(self, scroll)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 52)
	margin.add_theme_constant_override("margin_bottom", 36)
	scroll.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	margin.add_child(col)

	col.add_child(ui._label("استودیوی اسکین", 52, Color.WHITE))

	# ---- بوم + پیش‌نمایش کنار هم ----
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	col.add_child(row)

	var canvas_box := PanelContainer.new()
	canvas_box.add_theme_stylebox_override("panel", ui._flat(Color(0.05, 0.02, 0.1, 0.9), 14, 3))
	canvas_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	canvas_box.size_flags_stretch_ratio = 1.9
	row.add_child(canvas_box)
	canvas = SkinCanvas.new()
	canvas.custom_minimum_size = Vector2(420, 420)
	canvas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	canvas_box.add_child(canvas)

	model = CharacterModel.new()
	var pv: Control = ui._make_preview("studio", 430, model, false)
	pv.size_flags_stretch_ratio = 1.0
	pv.custom_minimum_size = Vector2(200, 430)
	row.add_child(pv)

	_hover_lbl = ui._label("روی بوم بکش؛ سمت راست نتیجه زنده دیده می‌شود", 22, Color(1, 1, 1, 0.85))
	_hover_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hover_lbl.custom_minimum_size = Vector2(600, 0)
	col.add_child(_hover_lbl)

	# ---- ابزارها ----
	var tools := HBoxContainer.new()
	tools.add_theme_constant_override("separation", 8)
	tools.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(tools)
	var defs := [["قلم", SkinCanvas.Tool.PEN], ["پاک‌کن", SkinCanvas.Tool.ERASER], ["پر کردن", SkinCanvas.Tool.FILL], ["قطره", SkinCanvas.Tool.PICKER], ["دست", SkinCanvas.Tool.HAND]]
	for d in defs:
		var t: int = d[1]
		var b: Button = ui._button(str(d[0]), func(): canvas.set_tool(t), Vector2(128, 74), 24)
		tools.add_child(b)
		_tool_btns[t] = b

	# ---- اندازه‌ی قلم و زوم ----
	var r2 := HBoxContainer.new()
	r2.add_theme_constant_override("separation", 8)
	r2.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(r2)
	r2.add_child(ui._label("قلم", 24))
	for n in range(1, 5):
		var nn: int = n
		var bb: Button = ui._button(str(n), func(): canvas.set_brush(nn); _refresh_ui(), Vector2(64, 64), 28)
		r2.add_child(bb)
		_brush_btns.append(bb)
	r2.add_child(ui._label("  زوم", 24))
	r2.add_child(ui._button("−", func(): canvas.zoom_by(0.8); _refresh_ui(), Vector2(64, 64), 32))
	_zoom_lbl = ui._label("1×", 24)
	_zoom_lbl.custom_minimum_size = Vector2(56, 0)
	_zoom_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	r2.add_child(_zoom_lbl)
	r2.add_child(ui._button("+", func(): canvas.zoom_by(1.25); _refresh_ui(), Vector2(64, 64), 32))
	r2.add_child(ui._button("⌂", func(): canvas.reset_view(); _refresh_ui(), Vector2(64, 64), 28))

	# ---- تقارن، واگرد، بازوی باریک ----
	var r3 := HBoxContainer.new()
	r3.add_theme_constant_override("separation", 8)
	r3.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(r3)
	_sym_btn = ui._button("", func(): canvas.set_sym((canvas.sym + 1) % 3); _refresh_ui(), Vector2(290, 70), 22)
	r3.add_child(_sym_btn)
	_undo_btn = ui._button("واگرد", func(): canvas.undo(), Vector2(150, 70), 24)
	r3.add_child(_undo_btn)
	_redo_btn = ui._button("بازگرد", func(): canvas.redo(), Vector2(150, 70), 24)
	r3.add_child(_redo_btn)

	_slim_btn = ui._button("", func(): canvas.set_slim(not canvas.slim); _refresh_ui(), Vector2(600, 64), 24)
	col.add_child(_slim_btn)

	# ---- رنگ ----
	col.add_child(ui._label("رنگ", 28, Color.WHITE))
	var cr := HBoxContainer.new()
	cr.add_theme_constant_override("separation", 10)
	col.add_child(cr)
	_swatch = ColorRect.new()
	_swatch.custom_minimum_size = Vector2(110, 110)
	cr.add_child(_swatch)
	var sl_box := VBoxContainer.new()
	sl_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl_box.add_theme_constant_override("separation", 4)
	cr.add_child(sl_box)
	for i in 3:
		var s := HSlider.new()
		s.min_value = 0.0
		s.max_value = 1.0
		s.step = 0.005
		s.custom_minimum_size = Vector2(0, 34)
		s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		s.value_changed.connect(func(_v: float): _on_hsv())
		sl_box.add_child(s)
		_hsv.append(s)

	var grid := GridContainer.new()
	grid.columns = 12
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	col.add_child(grid)
	for hx in PALETTE:
		grid.add_child(_swatch_button(Color(hx)))
	col.add_child(ui._label("اخیر", 20, Color(1, 1, 1, 0.7)))
	_recent = HBoxContainer.new()
	_recent.add_theme_constant_override("separation", 6)
	_recent.custom_minimum_size = Vector2(0, 56)
	col.add_child(_recent)

	# ---- پریست‌ها ----
	col.add_child(ui._label("شروع از یک طرح آماده", 28, Color.WHITE))
	var pr := HBoxContainer.new()
	pr.add_theme_constant_override("separation", 8)
	pr.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(pr)
	for p in PRESETS:
		var idx: int = p["i"]
		pr.add_child(ui._button(str(p["name"]), func(): _load_preset(idx), Vector2(140, 76), 24))

	# ---- عکس و فایل ----
	col.add_child(ui._button("ساخت از عکس (حذف خودکار پس‌زمینه)", func(): pick_requested.emit("studio_photo"), Vector2(600, 84), 28))
	var fr := HBoxContainer.new()
	fr.add_theme_constant_override("separation", 10)
	fr.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(fr)
	fr.add_child(ui._button("بارگذاری PNG", func(): pick_requested.emit("studio_png"), Vector2(295, 76), 26))
	fr.add_child(ui._button("ذخیره‌ی PNG", func(): _export_png(), Vector2(295, 76), 26))

	# ---- ذخیره در بازی ----
	_name_edit = LineEdit.new()
	_name_edit.placeholder_text = "نام کاراکتر"
	_name_edit.custom_minimum_size = Vector2(600, 70)
	_name_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	_name_edit.add_theme_font_size_override("font_size", 28)
	_name_edit.max_length = 16
	col.add_child(_name_edit)
	col.add_child(ui._button("ذخیره و استفاده در بازی", func(): _save_game(false), Vector2(600, 100), 36, "Gold"))
	_save_new_btn = ui._button("ذخیره به‌عنوان کاراکتر جدید", func(): _save_game(true), Vector2(600, 76), 26)
	col.add_child(_save_new_btn)
	col.add_child(ui._button("بازگشت", func(): _leave(), Vector2(600, 80), 30, "Dark"))

	canvas.history_changed.connect(func(_u: int, _r: int): _refresh_ui())
	canvas.tool_changed.connect(func(_t: int): _refresh_ui())
	canvas.color_picked.connect(func(c: Color): _set_color(c, false))
	canvas.hover_info.connect(func(t: String):
		if t != "":
			_hover_lbl.text = t)
	canvas.notice.connect(func(t: String): toast_requested.emit(t))
	canvas.layout_changed.connect(func(_s: bool): _refresh_model())
	canvas.edited.connect(_on_edited)

	_set_color(Color("e0243c"), false)
	_refresh_model()
	_refresh_ui()


func _swatch_button(c: Color) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(46, 46)
	for st in ["normal", "hover", "pressed", "focus"]:
		var sb: StyleBoxFlat = ui._flat(c, 8, 2)
		sb.border_color = Color(1, 1, 1, 0.5)
		b.add_theme_stylebox_override(st, sb)
	b.pressed.connect(func():
		Sfx.play("click")
		_set_color(c, false))
	return b


# ------------------------- رنگ -------------------------
func _set_color(c: Color, remember: bool) -> void:
	canvas.set_color(c)
	_updating = true
	_hsv[0].value = c.h
	_hsv[1].value = c.s
	_hsv[2].value = c.v
	_updating = false
	_swatch.color = c
	if remember:
		_remember(c)


func _on_hsv() -> void:
	if _updating:
		return
	var c := Color.from_hsv(_hsv[0].value, _hsv[1].value, _hsv[2].value)
	canvas.set_color(c)
	_swatch.color = c


func _remember(c: Color) -> void:
	for i in range(_recent_cols.size() - 1, -1, -1):
		if _recent_cols[i].is_equal_approx(c):
			_recent_cols.remove_at(i)
	_recent_cols.push_front(c)
	while _recent_cols.size() > 10:
		_recent_cols.pop_back()
	for ch in _recent.get_children():
		_recent.remove_child(ch)
		ch.queue_free()
	for rc in _recent_cols:
		var b := _swatch_button(rc)
		b.custom_minimum_size = Vector2(44, 44)
		_recent.add_child(b)


func _on_edited() -> void:
	_remember(canvas.color)
	_save_draft()
	_refresh_ui()


# ------------------------- وضعیت ظاهر -------------------------
func _refresh_ui() -> void:
	if canvas == null:
		return
	for t in _tool_btns:
		var b: Button = _tool_btns[t]
		b.modulate = Color(1, 1, 1, 1) if canvas.tool == t else Color(1, 1, 1, 0.55)
	for i in _brush_btns.size():
		_brush_btns[i].modulate = Color(1, 1, 1, 1) if canvas.brush == i + 1 else Color(1, 1, 1, 0.55)
	_sym_btn.text = "تقارن: " + SkinCanvas.SYM_NAMES[canvas.sym]
	_undo_btn.text = "واگرد (%d)" % canvas.undo_count()
	_undo_btn.disabled = canvas.undo_count() == 0
	_redo_btn.disabled = canvas._redo.is_empty()
	_slim_btn.text = "بازو: " + ("باریک (Alex)" if canvas.slim else "کلاسیک (Steve)") + " — برای تغییر بزن"
	_zoom_lbl.text = "%.1f×" % canvas.zoom
	_save_new_btn.visible = editing_id != ""


func _refresh_model() -> void:
	if model != null and canvas != null:
		model.set_skin(canvas.texture, canvas.slim, false)


# ------------------------- ورود/خروج -------------------------
## mode: "draft" (ادامه‌ی پیش‌نویس یا شروع جدید) | "current" (ویرایش کاراکتر انتخاب‌شده)
func open_studio(mode: String) -> void:
	editing_id = ""
	canvas.clear_history()
	if mode == "current":
		var e: Dictionary = Skins.current_entry()
		var res: Dictionary = Skins.result_for(e)
		var img: Image = res["image"]
		if img.get_width() != 64:
			img = img.duplicate() as Image
			img.resize(64, 64, Image.INTERPOLATE_NEAREST)
		canvas.load_image(img, bool(res["slim"]), false)
		_name_edit.text = str(e["name"]) if Skins.is_custom(e) else ""
		if Skins.is_custom(e) and not Skins.is_multi(e) and str(e["file"]) != "":
			editing_id = str(e["id"])
	else:
		if not _load_draft():
			canvas.load_image(SkinLib.preset(4), false, false)
			_name_edit.text = ""
	canvas.reset_view()
	canvas.clear_history()
	_refresh_model()
	_refresh_ui()


func _leave() -> void:
	_save_draft()
	close_requested.emit()


# ------------------------- پیش‌نویس -------------------------
func _save_draft() -> void:
	canvas.image.save_png(DRAFT_PNG)
	var cfg := ConfigFile.new()
	cfg.set_value("d", "slim", canvas.slim)
	cfg.set_value("d", "name", _name_edit.text)
	cfg.save(DRAFT_CFG)


func _load_draft() -> bool:
	if not FileAccess.file_exists(DRAFT_PNG):
		return false
	var im := Image.load_from_file(DRAFT_PNG)
	if im == null or im.is_empty() or im.get_width() != 64 or im.get_height() != 64:
		return false
	var cfg := ConfigFile.new()
	var sl := false
	var nm := ""
	if cfg.load(DRAFT_CFG) == OK:
		sl = bool(cfg.get_value("d", "slim", false))
		nm = str(cfg.get_value("d", "name", ""))
	canvas.load_image(im, sl, false)
	_name_edit.text = nm
	return true


# ------------------------- پریست / عکس / PNG -------------------------
func _load_preset(i: int) -> void:
	Sfx.play("click")
	canvas.load_image(SkinLib.preset(i), false)
	_refresh_ui()


## تصویر انتخاب‌شده را وارد بوم می‌کند. kind: "studio_png" | "studio_photo"
func import_image(img: Image, kind: String) -> void:
	img.convert(Image.FORMAT_RGBA8)
	var as_skin := SkinLib.looks_like_skin(img) and kind != "studio_photo"
	if as_skin:
		var r := SkinLib.to_editor_image(img)
		canvas.load_image(r["image"], bool(r["slim"]))
		toast_requested.emit("اسکین بارگذاری شد")
	else:
		var m := maxi(img.get_width(), img.get_height())
		if m > 768:
			var f := 768.0 / float(m)
			img.resize(maxi(8, int(img.get_width() * f)), maxi(8, int(img.get_height() * f)), Image.INTERPOLATE_LANCZOS)
		var built := SkinLib.build_from_photos({"front": img}, 0)
		if built.has("error"):
			toast_requested.emit(str(built["error"]))
			Sfx.play("error")
			return
		canvas.load_image(built["image"], bool(built.get("slim", false)))
		toast_requested.emit("عکس به اسکین ۶۴×۶۴ تبدیل شد؛ با ابزارها صافش کن")
	Sfx.play("buy")
	_save_draft()
	_refresh_ui()


func _export_png() -> void:
	var nm := _name_edit.text.strip_edges()
	if nm == "":
		nm = "skin"
	var r: Dictionary = Skins.export_image(canvas.export_image(), nm)
	if r["ok"]:
		toast_requested.emit("PNG ذخیره شد:\n" + str(r["path"]))
		Sfx.play("buy")
	else:
		toast_requested.emit("ذخیره‌ی فایل ناموفق بود")
		Sfx.play("error")


func _save_game(as_new: bool) -> void:
	var id := "" if as_new else editing_id
	var r: Dictionary = Skins.save_painted(id, canvas.export_image(), canvas.slim, _name_edit.text)
	if r.has("error"):
		toast_requested.emit(str(r["error"]))
		Sfx.play("error")
		return
	editing_id = str(r["id"])
	toast_requested.emit("کاراکتر ذخیره شد و انتخاب شد!")
	Sfx.play("buy")
	_save_draft()
	close_requested.emit()
