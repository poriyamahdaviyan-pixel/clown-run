extends Node
## هسته‌ی بازی (Autoload با نام «Game»): دونده‌ی بی‌پایان به سبک Subway Surfers / Temple Run.
## قوانین:
##  • مسیر تمام نمی‌شود؛ سرعت کم‌کم زیاد می‌شود. امتیاز = متر + سکه‌ها.
##  • برخورد اول با مانع = «لیز خوردن» (۵ ثانیه فرصت). برخورد دوم در این فرصت = گرفتنت!
##  • سپر یک برخورد را می‌گیرد؛ جت‌پک شکست‌ناپذیر است.
##  • هر ۴۵۰ متر محیط عوض می‌شود: شهر غروب ← صحرا ← جنگل و معبد.
##  • قدرت‌ها روی مسیر پیدا می‌شوند و در فروشگاه ارتقا می‌خورند.

signal score_changed(value: int)
signal run_coins_changed(value: int)
signal coins_changed(value: int)
signal high_score_changed(value: int)
signal distance_changed(value: int)
signal game_started
signal intro_started
signal game_over(summary: Dictionary)
signal session_ended
signal pause_changed(paused: bool)
signal player_hit
signal stumble_changed(active: bool)
signal grazed
signal shield_broke
signal coin_collected(value: int)
signal power_collected(id: int)
signal power_ended(id: int)
signal zone_changed(zone: int)
signal revived
signal boosts_changed
signal boost_used(id: String)
signal popup(text: String, good: bool)
signal toast(text: String)
signal mission_completed(text: String, reward: int)
signal missions_changed
signal combo_changed(mult: int, chain: int)
signal look_changed
signal mode_changed(id: String)
signal mini_started(id: String)
signal mini_finished(id: String)

enum Power { MAGNET, SHIELD, DOUBLE, JET, SPRING, SLOW }

# ------------------------- ثابت‌های قابل تنظیم -------------------------
const LANE_WIDTH := 2.4
const SAVE_PATH := "user://save.cfg"
const SPEED_ACCEL := 6.0
var START_SPEED := 11.0
var MAX_SPEED := 25.0
var SPEED_PER_SECOND := 0.07
var COIN_SCORE := 5
var ZONE_LENGTH := 450.0
const ZONE_COUNT := 6
const ZONE_NAMES: Array[String] = ["شهر در غروب", "صحرای طلایی", "جنگل و معبد", "کوهستان برفی", "بندر شبانه", "آتشفشان"]
var STUMBLE_TIME := 3.5
var STUMBLE_SLOW := 0.72
var JET_GRACE := 1.6
var SLOW_MULT := 0.7
var NEAR_BONUS := 15
var REVIVE_PRICE := 30
const REVIVE_INVULN := 3.0

const POWER_NAMES: Array[String] = ["آهنربا", "سپر", "سکه ×۲", "جت‌پک", "کفش فنری", "حرکت آهسته"]
const POWER_ICONS: Array[String] = ["M", "S", "×2", "J", "↑", "◔"]
var POWER_BASE: Array[float] = [8.0, 10.0, 10.0, 6.0, 10.0, 8.0]
var POWER_STEP: Array[float] = [2.0, 2.0, 2.5, 1.0, 2.5, 2.0]
const MAX_LEVEL := 5
var UPGRADE_BASE_PRICE := 40

## ابزارهای مصرفی: از قبل در فروشگاه قدرت‌ها می‌خری و اول یا وسط بازی با دکمه‌ی حین بازی مصرف می‌کنی.
## id، نام، نماد (BoostIcon)، رنگ، قیمت پیش‌فرض، مدت (ثانیه)، توضیح. قیمت و مدت و روشن/خاموش را مالک عوض می‌کند (BOOSTS در تنظیمات).
const BOOSTS := [
	{"id": "rocket", "name": "موشک شروع", "icon": "rocket", "color": "ff7a2a", "price": 60, "dur": 6.0, "power": 3,
		"desc": "جت‌پک فوری: چند ثانیه بالای مانع‌ها پرواز می‌کنی و شکست‌ناپذیری."},
	{"id": "coin2", "name": "سکه‌ی طلایی", "icon": "x2", "color": "ffc21a", "price": 40, "dur": 20.0, "power": 2,
		"desc": "تا ۲۰ ثانیه هر سکه دو برابر حساب می‌شود."},
	{"id": "shield", "name": "سپر آماده", "icon": "shield", "color": "38a8ff", "price": 45, "dur": 15.0, "power": 1,
		"desc": "یک برخورد را می‌گیرد؛ تا ۱۵ ثانیه فعال می‌ماند."},
	{"id": "ghost", "name": "شبح", "icon": "ghost", "color": "b8c8ff", "price": 70, "dur": 5.0, "power": -1,
		"desc": "۵ ثانیه از میان همه‌ی مانع‌ها رد می‌شوی (بدون پرواز)."},
	{"id": "magnet", "name": "آهنربای فوری", "icon": "magnet", "color": "ff4a4a", "price": 35, "dur": 12.0, "power": 0,
		"desc": "سکه‌های اطراف را فوراً به سمت خودت می‌کشد."},
	{"id": "freeze", "name": "زمان‌منجمد", "icon": "hourglass", "color": "7ad7ff", "price": 50, "dur": 7.0, "power": 5,
		"desc": "سرعت دنیا کم می‌شود تا نفس بکشی و جا عوض کنی."},
	{"id": "life", "name": "بلیت زندگی", "icon": "heart", "color": "ff3b5c", "price": 80, "dur": 0.0, "power": -1,
		"desc": "بعد از باخت، رایگان ادامه می‌دهی (بدون پرداخت سکه). فقط در صفحه‌ی پایان بازی مصرف می‌شود."},
]
const BOOST_MAX := 99
const LOADOUT_SLOTS := 3

# ------------------------- وضعیت -------------------------
var is_active := false
var is_paused := false
var over := false              # بازی تمام شده و هنوز به منو برنگشته‌ایم (برای زنده‌شدن دوباره)

var score := 0
var run_coins := 0
var coins := 0
var high_score := 0
var best_distance := 0
var distance := 0.0
var elapsed := 0.0
var run_speed := 0.0
var target_speed := 0.0
var stumble := 0.0
var intro_active := false
var intro_on := true
const CAM_NAMES: Array[String] = ["پشت‌سر (کلاسیک)", "بالا (دید وسیع)", "نزدیک (هیجانی)", "شانه (کج)"]
var cam_view := 0
const MENU_THEMES: Array[String] = ["غروب طلایی", "نئون شبانه", "جنگل", "اقیانوس"]
var menu_theme := 0
signal menu_theme_changed
# --- پرتال‌ها و جهان‌ها
const PORTAL_FIRST := 450.0
const PORTAL_GAP_MIN := 650.0
const PORTAL_GAP_MAX := 1000.0
const MODE_BONUS := 400
var portals_on := true
var portal_skin := -1          # -1 = هر بار تصادفی، وگرنه شماره‌ی ظاهر ثابت
var portal_dest := ""          # "" = مقصد تصادفی، وگرنه شناسه‌ی جهان/بازی ثابت
var portal_trig := 0           # 0 فاصله، 1 امتیاز، 2 سکه، 3 شانسی
var portal_level := 2          # شماره‌ی پیش‌تنظیم داخل PORTAL_PRESETS
var portal_len := 1.0          # ضریب طول جهان‌های دویدنی
var next_portal_score := 0
var next_portal_coins := 0
const PORTAL_PRESETS := [[300, 500, 800, 1200, 2000], [2000, 5000, 10000, 20000, 40000], [15, 30, 60, 100, 200], [1, 2, 4, 8, 15]]
const PORTAL_TRIG_NAMES: Array[String] = ["فاصله", "امتیاز", "سکه", "شانسی"]
const PORTAL_LENS: Array[float] = [0.5, 0.75, 1.0, 1.5, 2.0]

# --- شرط بازگشت از جهان به بازی اصلی
var ret_mode := 0              # 0 مسافت، 1 زمان، 2 سکه، 3 امتیاز، 4 هر وقت خودم خواستم
var ret_level := 2
var mode_t := 0.0              # ثانیه‌های گذشته در جهان فعلی
var mode_coins0 := 0
var mode_score0 := 0
var ret_not_before := 0.0      # بعد از رد کردن دروازه‌ی بازگشت، تا این مسافت دوباره نمی‌سازد
const RET_NAMES: Array[String] = ["مسافت", "زمان", "سکه", "امتیاز", "هر وقت خودم خواستم"]
const RET_PRESETS := [[], [20, 30, 45, 60, 90], [5, 10, 20, 40, 80], [300, 600, 1200, 2500, 5000], [150, 150, 150, 150, 150]]


func ret_amount() -> int:
	var arr: Array = RET_PRESETS[ret_mode]
	if arr.is_empty():
		return 0
	return int(arr[clampi(ret_level, 0, arr.size() - 1)])


func ret_text() -> String:
	match ret_mode:
		0: return "بعد از طی مسافت جهان (طول بالا)"
		1: return "بعد از %d ثانیه" % ret_amount()
		2: return "بعد از جمع‌کردن %d سکه" % ret_amount()
		3: return "بعد از گرفتن %d امتیاز" % ret_amount()
	return "دروازه‌ی بازگشت هر ۲۰۰ متر می‌آید؛ خودت تصمیم می‌گیری"


## پیشرفت به‌سوی شرط بازگشت (۰ تا ۱)
func ret_progress() -> float:
	match ret_mode:
		0: return clampf((distance - mode_start) / maxf(mode_end - mode_start, 1.0), 0.0, 1.0)
		1: return clampf(mode_t / float(maxi(ret_amount(), 1)), 0.0, 1.0)
		2: return clampf(float(run_coins - mode_coins0) / float(maxi(ret_amount(), 1)), 0.0, 1.0)
		3: return clampf(float(score - mode_score0) / float(maxi(ret_amount(), 1)), 0.0, 1.0)
	return clampf((distance - mode_start) / 150.0, 0.0, 1.0)


## متن کوتاه «چقدر مانده» برای نوار جهان
func ret_left_text() -> String:
	match ret_mode:
		0: return "%dm" % int(maxf(mode_end - distance, 0.0))
		1: return "%d ث" % int(ceilf(maxf(float(ret_amount()) - mode_t, 0.0)))
		2: return "%d سکه" % maxi(ret_amount() - (run_coins - mode_coins0), 0)
		3: return "%d امتیاز" % maxi(ret_amount() - (score - mode_score0), 0)
	return "دروازه‌ی بازگشت"


## آیا الان باید دروازه‌ی بازگشت جلوی بازیکن ساخته شود؟ (spawn_ahead = فاصله‌ی ساخت)
func ret_due(spawn_ahead: float) -> bool:
	if mode == "" or exit_spawned or distance < ret_not_before:
		return false
	match ret_mode:
		0: return distance + spawn_ahead >= mode_end
		1: return mode_t >= float(ret_amount()) - 5.0
		2: return run_coins - mode_coins0 >= ret_amount()
		3: return score - mode_score0 >= ret_amount()
	return distance - mode_start >= 150.0


## بازیکن دروازه‌ی بازگشت را رد کرد (انتخاب خودش): بعد از مدتی دوباره می‌آید
func exit_missed() -> void:
	exit_spawned = false
	ret_not_before = distance + 200.0
	popup.emit("دروازه‌ی بازگشت را رد کردی؛ هنوز در جهان هستی", false)


func cycle_ret_mode() -> void:
	ret_mode = (ret_mode + 1) % RET_NAMES.size()
	ret_level = 2
	save_game()


func cycle_ret_level() -> void:
	var arr: Array = RET_PRESETS[ret_mode]
	if arr.is_empty():
		return
	ret_level = (ret_level + 1) % arr.size()
	save_game()


func portal_every() -> int:
	var arr: Array = PORTAL_PRESETS[portal_trig]
	return int(arr[clampi(portal_level, 0, arr.size() - 1)])


func portal_every_text() -> String:
	var v := portal_every()
	match portal_trig:
		0: return "هر حدود %d متر" % v
		1: return "هر %d امتیاز" % v
		2: return "هر %d سکه" % v
	return "شانس %d٪ در هر ردیف (بعد از ۲۰۰ متر فاصله)" % v


## زمان‌بندی پرتال بعدی بر اساس نوع محرک (فاصله/امتیاز/سکه/شانسی)
func schedule_portal(first: bool = false) -> void:
	var ev := float(portal_every())
	match portal_trig:
		0:
			next_portal_at = distance + (PORTAL_FIRST if first else ev * randf_range(0.8, 1.25))
		1:
			next_portal_at = distance + (PORTAL_FIRST if first else 200.0)
			next_portal_score = score + int(ev * (0.5 if first else 1.0))
		2:
			next_portal_at = distance + (PORTAL_FIRST if first else 200.0)
			next_portal_coins = run_coins + int(ev * (0.5 if first else 1.0))
		_:
			next_portal_at = distance + (PORTAL_FIRST * 0.5 if first else 200.0)


## آیا شرط ظاهر شدن پرتال برقرار است؟ (شرط فاصله‌ی حداقلی را خود مسیر چک می‌کند)
func portal_due() -> bool:
	match portal_trig:
		1: return score >= next_portal_score
		2: return run_coins >= next_portal_coins
		3: return randf() * 100.0 < float(portal_every())
	return true


func pick_portal_skin(rng: RandomNumberGenerator) -> int:
	var ok: Array[int] = []
	for i in PortalSkins.NAMES.size():
		if Content.feature("portal_skin_%d" % i):
			ok.append(i)
	if ok.is_empty():
		return 0
	if portal_skin >= 0 and ok.has(portal_skin):
		return portal_skin
	return ok[rng.randi() % ok.size()]


func cycle_portal_skin() -> void:
	portal_skin += 1
	if portal_skin >= PortalSkins.NAMES.size():
		portal_skin = -1
	save_game()


func cycle_portal_dest() -> void:
	var ids := Modes.IDS
	var i := ids.find(portal_dest) if portal_dest != "" else -1
	i += 1
	portal_dest = "" if i >= ids.size() else ids[i]
	save_game()


func cycle_portal_trig() -> void:
	portal_trig = (portal_trig + 1) % PORTAL_PRESETS.size()
	portal_level = 2
	schedule_portal(true)
	save_game()


func cycle_portal_level() -> void:
	portal_level = (portal_level + 1) % (PORTAL_PRESETS[portal_trig] as Array).size()
	schedule_portal(true)
	save_game()


func cycle_portal_len() -> void:
	var i := PORTAL_LENS.find(portal_len)
	portal_len = PORTAL_LENS[(i + 1) % PORTAL_LENS.size()]
	save_game()
var mode_off := {}            # id → true اگر بازیکن آن جهان را خاموش کرده
var steer_sens := 1.0
var mode := ""
var mode_start := 0.0
var mode_end := 0.0
var next_portal_at := PORTAL_FIRST
var exit_spawned := false
var rings := 0
var mini := ""
var look_style := 0
var npcs_on := true
## 0 = بازی عادی؛ غیر از آن: کد اتاقِ رقابتی (مسیر مشترک با همان seed)
var challenge_room := 0
## صدای هر کاراکتر: شناسه‌ی کاراکتر -> شماره‌ی پروفایل صدا (مدیر می‌تواند عوض کند)
var voice_map := {}
var heat_left := 0.0   # بعد از لیز خوردن، پلیس تا چند ثانیه پشت سرت می‌ماند
var HEAT_TIME := 4.0
var jet_grace := 0.0
var zone := 0
var used_revive := false

var power_left: Array[float] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
var power_total: Array[float] = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
var levels: Array[int] = [0, 0, 0, 0, 0, 0]
## موجودی ابزارها (سرور مرجع است): شناسه → تعداد
var boosts := {}
## ابزارهای همراه (حداکثر ۳)؛ حین بازی دکمه‌شان دیده می‌شود. auto_start: در شروع بازی خودکار مصرف شود
var loadout: Array = []
var auto_start := {}
var boost_cfg := {}           # تنظیم مالک: شناسه → {price, dur, on}
var run_used := {}            # مصرف همین دور (برای گزارش به سرور)
var ghost_left := 0.0
var ghost_total := 1.0
var near_streak := 0
# --- کمبوی سکه: سکه‌ها را پشت‌سرهم و سریع بردار تا ضریب امتیاز بالا برود
const COMBO_WINDOW := 1.6
const COMBO_STEP := 8          # هر ۸ سکه‌ی زنجیره‌ای یک پله
const COMBO_MAX := 5
var combo_chain := 0
var combo_time := 0.0
var combo_mult := 1
var run_bonus := 0
var best_combo := 0
# --- پاداش روزانه‌ی ورود
const DAILY_REWARDS: Array[int] = [10, 15, 20, 30, 40, 60, 100]
var streak := 0
var last_daily := -1
var run_near := 0
var run_powers := 0
var missions: Array = []   # هر مورد: {t: نوع، goal، prog، reward}

var sound_on := true
## صدای هر بخش (نسخه‌ی مدیر می‌تواند جدا تنظیم کند): کل، کاراکتر، پلیس، دنیا، رابط، موسیقی، محیط
var vol := {"master": 1.0, "player": 1.0, "police": 1.0, "world": 1.0, "ui": 1.0, "music": 0.55, "ambient": 0.7}
var vibration_on := true

var _last_distance := 0
var _last_summary := {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_tuning_defaults = tuning_dict()
	_load_save()
	_ensure_missions()
	_daily_check.call_deferred()


func _process(delta: float) -> void:
	if not is_active or is_paused:
		return
	elapsed += delta
	if mode != "":
		mode_t += delta
	target_speed = minf(MAX_SPEED, START_SPEED + elapsed * SPEED_PER_SECOND)
	var tgt := target_speed * (STUMBLE_SLOW if stumble > 0.0 else 1.0) * (SLOW_MULT if power_left[Power.SLOW] > 0.0 else 1.0) * mode_speed()
	run_speed = move_toward(run_speed, tgt, SPEED_ACCEL * delta)
	distance += run_speed * delta
	var d := int(distance)
	if d != _last_distance:
		_last_distance = d
		distance_changed.emit(d)
		_update_score()
		var z := zone_at(distance)
		if z != zone:
			zone = z
			zone_changed.emit(zone)
			toast.emit("ورود به: " + ZONE_NAMES[zone])

	if combo_time > 0.0:
		combo_time = maxf(0.0, combo_time - delta)
		if combo_time <= 0.0:
			reset_combo()
	if heat_left > 0.0 and stumble <= 0.0:
		heat_left = maxf(0.0, heat_left - delta)
	if stumble > 0.0:
		stumble = maxf(0.0, stumble - delta)
		if stumble <= 0.0:
			stumble_changed.emit(false)
	if jet_grace > 0.0:
		jet_grace = maxf(0.0, jet_grace - delta)
	if ghost_left > 0.0:
		ghost_left = maxf(0.0, ghost_left - delta)
		if ghost_left <= 0.0:
			jet_grace = maxf(jet_grace, 0.8)
	for i in power_left.size():
		if power_left[i] > 0.0:
			power_left[i] = maxf(0.0, power_left[i] - delta)
			if power_left[i] <= 0.0:
				if i == Power.JET:
					jet_grace = JET_GRACE
				power_ended.emit(i)


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_WINDOW_FOCUS_OUT:
			save_game()
			if is_active and not is_paused:
				pause_game()
		NOTIFICATION_WM_CLOSE_REQUEST:
			save_game()


# ------------------------- محیط و سختی -------------------------
## محیط در فاصله‌ی داده‌شده (متر). برای ساخت دنیا و موانع جلوتر از بازیکن هم استفاده می‌شود
func zone_at(dist: float) -> int:
	var z := int(maxf(dist, 0.0) / ZONE_LENGTH) % ZONE_COUNT
	for k in ZONE_COUNT:
		var c := (z + k) % ZONE_COUNT
		if Content.feature("zone_%d" % c):
			return c
	return z


func difficulty() -> float:
	if not is_active and not over:
		return 0.3
	return clampf(elapsed / 240.0, 0.0, 1.0)


# ------------------------- شروع بازی -------------------------
func voice_of(char_id: String) -> int:
	if voice_map.has(char_id):
		return int(voice_map[char_id]) % Sfx.VOICES.size()
	return absi(char_id.hash()) % Sfx.VOICES.size()


func set_voice(char_id: String, v: int) -> void:
	voice_map[char_id] = posmod(v, Sfx.VOICES.size())
	save_game()


func play_normal() -> void:
	challenge_room = 0
	challenge_mod = {}
	play()


## room = کد رقابت؛ mod = «قانون» این رقابت {id, name, mult:{متغیر: ضریب}} (خالی = بدون قانون)
func start_challenge(room: int, mod: Dictionary = {}) -> void:
	challenge_room = room
	challenge_mod = mod
	play()


var challenge_mod: Dictionary = {}
var _mod_saved: Dictionary = {}


## ضریب‌های قانون رقابت را روی تنظیمات اعمال می‌کند (با همان محدوده‌ی امن تنظیمات از راه دور)
func _apply_challenge_mod() -> void:
	_clear_challenge_mod()
	if challenge_room <= 0 or challenge_mod.is_empty():
		return
	var mult: Dictionary = challenge_mod.get("mult", {})
	for k in mult.keys():
		var key := String(k)
		if not REMOTE_LIMITS.has(key) or key in ["REVIVE_PRICE", "UPGRADE_BASE_PRICE"]:
			continue
		var lim: Array = REMOTE_LIMITS[key]
		var cur = get(key)
		_mod_saved[key] = cur
		var v := clampf(float(cur) * float(mult[k]), float(lim[0]), float(lim[1]))
		set(key, int(round(v)) if cur is int else v)
	if MAX_SPEED < START_SPEED:
		MAX_SPEED = START_SPEED


func _clear_challenge_mod() -> void:
	for k in _mod_saved.keys():
		set(String(k), _mod_saved[k])
	_mod_saved = {}


## دکمه‌ی «شروع بازی»: اول اینترو (اگر روشن باشد) و بعد دویدن
func play() -> void:
	if intro_on and not intro_active:
		intro_active = true
		intro_started.emit()
	else:
		start_run()


func start_run() -> void:
	reset_mode()
	_apply_challenge_mod()
	intro_active = false
	is_active = true
	is_paused = false
	over = false
	used_revive = false
	score = 0
	run_coins = 0
	elapsed = 0.0
	distance = 0.0
	stumble = 0.0
	heat_left = 0.0
	jet_grace = 0.0
	near_streak = 0
	run_near = 0
	run_bonus = 0
	best_combo = 0
	combo_chain = 0
	combo_time = 0.0
	combo_mult = 1
	run_powers = 0
	zone = 0
	_last_distance = 0
	run_speed = START_SPEED
	target_speed = START_SPEED
	ghost_left = 0.0
	run_used = {}
	for i in power_left.size():
		power_left[i] = 0.0
	score_changed.emit(0)
	run_coins_changed.emit(0)
	distance_changed.emit(0)
	game_started.emit()
	for id in loadout:
		if bool(auto_start.get(String(id), false)) and String(id) != "life":
			use_boost(String(id))


func _update_score() -> void:
	var s := int(distance) + run_coins * COIN_SCORE + run_near * NEAR_BONUS + run_bonus
	if s != score:
		score = s
		score_changed.emit(score)


# ------------------------- سکه و قدرت‌ها -------------------------
func coin_value() -> int:
	return 2 if power_left[Power.DOUBLE] > 0.0 else 1


func register_coin() -> void:
	if not is_active:
		return
	var v := coin_value()
	run_coins += v
	coins += v
	run_coins_changed.emit(run_coins)
	coins_changed.emit(coins)
	coin_collected.emit(v)
	_mission_add("coins", v)
	_combo_hit(v)
	_update_score()


func _combo_hit(v: int) -> void:
	if not Content.feature("combo"):
		return
	if mode == "ring":
		rings += 1
	combo_chain = combo_chain + 1 if combo_time > 0.0 else 1
	combo_time = COMBO_WINDOW
	best_combo = maxi(best_combo, combo_chain)
	var m := clampi(1 + combo_chain / COMBO_STEP, 1, COMBO_MAX)
	run_bonus += COIN_SCORE * v * (m - 1)
	if m != combo_mult:
		combo_mult = m
		if m > 1:
			popup.emit("کمبو x%d" % m, true)
	combo_changed.emit(combo_mult, combo_chain)


func reset_combo() -> void:
	if combo_chain == 0 and combo_mult == 1:
		return
	combo_chain = 0
	combo_time = 0.0
	combo_mult = 1
	combo_changed.emit(1, 0)


## پاداش روزانه: روز تازه → ادامه‌ی سری (یا شروع دوباره اگر یک روز رد شده باشد)
func _today() -> int:
	return int((Time.get_unix_time_from_system() + float(Time.get_time_zone_from_system().bias) * 60.0) / 86400.0)


func daily_due() -> bool:
	return Content.feature("daily") and last_daily != _today()


func daily_reward_for(day_index: int) -> int:
	return DAILY_REWARDS[clampi(day_index, 0, DAILY_REWARDS.size() - 1)]


func mode_def() -> Dictionary:
	return Modes.def(mode)


func mode_speed() -> float:
	return float(mode_def().get("speed", 1.0)) if mode != "" else 1.0


func free_steer() -> bool:
	return mode != "" and String(mode_def().get("steer", "lane")) == "free"


func start_mini(id: String) -> void:
	if mini != "" or not Modes.is_mini(id):
		return
	mini = id
	is_paused = true            # بی‌صدا؛ دنیای اصلی تا برگشت متوقف است
	schedule_portal()
	mini_started.emit(id)


func finish_mini(res: Dictionary) -> void:
	var id := mini
	if id == "":
		return
	mini = ""
	is_paused = false
	var n := clampi(int(res.get("coins", 0)), 0, 120)
	run_coins += n
	_mission_add("coins", n)
	run_bonus += n * COIN_SCORE + int(res.get("bonus", 0)) + MODE_BONUS
	popup.emit("برگشتی! +%d سکه" % n, true)
	coin_collected.emit(n)
	_update_score()
	mini_finished.emit(id)


func enter_mode(id: String) -> void:
	if Modes.is_mini(id):
		start_mini(id)
		return
	if mode != "" or not Modes.is_run(id):
		return
	mode = id
	mode_start = distance
	mode_end = distance + float(Modes.def(id).get("len", 400.0)) * portal_len
	exit_spawned = false
	mode_t = 0.0
	mode_coins0 = run_coins
	mode_score0 = score
	ret_not_before = 0.0
	rings = 0
	popup.emit("پرتال: " + String(Modes.def(id).get("name", "")), true)
	mode_changed.emit(id)


func exit_mode(bonus: bool = true) -> void:
	if mode == "":
		return
	mode = ""
	rings = 0
	exit_spawned = false
	schedule_portal()
	if bonus:
		run_bonus += MODE_BONUS
		popup.emit("برگشتی! +%d امتیاز" % MODE_BONUS, true)
		_update_score()
	mode_changed.emit("")


func reset_mode() -> void:
	var had := mode != ""
	mini = ""
	mode = ""
	rings = 0
	exit_spawned = false
	schedule_portal(true)
	if had:
		mode_changed.emit("")


func toggle_portals() -> void:
	portals_on = not portals_on
	save_game()


func toggle_mode_enabled(id: String) -> void:
	if mode_off.get(id, false):
		mode_off.erase(id)
	else:
		mode_off[id] = true
	save_game()


func cycle_steer_sens() -> void:
	steer_sens = 1.5 if steer_sens < 0.9 else (2.0 if steer_sens < 1.4 else 0.7)
	save_game()


func cycle_menu_theme() -> void:
	menu_theme = (menu_theme + 1) % MENU_THEMES.size()
	save_game()
	menu_theme_changed.emit()


func cycle_cam_view() -> void:
	for _i in CAM_NAMES.size():
		cam_view = (cam_view + 1) % CAM_NAMES.size()
		if Content.feature("cam_%d" % cam_view):
			break
	save_game()


func cycle_look() -> void:
	for _i in LookFx.NAMES.size():
		look_style = (look_style + 1) % LookFx.NAMES.size()
		if Content.feature("look_%d" % look_style):
			break
	save_game()
	look_changed.emit()


func claim_daily() -> int:
	if not daily_due():
		return 0
	var t := _today()
	streak = streak + 1 if last_daily == t - 1 else 1
	last_daily = t
	var rw := daily_reward_for((streak - 1) % DAILY_REWARDS.size())
	coins += rw
	coins_changed.emit(coins)
	Online.mission_reward(rw)
	save_game()
	return rw


func _daily_check() -> void:
	await get_tree().create_timer(2.0).timeout
	var rw := claim_daily()
	if rw > 0:
		toast.emit("پاداش ورود روز %d: +%d سکه" % [streak, rw])


func register_power(id: int, custom_dur: float = -1.0, label: String = "") -> void:
	if not is_active:
		return
	var dur := custom_dur if custom_dur > 0.0 else power_duration(id)
	power_left[id] = dur
	power_total[id] = dur
	power_collected.emit(id)
	run_powers += 1
	_mission_add("powers", 1)
	popup.emit(label if label != "" else POWER_NAMES[id], true)


## ردشدن خیلی نزدیک از کنار مانع؛ پشت‌سرهم بودنش پاداش را بیشتر می‌کند
func register_near_miss() -> void:
	if not is_active:
		return
	near_streak += 1
	run_near += 1
	Sfx.play("near", -4.0)
	Rules.fire("near_miss")
	popup.emit("عالی! ×%d" % near_streak if near_streak > 1 else "کم مونده بود!", true)
	_mission_add("near", 1)
	_update_score()


# ------------------------- ماموریت‌ها -------------------------
const MISSION_TEMPLATES := [
	{"t": "coins", "txt": "جمع‌کردن %d سکه", "goals": [60, 120, 250], "rw": [20, 40, 80], "total": true},
	{"t": "powers", "txt": "برداشتن %d قدرت", "goals": [3, 6, 10], "rw": [20, 40, 70], "total": true},
	{"t": "near", "txt": "%d بار ردشدن از نزدیک مانع", "goals": [5, 10, 20], "rw": [25, 45, 80], "total": true},
	{"t": "dist", "txt": "رسیدن به %d متر در یک بازی", "goals": [500, 1000, 2000], "rw": [25, 50, 100], "total": false},
	{"t": "score", "txt": "کسب %d امتیاز در یک بازی", "goals": [1500, 3000, 6000], "rw": [25, 50, 100], "total": false},
]


func _new_mission(avoid: Array) -> Dictionary:
	for _try in 20:
		var tpl: Dictionary = MISSION_TEMPLATES[randi() % MISSION_TEMPLATES.size()]
		if avoid.has(tpl.t):
			continue
		var k := clampi(randi() % 3, 0, 2)
		return {"t": tpl.t, "goal": tpl.goals[k], "prog": 0, "reward": tpl.rw[k]}
	var f: Dictionary = MISSION_TEMPLATES[0]
	return {"t": f.t, "goal": f.goals[0], "prog": 0, "reward": f.rw[0]}


func _ensure_missions() -> void:
	var changed := false
	while missions.size() < 3:
		var used: Array = []
		for m: Dictionary in missions:
			used.append(m.t)
		missions.append(_new_mission(used))
		changed = true
	if changed:
		save_game()


func mission_text(m: Dictionary) -> String:
	for tpl: Dictionary in MISSION_TEMPLATES:
		if tpl.t == m.t:
			return tpl.txt % int(m.goal)
	return ""


func _mission_add(kind: String, amount: int) -> void:
	_mission_set(kind, amount, true)


func _mission_set(kind: String, value: int, add: bool) -> void:
	var done: Array = []
	for i in missions.size():
		var m: Dictionary = missions[i]
		if m.t != kind:
			continue
		m.prog = (int(m.prog) + value) if add else maxi(int(m.prog), value)
		if int(m.prog) >= int(m.goal):
			done.append(i)
	for i in done:
		var m: Dictionary = missions[i]
		coins += int(m.reward)
		coins_changed.emit(coins)
		Online.mission_reward(int(m.reward))
		var txt := mission_text(m)
		var rw := int(m.reward)
		var used: Array = []
		for o: Dictionary in missions:
			used.append(o.t)
		missions[i] = _new_mission(used)
		mission_completed.emit(txt, rw)
		toast.emit("ماموریت انجام شد! +%d سکه" % rw)
	missions_changed.emit()
	if not done.is_empty():
		Online.queue_save()


func has_power(id: int) -> bool:
	return power_left[id] > 0.0


## شکست‌ناپذیر (جت‌پک یا چند لحظه بعد از آن)
func is_invincible() -> bool:
	return power_left[Power.JET] > 0.0 or jet_grace > 0.0 or ghost_left > 0.0


## برخورد با مانع. نتیجه: "ignored" | "shield" | "stumble" | "caught"
## graze=true: فقط لبه‌ی مانع را خراشیده‌ای (پلیس نزدیک می‌شود، ولی می‌مانی)
## graze=false: برخورد کامل با مانع = دستگیری فوری
func register_obstacle_hit(graze: bool = false) -> String:
	if not is_active:
		return "ignored"
	if is_invincible():
		return "ignored"
	near_streak = 0
	reset_combo()
	if power_left[Power.SHIELD] > 0.0:
		power_left[Power.SHIELD] = 0.0
		power_ended.emit(Power.SHIELD)
		popup.emit("سپر شکست!", false)
		shield_broke.emit()
		player_hit.emit()
		return "shield"
	if mode == "ring" and rings > 0:
		# مثل سونیک: با داشتن حلقه، برخورد نمی‌کُشد؛ حلقه‌ها پخش می‌شوند
		var lost := rings
		rings = 0
		popup.emit("حلقه‌ها پخش شد! (-%d)" % lost, false)
		player_hit.emit()
		return "ring"
	player_hit.emit()
	if stumble > 0.0 or not graze:
		_end_run("caught")
		return "caught"
	stumble = STUMBLE_TIME
	heat_left = STUMBLE_TIME + HEAT_TIME
	run_speed *= STUMBLE_SLOW
	stumble_changed.emit(true)
	popup.emit("خراش خوردی! مراقب باش", false)
	grazed.emit()
	return "stumble"


# ------------------------- ابزارهای مصرفی -------------------------
func boost_def(id: String) -> Dictionary:
	for d: Dictionary in BOOSTS:
		if String(d.id) == id:
			return d
	return {}


func boost_price(id: String) -> int:
	var c = boost_cfg.get(id, {})
	var d := boost_def(id)
	return clampi(int(c.get("price", d.get("price", 50))) if c is Dictionary else int(d.get("price", 50)), 0, 5000)


func boost_dur(id: String) -> float:
	var c = boost_cfg.get(id, {})
	var d := boost_def(id)
	return clampf(float(c.get("dur", d.get("dur", 5.0))) if c is Dictionary else float(d.get("dur", 5.0)), 0.5, 120.0)


## آیا این ابزار در فروشگاه عرضه می‌شود؟ (مالک می‌تواند خاموش کند)
func boost_on(id: String) -> bool:
	var c = boost_cfg.get(id, {})
	return bool(c.get("on", true)) if c is Dictionary else true


func boost_count(id: String) -> int:
	return clampi(int(boosts.get(id, 0)), 0, BOOST_MAX)


func shown_boosts() -> Array:
	var out: Array = []
	for d: Dictionary in BOOSTS:
		if boost_on(String(d.id)) or boost_count(String(d.id)) > 0:
			out.append(d)
	return out


func set_loadout(id: String, on: bool) -> void:
	loadout.erase(id)
	if on and loadout.size() < LOADOUT_SLOTS:
		loadout.append(id)
	save_game()
	boosts_changed.emit()


func in_loadout(id: String) -> bool:
	return id in loadout


func toggle_auto_start(id: String) -> void:
	auto_start[id] = not bool(auto_start.get(id, false))
	save_game()
	boosts_changed.emit()


## وسط یا اول بازی یک ابزار را مصرف می‌کند. برمی‌گرداند: مصرف شد؟
func use_boost(id: String) -> bool:
	if not is_active or is_paused or id == "life":
		return false
	var d := boost_def(id)
	if d.is_empty() or boost_count(id) <= 0:
		return false
	var dur := boost_dur(id)
	if id == "ghost":
		if ghost_left > 0.0:
			return false
		ghost_left = dur
		ghost_total = dur
		popup.emit(String(d.name), true)
	else:
		var pw := int(d.get("power", -1))
		if pw < 0 or power_left[pw] > 0.0:
			return false
		register_power(pw, dur, String(d.name))
	boosts[id] = boost_count(id) - 1
	run_used[id] = int(run_used.get(id, 0)) + 1
	Online.boosts = boosts.duplicate()
	boost_used.emit(id)
	boosts_changed.emit()
	return true


var _buying_boost := false


func buy_boost(id: String, qty: int = 1) -> void:
	var d := boost_def(id)
	if d.is_empty() or not boost_on(id) or _buying_boost:
		return
	_buying_boost = true
	if boost_count(id) + qty > BOOST_MAX:
		toast.emit("بیشتر از %d عدد جا نداری" % BOOST_MAX)
		_buying_boost = false
		return
	var r: Dictionary = await Online.buy_boost(id, qty)
	_buying_boost = false
	if not r.get("ok", false):
		toast.emit(Online.error_text(String(r.get("error", "")), int(r.get("need", 0))))
		Sfx.play("error")
		return
	boosts = Online.boosts.duplicate()
	coins = int(r.coins)
	coins_changed.emit(coins)
	boosts_changed.emit()
	toast.emit("«%s» ×%d خریده شد" % [String(d.name), qty])
	Sfx.play("buy")


## مصرف این دور را به سرور می‌فرستد (سرور فقط کم می‌کند؛ هیچ‌وقت زیاد نمی‌کند)
func flush_boost_use() -> void:
	if run_used.is_empty():
		return
	var u := run_used.duplicate()
	run_used = {}
	Online.report_boosts(u)


# ------------------------- پایان بازی و زنده‌شدن -------------------------
func _end_run(reason: String) -> void:
	if not is_active:
		return
	is_active = false
	over = true
	_update_score()
	var new_record := score > high_score
	if new_record:
		high_score = score
		high_score_changed.emit(high_score)
	var dist := int(distance)
	_mission_set("dist", dist, false)
	_mission_set("score", score, false)
	if dist > best_distance:
		best_distance = dist
	save_game()
	flush_boost_use()
	_last_summary = {
		"reason": reason, "score": score, "distance": dist, "coins": run_coins,
		"new_record": new_record, "high_score": high_score, "can_revive": can_revive(),
	}
	game_over.emit(_last_summary)
	_clear_challenge_mod()


func can_revive() -> bool:
	return over and not used_revive and (coins >= REVIVE_PRICE or has_life_ticket()) and not _reviving


func has_life_ticket() -> bool:
	return boost_count("life") > 0


var _reviving := false


## با بلیت زندگی رایگان؛ وگرنه با سکه
func revive(with_ticket: bool = false) -> void:
	if not over or used_revive or _reviving:
		return
	if with_ticket and not has_life_ticket():
		return
	if not with_ticket and coins < REVIVE_PRICE:
		return
	_reviving = true
	if with_ticket:
		var t: Dictionary = await Online.use_boosts_now({"life": 1})
		_reviving = false
		if not t.get("ok", false):
			toast.emit("بلیت مصرف نشد: " + Online.error_text(String(t.get("error", "")), 0))
			Sfx.play("error")
			return
		boosts = Online.boosts.duplicate()
		boosts_changed.emit()
	else:
		var r: Dictionary = await Online.pay_revive()
		_reviving = false
		if not r.get("ok", false):
			toast.emit(Online.error_text(String(r.get("error", "")), int(r.get("need", 0))))
			Sfx.play("error")
			return
		coins = int(r.coins)
		coins_changed.emit(coins)
	used_revive = true
	_apply_challenge_mod()           # ادامه‌ی همان دویدن؛ قانون رقابت دوباره اعمال می‌شود
	over = false
	is_active = true
	is_paused = false
	stumble = 0.0
	heat_left = 0.0
	stumble_changed.emit(false)
	run_speed = START_SPEED
	jet_grace = REVIVE_INVULN
	save_game()
	revived.emit()


# ------------------------- توقف / خروج -------------------------
func pause_game() -> void:
	if not is_active or is_paused:
		return
	is_paused = true
	pause_changed.emit(true)


func resume_game() -> void:
	if not is_paused:
		return
	is_paused = false
	pause_changed.emit(false)


func quit_to_menu() -> void:
	flush_boost_use()
	reset_mode()
	is_active = false
	is_paused = false
	over = false
	pause_changed.emit(false)
	session_ended.emit()


# ------------------------- فروشگاه (ارتقاهای دائمی) -------------------------
func power_duration(id: int) -> float:
	return POWER_BASE[id] + POWER_STEP[id] * float(levels[id])


func upgrade_price(id: int) -> int:
	return UPGRADE_BASE_PRICE * (levels[id] + 1)


func buy_upgrade(id: int) -> void:
	if levels[id] >= MAX_LEVEL:
		toast.emit("به آخرین سطح رسیده‌ای!")
		return
	var r: Dictionary = await Online.buy_upgrade(id)
	if not r.get("ok", false):
		toast.emit(Online.error_text(String(r.get("error", "")), int(r.get("need", 0))))
		Sfx.play("error")
		return
	levels[id] = int(r.level)
	coins = int(r.coins)
	coins_changed.emit(coins)
	toast.emit("%s ارتقا یافت: %d ثانیه" % [POWER_NAMES[id], int(power_duration(id))])
	Sfx.play("buy")


func set_missions_from_server(ms: Array) -> void:
	var out: Array = []
	for m in ms:
		if m is Dictionary and m.has("t") and m.has("goal") and m.has("prog") and m.has("reward"):
			out.append(m)
	if not out.is_empty():
		missions = out
		missions_changed.emit()


# ------------------------- تنظیمات -------------------------
func set_sound(value: bool) -> void:
	sound_on = value
	save_game()



func set_vol(key: String, value: float) -> void:
	vol[key] = clampf(value, 0.0, 1.0)
	save_game()
	Sfx.refresh_loops()


func set_vibration(value: bool) -> void:
	vibration_on = value
	save_game()


# ------------------------- ذخیره‌سازی -------------------------
func _load_save() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	coins = int(cfg.get_value("save", "coins", 0))
	high_score = int(cfg.get_value("save", "high_score", 0))
	best_distance = int(cfg.get_value("save", "best_distance", 0))
	streak = int(cfg.get_value("daily", "streak", 0))
	last_daily = int(cfg.get_value("daily", "last", -1))
	for i in levels.size():
		levels[i] = clampi(int(cfg.get_value("levels", str(i), 0)), 0, MAX_LEVEL)
	var ms = cfg.get_value("missions", "list", [])
	if ms is Array:
		for m in ms:
			if m is Dictionary and m.has("t") and m.has("goal") and m.has("prog") and m.has("reward"):
				missions.append(m)
	sound_on = bool(cfg.get_value("settings", "sound", true))
	vibration_on = bool(cfg.get_value("settings", "vibration", true))
	for k in vol.keys():
		vol[k] = clampf(float(cfg.get_value("volume", k, vol[k])), 0.0, 1.0)
	intro_on = bool(cfg.get_value("settings", "intro", true))
	cam_view = clampi(int(cfg.get_value("settings", "cam_view", 0)), 0, CAM_NAMES.size() - 1)
	portals_on = bool(cfg.get_value("settings", "portals", true))
	portal_skin = clampi(int(cfg.get_value("settings", "portal_skin", -1)), -1, PortalSkins.NAMES.size() - 1)
	portal_dest = String(cfg.get_value("settings", "portal_dest", ""))
	portal_trig = clampi(int(cfg.get_value("settings", "portal_trig", 0)), 0, PORTAL_PRESETS.size() - 1)
	portal_level = clampi(int(cfg.get_value("settings", "portal_level", 2)), 0, 4)
	portal_len = float(cfg.get_value("settings", "portal_len", 1.0))
	ret_mode = clampi(int(cfg.get_value("settings", "ret_mode", 0)), 0, RET_NAMES.size() - 1)
	ret_level = clampi(int(cfg.get_value("settings", "ret_level", 2)), 0, 4)
	menu_theme = clampi(int(cfg.get_value("settings", "menu_theme", 0)), 0, MENU_THEMES.size() - 1)
	steer_sens = clampf(float(cfg.get_value("settings", "steer_sens", 1.0)), 0.5, 2.0)
	mode_off = cfg.get_value("settings", "mode_off", {})
	look_style = clampi(int(cfg.get_value("settings", "look", 0)), 0, LookFx.NAMES.size() - 1)
	npcs_on = bool(cfg.get_value("settings", "npcs", true))
	var vm = cfg.get_value("voices", "map", {})
	voice_map = vm if vm is Dictionary else {}
	var lo = cfg.get_value("boosts", "loadout", [])
	if lo is Array:
		for x in lo:
			if not boost_def(String(x)).is_empty() and loadout.size() < LOADOUT_SLOTS and not String(x) in loadout:
				loadout.append(String(x))
	var au = cfg.get_value("boosts", "auto", {})
	auto_start = au if au is Dictionary else {}


func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("save", "coins", coins)
	cfg.set_value("save", "high_score", high_score)
	cfg.set_value("save", "best_distance", best_distance)
	cfg.set_value("daily", "streak", streak)
	cfg.set_value("daily", "last", last_daily)
	for i in levels.size():
		cfg.set_value("levels", str(i), levels[i])
	cfg.set_value("missions", "list", missions)
	cfg.set_value("settings", "sound", sound_on)
	cfg.set_value("settings", "vibration", vibration_on)
	cfg.set_value("settings", "intro", intro_on)
	cfg.set_value("settings", "cam_view", cam_view)
	cfg.set_value("settings", "portals", portals_on)
	cfg.set_value("settings", "portal_skin", portal_skin)
	cfg.set_value("settings", "portal_dest", portal_dest)
	cfg.set_value("settings", "portal_trig", portal_trig)
	cfg.set_value("settings", "portal_level", portal_level)
	cfg.set_value("settings", "portal_len", portal_len)
	cfg.set_value("settings", "ret_mode", ret_mode)
	cfg.set_value("settings", "ret_level", ret_level)
	cfg.set_value("settings", "menu_theme", menu_theme)
	cfg.set_value("settings", "steer_sens", steer_sens)
	cfg.set_value("settings", "mode_off", mode_off)
	cfg.set_value("settings", "look", look_style)
	cfg.set_value("settings", "npcs", npcs_on)
	cfg.set_value("voices", "map", voice_map)
	cfg.set_value("boosts", "loadout", loadout)
	cfg.set_value("boosts", "auto", auto_start)
	for k in vol.keys():
		cfg.set_value("volume", k, vol[k])
	cfg.save(SAVE_PATH)


# ------------------------- تنظیمات از راه دور (پنل مدیریت) -------------------------
## هر کلید همان نام متغیر است. مقدارها محدود می‌شوند تا تنظیم اشتباه بازی را خراب نکند.
const REMOTE_LIMITS := {
	"START_SPEED": [6.0, 30.0], "MAX_SPEED": [10.0, 45.0], "SPEED_PER_SECOND": [0.0, 0.5],
	"COIN_SCORE": [0, 100], "ZONE_LENGTH": [100.0, 3000.0], "STUMBLE_TIME": [1.0, 15.0],
	"STUMBLE_SLOW": [0.3, 1.0], "JET_GRACE": [0.0, 5.0], "SLOW_MULT": [0.3, 1.0],
	"NEAR_BONUS": [0, 200], "REVIVE_PRICE": [0, 1000], "UPGRADE_BASE_PRICE": [1, 2000],
	"HEAT_TIME": [0.0, 60.0],
}
var remote_config: Dictionary = {}
var _tuning_defaults: Dictionary = {}


func tuning_dict() -> Dictionary:
	var d := {}
	for k: String in REMOTE_LIMITS:
		d[k] = get(k)
	d["POWER_BASE"] = POWER_BASE.duplicate()
	d["POWER_STEP"] = POWER_STEP.duplicate()
	d["BOOSTS"] = boost_cfg.duplicate(true)
	return d


func reset_tuning() -> void:
	if not _tuning_defaults.is_empty():
		apply_remote_config(_tuning_defaults.duplicate(true))


func apply_remote_config(d: Dictionary) -> void:
	remote_config = d
	for k: String in REMOTE_LIMITS:
		if not d.has(k):
			continue
		var lim: Array = REMOTE_LIMITS[k]
		var cur = get(k)
		var v := float(d[k])
		v = clampf(v, float(lim[0]), float(lim[1]))
		set(k, int(v) if cur is int else v)
	if d.has("BOOSTS") and d["BOOSTS"] is Dictionary:
		var bc := {}
		for k in (d["BOOSTS"] as Dictionary).keys():
			var v = d["BOOSTS"][k]
			if v is Dictionary and not boost_def(String(k)).is_empty():
				bc[String(k)] = {"price": clampi(int(v.get("price", boost_def(String(k)).price)), 0, 5000),
					"dur": clampf(float(v.get("dur", boost_def(String(k)).dur)), 0.5, 120.0), "on": bool(v.get("on", true))}
		boost_cfg = bc
		boosts_changed.emit()
	for k in ["POWER_BASE", "POWER_STEP"]:
		if d.has(k) and d[k] is Array and (d[k] as Array).size() == 6:
			var arr: Array[float] = []
			for x in d[k]:
				arr.append(clampf(float(x), 0.5, 120.0))
			set(k, arr)
	if MAX_SPEED < START_SPEED:
		MAX_SPEED = START_SPEED
