extends Node
## هسته‌ی بازی (Autoload با نام «Game»): دونده‌ی بی‌پایان به سبک Subway Surfers / Temple Run.
## قوانین:
##  • مسیر تمام نمی‌شود؛ سرعت کم‌کم زیاد می‌شود. امتیاز = متر + سکه‌ها.
##  • برخورد اول با مانع = «لیز خوردن» (۵ ثانیه فرصت). برخورد دوم در این فرصت = گرفتنت!
##  • سپر یک برخورد را می‌گیرد؛ جت‌پک شکست‌ناپذیر است.
##  • هر ۴۵۰ متر محیط عوض می‌شود: شهر غروب ← صحرا ← جنگل و معبد.
##  • قدرت‌ها روی مسیر پیدا می‌شوند و در فروشگاه ارتقا می‌خورند.

signal score_changed(value: int)
signal run_coins_changed(value: int)
signal coins_changed(value: int)
signal high_score_changed(value: int)
signal distance_changed(value: int)
signal game_started
signal intro_started
signal game_over(summary: Dictionary)
signal session_ended
signal pause_changed(paused: bool)
signal player_hit
signal stumble_changed(active: bool)
signal grazed
signal shield_broke
signal coin_collected(value: int)
signal power_collected(id: int)
signal power_ended(id: int)
signal zone_changed(zone: int)
signal revived
signal popup(text: String, good: bool)
signal toast(text: String)
signal mission_completed(text: String, reward: int)
signal missions_changed

enum Power { MAGNET, SHIELD, DOUBLE, JET, SPRING, SLOW }

# ------------------------- ثابت‌های قابل تنظیم -------------------------
const LANE_WIDTH := 2.4
const SAVE_PATH := "user://save.cfg"
const SPEED_ACCEL := 6.0
var START_SPEED := 11.0
var MAX_SPEED := 25.0
var SPEED_PER_SECOND := 0.07
var COIN_SCORE := 5
var ZONE_LENGTH := 450.0
const ZONE_COUNT := 6
const ZONE_NAMES: Array[String] = ["شهر در غروب", "صحرای طلایی", "جنگل و معبد", "کوهستان برفی", "بندر شبانه", "آتشفشان"]
var STUMBLE_TIME := 3.5
var STUMBLE_SLOW := 0.72
var JET_GRACE := 1.6
var SLOW_MULT := 0.7
var NEAR_BONUS := 15
var REVIVE_PRICE := 30
const REVIVE_INVULN := 3.0

const POWER_NAMES: Array[String] = ["آهنربا", "سپر", "سکه ×۲", "جت‌پک", "کفش فنری", "حرکت آهسته"]
const POWER_ICONS: Array[String] = ["M", "S", "×2", "J", "↑", "◔"]
var POWER_BASE: Array[float] = [8.0, 10.0, 10.0, 6.0, 10.0, 8.0]
var POWER_STEP: Array[float] = [2.0, 2.0, 2.5, 1.0, 2.5, 2.0]
const MAX_LEVEL := 5
var UPGRADE_BASE_PRICE := 40

# ------------------------- وضعیت -------------------------
var is_active := false
var is_paused := false
var over := false              # بازی تمام شده و هنوز به منو برنگشته‌ایم (برای زنده‌شدن دوباره)

var score := 0
var run_coins := 0
var coins := 0
var high_score := 0
var best_distance := 0
var distance := 0.0
var elapsed := 0.0
var run_speed := 0.0
var target_speed := 0.0
var stumble := 0.0
var intro_active := false
var intro_on := true
## 0 = بازی عادی؛ غیر از آن: کد اتاقِ رقابتی (مسیر مشترک با همان seed)
var challenge_room := 0
## صدای هر کاراکتر: شناسه‌ی کاراکتر -> شماره‌ی پروفایل صدا (مدیر می‌تواند عوض کند)
var voice_map := {}
var heat_left := 0.0   # بعد از لیز خوردن، پلیس تا چند ثانیه پشت سرت می‌ماند
var HEAT_TIME := 4.0
var jet_grace := 0.0
var zone := 0
var used_revive := false

var power_left: Array[float] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
var power_total: Array[float] = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
var levels: Array[int] = [0, 0, 0, 0, 0, 0]
var near_streak := 0
var run_near := 0
var run_powers := 0
var missions: Array = []   # هر مورد: {t: نوع، goal، prog، reward}

var sound_on := true
## صدای هر بخش (نسخه‌ی مدیر می‌تواند جدا تنظیم کند): کل، کاراکتر، پلیس، دنیا، رابط، موسیقی، محیط
var vol := {"master": 1.0, "player": 1.0, "police": 1.0, "world": 1.0, "ui": 1.0, "music": 0.55, "ambient": 0.7}
var vibration_on := true

var _last_distance := 0
var _last_summary := {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_tuning_defaults = tuning_dict()
	_load_save()
	_ensure_missions()


func _process(delta: float) -> void:
	if not is_active or is_paused:
		return
	elapsed += delta
	target_speed = minf(MAX_SPEED, START_SPEED + elapsed * SPEED_PER_SECOND)
	var tgt := target_speed * (STUMBLE_SLOW if stumble > 0.0 else 1.0) * (SLOW_MULT if power_left[Power.SLOW] > 0.0 else 1.0)
	run_speed = move_toward(run_speed, tgt, SPEED_ACCEL * delta)
	distance += run_speed * delta
	var d := int(distance)
	if d != _last_distance:
		_last_distance = d
		distance_changed.emit(d)
		_update_score()
		var z := zone_at(distance)
		if z != zone:
			zone = z
			zone_changed.emit(zone)
			toast.emit("ورود به: " + ZONE_NAMES[zone])

	if heat_left > 0.0 and stumble <= 0.0:
		heat_left = maxf(0.0, heat_left - delta)
	if stumble > 0.0:
		stumble = maxf(0.0, stumble - delta)
		if stumble <= 0.0:
			stumble_changed.emit(false)
	if jet_grace > 0.0:
		jet_grace = maxf(0.0, jet_grace - delta)
	for i in power_left.size():
		if power_left[i] > 0.0:
			power_left[i] = maxf(0.0, power_left[i] - delta)
			if power_left[i] <= 0.0:
				if i == Power.JET:
					jet_grace = JET_GRACE
				power_ended.emit(i)


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_WINDOW_FOCUS_OUT:
			save_game()
			if is_active and not is_paused:
				pause_game()
		NOTIFICATION_WM_CLOSE_REQUEST:
			save_game()


# ------------------------- محیط و سختی -------------------------
## محیط در فاصله‌ی داده‌شده (متر). برای ساخت دنیا و موانع جلوتر از بازیکن هم استفاده می‌شود
func zone_at(dist: float) -> int:
	return int(maxf(dist, 0.0) / ZONE_LENGTH) % ZONE_COUNT


func difficulty() -> float:
	if not is_active and not over:
		return 0.3
	return clampf(elapsed / 240.0, 0.0, 1.0)


# ------------------------- شروع بازی -------------------------
func voice_of(char_id: String) -> int:
	if voice_map.has(char_id):
		return int(voice_map[char_id]) % Sfx.VOICES.size()
	return absi(char_id.hash()) % Sfx.VOICES.size()


func set_voice(char_id: String, v: int) -> void:
	voice_map[char_id] = posmod(v, Sfx.VOICES.size())
	save_game()


func play_normal() -> void:
	challenge_room = 0
	challenge_mod = {}
	play()


## room = کد رقابت؛ mod = «قانون» این رقابت {id, name, mult:{متغیر: ضریب}} (خالی = بدون قانون)
func start_challenge(room: int, mod: Dictionary = {}) -> void:
	challenge_room = room
	challenge_mod = mod
	play()


var challenge_mod: Dictionary = {}
var _mod_saved: Dictionary = {}


## ضریب‌های قانون رقابت را روی تنظیمات اعمال می‌کند (با همان محدوده‌ی امن تنظیمات از راه دور)
func _apply_challenge_mod() -> void:
	_clear_challenge_mod()
	if challenge_room <= 0 or challenge_mod.is_empty():
		return
	var mult: Dictionary = challenge_mod.get("mult", {})
	for k in mult.keys():
		var key := String(k)
		if not REMOTE_LIMITS.has(key) or key in ["REVIVE_PRICE", "UPGRADE_BASE_PRICE"]:
			continue
		var lim: Array = REMOTE_LIMITS[key]
		var cur = get(key)
		_mod_saved[key] = cur
		var v := clampf(float(cur) * float(mult[k]), float(lim[0]), float(lim[1]))
		set(key, int(round(v)) if cur is int else v)
	if MAX_SPEED < START_SPEED:
		MAX_SPEED = START_SPEED


func _clear_challenge_mod() -> void:
	for k in _mod_saved.keys():
		set(String(k), _mod_saved[k])
	_mod_saved = {}


## دکمه‌ی «شروع بازی»: اول اینترو (اگر روشن باشد) و بعد دویدن
func play() -> void:
	if intro_on and not intro_active:
		intro_active = true
		intro_started.emit()
	else:
		start_run()


func start_run() -> void:
	_apply_challenge_mod()
	intro_active = false
	is_active = true
	is_paused = false
	over = false
	used_revive = false
	score = 0
	run_coins = 0
	elapsed = 0.0
	distance = 0.0
	stumble = 0.0
	heat_left = 0.0
	jet_grace = 0.0
	near_streak = 0
	run_near = 0
	run_powers = 0
	zone = 0
	_last_distance = 0
	run_speed = START_SPEED
	target_speed = START_SPEED
	for i in power_left.size():
		power_left[i] = 0.0
	score_changed.emit(0)
	run_coins_changed.emit(0)
	distance_changed.emit(0)
	game_started.emit()


func _update_score() -> void:
	var s := int(distance) + run_coins * COIN_SCORE + run_near * NEAR_BONUS
	if s != score:
		score = s
		score_changed.emit(score)


# ------------------------- سکه و قدرت‌ها -------------------------
func coin_value() -> int:
	return 2 if power_left[Power.DOUBLE] > 0.0 else 1


func register_coin() -> void:
	if not is_active:
		return
	var v := coin_value()
	run_coins += v
	coins += v
	run_coins_changed.emit(run_coins)
	coins_changed.emit(coins)
	coin_collected.emit(v)
	_mission_add("coins", v)
	_update_score()


func register_power(id: int) -> void:
	if not is_active:
		return
	var dur := power_duration(id)
	power_left[id] = dur
	power_total[id] = dur
	power_collected.emit(id)
	run_powers += 1
	_mission_add("powers", 1)
	popup.emit(POWER_NAMES[id], true)


## ردشدن خیلی نزدیک از کنار مانع؛ پشت‌سرهم بودنش پاداش را بیشتر می‌کند
func register_near_miss() -> void:
	if not is_active:
		return
	near_streak += 1
	run_near += 1
	Sfx.play("near", -4.0)
	Rules.fire("near_miss")
	popup.emit("عالی! ×%d" % near_streak if near_streak > 1 else "کم مونده بود!", true)
	_mission_add("near", 1)
	_update_score()


# ------------------------- ماموریت‌ها -------------------------
const MISSION_TEMPLATES := [
	{"t": "coins", "txt": "جمع‌کردن %d سکه", "goals": [60, 120, 250], "rw": [20, 40, 80], "total": true},
	{"t": "powers", "txt": "برداشتن %d قدرت", "goals": [3, 6, 10], "rw": [20, 40, 70], "total": true},
	{"t": "near", "txt": "%d بار ردشدن از نزدیک مانع", "goals": [5, 10, 20], "rw": [25, 45, 80], "total": true},
	{"t": "dist", "txt": "رسیدن به %d متر در یک بازی", "goals": [500, 1000, 2000], "rw": [25, 50, 100], "total": false},
	{"t": "score", "txt": "کسب %d امتیاز در یک بازی", "goals": [1500, 3000, 6000], "rw": [25, 50, 100], "total": false},
]


func _new_mission(avoid: Array) -> Dictionary:
	for _try in 20:
		var tpl: Dictionary = MISSION_TEMPLATES[randi() % MISSION_TEMPLATES.size()]
		if avoid.has(tpl.t):
			continue
		var k := clampi(randi() % 3, 0, 2)
		return {"t": tpl.t, "goal": tpl.goals[k], "prog": 0, "reward": tpl.rw[k]}
	var f: Dictionary = MISSION_TEMPLATES[0]
	return {"t": f.t, "goal": f.goals[0], "prog": 0, "reward": f.rw[0]}


func _ensure_missions() -> void:
	var changed := false
	while missions.size() < 3:
		var used: Array = []
		for m: Dictionary in missions:
			used.append(m.t)
		missions.append(_new_mission(used))
		changed = true
	if changed:
		save_game()


func mission_text(m: Dictionary) -> String:
	for tpl: Dictionary in MISSION_TEMPLATES:
		if tpl.t == m.t:
			return tpl.txt % int(m.goal)
	return ""


func _mission_add(kind: String, amount: int) -> void:
	_mission_set(kind, amount, true)


func _mission_set(kind: String, value: int, add: bool) -> void:
	var done: Array = []
	for i in missions.size():
		var m: Dictionary = missions[i]
		if m.t != kind:
			continue
		m.prog = (int(m.prog) + value) if add else maxi(int(m.prog), value)
		if int(m.prog) >= int(m.goal):
			done.append(i)
	for i in done:
		var m: Dictionary = missions[i]
		coins += int(m.reward)
		coins_changed.emit(coins)
		Online.mission_reward(int(m.reward))
		var txt := mission_text(m)
		var rw := int(m.reward)
		var used: Array = []
		for o: Dictionary in missions:
			used.append(o.t)
		missions[i] = _new_mission(used)
		mission_completed.emit(txt, rw)
		toast.emit("ماموریت انجام شد! +%d سکه" % rw)
	missions_changed.emit()
	if not done.is_empty():
		Online.queue_save()


func has_power(id: int) -> bool:
	return power_left[id] > 0.0


## شکست‌ناپذیر (جت‌پک یا چند لحظه بعد از آن)
func is_invincible() -> bool:
	return power_left[Power.JET] > 0.0 or jet_grace > 0.0


## برخورد با مانع. نتیجه: "ignored" | "shield" | "stumble" | "caught"
## graze=true: فقط لبه‌ی مانع را خراشیده‌ای (پلیس نزدیک می‌شود، ولی می‌مانی)
## graze=false: برخورد کامل با مانع = دستگیری فوری
func register_obstacle_hit(graze: bool = false) -> String:
	if not is_active:
		return "ignored"
	if is_invincible():
		return "ignored"
	near_streak = 0
	if power_left[Power.SHIELD] > 0.0:
		power_left[Power.SHIELD] = 0.0
		power_ended.emit(Power.SHIELD)
		popup.emit("سپر شکست!", false)
		shield_broke.emit()
		player_hit.emit()
		return "shield"
	player_hit.emit()
	if stumble > 0.0 or not graze:
		_end_run("caught")
		return "caught"
	stumble = STUMBLE_TIME
	heat_left = STUMBLE_TIME + HEAT_TIME
	run_speed *= STUMBLE_SLOW
	stumble_changed.emit(true)
	popup.emit("خراش خوردی! مراقب باش", false)
	grazed.emit()
	return "stumble"


# ------------------------- پایان بازی و زنده‌شدن -------------------------
func _end_run(reason: String) -> void:
	if not is_active:
		return
	is_active = false
	over = true
	_update_score()
	var new_record := score > high_score
	if new_record:
		high_score = score
		high_score_changed.emit(high_score)
	var dist := int(distance)
	_mission_set("dist", dist, false)
	_mission_set("score", score, false)
	if dist > best_distance:
		best_distance = dist
	save_game()
	_last_summary = {
		"reason": reason, "score": score, "distance": dist, "coins": run_coins,
		"new_record": new_record, "high_score": high_score, "can_revive": can_revive(),
	}
	game_over.emit(_last_summary)
	_clear_challenge_mod()


func can_revive() -> bool:
	return over and not used_revive and coins >= REVIVE_PRICE and not _reviving


var _reviving := false


func revive() -> void:
	if not can_revive():
		return
	_reviving = true
	var r: Dictionary = await Online.pay_revive()
	_reviving = false
	if not r.get("ok", false):
		toast.emit(Online.error_text(String(r.get("error", "")), int(r.get("need", 0))))
		Sfx.play("error")
		return
	coins = int(r.coins)
	coins_changed.emit(coins)
	used_revive = true
	_apply_challenge_mod()           # ادامه‌ی همان دویدن؛ قانون رقابت دوباره اعمال می‌شود
	over = false
	is_active = true
	is_paused = false
	stumble = 0.0
	heat_left = 0.0
	stumble_changed.emit(false)
	run_speed = START_SPEED
	jet_grace = REVIVE_INVULN
	save_game()
	revived.emit()


# ------------------------- توقف / خروج -------------------------
func pause_game() -> void:
	if not is_active or is_paused:
		return
	is_paused = true
	pause_changed.emit(true)


func resume_game() -> void:
	if not is_paused:
		return
	is_paused = false
	pause_changed.emit(false)


func quit_to_menu() -> void:
	is_active = false
	is_paused = false
	over = false
	pause_changed.emit(false)
	session_ended.emit()


# ------------------------- فروشگاه (ارتقاهای دائمی) -------------------------
func power_duration(id: int) -> float:
	return POWER_BASE[id] + POWER_STEP[id] * float(levels[id])


func upgrade_price(id: int) -> int:
	return UPGRADE_BASE_PRICE * (levels[id] + 1)


func buy_upgrade(id: int) -> void:
	if levels[id] >= MAX_LEVEL:
		toast.emit("به آخرین سطح رسیده‌ای!")
		return
	var r: Dictionary = await Online.buy_upgrade(id)
	if not r.get("ok", false):
		toast.emit(Online.error_text(String(r.get("error", "")), int(r.get("need", 0))))
		Sfx.play("error")
		return
	levels[id] = int(r.level)
	coins = int(r.coins)
	coins_changed.emit(coins)
	toast.emit("%s ارتقا یافت: %d ثانیه" % [POWER_NAMES[id], int(power_duration(id))])
	Sfx.play("buy")


func set_missions_from_server(ms: Array) -> void:
	var out: Array = []
	for m in ms:
		if m is Dictionary and m.has("t") and m.has("goal") and m.has("prog") and m.has("reward"):
			out.append(m)
	if not out.is_empty():
		missions = out
		missions_changed.emit()


# ------------------------- تنظیمات -------------------------
func set_sound(value: bool) -> void:
	sound_on = value
	save_game()



func set_vol(key: String, value: float) -> void:
	vol[key] = clampf(value, 0.0, 1.0)
	save_game()
	Sfx.refresh_loops()


func set_vibration(value: bool) -> void:
	vibration_on = value
	save_game()


# ------------------------- ذخیره‌سازی -------------------------
func _load_save() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	coins = int(cfg.get_value("save", "coins", 0))
	high_score = int(cfg.get_value("save", "high_score", 0))
	best_distance = int(cfg.get_value("save", "best_distance", 0))
	for i in levels.size():
		levels[i] = clampi(int(cfg.get_value("levels", str(i), 0)), 0, MAX_LEVEL)
	var ms = cfg.get_value("missions", "list", [])
	if ms is Array:
		for m in ms:
			if m is Dictionary and m.has("t") and m.has("goal") and m.has("prog") and m.has("reward"):
				missions.append(m)
	sound_on = bool(cfg.get_value("settings", "sound", true))
	vibration_on = bool(cfg.get_value("settings", "vibration", true))
	for k in vol.keys():
		vol[k] = clampf(float(cfg.get_value("volume", k, vol[k])), 0.0, 1.0)
	intro_on = bool(cfg.get_value("settings", "intro", true))
	var vm = cfg.get_value("voices", "map", {})
	voice_map = vm if vm is Dictionary else {}


func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("save", "coins", coins)
	cfg.set_value("save", "high_score", high_score)
	cfg.set_value("save", "best_distance", best_distance)
	for i in levels.size():
		cfg.set_value("levels", str(i), levels[i])
	cfg.set_value("missions", "list", missions)
	cfg.set_value("settings", "sound", sound_on)
	cfg.set_value("settings", "vibration", vibration_on)
	cfg.set_value("settings", "intro", intro_on)
	cfg.set_value("voices", "map", voice_map)
	for k in vol.keys():
		cfg.set_value("volume", k, vol[k])
	cfg.save(SAVE_PATH)


# ------------------------- تنظیمات از راه دور (پنل مدیریت) -------------------------
## هر کلید همان نام متغیر است. مقدارها محدود می‌شوند تا تنظیم اشتباه بازی را خراب نکند.
const REMOTE_LIMITS := {
	"START_SPEED": [6.0, 30.0], "MAX_SPEED": [10.0, 45.0], "SPEED_PER_SECOND": [0.0, 0.5],
	"COIN_SCORE": [0, 100], "ZONE_LENGTH": [100.0, 3000.0], "STUMBLE_TIME": [1.0, 15.0],
	"STUMBLE_SLOW": [0.3, 1.0], "JET_GRACE": [0.0, 5.0], "SLOW_MULT": [0.3, 1.0],
	"NEAR_BONUS": [0, 200], "REVIVE_PRICE": [0, 1000], "UPGRADE_BASE_PRICE": [1, 2000],
	"HEAT_TIME": [0.0, 60.0],
}
var remote_config: Dictionary = {}
var _tuning_defaults: Dictionary = {}


func tuning_dict() -> Dictionary:
	var d := {}
	for k: String in REMOTE_LIMITS:
		d[k] = get(k)
	d["POWER_BASE"] = POWER_BASE.duplicate()
	d["POWER_STEP"] = POWER_STEP.duplicate()
	return d


func reset_tuning() -> void:
	if not _tuning_defaults.is_empty():
		apply_remote_config(_tuning_defaults.duplicate(true))


func apply_remote_config(d: Dictionary) -> void:
	remote_config = d
	for k: String in REMOTE_LIMITS:
		if not d.has(k):
			continue
		var lim: Array = REMOTE_LIMITS[k]
		var cur = get(k)
		var v := float(d[k])
		v = clampf(v, float(lim[0]), float(lim[1]))
		set(k, int(v) if cur is int else v)
	for k in ["POWER_BASE", "POWER_STEP"]:
		if d.has(k) and d[k] is Array and (d[k] as Array).size() == 6:
			var arr: Array[float] = []
			for x in d[k]:
				arr.append(clampf(float(x), 0.5, 120.0))
			set(k, arr)
	if MAX_SPEED < START_SPEED:
		MAX_SPEED = START_SPEED
