extends Node3D
## بازیکن (دونده). ظاهر او را CharacterModel (مدل بلوکی ماینکرفتی + اسکین انتخابی) می‌سازد.
## جلو = محور منفی Z. بازیکن همیشه در z=0 است و دنیا به سمتش می‌آید.

const CharacterModel := preload("res://scripts/character_model.gd")
const GlbModel := preload("res://scripts/glb_model.gd")

signal jumped
signal slid
signal lane_changed
signal landed
signal stepped

const JUMP_HEIGHT := 2.3
const SPRING_MULT := 1.75
const JET_Y := 3.4
const JUMP_TIME := 0.62
const SLIDE_TIME := 0.7
const FAST_FALL_SPEED := 28.0
const STAND_HEIGHT := 1.9
const SLIDE_HEIGHT := 0.75
const LANE_SMOOTH := 16.0
const INVULN_TIME := 1.4
const SWIPE_DISTANCE := 48.0

var lane := 0
var jump_y := 0.0           # ارتفاع مطلق پاها از زمینِ صفر
var ground_h := 0.0         # ارتفاع سطحِ زیر پا (روی رمپ/سکو بیشتر از صفر؛ مقدار را Track می‌دهد)
var invuln := 0.0

var _jump_t := -1.0
var _pvy := 0.0                 # سرعت عمودی (فیزیک پرش و افتادن)
var _grav := 8.0 * JUMP_HEIGHT / (JUMP_TIME * JUMP_TIME)
var _jump_h := JUMP_HEIGHT
var _flying := false
var _slide_t := -1.0
var _fast_fall := false
var _queued_slide := false
var _phase := 0.0
var _land_t := 0.0
var _hit_t := 0.0
var _prev_y := 0.0
var _vy := 0.0
var _clock := 0.0
var _swipe_origin := Vector2.ZERO
var _swipe_active := false

var _visual: Node3D
var _model
var _shadow: MeshInstance3D
var _bubble: MeshInstance3D
var _flame: CPUParticles3D
var _pack: Node3D


func _ready() -> void:
	_visual = Node3D.new()
	add_child(_visual)
	_model = CharacterModel.new()
	_visual.add_child(_model)
	_apply_skin()
	Skins.changed.connect(_apply_skin)
	Skins.glb_cfg_changed.connect(func():
		if _model != null and _model.get("is_glb") == true:
			_model.apply_config(Skins.glb_cfg(Skins.current_entry())))

	# سایه‌ی دایره‌ای زیر پا
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.45
	cyl.bottom_radius = 0.45
	cyl.height = 0.02
	var sh_mat := StandardMaterial3D.new()
	sh_mat.albedo_color = Color(0.0, 0.0, 0.0, 0.45)
	sh_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sh_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_shadow = MeshInstance3D.new()
	_shadow.mesh = cyl
	_shadow.material_override = sh_mat
	_shadow.position = Vector3(0.0, 0.03, 0.0)
	add_child(_shadow)

	# حباب سپر
	var sph := SphereMesh.new()
	sph.radius = 1.25
	sph.height = 2.5
	var bm := StandardMaterial3D.new()
	bm.albedo_color = Color(0.3, 0.85, 1.0, 0.28)
	bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bm.cull_mode = BaseMaterial3D.CULL_DISABLED
	bm.emission_enabled = true
	bm.emission = Color(0.2, 0.7, 1.0)
	bm.emission_energy_multiplier = 0.8
	_bubble = MeshInstance3D.new()
	_bubble.mesh = sph
	_bubble.material_override = bm
	_bubble.position = Vector3(0.0, 1.0, 0.0)
	_bubble.visible = false
	_visual.add_child(_bubble)

	# شعله‌ی جت‌پک
	_flame = CPUParticles3D.new()
	_flame.amount = 24
	_flame.lifetime = 0.35
	_flame.direction = Vector3(0.0, -1.0, 0.3)
	_flame.spread = 18.0
	_flame.initial_velocity_min = 3.0
	_flame.initial_velocity_max = 5.0
	_flame.gravity = Vector3.ZERO
	var fm := SphereMesh.new()
	fm.radius = 0.12
	fm.height = 0.24
	fm.radial_segments = 6
	fm.rings = 3
	var fmat := StandardMaterial3D.new()
	fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmat.albedo_color = Color(1.0, 0.6, 0.15)
	fm.material = fmat
	_flame.mesh = fm
	_flame.position = Vector3(0.0, 0.5, 0.42)
	_flame.emitting = false
	_visual.add_child(_flame)
	_build_jetpack()


## جت‌پک روی کمر (پشتِ کاراکتر، چون کاراکتر رو به −Z است): دو مخزن، نازل و پیچ‌وتاب
func _build_jetpack() -> void:
	_pack = Node3D.new()
	_pack.position = Vector3(0.0, 0.95, 0.3)
	_pack.visible = false
	_visual.add_child(_pack)
	var body := StandardMaterial3D.new()
	body.albedo_color = Color("d63a2f")
	body.metallic = 0.6
	body.roughness = 0.35
	var steel := StandardMaterial3D.new()
	steel.albedo_color = Color("9aa3ad")
	steel.metallic = 0.9
	steel.roughness = 0.3
	var glow := StandardMaterial3D.new()
	glow.albedo_color = Color("ffb02e")
	glow.emission_enabled = true
	glow.emission = Color("ff8a2a")
	glow.emission_energy_multiplier = 1.6
	for sx in [-0.17, 0.17]:
		var tank := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.13
		cm.bottom_radius = 0.13
		cm.height = 0.62
		cm.material = body
		tank.mesh = cm
		tank.position = Vector3(sx, 0.0, 0.0)
		_pack.add_child(tank)
		var cap := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.13
		sm.height = 0.26
		sm.material = body
		cap.mesh = sm
		cap.position = Vector3(sx, 0.31, 0.0)
		_pack.add_child(cap)
		var nz := MeshInstance3D.new()
		var nm := CylinderMesh.new()
		nm.top_radius = 0.09
		nm.bottom_radius = 0.14
		nm.height = 0.14
		nm.material = steel
		nz.mesh = nm
		nz.position = Vector3(sx, -0.37, 0.0)
		_pack.add_child(nz)
		var ring := MeshInstance3D.new()
		var tm := CylinderMesh.new()
		tm.top_radius = 0.135
		tm.bottom_radius = 0.135
		tm.height = 0.05
		tm.material = glow
		ring.mesh = tm
		ring.position = Vector3(sx, 0.12, 0.0)
		_pack.add_child(ring)
	var strap := MeshInstance3D.new()
	var bx := BoxMesh.new()
	bx.size = Vector3(0.5, 0.1, 0.12)
	bx.material = steel
	strap.mesh = bx
	strap.position = Vector3(0.0, 0.12, -0.04)
	_pack.add_child(strap)


func _apply_skin() -> void:
	var e: Dictionary = Skins.current_entry()
	if Skins.is_glb(e):
		var gm := GlbModel.new()
		_visual.add_child(gm)
		if gm.load_from_file(str(e["glb"]), int(e["glb_yaw"])):
			gm.apply_config(Skins.glb_cfg(e))
			_replace_model(gm)
			return
		gm.queue_free()
		Game.toast.emit("مدل GLB بارگذاری نشد: " + gm.load_error)
	if _model is CharacterModel or _model.get_script() == CharacterModel:
		_model.set_skin(Skins.texture, Skins.slim, Skins.smooth)
	else:
		var cm := CharacterModel.new()
		_visual.add_child(cm)
		_replace_model(cm)
		_model.set_skin(Skins.texture, Skins.slim, Skins.smooth)


func _replace_model(m: Node3D) -> void:
	_trick = ""
	if _model != null and is_instance_valid(_model) and _model != m:
		_visual.remove_child(_model)
		_model.queue_free()
	_model = m


# ------------------------- ورودی -------------------------
func _can_control() -> bool:
	return Game.is_active and not Game.is_paused


func _input(event: InputEvent) -> void:
	if not _can_control():
		return
	if event is InputEventKey:
		if event.pressed and not event.echo:
			match event.physical_keycode:
				KEY_LEFT, KEY_A:
					move_lane(-1)
				KEY_RIGHT, KEY_D:
					move_lane(1)
				KEY_UP, KEY_W, KEY_SPACE:
					jump()
				KEY_DOWN, KEY_S:
					slide()
	elif event is InputEventScreenTouch:
		if event.index == 0:
			_swipe_active = event.pressed
			_swipe_origin = event.position
	elif event is InputEventScreenDrag:
		if _swipe_active and event.index == 0:
			var d: Vector2 = event.position - _swipe_origin
			if d.length() >= SWIPE_DISTANCE:
				_swipe_active = false  # هر سوایپ فقط یک حرکت
				if absf(d.x) > absf(d.y):
					move_lane(1 if d.x > 0.0 else -1)
				elif d.y < 0.0:
					jump()
				else:
					slide()


# ------------------------- حرکت‌ها -------------------------
func move_lane(dir: int) -> void:
	var new_lane := clampi(lane + dir, -1, 1)
	if new_lane == lane:
		return
	lane = new_lane
	lane_changed.emit()


func jump() -> void:
	if _jump_t >= 0.0 or _flying:
		return
	_slide_t = -1.0
	_jump_t = 0.0
	_jump_h = JUMP_HEIGHT * (SPRING_MULT if Game.has_power(Game.Power.SPRING) else 1.0)
	# سهمی با ارتفاع _jump_h و مدت JUMP_TIME (روی سطح صاف دقیقاً مثل قبل)
	_pvy = 4.0 * _jump_h / JUMP_TIME
	_grav = 8.0 * _jump_h / (JUMP_TIME * JUMP_TIME)
	jumped.emit()


func slide() -> void:
	if _slide_t >= 0.0 or _flying:
		return
	if _jump_t >= 0.0:
		# سُرخوردن در هوا: سریع فرود بیا و بلافاصله سُر بخور
		_fast_fall = true
		_queued_slide = true
		return
	_slide_t = 0.0
	slid.emit()


func hold_slide() -> void:
	if _slide_t >= 0.0:
		_slide_t = minf(_slide_t, 0.3)


func _land() -> void:
	landed.emit()
	_land_t = 0.2
	jump_y = ground_h
	_pvy = 0.0
	_jump_t = -1.0
	_fast_fall = false
	if _queued_slide:
		_queued_slide = false
		_slide_t = 0.0
		slid.emit()


## بعد از خراش‌خوردن با لبه‌ی مانع، به خطِ امن‌تر برمی‌گردد
func bounce_from(obstacle_x: float) -> void:
	var dir := 1 if position.x > obstacle_x else -1
	var nl := clampi(lane + dir, -1, 1)
	if nl != lane:
		lane = nl
		lane_changed.emit()


func on_hit() -> void:
	invuln = INVULN_TIME
	_hit_t = 0.7


## بازه‌ی ارتفاع بدن بازیکن (برای تشخیص برخورد با موانع)
func get_y_range() -> Vector2:
	if _slide_t >= 0.0:
		return Vector2(0.0, SLIDE_HEIGHT)
	return Vector2(jump_y, jump_y + STAND_HEIGHT)


## روی سطحی بالاتر از صفر ایستاده؟ (سکو/رمپ)
func on_platform() -> bool:
	return ground_h > 0.05 and jump_y <= ground_h + 0.05


func reset() -> void:
	lane = 0
	jump_y = 0.0
	ground_h = 0.0
	_pvy = 0.0
	invuln = 0.0
	_jump_t = -1.0
	_slide_t = -1.0
	_fast_fall = false
	_queued_slide = false
	_swipe_active = false
	_flying = false
	_jump_h = JUMP_HEIGHT
	position = Vector3.ZERO
	if _visual:
		_visual.visible = true
		_visual.rotation = Vector3.ZERO
		_visual.position = Vector3.ZERO


# ------------------------- به‌روزرسانی هر فریم -------------------------
# ------------------------- حرکت‌های نمایشی (برای قانون‌های انیمیشن) -------------------------
var _trick := ""
var _trick_t := 0.0
var _trick_len := 1.2


## spin / flip / wave / bounce / crouch / shake   یا   clip:نام‌کلیپ (برای مدل GLB)
func play_trick(trick_name: String, dur: float = 1.2) -> void:
	if trick_name.begins_with("clip:"):
		if _model != null and _model.has_method("play_clip_once"):
			_model.play_clip_once(trick_name.substr(5), dur)
		return
	_trick = trick_name
	_trick_t = 0.0
	_trick_len = maxf(dur, 0.3)


func _apply_trick(delta: float) -> void:
	if _trick == "" or _model == null:
		return
	_trick_t += delta
	var u := clampf(_trick_t / _trick_len, 0.0, 1.0)
	var e := u * u * (3.0 - 2.0 * u)
	_model.rotation = Vector3.ZERO
	_model.position = Vector3.ZERO
	_model.scale = Vector3.ONE
	if u < 1.0:
		match _trick:
			"spin": _model.rotation.y = TAU * e
			"flip":
				_model.rotation.x = -TAU * e
				_model.position.y = sin(PI * u) * 1.0
				_model.position.z = 0.0
			"wave": _model.rotation.z = sin(u * TAU * 3.0) * 0.35
			"bounce": _model.position.y = absf(sin(u * PI * 4.0)) * 0.35
			"crouch": _model.scale.y = 1.0 - 0.35 * sin(u * PI)
			"shake": _model.position.x = sin(u * 70.0) * 0.08 * (1.0 - u)
	else:
		_trick = ""


func tick(delta: float, speed: float) -> void:
	_apply_trick(delta)
	var target_x := float(lane) * Game.LANE_WIDTH
	position.x = lerpf(position.x, target_x, 1.0 - exp(-LANE_SMOOTH * delta))
	if absf(position.x - target_x) < 0.005:
		position.x = target_x

	var jet := Game.is_active and Game.has_power(Game.Power.JET)
	if jet:
		if not _flying:
			_flying = true
			_jump_t = -1.0
			_slide_t = -1.0
			_fast_fall = false
			_queued_slide = false
			_pvy = 0.0
		jump_y = move_toward(jump_y, maxf(JET_Y, ground_h + 1.6), 9.0 * delta)
	elif _flying:
		# فرود نرم بعد از جت
		jump_y = move_toward(jump_y, ground_h, 10.0 * delta)
		if jump_y <= ground_h:
			_flying = false
	if _flying:
		pass
	elif _jump_t >= 0.0:
		# در هوا: پرش یا افتادن از لبه‌ی سکو
		_jump_t += delta
		if _fast_fall:
			_pvy = -FAST_FALL_SPEED
		else:
			_pvy -= _grav * delta
		jump_y += _pvy * delta
		if jump_y <= ground_h and _pvy <= 0.0:
			_land()
	else:
		# روی زمین/سکو: دنبال سطح زیر پا (رمپ بالا می‌برد؛ تمام‌شدن سکو = افتادن)
		if ground_h > jump_y - 0.001:
			jump_y = ground_h
		elif jump_y - ground_h > 0.02:
			_jump_t = 0.0
			_pvy = 0.0
			_grav = 8.0 * JUMP_HEIGHT / (JUMP_TIME * JUMP_TIME)

	if _slide_t >= 0.0 and not _flying:
		_slide_t += delta
		if _slide_t >= SLIDE_TIME:
			_slide_t = -1.0

	if invuln > 0.0:
		invuln = maxf(0.0, invuln - delta)

	_animate(delta, speed, target_x)


func _animate(delta: float, speed: float, target_x: float) -> void:
	var moving := speed > 0.1
	var airborne := _jump_t >= 0.0
	var sliding := _slide_t >= 0.0
	if moving:
		var before := floori(_phase / PI)
		_phase += delta * (6.0 + speed * 0.55)
		if floori(_phase / PI) != before and not airborne and not sliding and not _flying:
			stepped.emit()
	var swing := sin(_phase) * 0.9

	_clock += delta
	_land_t = maxf(0.0, _land_t - delta)
	_hit_t = maxf(0.0, _hit_t - delta)
	if delta > 0.0:
		_vy = (jump_y - _prev_y) / delta
	_prev_y = jump_y
	if _model.has_method("animate_state"):
		_model.animate_state({
			"moving": moving, "speed": speed, "phase": _phase, "airborne": airborne,
			"sliding": sliding, "flying": _flying, "hit": _hit_t > 0.0,
			"landing": _land_t > 0.0, "vy": _vy, "t": _clock,
		}, delta)
		_animate_common(delta, speed, target_x, moving, airborne, sliding)
		return
	var legs: Array[Node3D] = _model.legs
	var arms: Array[Node3D] = _model.arms
	if legs.size() < 2 or arms.size() < 2:
		return
	if _flying:
		legs[0].rotation.x = 0.35
		legs[1].rotation.x = -0.2
		arms[0].rotation.x = 3.0
		arms[1].rotation.x = 3.0
	elif airborne:
		legs[0].rotation.x = 0.8
		legs[1].rotation.x = -0.45
		arms[0].rotation.x = 2.5
		arms[1].rotation.x = 2.5
	elif sliding:
		legs[0].rotation.x = 0.1
		legs[1].rotation.x = 0.1
		arms[0].rotation.x = -0.3
		arms[1].rotation.x = -0.3
	else:
		legs[0].rotation.x = swing
		legs[1].rotation.x = -swing
		arms[0].rotation.x = -swing
		arms[1].rotation.x = swing

	_animate_common(delta, speed, target_x, moving, airborne, sliding)


func _animate_common(delta: float, _speed: float, target_x: float, moving: bool, airborne: bool, sliding: bool) -> void:
	var bob := 0.0
	if moving and not airborne and not sliding:
		bob = absf(sin(_phase)) * 0.07
	# مدل GLB با کلیپ واقعی خودش سُر می‌خورد/پرواز می‌کند؛ کج‌کردن اضافه ممنوع
	var by_clip: bool = _model.has_method("uses_clip") and _model.uses_clip()
	_visual.position.y = bob + (0.28 if (sliding and not by_clip) else 0.0) + jump_y

	var tilt_target := 0.0
	if not by_clip:
		tilt_target = 1.35 if sliding else (1.1 if _flying else 0.0)
	_visual.rotation.x = lerpf(_visual.rotation.x, tilt_target, 1.0 - exp(-20.0 * delta))
	var lean := clampf((position.x - target_x) * 0.35, -0.5, 0.5)
	_visual.rotation.z = lerpf(_visual.rotation.z, lean, 1.0 - exp(-14.0 * delta))

	# چشمک‌زدن در زمان شکست‌ناپذیری
	_visual.visible = not (invuln > 0.0 and int(invuln * 14.0) % 2 == 0)
	_bubble.visible = Game.is_active and Game.has_power(Game.Power.SHIELD)
	if _bubble.visible:
		var pulse := 1.0 + sin(Time.get_ticks_msec() / 120.0) * 0.03
		_bubble.scale = Vector3.ONE * pulse
	_flame.emitting = _flying and Game.has_power(Game.Power.JET)
	_pack.visible = Game.is_active and (Game.has_power(Game.Power.JET) or _flying)

	# سایه‌ی زیر پا
	var s := clampf(1.0 - (jump_y - ground_h) * 0.3, 0.3, 1.0)
	_shadow.scale = Vector3(s, 1.0, s)
	_shadow.position.y = ground_h + 0.03
