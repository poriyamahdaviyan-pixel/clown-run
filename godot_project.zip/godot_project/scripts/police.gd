extends Node3D
## تعقیب‌کننده (مثل پلیسِ Subway Surfers؛ در این بازی نمادین «پلیس» نامیده می‌شود):
## معمولاً پشت دوربین و دیده نمی‌شود؛ بعد از اولین برخورد (لیز خوردن) نزدیک می‌شود؛ برخورد دوم = دستگیری.
## ظاهرش مدلِ GLBی است که مالک می‌گذارد (assets/police.glb؛ بخش PoliceCfg).
## اگر مدلی نباشد، یک عروسکِ بلوکیِ ساده فقط به‌عنوان جانگهدار نمایش داده می‌شود.

const GlbModel := preload("res://scripts/glb_model.gd")
const FAR := 24.0          # فاصله‌ی عادی (پشت دوربین، دیده نمی‌شود)
const START_GAP := 3.4      # اول بازی چند متر پشت کاراکتر می‌دود
const START_HOLD := 2.0     # ثانیه؛ بعد آرام‌آرام جا می‌ماند
const NEAR := 2.2
const CATCH := 0.7

var player: Node3D
var _gap := START_GAP
var _phase := 0.0
var _siren := 0.0
var _x := 0.0
var _officer: Node3D
var _dog: Node3D
var _limbs := {}
var _light_r: OmniLight3D
var _light_b: OmniLight3D
var _siren_mat: StandardMaterial3D
var _caught := false
var _gm: Node3D
var _t := 0.0


func _ready() -> void:
	visible = false
	_build_officer()
	_build_dog()
	PoliceCfg.changed.connect(_rebuild_model)
	_rebuild_model()
	Game.game_started.connect(func(): _reset())
	Game.session_ended.connect(func(): visible = false; _gap = FAR; _caught = false)
	Game.game_over.connect(func(_s): _caught = true)
	Game.revived.connect(func(): _caught = false; _gap = NEAR + 1.0)


## مدل GLB مالک را (اگر هست) جایگزین عروسک ساده می‌کند
func _rebuild_model() -> void:
	if _gm != null:
		_gm.queue_free()
		_gm = null
	if PoliceCfg.has_model():
		var gm := GlbModel.new()
		add_child(gm)
		if gm.load_from_file(PoliceCfg.model_path(), PoliceCfg.yaw()):
			gm.apply_config(PoliceCfg.cfg())
			_gm = gm
		else:
			gm.queue_free()
	_officer.visible = _gm == null
	_dog.visible = _gm == null


func _reset() -> void:
	_caught = false
	_close = false
	_trick = ""
	_gap = START_GAP
	visible = true
	_x = player.position.x if player else 0.0


func _mat(c: Color, rough: float = 0.7, metal: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	return m


func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	bm.material = mat
	mi.mesh = bm
	mi.position = pos
	parent.add_child(mi)
	return mi


func _pivot(parent: Node3D, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	parent.add_child(n)
	return n


func _build_officer() -> void:
	_officer = Node3D.new()
	_officer.position = Vector3(0.0, 0.0, 0.0)
	_officer.rotation.y = 0.0     # رو به −Z (به‌سمت بازیکن)
	add_child(_officer)
	var navy := _mat(Color("1f3a7a"))
	var dark := _mat(Color("14234a"))
	var skin := _mat(Color("f0c29a"))
	var gold := _mat(Color("ffcc33"), 0.3, 0.8)
	var white := _mat(Color("f2f2f2"))
	var black := _mat(Color("151515"))
	_box(_officer, Vector3(0.56, 0.7, 0.32), Vector3(0, 1.1, 0), navy)             # تنه
	_box(_officer, Vector3(0.58, 0.12, 0.34), Vector3(0, 0.78, 0), black)         # کمربند
	_box(_officer, Vector3(0.12, 0.12, 0.02), Vector3(-0.14, 1.22, -0.17), gold)  # نشان
	_box(_officer, Vector3(0.12, 0.3, 0.02), Vector3(0.0, 1.2, -0.17), white)     # یقه
	var head := _pivot(_officer, Vector3(0, 1.62, 0))
	_box(head, Vector3(0.38, 0.38, 0.38), Vector3.ZERO, skin)
	_box(head, Vector3(0.44, 0.1, 0.44), Vector3(0, 0.22, 0), dark)               # کلاه
	_box(head, Vector3(0.44, 0.16, 0.14), Vector3(0, 0.16, -0.26), dark)          # لبه‌ی کلاه
	_box(head, Vector3(0.1, 0.07, 0.02), Vector3(0, 0.25, -0.23), gold)
	_box(head, Vector3(0.07, 0.07, 0.02), Vector3(-0.1, 0.03, -0.2), black)
	_box(head, Vector3(0.07, 0.07, 0.02), Vector3(0.1, 0.03, -0.2), black)
	# دست‌ها و پاها (محور چرخش در شانه/لگن)
	for side in [-1, 1]:
		var arm := _pivot(_officer, Vector3(0.38 * side, 1.4, 0))
		_box(arm, Vector3(0.18, 0.62, 0.18), Vector3(0, -0.28, 0), navy)
		_box(arm, Vector3(0.16, 0.16, 0.16), Vector3(0, -0.62, 0), skin)
		_limbs["arm%d" % side] = arm
		var leg := _pivot(_officer, Vector3(0.16 * side, 0.78, 0))
		_box(leg, Vector3(0.22, 0.7, 0.24), Vector3(0, -0.35, 0), dark)
		_box(leg, Vector3(0.24, 0.12, 0.34), Vector3(0, -0.74, -0.04), black)
		_limbs["leg%d" % side] = leg
	# چراغ آژیر روی کلاه/دوش
	var bar := _pivot(_officer, Vector3(0, 2.12, 0))
	_siren_mat = StandardMaterial3D.new()
	_siren_mat.albedo_color = Color.RED
	_siren_mat.emission_enabled = true
	_siren_mat.emission = Color.RED
	_siren_mat.emission_energy_multiplier = 2.5
	_box(bar, Vector3(0.5, 0.12, 0.16), Vector3.ZERO, _siren_mat)
	_light_r = OmniLight3D.new()
	_light_r.light_color = Color(1, 0.1, 0.1)
	_light_r.omni_range = 7.0
	_light_r.position = Vector3(-0.3, 0, 0)
	bar.add_child(_light_r)
	_light_b = OmniLight3D.new()
	_light_b.light_color = Color(0.1, 0.3, 1)
	_light_b.omni_range = 7.0
	_light_b.position = Vector3(0.3, 0, 0)
	bar.add_child(_light_b)
	_officer.scale = Vector3.ONE * 1.05


func _build_dog() -> void:
	_dog = Node3D.new()
	add_child(_dog)
	var fur := _mat(Color("8a5a2b"))
	var dark := _mat(Color("4a2e14"))
	var black := _mat(Color("101010"))
	_box(_dog, Vector3(0.34, 0.34, 0.8), Vector3(0, 0.55, 0), fur)
	var head := _pivot(_dog, Vector3(0, 0.78, -0.5))
	_box(head, Vector3(0.3, 0.28, 0.3), Vector3.ZERO, fur)
	_box(head, Vector3(0.18, 0.14, 0.2), Vector3(0, -0.06, -0.22), dark)          # پوزه
	_box(head, Vector3(0.06, 0.06, 0.02), Vector3(0, -0.02, -0.33), black)
	_box(head, Vector3(0.08, 0.16, 0.06), Vector3(-0.12, 0.2, 0.02), dark)        # گوش‌ها
	_box(head, Vector3(0.08, 0.16, 0.06), Vector3(0.12, 0.2, 0.02), dark)
	var tail := _pivot(_dog, Vector3(0, 0.66, 0.42))
	tail.rotation.x = 0.7
	_box(tail, Vector3(0.07, 0.07, 0.4), Vector3(0, 0, 0.18), fur)
	for i in 4:
		var lx := -0.13 if i % 2 == 0 else 0.13
		var lz := -0.28 if i < 2 else 0.28
		var leg := _pivot(_dog, Vector3(lx, 0.4, lz))
		_box(leg, Vector3(0.1, 0.4, 0.1), Vector3(0, -0.2, 0), dark)
		_limbs["dleg%d" % i] = leg


## ۱ وقتی پلیس کاملاً پشت کاراکتر و توی کادر است، ۰ وقتی دور و دیده‌نشده
func near_k() -> float:
	return clampf((11.0 - _gap) / 6.0, 0.0, 1.0) if visible else 0.0


func get_gap() -> float:
	return _gap


## اینترو: main فاصله را مستقیم تعیین می‌کند
var intro_gap := 14.0
var intro_off := 0.0


func _process(delta: float) -> void:
	if player == null:
		return
	var rate := 4.0
	var want := FAR
	if Game.intro_active:
		_gap = intro_gap
		_x = player.position.x + intro_off
		_show(delta)
		return
	if not Game.is_active and not _caught:
		return
	if _caught:
		want = CATCH
		rate = 14.0
	elif Game.stumble > 0.0:
		want = NEAR            # بعد از خراش‌خوردن: می‌رسد و پشت سرت می‌دود
		rate = 14.0
	elif Game.heat_left > 0.0:
		want = NEAR + 5.0      # کم‌کم عقب می‌افتد
		rate = 2.6
	elif Game.elapsed < START_HOLD:
		want = START_GAP       # اول بازی چند متر پشت کاراکتر
		rate = 3.0
	else:
		rate = 3.0             # عقب می‌ماند و از کادر بیرون می‌رود
	_gap = move_toward(_gap, want, delta * rate)
	_x = lerpf(_x, player.position.x, 1.0 - exp(-3.5 * delta))
	_track_close()
	_show(delta)


func _step_sound(prev: int) -> void:
	if floori(_phase / PI) != prev and visible and _gap < 12.0:
		Sfx.play("step_p", -5.0 - _gap * 0.9)


# ------------------------- حرکت‌های ویژه (قوانین انیمیشن) -------------------------
var _trick := ""
var _trick_t := 0.0
var _trick_len := 1.2
var _close := false


## spin / flip / wave / bounce / crouch / shake یا clip:نام‌کلیپ (مدل GLB)
func play_trick(trick_name: String, dur: float = 1.2) -> void:
	if trick_name.begins_with("clip:"):
		if _gm != null and _gm.has_method("play_clip_once"):
			_gm.play_clip_once(trick_name.substr(5), dur)
		return
	_trick = trick_name
	_trick_t = 0.0
	_trick_len = maxf(dur, 0.3)


func _apply_trick(delta: float) -> void:
	rotation = Vector3.ZERO
	scale = Vector3.ONE
	if _trick == "":
		return
	_trick_t += delta
	var u := clampf(_trick_t / _trick_len, 0.0, 1.0)
	var e := u * u * (3.0 - 2.0 * u)
	if u >= 1.0:
		_trick = ""
		return
	match _trick:
		"spin": rotation.y = TAU * e
		"flip":
			rotation.x = -TAU * e
			position.y += sin(PI * u) * 1.0
		"wave": rotation.z = sin(u * TAU * 3.0) * 0.35
		"bounce": position.y += absf(sin(u * PI * 4.0)) * 0.35
		"crouch": scale.y = 1.0 - 0.35 * sin(u * PI)
		"shake": position.x += sin(u * 70.0) * 0.08 * (1.0 - u)


## رویدادهای نزدیک/دور شدن برای قوانین (بعد از مکث اول بازی)
func _track_close() -> void:
	if not Game.is_active or Game.intro_active or Game.elapsed < START_HOLD:
		return
	if not _close and _gap < 9.0:
		_close = true
		Rules.fire("chaser_approach", 0.0, Rules.CHASER)
	elif _close and _gap > 12.0:
		_close = false
		Rules.fire("chaser_leave", 0.0, Rules.CHASER)


func _show(delta: float) -> void:
	_show_inner(delta)
	_apply_trick(delta)


func _show_inner(delta: float) -> void:
	visible = _gap < 15.0
	position = Vector3(_x, 0.0, _gap)
	var speed := maxf(Game.run_speed, 6.0)
	if _gm != null:
		_t += delta
		var pv := floori(_phase / PI)
		_phase += delta * (6.0 + speed * 0.55)
		_step_sound(pv)
		_gm.animate_state({"moving": not _caught, "speed": speed, "phase": _phase, "airborne": false,
			"sliding": false, "flying": false, "hit": false, "landing": false, "vy": 0.0, "t": _t}, delta)
		return
	var pv2 := floori(_phase / PI)
	_phase += delta * (6.0 + speed * 0.55)
	_step_sound(pv2)
	var s := sin(_phase)
	_limbs["arm-1"].rotation.x = -s * 0.9
	_limbs["arm1"].rotation.x = s * 0.9
	_limbs["leg-1"].rotation.x = s * 0.95
	_limbs["leg1"].rotation.x = -s * 0.95
	_officer.position.y = absf(sin(_phase)) * 0.12
	_officer.rotation.x = 0.18
	# سگ کنارِ پلیس، کمی جلوتر
	_dog.position = Vector3(1.05, absf(sin(_phase * 1.3)) * 0.1, -0.9)
	for i in 4:
		var ph := _phase * 1.3 + (0.0 if i % 3 == 0 else PI)
		_limbs["dleg%d" % i].rotation.x = sin(ph) * 0.85
	_siren += delta * 9.0
	var on_red := sin(_siren) > 0.0
	_light_r.light_energy = 3.0 if on_red else 0.0
	_light_b.light_energy = 0.0 if on_red else 3.0
	_siren_mat.emission = Color(1, 0.1, 0.1) if on_red else Color(0.1, 0.3, 1.0)
	_siren_mat.albedo_color = _siren_mat.emission
