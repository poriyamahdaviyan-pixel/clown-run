extends Control
## صفحه‌ی تنظیمات: صدا و لرزش + «کنترل مدل کاراکتر و بدن» (برای مدل GLB):
## پیش‌نمایش زنده‌ی همه‌ی حالت‌ها (ایستادن، دویدن، پرش، سُرخوردن، برخورد، پرواز، فرود)،
## اندازه، ارتفاع، سرعت انیمیشن، شدت تاب دست‌وپا، خم‌شدن بدن، انتخاب کلیپ هر حالت، جهت و فهرست استخوان‌ها.

signal close_requested
signal goto_character_requested

const GlbModel := preload("res://scripts/glb_model.gd")

var ui
var _sound_btn: Button
var _vib_btn: Button
var _body_box: VBoxContainer
var _no_glb_box: VBoxContainer
var _info_lbl: Label
var _bones_lbl: Label
var _sliders := {}
var _proc_btn: Button
var _map_opts := {}
var _state_btns := {}
var _updating := false
var _cur_state := "run"
var _clip_sig := ""
var _target := "char"          # char | police (فقط مالک «پلیس» را می‌بیند)
var _target_box: HBoxContainer
var _target_btns := {}
var _police_box: VBoxContainer
var _no_glb_lbl: Label
var _no_glb_goto: Button


func setup(p_ui) -> void:
	ui = p_ui
	_build()
	Skins.changed.connect(refresh)
	Skins.glb_cfg_changed.connect(_sync_values)
	PoliceCfg.changed.connect(_on_police_changed)
	Edition.changed.connect(refresh)


func _build() -> void:
	ui._add_full(self, ui._dim_rect(0.9))
	var scroll := ScrollContainer.new()
	ui._add_full(self, scroll)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 56)
	margin.add_theme_constant_override("margin_bottom", 36)
	scroll.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 12)
	margin.add_child(col)

	col.add_child(ui._label("تنظیمات", 56, Color.WHITE))
	var r := HBoxContainer.new()
	r.alignment = BoxContainer.ALIGNMENT_CENTER
	r.add_theme_constant_override("separation", 14)
	col.add_child(r)
	_sound_btn = ui._button("", func(): Game.set_sound(not Game.sound_on); refresh(), Vector2(290, 80), 28)
	_vib_btn = ui._button("", func(): Game.set_vibration(not Game.vibration_on); refresh(), Vector2(290, 80), 28)
	r.add_child(_sound_btn)
	r.add_child(_vib_btn)
	var r2 := HBoxContainer.new()
	r2.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(r2)
	_intro_btn = ui._button("", func(): Game.intro_on = not Game.intro_on; Game.save_game(); refresh(), Vector2(594, 80), 28)
	r2.add_child(_intro_btn)
	_build_sound_panel(col)
	_build_music_panel(col)

	_ctrl_head = ui._label("کنترل مدل کاراکتر و بدن", 40, Color("ffb02e"))
	col.add_child(_ctrl_head)
	_target_box = HBoxContainer.new()
	_target_box.add_theme_constant_override("separation", 10)
	col.add_child(_target_box)
	for pair in [["char", "کاراکتر بازیکن"], ["police", "پلیس (تعقیب‌کننده)"]]:
		var key: String = pair[0]
		var tb: Button = ui._button(pair[1], func(): _set_target(key), Vector2(295, 72), 24)
		_target_box.add_child(tb)
		_target_btns[key] = tb

	_no_glb_box = VBoxContainer.new()
	_no_glb_box.add_theme_constant_override("separation", 10)
	col.add_child(_no_glb_box)
	var nl: Label = ui._label("این بخش برای کاراکترهای سه‌بعدی GLB است. اول در بخش «کاراکتر» یک مدل GLB اضافه یا انتخاب کن؛ بعد اینجا اندازه، حرکت‌ها و بدنش را کنترل می‌کنی.", 26)
	nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nl.custom_minimum_size = Vector2(600, 0)
	_no_glb_box.add_child(nl)
	_no_glb_lbl = nl
	_no_glb_goto = ui._button("رفتن به بخش کاراکتر", func(): goto_character_requested.emit(), Vector2(600, 90), 30, "Teal")
	_no_glb_box.add_child(_no_glb_goto)

	_police_box = VBoxContainer.new()
	_police_box.add_theme_constant_override("separation", 10)
	col.add_child(_police_box)
	var pl: Label = ui._label("مدل پلیس را فایل assets/police.glb تعیین می‌کند (برای همه‌ی بازیکنان). برای آزمایش روی همین دستگاه می‌توانی اینجا فایل دیگری انتخاب کنی؛ تنظیمات پایین هم فقط روی همین دستگاه ذخیره می‌شود تا یکی از دو دکمه‌ی آخر را بزنی.", 22, Color(1, 1, 1, 0.75))
	pl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	pl.custom_minimum_size = Vector2(600, 0)
	_police_box.add_child(pl)
	_police_box.add_child(ui._button("انتخاب فایل مدل پلیس (GLB)", func(): ui._open_picker("police_glb"), Vector2(600, 80), 26, "Teal"))
	_police_box.add_child(ui._button("حذف مدل انتخابی من (برگشت به assets/police.glb)", func(): PoliceCfg.clear_model(), Vector2(600, 72), 24, "Dark"))
	_police_box.add_child(ui._button("کپی تنظیمات پلیس (برای assets/police.cfg.json)", func():
		DisplayServer.clipboard_set(PoliceCfg.export_json())
		_owner_note("تنظیمات کپی شد؛ داخل فایل assets/police.cfg.json بچسبان تا در نسخه‌ی عمومی هم اعمال شود."), Vector2(600, 72), 24, "Dark"))
	_police_box.add_child(ui._button("ارسال تنظیمات پلیس به همه‌ی بازیکنان", func(): _push_chaser(), Vector2(600, 72), 24, "Gold"))

	_body_box = VBoxContainer.new()
	_body_box.add_theme_constant_override("separation", 10)
	col.add_child(_body_box)

	_body_box.add_child(ui._make_preview("settings", 420, GlbModel.new(), false))
	_info_lbl = ui._label("", 24, Color(1, 1, 1, 0.85))
	_info_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_info_lbl.custom_minimum_size = Vector2(600, 0)
	_body_box.add_child(_info_lbl)

	_body_box.add_child(ui._label("حالتی که می‌خواهی ببینی", 26))
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	_body_box.add_child(grid)
	for st in GlbModel.STATES:
		var s: String = st
		var b: Button = ui._button(GlbModel.STATE_TITLES[s], func(): _set_state(s), Vector2(146, 70), 22)
		grid.add_child(b)
		_state_btns[s] = b

	_add_slider("scale", "اندازه‌ی بدن", 0.6, 1.6, 0.01)
	_add_slider("off_y", "ارتفاع از زمین", -0.4, 0.4, 0.01)
	_add_slider("speed", "سرعت انیمیشن", 0.5, 2.0, 0.01)
	_add_slider("swing", "شدت تاب دست و پا", 0.3, 1.6, 0.01)
	_add_slider("lean", "خم‌شدن بدن و سر", 0.0, 1.6, 0.01)
	_proc_btn = ui._button("", func(): _set_cfg("proc", not bool(_cfg()["proc"])), Vector2(600, 72), 24)
	_body_box.add_child(_proc_btn)

	_body_box.add_child(ui._label("کلیپ هر حالت", 30, Color.WHITE))
	var hint: Label = ui._label("«خودکار» = از روی نام کلیپ‌های فایل. «حرکت ساختگی» = ساخت حرکت با کد روی استخوان‌ها.", 20, Color(1, 1, 1, 0.7))
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.custom_minimum_size = Vector2(600, 0)
	_body_box.add_child(hint)
	for st in GlbModel.STATES:
		var s2: String = st
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		_body_box.add_child(row)
		var l: Label = ui._label(GlbModel.STATE_TITLES[s2], 24)
		l.custom_minimum_size = Vector2(170, 0)
		row.add_child(l)
		var ob := OptionButton.new()
		ob.custom_minimum_size = Vector2(0, 62)
		ob.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		ob.add_theme_font_size_override("font_size", 24)
		ob.item_selected.connect(func(idx: int): _on_map(s2, ob, idx))
		row.add_child(ob)
		_map_opts[s2] = ob

	_body_box.add_child(ui._button("چرخاندن مدل ۹۰ درجه", func(): _cycle_yaw(), Vector2(600, 72), 26))
	_body_box.add_child(ui._label("استخوان‌های شناخته‌شده", 26))
	_bones_lbl = ui._label("", 20, Color(1, 1, 1, 0.7))
	_bones_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_bones_lbl.custom_minimum_size = Vector2(600, 0)
	_body_box.add_child(_bones_lbl)
	_body_box.add_child(ui._button("بازنشانی همه‌ی تنظیمات این مدل", func(): _reset_cfg(), Vector2(600, 72), 26, "Red"))

	_build_owner_panel(col)
	col.add_child(ui._button("بازگشت", func(): close_requested.emit(), Vector2(600, 90), 34, "Dark"))


# ------------------------- پنل مالک -------------------------
const TUNING_TITLES := {
	"START_SPEED": "سرعت شروع", "MAX_SPEED": "حداکثر سرعت", "SPEED_PER_SECOND": "افزایش سرعت در ثانیه",
	"COIN_SCORE": "امتیاز هر سکه", "ZONE_LENGTH": "طول هر محیط (متر)", "STUMBLE_TIME": "مدت لیز خوردن",
	"STUMBLE_SLOW": "ضریب سرعت پس از لیز خوردن", "JET_GRACE": "مهلت امن بعد از جت‌پک", "SLOW_MULT": "ضریب حرکت آهسته",
	"NEAR_BONUS": "امتیاز ردشدن از نزدیک", "REVIVE_PRICE": "قیمت زنده‌شدن", "UPGRADE_BASE_PRICE": "قیمت پایه ارتقا",
	"HEAT_TIME": "مدت ماندن پلیس",
}
const SoundPanel := preload("res://scripts/sound_panel.gd")
var _snd_box: VBoxContainer
var _perm_box: VBoxContainer
var _snd_sig := ""
var _voice_btn: Button
var _intro_btn: Button
var _ctrl_head: Label
var _owner_box: VBoxContainer
var _owner_head: Label
var _owner_body: VBoxContainer
var _owner_msg: Label


func _build_sound_panel(col: VBoxContainer) -> void:
	_snd_box = VBoxContainer.new()
	_snd_box.add_theme_constant_override("separation", 8)
	col.add_child(_snd_box)
	Content.changed.connect(_maybe_rebuild_sound)
	Content.changed.connect(_maybe_refill_music)
	Skins.changed.connect(_maybe_rebuild_sound)
	_maybe_rebuild_sound()


var _music_sig := ""


func _maybe_refill_music() -> void:
	var sig := str(Content._merged("perms")) + str(Edition.is_owner())
	if sig != _music_sig and _music_box != null:
		_music_sig = sig
		_fill_music()


## با هر جابه‌جایی کشو نباید دوباره ساخته شود؛ فقط وقتی دسترسی‌ها یا کاراکتر عوض شد
func _maybe_rebuild_sound() -> void:
	var sig := "%s|%s|%s|%d" % [str(Content._merged("perms")), str(Edition.is_owner()), Skins.current_id, Skins.entries.size()]
	if sig == _snd_sig:
		return
	_snd_sig = sig
	SoundPanel.build_player(ui, _snd_box)


# ------------------------- موسیقی (برای همه‌ی بازیکن‌ها؛ برای هر حساب جدا) -------------------------
var _music_box: VBoxContainer


func _build_music_panel(col: VBoxContainer) -> void:
	_music_box = VBoxContainer.new()
	_music_box.add_theme_constant_override("separation", 10)
	col.add_child(_music_box)
	Music.changed.connect(_fill_music)
	Skins.changed.connect(_fill_music)
	Edition.changed.connect(_fill_music)
	_fill_music()


func _fill_music() -> void:
	for c in _music_box.get_children():
		c.queue_free()
	var B := _music_box
	B.add_child(ui._label("موسیقی و صدای شروع", 38, Color("ffb02e")))
	var note: Label = ui._label("این انتخاب‌ها برای همین حساب (بازیکن) ذخیره می‌شود؛ هر بازیکن می‌تواند آهنگ خودش را داشته باشد.", 20, Color("c9d6e6"))
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	B.add_child(note)
	for sc in ([["menu", "موسیقی منو"], ["game", "موسیقی هنگام بازی"]] if Content.perm_b("snd_music_pick") else []):
		var sid: String = sc[0]
		B.add_child(ui._label(String(sc[1]), 28, Color.WHITE))
		var fl := HFlowContainer.new()
		fl.add_theme_constant_override("h_separation", 8)
		fl.add_theme_constant_override("v_separation", 8)
		B.add_child(fl)
		for t in Music.all_tracks():
			var tid: String = t.id
			var on: bool = Music.choice(sid) == tid
			var row := HBoxContainer.new()
			fl.add_child(row)
			row.add_child(ui._button(("✓ " if on else "") + String(t.name), func():
				Music.set_choice(sid, tid)
				Music.preview(tid) if tid != Music.NONE else null, Vector2(0, 64), 22, "Gold" if on else "Dark"))
			if bool(t.own):
				row.add_child(ui._button("✕", func(): Music.remove_track(tid.substr(4)), Vector2(60, 64), 22, "Red"))
	if Content.perm_b("snd_music_import"):
		B.add_child(ui._button("+ افزودن آهنگ از گوشی (mp3 / ogg / wav)", func():
			var why := Content.import_block("music")
			if why != "":
				ui._show_toast(why)
				return
			ui.pick_file("music", func(_p): pass), Vector2(0, 72), 24, "Teal"))
	var ck := Skins.char_key(Skins.current_entry())
	if not Content.perm_b("snd_music_char") and not Content.perm_b("snd_start_pick"):
		return
	if not Content.perm_b("snd_music_char"):
		_fill_start_sound(B)
		return
	B.add_child(ui._label("موسیقی مخصوص کاراکتر فعلی: %s" % String(Skins.current_entry().get("name", "")), 28, Color("ffd24a")))
	var cn: Label = ui._label("وقتی با این کاراکتر بازی می‌کنی همین آهنگ پخش می‌شود. «پیش‌فرض» یعنی از موسیقی هنگام بازی (بالا) پیروی کند. برای کاراکتر دیگر، اول آن را در بخش «کاراکتر» انتخاب کن.", 20, Color("c9d6e6"))
	cn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	cn.custom_minimum_size = Vector2(600, 0)
	B.add_child(cn)
	var cf := HFlowContainer.new()
	cf.add_theme_constant_override("h_separation", 8)
	cf.add_theme_constant_override("v_separation", 8)
	B.add_child(cf)
	var opts: Array = [{"id": "", "name": "پیش‌فرض"}]
	opts.append_array(Music.all_tracks())
	for t in opts:
		var tid: String = t.id
		var on: bool = Music.char_choice(ck) == tid
		cf.add_child(ui._button(("✓ " if on else "") + String(t.name), func():
			Music.set_char_choice(ck, tid)
			Music.preview(tid) if tid != "" and tid != Music.NONE else null, Vector2(0, 64), 22, "Gold" if on else "Dark"))
	_fill_start_sound(B)


func _fill_start_sound(B: VBoxContainer) -> void:
	if not Content.perm_b("snd_start_pick"):
		return
	B.add_child(ui._label("صدای شروع بازی", 28, Color.WHITE))
	var sf := HFlowContainer.new()
	sf.add_theme_constant_override("h_separation", 8)
	sf.add_theme_constant_override("v_separation", 8)
	B.add_child(sf)
	for ss in Music.START_SOUNDS:
		var ssid: String = ss[0]
		var son: bool = Music.choice("start") == ssid
		sf.add_child(ui._button(("✓ " if son else "") + String(ss[1]), func():
			Music.set_choice("start", ssid)
			if ssid != Music.NONE:
				Sfx.play(ssid), Vector2(0, 64), 22, "Gold" if son else "Dark"))


func _build_owner_panel(col: VBoxContainer) -> void:
	_owner_box = VBoxContainer.new()
	_owner_box.add_theme_constant_override("separation", 10)
	col.add_child(_owner_box)
	_owner_box.add_child(ui._label("پنل مالک", 40, Color("ff7a5a")))
	_owner_head = ui._label("", 24, Color(1, 1, 1, 0.85))
	_owner_head.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_owner_head.custom_minimum_size = Vector2(600, 0)
	_owner_box.add_child(_owner_head)
	_owner_box.add_child(ui._button("", func(): Edition.set_simulate_public(not Edition.simulate_public), Vector2(600, 72), 26, "Dark"))
	_owner_body = VBoxContainer.new()
	_owner_body.add_theme_constant_override("separation", 8)
	_owner_box.add_child(_owner_body)
	for k: String in Game.REMOTE_LIMITS:
		var lim: Array = Game.REMOTE_LIMITS[k]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		_owner_body.add_child(row)
		var l: Label = ui._label(TUNING_TITLES.get(k, k), 24)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		var sb := SpinBox.new()
		sb.min_value = float(lim[0])
		sb.max_value = float(lim[1])
		sb.step = 0.01 if (float(lim[1]) <= 50.0 and lim[0] is float) else 1.0
		sb.value = float(Game.get(k))
		sb.custom_minimum_size = Vector2(190, 56)
		sb.set_meta("key", k)
		sb.value_changed.connect(func(v: float): Game.set(k, int(v) if Game.get(k) is int else v))
		row.add_child(sb)
	_voice_btn = ui._button("", func():
		Game.set_voice(Skins.current_id, Game.voice_of(Skins.current_id) + 1)
		Sfx.voice("jump")
		get_tree().create_timer(0.35).timeout.connect(func(): Sfx.voice("hit"))
		_refresh_owner(), Vector2(600, 64), 24, "Teal")
	_owner_body.add_child(_voice_btn)
	_owner_body.add_child(ui._button("پخش صدای آزمایشی: قدم / سکه / پلیس", func(): Sfx.play("step"); Sfx.play("plus"); Sfx.play("horn"), Vector2(600, 64), 24, "Dark"))
	_owner_body.add_child(ui._button("اینترو اول بازی: روشن/خاموش", func(): Game.intro_on = not Game.intro_on; Game.save_game(); _owner_note("اینترو " + ("روشن شد" if Game.intro_on else "خاموش شد")), Vector2(600, 64), 24, "Dark"))
	_owner_body.add_child(ui._button("+۱۰۰۰ سکه (حساب مدیر)", func():
		var r: Dictionary = await Online.admin_grant_self(1000)
		_owner_note("۱۰۰۰ سکه اضافه شد" if r.ok else "ناموفق: حساب باید مدیر باشد (is_admin) و آنلاین"), Vector2(600, 72), 26, "Teal"))
	_owner_body.add_child(ui._button("ماموریت‌های جدید", func(): Game.missions.clear(); Game._ensure_missions(); Game.missions_changed.emit(); _owner_note("ماموریت‌ها عوض شد"), Vector2(600, 72), 26, "Teal"))
	_owner_body.add_child(ui._button("بازگرداندن مقدارهای پیش‌فرض", func(): Game.reset_tuning(); _sync_owner_values(); _owner_note("پیش‌فرض‌ها برگشت"), Vector2(600, 72), 26, "Red"))
	_owner_body.add_child(ui._button("ارسال این تنظیمات به همه‌ی بازیکنان", func(): _push_tuning(), Vector2(600, 80), 26, "Gold"))
	_perm_box = VBoxContainer.new()
	_perm_box.add_theme_constant_override("separation", 8)
	_owner_body.add_child(_perm_box)
	_owner_msg = ui._label("", 24, Color("ffd27a"))
	_owner_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_owner_msg.custom_minimum_size = Vector2(600, 0)
	_owner_box.add_child(_owner_msg)
	Edition.changed.connect(_refresh_owner)
	_refresh_owner()
	SoundPanel.build_perms(ui, _perm_box, _owner_note)


func _owner_note(t: String) -> void:
	_owner_msg.text = t


func _sync_owner_values() -> void:
	for row in _owner_body.get_children():
		for c in row.get_children():
			if c is SpinBox:
				c.value = float(Game.get(String(c.get_meta("key"))))


func _push_tuning() -> void:
	if not Online.is_admin:
		_owner_note("برای ارسال به همه، با حساب مدیر وارد شو (بخش حساب من).")
		return
	var r := await Online.push_game_config(Game.tuning_dict())
	_owner_note("برای همه ذخیره شد؛ بازیکنان در اجرای بعدی می‌گیرند." if r.ok else "خطا: " + String(r.error))


func _refresh_owner() -> void:
	_owner_box.visible = Edition.has_owner_rights()
	var btn: Button = _owner_box.get_child(2)
	btn.text = "حالا: نسخه‌ی عمومی (شبیه‌سازی) — برگشت به مالک" if Edition.simulate_public else "شبیه‌سازی نسخه‌ی عمومی (برای آزمودن)"
	_owner_body.visible = Edition.is_owner()
	if _voice_btn != null:
		_voice_btn.text = "صدای این کاراکتر: %s (لمس = بعدی)" % Sfx.VOICES[Game.voice_of(Skins.current_id)][0]
	_owner_head.text = "%s — همه‌ی قابلیت‌ها باز است: افزودن GLB دلخواه، تغییر مقدارهای گیم‌پلی روی همین دستگاه، سکه‌ی آزمایشی. برای اعمال روی همه‌ی بازیکنان از پنل وب (admin/index.html) یا دکمه‌ی ارسال استفاده کن." % Edition.label() if Edition.is_owner() else "نسخه‌ی عمومی (شبیه‌سازی‌شده): همین چیزی که بازیکنان می‌بینند."


func _add_slider(key: String, title: String, lo: float, hi: float, step: float) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	_body_box.add_child(row)
	var l: Label = ui._label(title, 24)
	l.custom_minimum_size = Vector2(190, 0)
	row.add_child(l)
	var sl := HSlider.new()
	sl.min_value = lo
	sl.max_value = hi
	sl.step = step
	sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl.custom_minimum_size = Vector2(0, 50)
	sl.value_changed.connect(func(v: float):
		if not _updating:
			_set_cfg(key, v))
	row.add_child(sl)
	_sliders[key] = sl


func _entry() -> Dictionary:
	return PoliceCfg.as_entry() if _target == "police" else Skins.current_entry()


func _cfg() -> Dictionary:
	return PoliceCfg.cfg() if _target == "police" else Skins.glb_cfg(Skins.current_entry())


func _set_cfg(k: String, v) -> void:
	if _target == "police":
		PoliceCfg.set_cfg(k, v)
	else:
		Skins.set_glb_cfg(k, v)


func _set_map(st: String, clip: String) -> void:
	if _target == "police":
		PoliceCfg.set_map(st, clip)
	else:
		Skins.set_glb_map(st, clip)


func _reset_cfg() -> void:
	if _target == "police":
		PoliceCfg.reset_cfg()
	else:
		Skins.reset_glb_cfg()


func _cycle_yaw() -> void:
	if _target == "police":
		PoliceCfg.cycle_yaw()
	else:
		Skins.cycle_glb_yaw()


var _police_sig := ""


func _on_police_changed() -> void:
	if _target != "police":
		return
	var sig := "%s|%d" % [PoliceCfg.model_path(), FileAccess.get_modified_time(PoliceCfg.model_path())]
	if sig != _police_sig:
		_police_sig = sig
		refresh()
		return
	var e := PoliceCfg.as_entry()
	if Skins.is_glb(e):
		ui._sync_preview_model("settings", e)
		_apply_preview_state()
	_sync_values()


func _set_target(t: String) -> void:
	_target = t
	_police_sig = "%s|%d" % [PoliceCfg.model_path(), FileAccess.get_modified_time(PoliceCfg.model_path())]
	refresh()


func _push_chaser() -> void:
	if not Online.is_admin:
		_owner_note("برای ارسال به همه، با حساب مدیر وارد شو (بخش حساب من).")
		return
	var d := PoliceCfg.cfg()
	d["yaw"] = PoliceCfg.yaw()
	var r := await Online.push_chaser_config(d)
	_owner_note("برای همه ذخیره شد." if r.ok else "خطا: " + String(r.error))


func _set_state(s: String) -> void:
	_cur_state = s
	_apply_preview_state()
	for k in _state_btns:
		(_state_btns[k] as Button).modulate = Color(1, 1, 1, 1) if k == s else Color(1, 1, 1, 0.55)


func _apply_preview_state() -> void:
	if ui._pv.has("settings"):
		var c = ui._pv["settings"]["content"]
		if c.get("is_glb") == true:
			c.preview_state = _cur_state


func _on_map(state: String, ob: OptionButton, idx: int) -> void:
	if _updating:
		return
	var meta = ob.get_item_metadata(idx)
	_set_map(state, str(meta))


## هنگام باز شدن صفحه یا تغییر کاراکتر
func refresh() -> void:
	if _sound_btn == null:
		return
	_sound_btn.visible = Content.perm_b("snd_toggle")
	if Edition.is_owner() and _perm_box != null:
		SoundPanel.build_perms(ui, _perm_box, _owner_note)
	_maybe_rebuild_sound()
	_sound_btn.text = "صدا: " + ("روشن" if Game.sound_on else "خاموش")
	_vib_btn.text = "لرزش: " + ("روشن" if Game.vibration_on else "خاموش")
	_intro_btn.text = "اینترو اول بازی: " + ("روشن" if Game.intro_on else "خاموش")
	if not Edition.is_owner():
		_target = "char"
	_target_box.visible = Edition.is_owner()
	_police_box.visible = _target == "police"
	for k in _target_btns:
		(_target_btns[k] as Button).modulate = Color.WHITE if k == _target else Color(1, 1, 1, 0.55)
	var e: Dictionary = _entry()
	var glb := Skins.is_glb(e)
	# بازیکن عمومی بدون مدل GLB چیزی برای کنترل ندارد → کل بخش پنهان می‌شود
	var extra := Content.can("settings_extra")
	_vib_btn.visible = extra
	_intro_btn.visible = extra
	var show_ctrl := (Edition.is_owner() or glb) and extra
	_ctrl_head.visible = show_ctrl
	_no_glb_box.visible = not glb and show_ctrl
	_body_box.visible = glb and extra
	if not extra:
		_target_box.visible = false
	_no_glb_goto.visible = _target == "char"
	if _target == "police":
		_no_glb_lbl.text = "هنوز مدلی برای پلیس نیست. فایل GLB را با نام police.glb داخل پوشه‌ی assets پروژه بگذار، یا با دکمه‌ی پایین همین‌جا انتخاب کن."
	else:
		_no_glb_lbl.text = "این بخش برای کاراکترهای سه‌بعدی GLB است. اول در بخش «کاراکتر» یک مدل GLB اضافه یا انتخاب کن؛ بعد اینجا اندازه، حرکت‌ها و بدنش را کنترل می‌کنی."
	if not glb:
		return
	ui._sync_preview_model("settings", e if _target == "police" else {})
	_apply_preview_state()
	var m = ui._pv["settings"]["content"]
	var clips: Array[String] = m.clip_names
	_info_lbl.text = "%s\nکلیپ‌های فایل: %s" % [m.rig_info, "، ".join(clips) if not clips.is_empty() else "ندارد"]
	var roles: Array[String] = m.rig_roles()
	_bones_lbl.text = "\n".join(roles) if not roles.is_empty() else "—"
	var sig := "|".join(clips)
	_rebuild_opts(m, clips)
	_clip_sig = sig
	_sync_values()
	_set_state(_cur_state)


func _rebuild_opts(m, clips: Array[String]) -> void:
	_updating = true
	for st in GlbModel.STATES:
		var ob: OptionButton = _map_opts[st]
		ob.clear()
		ob.add_item("خودکار")
		ob.set_item_metadata(0, "")
		ob.add_item("حرکت ساختگی (کد)")
		ob.set_item_metadata(1, "-")
		for c in clips:
			ob.add_item(c)
			ob.set_item_metadata(ob.item_count - 1, c)
	_updating = false


func _sync_values() -> void:
	var e: Dictionary = _entry()
	if not Skins.is_glb(e) or _sliders.is_empty():
		return
	var c: Dictionary = _cfg()
	_updating = true
	for k in _sliders:
		(_sliders[k] as HSlider).value = float(c[k])
	_proc_btn.text = "حرکت خودکار روی استخوان‌ها: " + ("روشن" if bool(c["proc"]) else "خاموش")
	var map: Dictionary = c.get("map", {})
	for st in GlbModel.STATES:
		var ob: OptionButton = _map_opts[st]
		var want := String(map.get(st, ""))
		var sel := 0
		for i in ob.item_count:
			if str(ob.get_item_metadata(i)) == want:
				sel = i
				break
		ob.select(sel)
	_updating = false
