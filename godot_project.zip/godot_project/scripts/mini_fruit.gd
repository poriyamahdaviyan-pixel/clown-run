class_name MiniFruit
extends MiniBase
## «برش میوه» (سبک نینجای میوه): انگشت را روی صفحه بکش و میوه‌های پرتابی را ببُر. به بمب نزن (−۵ ثانیه)!
## ۳ میوه یا بیشتر با یک کشیدن = کمبو و پاداش. میوه‌ی طلایی ۱۰ سکه می‌دهد.

const GRAV := 1500.0
const FRUITS := [
	{"c": "e8342f", "i": "ffd0c0", "r": 54.0},   # سیب
	{"c": "ff9a1f", "i": "ffd88a", "r": 58.0},   # پرتقال
	{"c": "3aa84a", "i": "ff5a6a", "r": 66.0},   # هندوانه
	{"c": "ffe03a", "i": "fff6b0", "r": 50.0},   # لیمو
	{"c": "8a4fd0", "i": "d8b0ff", "r": 44.0},   # انگور
]

var _cv: Control
var _items: Array[Dictionary] = []
var _halves: Array[Dictionary] = []
var _drops: Array[Dictionary] = []
var _trail: Array[Dictionary] = []     # {p, t}
var _rng := RandomNumberGenerator.new()
var _spawn_t := 0.6
var _last := Vector2.ZERO
var _down := false
var _swipe_hits := 0
var _bomb_flash := 0.0
var _t := 0.0


func _ready() -> void:
	title = "برش میوه"
	hint = "با انگشت بکش و میوه‌ها را ببُر\nبه بمب نزن!"
	accent = Color("3de06a")
	duration = 40.0
	_rng.randomize()
	var env := make_env(Color("2a1a4a"), Color("6a3a8a"), Color("2a1a4a"), 0.0, Color.WHITE, 1.0)
	_build_base(env)
	stick.enabled = false
	var bg := ColorRect.new()
	bg.color = Color("2a1d3a")
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var layer := CanvasLayer.new()
	layer.layer = 3
	add_child(layer)
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color("2a1650"), Color("a83a6a"), Color("ff9a4a")])
	grad.offsets = PackedFloat32Array([0.0, 0.62, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0.5, 0.0)
	gt.fill_to = Vector2(0.5, 1.0)
	var tr := TextureRect.new()
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.set_anchors_preset(Control.PRESET_FULL_RECT)
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(tr)
	var scn := Control.new()
	scn.set_anchors_preset(Control.PRESET_FULL_RECT)
	scn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scn.draw.connect(func(): _draw_scenery(scn))
	layer.add_child(scn)
	_cv = Control.new()
	_cv.set_anchors_preset(Control.PRESET_FULL_RECT)
	_cv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_cv.draw.connect(_on_draw)
	layer.add_child(_cv)


## پس‌زمینه‌ی دوجو: خورشید غروب، کوه‌ها، بامبو و کف چوبی
func _draw_scenery(c: Control) -> void:
	var s := c.size
	var sun := Vector2(s.x * 0.5, s.y * 0.5)
	c.draw_circle(sun, s.x * 0.30, Color(1.0, 0.82, 0.45, 0.22))
	c.draw_circle(sun, s.x * 0.21, Color(1.0, 0.86, 0.5, 0.9))
	var m1 := PackedVector2Array([Vector2(0, s.y * 0.66), Vector2(s.x * 0.18, s.y * 0.5), Vector2(s.x * 0.36, s.y * 0.64), Vector2(s.x * 0.58, s.y * 0.46), Vector2(s.x * 0.8, s.y * 0.63), Vector2(s.x, s.y * 0.52), Vector2(s.x, s.y * 0.8), Vector2(0, s.y * 0.8)])
	c.draw_colored_polygon(m1, Color("3a1a5a"))
	var m2 := PackedVector2Array([Vector2(0, s.y * 0.76), Vector2(s.x * 0.25, s.y * 0.62), Vector2(s.x * 0.5, s.y * 0.74), Vector2(s.x * 0.75, s.y * 0.6), Vector2(s.x, s.y * 0.74), Vector2(s.x, s.y * 0.9), Vector2(0, s.y * 0.9)])
	c.draw_colored_polygon(m2, Color("22103c"))
	# بامبو
	for i in 7:
		var x := s.x * (0.04 + 0.15 * float(i)) + (18.0 if i % 2 == 0 else -6.0)
		var top := s.y * (0.18 + 0.07 * float(i % 3))
		c.draw_rect(Rect2(x, top, 14.0, s.y - top), Color("1c3a2a"))
		var yy := top + 60.0
		while yy < s.y:
			c.draw_rect(Rect2(x - 2.0, yy, 18.0, 5.0), Color("2f6a46"))
			yy += 120.0
	# کف چوبی
	c.draw_rect(Rect2(0, s.y * 0.92, s.x, s.y * 0.08), Color("5a3320"))
	var px := 0.0
	while px < s.x:
		c.draw_rect(Rect2(px, s.y * 0.92, 3.0, s.y * 0.08), Color("3a2012"))
		px += 90.0
	c.draw_rect(Rect2(0, s.y * 0.92, s.x, 6.0), Color("8a5a38"))


func _size() -> Vector2:
	return get_viewport().get_visible_rect().size


func _spawn() -> void:
	var s := _size()
	var r := _rng.randf()
	var kind := 0       # 0 میوه 1 بمب 2 طلایی
	if r < 0.16 + minf(_t * 0.002, 0.08):
		kind = 1
	elif r > 0.965:
		kind = 2
	var fx := _rng.randf_range(s.x * 0.18, s.x * 0.82)
	var tx := s.x * 0.5 + (s.x * 0.5 - fx) * _rng.randf_range(0.2, 0.7)
	var peak := _rng.randf_range(s.y * 0.42, s.y * 0.7)
	var vy := -sqrt(2.0 * GRAV * peak)
	var tt := -vy / GRAV
	var vx := (tx - fx) / (tt * 1.2)
	var f: Dictionary = FRUITS[_rng.randi() % FRUITS.size()]
	_items.append({"p": Vector2(fx, s.y + 70.0), "v": Vector2(vx, vy), "kind": kind, "f": f, "rot": 0.0, "w": _rng.randf_range(-4.0, 4.0), "r": 56.0 if kind != 0 else float(f["r"])})


func _tick(delta: float) -> void:
	_t += delta
	var s := _size()
	_spawn_t -= delta
	if _spawn_t <= 0.0:
		var n := 1 + (1 if _rng.randf() < 0.45 else 0) + (1 if _rng.randf() < 0.2 and _t > 8.0 else 0)
		for i in n:
			_spawn()
		_spawn_t = maxf(0.55, 1.1 - _t * 0.012)
	for i in range(_items.size() - 1, -1, -1):
		var it: Dictionary = _items[i]
		it["v"] = (it["v"] as Vector2) + Vector2(0, GRAV * delta)
		it["p"] = (it["p"] as Vector2) + (it["v"] as Vector2) * delta
		it["rot"] = float(it["rot"]) + float(it["w"]) * delta
		if (it["p"] as Vector2).y > s.y + 120.0 and (it["v"] as Vector2).y > 0.0:
			_items.remove_at(i)
	for i in range(_halves.size() - 1, -1, -1):
		var h: Dictionary = _halves[i]
		h["v"] = (h["v"] as Vector2) + Vector2(0, GRAV * delta)
		h["p"] = (h["p"] as Vector2) + (h["v"] as Vector2) * delta
		h["rot"] = float(h["rot"]) + float(h["w"]) * delta
		if (h["p"] as Vector2).y > s.y + 150.0:
			_halves.remove_at(i)
	for i in range(_drops.size() - 1, -1, -1):
		var d: Dictionary = _drops[i]
		d["v"] = (d["v"] as Vector2) + Vector2(0, GRAV * 0.5 * delta)
		d["p"] = (d["p"] as Vector2) + (d["v"] as Vector2) * delta
		d["life"] = float(d["life"]) - delta
		if float(d["life"]) <= 0.0:
			_drops.remove_at(i)
	for i in range(_trail.size() - 1, -1, -1):
		_trail[i]["t"] = float(_trail[i]["t"]) - delta
		if float(_trail[i]["t"]) <= 0.0:
			_trail.remove_at(i)
	_bomb_flash = maxf(0.0, _bomb_flash - delta)
	if _cv != null:
		_cv.queue_redraw()


func _input(event: InputEvent) -> void:
	if not running:
		return
	if event is InputEventScreenTouch:
		_down = event.pressed
		_last = event.position
		if _down:
			_swipe_hits = 0
		else:
			_end_swipe()
	elif event is InputEventScreenDrag:
		_move_to(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_down = event.pressed
		_last = event.position
		if _down:
			_swipe_hits = 0
		else:
			_end_swipe()
	elif event is InputEventMouseMotion and _down:
		_move_to(event.position)


func _move_to(p: Vector2) -> void:
	_trail.append({"p": p, "t": 0.22})
	for i in range(_items.size() - 1, -1, -1):
		var it: Dictionary = _items[i]
		if _seg_hits(_last, p, it["p"] as Vector2, float(it["r"])):
			_slice(i, p - _last)
	_last = p


func _end_swipe() -> void:
	if _swipe_hits >= 3:
		var b := _swipe_hits * 2
		add_coins(b)
		say("کمبو ×%d  +%d" % [_swipe_hits, b], 0.9)
	_swipe_hits = 0


static func _seg_hits(a: Vector2, b: Vector2, c: Vector2, r: float) -> bool:
	var ab := b - a
	var l2 := ab.length_squared()
	var t := 0.0 if l2 < 0.001 else clampf((c - a).dot(ab) / l2, 0.0, 1.0)
	return (a + ab * t).distance_to(c) <= r


func _slice(i: int, dir: Vector2) -> void:
	var it: Dictionary = _items[i]
	_items.remove_at(i)
	var p: Vector2 = it["p"]
	var f: Dictionary = it["f"]
	var kind := int(it["kind"])
	if kind == 1:
		time_left -= 5.0
		_bomb_flash = 0.4
		say("بمب! −۵ ثانیه", 0.9)
		for k in 18:
			_drops.append({"p": p, "v": Vector2.from_angle(_rng.randf() * TAU) * _rng.randf_range(200, 700), "life": 0.5, "c": Color("ffb030"), "r": _rng.randf_range(5.0, 12.0)})
		return
	var col := Color(String(f["c"]))
	var inner := Color(String(f["i"]))
	if kind == 2:
		col = Color("ffcf30")
		inner = Color("fff4b0")
		add_coins(10)
		say("میوه‌ی طلایی! +۱۰", 0.9)
	else:
		add_coins(1)
	_swipe_hits += 1
	var nrm := Vector2(-dir.y, dir.x).normalized() if dir.length() > 0.1 else Vector2.RIGHT
	for sgn in [-1.0, 1.0]:
		_halves.append({"p": p, "v": (it["v"] as Vector2) * 0.5 + nrm * sgn * 260.0, "rot": float(it["rot"]), "w": sgn * _rng.randf_range(2.0, 6.0), "c": col, "i": inner, "r": float(it["r"]), "a": nrm.angle() + (0.0 if sgn > 0 else PI)})
	for k in 14:
		_drops.append({"p": p, "v": Vector2.from_angle(_rng.randf() * TAU) * _rng.randf_range(120, 520), "life": 0.6, "c": inner, "r": _rng.randf_range(4.0, 10.0)})


func _on_draw() -> void:
	var s := _size()
	# جرقه‌های پس‌زمینه (ستاره‌های ثابت)
	var rs := RandomNumberGenerator.new()
	rs.seed = 5
	for i in 40:
		_cv.draw_circle(Vector2(rs.randf() * s.x, rs.randf() * s.y), rs.randf_range(1.0, 2.6), Color(1, 1, 1, 0.25))
	for d in _drops:
		var c: Color = d["c"]
		c.a = clampf(float(d["life"]) * 2.0, 0.0, 1.0)
		_cv.draw_circle(d["p"] as Vector2, float(d["r"]), c)
	for h in _halves:
		_draw_half(h)
	for it in _items:
		_draw_item(it)
	# رد انگشت
	for i in range(1, _trail.size()):
		var a: Dictionary = _trail[i - 1]
		var b: Dictionary = _trail[i]
		var w := 4.0 + 14.0 * float(b["t"]) / 0.22
		_cv.draw_line(a["p"] as Vector2, b["p"] as Vector2, Color(1, 1, 1, float(b["t"]) / 0.22), w)
	if _bomb_flash > 0.0:
		_cv.draw_rect(Rect2(Vector2.ZERO, s), Color(1, 0.3, 0.1, _bomb_flash * 0.8))


func _draw_item(it: Dictionary) -> void:
	var p: Vector2 = it["p"]
	var r := float(it["r"])
	var kind := int(it["kind"])
	if kind == 1:
		_cv.draw_circle(p, r, Color("15121c"))
		_cv.draw_circle(p + Vector2(-r * 0.3, -r * 0.3), r * 0.28, Color(1, 1, 1, 0.18))
		_cv.draw_line(p + Vector2(0, -r), p + Vector2(r * 0.4, -r * 1.4), Color("c8a060"), 6.0)
		_cv.draw_circle(p + Vector2(r * 0.4, -r * 1.4), 9.0 + 3.0 * sin(_t * 30.0), Color("ffb030"))
		_cv.draw_string(ThemeDB.fallback_font, p + Vector2(-r * 0.3, r * 0.3), "☠", HORIZONTAL_ALIGNMENT_LEFT, -1, int(r))
		return
	var f: Dictionary = it["f"]
	var col := Color(String(f["c"])) if kind == 0 else Color("ffcf30")
	_cv.draw_circle(p + Vector2(4, 6), r, Color(0, 0, 0, 0.25))
	_cv.draw_circle(p, r, col)
	_cv.draw_circle(p + Vector2(-r * 0.32, -r * 0.34), r * 0.3, Color(1, 1, 1, 0.3))
	_cv.draw_line(p + Vector2(0, -r * 0.9), p + Vector2(r * 0.15, -r * 1.2), Color("5a3a1c"), 5.0)
	if kind == 2:
		_cv.draw_arc(p, r + 6.0, 0.0, TAU, 32, Color(1, 0.9, 0.4, 0.6 + 0.4 * sin(_t * 12.0)), 4.0)


func _draw_half(h: Dictionary) -> void:
	var p: Vector2 = h["p"]
	var r := float(h["r"])
	var a := float(h["a"]) + float(h["rot"])
	var pts := PackedVector2Array()
	for k in 13:
		var ang := a - PI * 0.5 + PI * float(k) / 12.0
		pts.append(p + Vector2.from_angle(ang) * r)
	_cv.draw_colored_polygon(pts, h["c"] as Color)
	var pts2 := PackedVector2Array()
	for k in 13:
		var ang2 := a - PI * 0.5 + PI * float(k) / 12.0
		pts2.append(p + Vector2.from_angle(ang2) * r * 0.82)
	_cv.draw_colored_polygon(pts2, h["i"] as Color)
