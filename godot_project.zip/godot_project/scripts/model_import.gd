class_name ModelImport
extends RefCounted
## ورود مدل سه‌بعدی با فرمت‌های مختلف: GLB، glTF، VRM، FBX، OBJ
## همه به یک فایل GLB داخل حافظه‌ی برنامه تبدیل می‌شوند (انیمیشن، اسکلت و تکسچر حفظ می‌شود).

const EXTS := ["glb", "gltf", "vrm", "fbx", "obj", "zip", "bin"]
const TMP := "user://import_tmp"
const PRIORITY := ["glb", "vrm", "gltf", "fbx", "obj"]


static func is_model(path: String) -> bool:
	return path.get_extension().to_lower() in EXTS


## فایل را به GLB در dst تبدیل/کپی می‌کند. خطا یا "".
static func to_glb(src: String, dst: String) -> String:
	var ext := src.get_extension().to_lower()
	if not FileAccess.file_exists(src):
		return "فایل پیدا نشد"
	if ext == "zip":
		return _from_zip(src, dst)
	if ext == "bin" or not ext in ["glb", "vrm", "gltf", "fbx", "obj"]:
		return _from_unknown(src, dst)
	match ext:
		"glb", "vrm":
			var bytes := FileAccess.get_file_as_bytes(src)
			if bytes.is_empty():
				return "فایل خوانده نشد. روی گوشی مجوز دسترسی را بده"
			var f := FileAccess.open(dst, FileAccess.WRITE)
			if f == null:
				return "ذخیره‌ی فایل ناموفق بود"
			f.store_buffer(bytes)
			f.close()
			return ""
		"gltf":
			return _convert_with(GLTFDocument.new(), GLTFState.new(), src, dst)
		"fbx":
			if not ClassDB.class_exists("FBXDocument"):
				return "این نسخه‌ی Godot از FBX پشتیبانی نمی‌کند؛ فایل را در Blender به GLB تبدیل کن"
			return _convert_with(ClassDB.instantiate("FBXDocument"), ClassDB.instantiate("FBXState"), src, dst)
		"obj":
			return _convert_obj(src, dst)
	return "فرمت پشتیبانی نمی‌شود"


## فایل با پسوند نامعلوم/bin: از روی سرآیند فرمتش را تشخیص می‌دهد
static func _from_unknown(src: String, dst: String) -> String:
	var f := FileAccess.open(src, FileAccess.READ)
	if f == null:
		return "فایل خوانده نشد. روی گوشی مجوز دسترسی را بده"
	var head := f.get_buffer(64)
	f.close()
	var h := head.get_string_from_ascii()
	var kind := ""
	if h.begins_with("glTF"):
		kind = "glb"
	elif h.begins_with("Kaydara FBX Binary") or h.begins_with("; FBX"):
		kind = "fbx"
	elif head.size() >= 4 and head[0] == 0x50 and head[1] == 0x4B:
		kind = "zip"
	elif h.strip_edges().begins_with("{") and FileAccess.get_file_as_string(src).contains("\"asset\""):
		kind = "gltf"
	elif h.begins_with("#") or h.begins_with("v ") or h.begins_with("mtllib") or h.begins_with("o "):
		kind = "obj"
	if kind != "":
		DirAccess.make_dir_recursive_absolute(TMP)
		var tmp := "%s/sniff_%d.%s" % [TMP, Time.get_ticks_usec(), kind]
		var bytes := FileAccess.get_file_as_bytes(src)
		var w := FileAccess.open(tmp, FileAccess.WRITE)
		if w == null:
			return "ذخیره‌ی فایل ناموفق بود"
		w.store_buffer(bytes)
		w.close()
		var r := to_glb(tmp, dst)
		DirAccess.remove_absolute(tmp)
		return r
	if src.get_extension().to_lower() == "bin":
		# bin جداگانه، داده‌ی خامِ یک glTF است؛ خودِ فایل gltf کنار آن را پیدا می‌کنیم
		var dir := src.get_base_dir()
		var d := DirAccess.open(dir)
		if d != null:
			var cands: Array = []
			for fn in d.get_files():
				if fn.get_extension().to_lower() == "gltf":
					cands.append(fn)
			var best := ""
			for fn in cands:
				if fn.get_basename() == src.get_file().get_basename() or FileAccess.get_file_as_string(dir.path_join(fn)).contains(src.get_file()):
					best = fn
					break
			if best == "" and cands.size() == 1:
				best = cands[0]
			if best != "":
				return to_glb(dir.path_join(best), dst)
		return "فایل bin به‌تنهایی مدل نیست. فایل gltf کنار آن را انتخاب کن (bin کنارش باشد) یا کل پوشه را zip کن و zip را بده"
	var ext := src.get_extension().to_lower()
	if ext in ["rar", "7z", "blend", "dae", "3ds", "max", "ma", "mb", "stl", "ply"]:
		return "فرمت «%s» را بازی مستقیم نمی‌خواند. در Blender (رایگان) باز کن و Export → glTF 2.0 بزن؛ یا خروجی FBX/OBJ بگیر" % ext
	return "فرمت فایل شناخته نشد. فرمت‌های پذیرفته: glb، gltf، vrm، fbx، obj، zip (حاوی مدل) و bin"


## zip: همه‌چیز در پوشه‌ی موقت باز می‌شود (تکسچر و bin کنار مدل می‌ماند)، بهترین مدل داخلش تبدیل می‌شود
static func _from_zip(src: String, dst: String) -> String:
	var zr := ZIPReader.new()
	if zr.open(src) != OK:
		return "zip باز نشد یا خراب است"
	var root := "%s/zip_%d" % [TMP, Time.get_ticks_usec()]
	DirAccess.make_dir_recursive_absolute(root)
	var found := {}                 # ext → [path, size]
	for entry in zr.get_files():
		if entry.ends_with("/") or entry.begins_with("/") or entry.contains("..") or entry.begins_with("__MACOSX"):
			continue
		var data := zr.read_file(entry)
		var out := root.path_join(entry)
		DirAccess.make_dir_recursive_absolute(out.get_base_dir())
		var w := FileAccess.open(out, FileAccess.WRITE)
		if w == null:
			continue
		w.store_buffer(data)
		w.close()
		var e := entry.get_extension().to_lower()
		if e in PRIORITY and (not found.has(e) or int(found[e][1]) < data.size()):
			found[e] = [out, data.size()]
	zr.close()
	var result := "داخل zip مدلی پیدا نشد (glb، gltf، vrm، fbx یا obj لازم است)"
	for e in PRIORITY:
		if found.has(e):
			result = to_glb(String(found[e][0]), dst)
			break
	_rm_tree(root)
	return result


static func _rm_tree(dir: String) -> void:
	var d := DirAccess.open(dir)
	if d == null:
		return
	for sub in d.get_directories():
		_rm_tree(dir.path_join(sub))
	for fn in d.get_files():
		d.remove(fn)
	DirAccess.remove_absolute(dir)


static func _convert_with(doc, st, src: String, dst: String) -> String:
	var err: int = doc.append_from_file(src, st)
	if err != OK:
		return "فایل خوانده نشد یا معتبر نیست (کد %d). اگر glTF فایل‌های جانبی (bin و تکسچر) دارد، کنار فایل باشند" % err
	var scene: Node = doc.generate_scene(st)
	if scene == null:
		return "مدلی در فایل پیدا نشد"
	return _write_scene(scene, dst)


static func _write_scene(scene: Node, dst: String) -> String:
	var gd := GLTFDocument.new()
	var gs := GLTFState.new()
	var err := gd.append_from_scene(scene, gs)
	if err != OK:
		scene.free()
		return "تبدیل مدل ناموفق بود"
	err = gd.write_to_filesystem(gs, dst)
	scene.free()                       # بعد از نوشتن (قبلش Godot کرش می‌کند)
	if err != OK:
		return "ذخیره‌ی مدل ناموفق بود (جای خالی کافی است؟)"
	return ""


static func _convert_obj(src: String, dst: String) -> String:
	var txt := FileAccess.get_file_as_string(src)
	if txt == "":
		return "فایل OBJ خوانده نشد"
	var v: Array[Vector3] = []
	var vt: Array[Vector2] = []
	var vn: Array[Vector3] = []
	var mtl_tex := ""
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var has_n := false
	var tri_count := 0
	for line in txt.split("\n"):
		var l := line.strip_edges()
		if l.begins_with("v "):
			var p := l.substr(2).split(" ", false)
			if p.size() >= 3:
				v.append(Vector3(float(p[0]), float(p[1]), float(p[2])))
		elif l.begins_with("vt "):
			var p2 := l.substr(3).split(" ", false)
			if p2.size() >= 2:
				vt.append(Vector2(float(p2[0]), 1.0 - float(p2[1])))
		elif l.begins_with("vn "):
			var p3 := l.substr(3).split(" ", false)
			if p3.size() >= 3:
				vn.append(Vector3(float(p3[0]), float(p3[1]), float(p3[2])))
		elif l.begins_with("mtllib "):
			mtl_tex = _mtl_texture(src.get_base_dir().path_join(l.substr(7).strip_edges()), src.get_base_dir())
		elif l.begins_with("f "):
			var idx := l.substr(2).split(" ", false)
			for k in range(1, idx.size() - 1):
				for corner in [0, k, k + 1]:
					var parts := String(idx[corner]).split("/")
					var vi := _ix(int(parts[0]), v.size())
					if vi < 0:
						continue
					if parts.size() > 1 and parts[1] != "":
						var ti := _ix(int(parts[1]), vt.size())
						if ti >= 0:
							st.set_uv(vt[ti])
					if parts.size() > 2 and parts[2] != "":
						var ni := _ix(int(parts[2]), vn.size())
						if ni >= 0:
							st.set_normal(vn[ni])
							has_n = true
					st.add_vertex(v[vi])
				tri_count += 1
	if tri_count == 0:
		return "این OBJ مثلثی ندارد"
	if not has_n:
		st.generate_normals()
	var mesh := st.commit()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.85, 0.85, 0.9)
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	if mtl_tex != "" and FileAccess.file_exists(mtl_tex):
		var img := Image.load_from_file(mtl_tex)
		if img != null and not img.is_empty():
			mat.albedo_texture = ImageTexture.create_from_image(img)
			mat.albedo_color = Color.WHITE
	mesh.surface_set_material(0, mat)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.name = src.get_file().get_basename()
	var root := Node3D.new()
	root.add_child(mi)
	mi.owner = root
	return _write_scene(root, dst)


static func _ix(i: int, n: int) -> int:
	if i > 0 and i <= n:
		return i - 1
	if i < 0 and -i <= n:
		return n + i
	return -1


static func _mtl_texture(mtl_path: String, base: String) -> String:
	if not FileAccess.file_exists(mtl_path):
		return ""
	for line in FileAccess.get_file_as_string(mtl_path).split("\n"):
		var l := line.strip_edges()
		if l.begins_with("map_Kd "):
			return base.path_join(l.substr(7).strip_edges().get_file())
	return ""
