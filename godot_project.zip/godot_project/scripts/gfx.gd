extends RefCounted
## ابزارهای گرافیکی مشترک (همه static): تکسچرهای ساخته‌شده با کد، متریال و ساخت مش.
## هیچ فایل تصویری لازم نیست؛ همه‌چیز موقع اجرا ساخته و کش می‌شود.

static var _cache := {}
static var _mesh_cache := {}


# ===================== ابزار پایه =====================
static func _img(w: int, h: int, c: Color) -> Image:
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	img.fill(c)
	return img


static func _tex(img: Image, mipmaps: bool = true) -> ImageTexture:
	if mipmaps:
		img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


static func _shade(c: Color, f: float) -> Color:
	return Color(clampf(c.r * f, 0.0, 1.0), clampf(c.g * f, 0.0, 1.0), clampf(c.b * f, 0.0, 1.0), c.a)


# ===================== تکسچرها =====================
## هاله‌ی نرم (برای نورها و سایه‌ها)
static func glow_tex() -> ImageTexture:
	if _cache.has("glow"):
		return _cache["glow"]
	var n := 64
	var img := _img(n, n, Color(1, 1, 1, 0))
	for y in n:
		for x in n:
			var d := Vector2(x - n * 0.5 + 0.5, y - n * 0.5 + 0.5).length() / (n * 0.5)
			var a := clampf(1.0 - d, 0.0, 1.0)
			img.set_pixel(x, y, Color(1, 1, 1, a * a))
	var t := _tex(img, false)
	_cache["glow"] = t
	return t


static func hazard_tex() -> ImageTexture:
	if _cache.has("hazard"):
		return _cache["hazard"]
	var img := _img(64, 64, Color.BLACK)
	for y in 64:
		for x in 64:
			var on := floori((x + y) / 10.0) % 2 == 0
			img.set_pixel(x, y, Color("ffc400") if on else Color("1c1c1c"))
	var t := _tex(img)
	_cache["hazard"] = t
	return t


static func noise_tex(base: Color, amp: float, size: int, seed_v: int) -> ImageTexture:
	var key := "noise_%s_%d_%d" % [base.to_html(), size, seed_v]
	if _cache.has(key):
		return _cache[key]
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_v
	var img := _img(size, size, base)
	for y in size:
		for x in size:
			img.set_pixel(x, y, _shade(base, 1.0 + rng.randf_range(-amp, amp)))
	var t := _tex(img)
	_cache[key] = t
	return t


static func crate_tex() -> ImageTexture:
	if _cache.has("crate"):
		return _cache["crate"]
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var wood := Color("a8743a")
	var img := _img(64, 64, wood)
	for y in 64:
		for x in 64:
			var plank := floori(y / 16.0)
			var f := 1.0 + rng.randf_range(-0.07, 0.07) + (plank % 2) * 0.05
			if y % 16 == 0:
				f *= 0.6
			img.set_pixel(x, y, _shade(wood, f))
	var dark := Color("5a3b1c")
	for i in 64:
		for k in 4:
			img.set_pixel(i, k, dark)
			img.set_pixel(i, 63 - k, dark)
			img.set_pixel(k, i, dark)
			img.set_pixel(63 - k, i, dark)
	for i in 56:
		for k in 3:
			img.set_pixel(clampi(4 + i + k, 0, 63), 4 + i, dark)
	var t := _tex(img)
	_cache["crate"] = t
	return t


## بدنه‌ی کانتینر/واگن: شیارهای عمودی
static func ribs_tex() -> ImageTexture:
	if _cache.has("ribs"):
		return _cache["ribs"]
	var img := _img(64, 64, Color.WHITE)
	for y in 64:
		for x in 64:
			var f := 1.0 if floori(x / 4.0) % 2 == 0 else 0.84
			if y < 3 or y > 60:
				f = 0.55
			img.set_pixel(x, y, _shade(Color.WHITE, f))
	var t := _tex(img)
	_cache["ribs"] = t
	return t


## پنجره‌های روشن ساختمان
static func window_tex(seed_v: int, density: float, palette: Array) -> ImageTexture:
	var key := "win_%d" % seed_v
	if _cache.has(key):
		return _cache[key]
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_v
	var cols := 4
	var rows := 8
	var cell := 16
	var img := _img(cols * cell, rows * cell, Color("100a20"))
	for gy in rows:
		for gx in cols:
			var x0 := gx * cell
			var y0 := gy * cell
			var lit := rng.randf() < density
			var c: Color = palette[rng.randi() % palette.size()] if lit else Color("1b1433")
			if lit:
				c = _shade(c, rng.randf_range(0.7, 1.0))
			img.fill_rect(Rect2i(x0 + 3, y0 + 3, cell - 6, cell - 7), c)
			if lit:
				img.fill_rect(Rect2i(x0 + 3, y0 + 3, cell - 6, 2), _shade(c, 1.2))
	var t := _tex(img)
	_cache[key] = t
	return t


## نمای ساختمان: [آلبیدو، نقشه‌ی نور پنجره‌ها]
static func facade_tex(seed_v: int, density: float, palette: Array, wall: Color, glass: Color) -> Array:
	var key := "facade_%d" % seed_v
	if _cache.has(key):
		return _cache[key]
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_v
	var cols := 4
	var rows := 8
	var cell := 16
	var alb := _img(cols * cell, rows * cell, wall)
	var emi := _img(cols * cell, rows * cell, Color.BLACK)
	for y in rows * cell:
		for x in cols * cell:
			alb.set_pixel(x, y, _shade(wall, 1.0 + rng.randf_range(-0.035, 0.035)))
	for gy in rows:
		for gx in cols:
			var x0 := gx * cell
			var y0 := gy * cell
			var lit := rng.randf() < density
			var c: Color = glass
			if lit:
				c = palette[rng.randi() % palette.size()]
			alb.fill_rect(Rect2i(x0 + 3, y0 + 3, cell - 6, cell - 6), _shade(wall, 0.55))
			alb.fill_rect(Rect2i(x0 + 4, y0 + 4, cell - 8, cell - 8), c)
			if lit:
				emi.fill_rect(Rect2i(x0 + 4, y0 + 4, cell - 8, cell - 8), _shade(c, 0.8))
			else:
				alb.fill_rect(Rect2i(x0 + 4, y0 + 4, cell - 8, 2), _shade(glass, 1.4))
	var res := [_tex(alb), _tex(emi)]
	_cache[key] = res
	return res


static func road_tex() -> ImageTexture:
	if _cache.has("road"):
		return _cache["road"]
	var w := 256
	var h := 512
	var road_w := 8.4
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var base := Color("9a948d")
	var img := _img(w, h, base)
	for y in h:
		for x in w:
			img.set_pixel(x, y, _shade(base, 1.0 + rng.randf_range(-0.07, 0.07)))
	var px_per_m := float(w) / road_w
	# جای چرخ‌ها (تیره‌تر) در مرکز هر لِین
	for lane in [-2.4, 0.0, 2.4]:
		for off in [-0.5, 0.5]:
			var cx := int((road_w * 0.5 + lane + off) * px_per_m)
			pass
			for y in h:
				for x in range(cx - 5, cx + 5):
					img.set_pixel(x, y, _shade(img.get_pixel(x, y), 0.9))
	# ترک‌ها
	for i in 9:
		var x := rng.randf_range(10.0, w - 10.0)
		var y := rng.randf_range(0.0, h - 60.0)
		for k in 50:
			x += rng.randf_range(-1.6, 1.6)
			y += 1.0
			img.set_pixel(clampi(int(x), 0, w - 1), clampi(int(y), 0, h - 1), Color("4a4540"))
	# خط‌چین بین لِین‌ها و خط‌های لبه
	var dash := Color("f4efe6")
	for lx in [-1.2, 1.2]:
		var cx := int((road_w * 0.5 + lx) * px_per_m)
		for k in 4:
			img.fill_rect(Rect2i(cx - 3, k * 128 + 32, 6, 64), dash)
	var edge := Color("f2c94c")
	var ex := int((0.5 - 3.95 / road_w) * w)
	img.fill_rect(Rect2i(ex - 3, 0, 6, h), edge)
	img.fill_rect(Rect2i(w - ex - 3, 0, 6, h), edge)
	var inner := Color("f4efe6")
	img.fill_rect(Rect2i(ex + 9, 0, 3, h), inner)
	img.fill_rect(Rect2i(w - ex - 12, 0, 3, h), inner)
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	_cache["road"] = t
	return t


## نقشه‌ی زبری جاده: لکه‌های آب (براق) روی آسفالت زبر
static func road_rough_tex() -> ImageTexture:
	if _cache.has("road_rough"):
		return _cache["road_rough"]
	var w := 128
	var h := 256
	var rng := RandomNumberGenerator.new()
	rng.seed = 21
	var img := _img(w, h, Color(0.62, 0.62, 0.62, 1.0))
	for i in 7:
		var cx := rng.randf_range(10.0, w - 10.0)
		var cy := rng.randf_range(10.0, h - 10.0)
		var rx := rng.randf_range(6.0, 16.0)
		var ry := rng.randf_range(10.0, 30.0)
		for y in range(maxi(0, int(cy - ry)), mini(h, int(cy + ry))):
			for x in range(maxi(0, int(cx - rx)), mini(w, int(cx + rx))):
				var d := pow((x - cx) / rx, 2.0) + pow((y - cy) / ry, 2.0)
				if d < 1.0:
					var v := lerpf(0.08, 0.62, clampf(d, 0.0, 1.0))
					img.set_pixel(x, y, Color(v, v, v, 1.0))
	var t := _tex(img)
	_cache["road_rough"] = t
	return t


## لایه‌های ماسه‌سنگ (صحرا)
static func strata_tex(c1: Color, c2: Color, seed_v: int) -> ImageTexture:
	var key := "strata_%d" % seed_v
	if _cache.has(key):
		return _cache[key]
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_v
	var img := _img(64, 128, c1)
	var y := 0
	while y < 128:
		var band := rng.randi_range(4, 14)
		var col := c1.lerp(c2, rng.randf())
		for yy in range(y, mini(128, y + band)):
			for x in 64:
				img.set_pixel(x, yy, _shade(col, 1.0 + rng.randf_range(-0.04, 0.04)))
		y += band
	var t := _tex(img)
	_cache[key] = t
	return t


## سنگ‌فرش/آجر معبد
static func stone_tex() -> ImageTexture:
	if _cache.has("stone"):
		return _cache["stone"]
	var rng := RandomNumberGenerator.new()
	rng.seed = 31
	var base := Color("8c8a7a")
	var img := _img(64, 64, base)
	for by in 4:
		var off := 8 if by % 2 == 1 else 0
		for bx in 4:
			var tint := rng.randf_range(0.85, 1.1)
			var green := rng.randf() < 0.3
			for y in range(by * 16, by * 16 + 16):
				for x in range(bx * 16, bx * 16 + 16):
					var xx := (x + off) % 64
					var c := _shade(base, tint * (1.0 + rng.randf_range(-0.06, 0.06)))
					if green and y < by * 16 + 6:
						c = c.lerp(Color("5e8c3a"), 0.5)
					if y == by * 16 or x == bx * 16:
						c = _shade(c, 0.6)
					img.set_pixel(xx, y, c)
	var t := _tex(img)
	_cache["stone"] = t
	return t


## پوست درخت
static func bark_tex() -> ImageTexture:
	if _cache.has("bark"):
		return _cache["bark"]
	var rng := RandomNumberGenerator.new()
	rng.seed = 41
	var base := Color("6b4a2c")
	var img := _img(64, 64, base)
	for x in 64:
		var streak := 1.0 + rng.randf_range(-0.22, 0.12)
		for y in 64:
			img.set_pixel(x, y, _shade(base, streak * (1.0 + rng.randf_range(-0.05, 0.05))))
	var t := _tex(img)
	_cache["bark"] = t
	return t


static func paving_tex() -> ImageTexture:
	if _cache.has("paving"):
		return _cache["paving"]
	var rng := RandomNumberGenerator.new()
	rng.seed = 9
	var base := Color("b8aca0")
	var img := _img(64, 64, base)
	for y in 64:
		for x in 64:
			var f := 1.0 + rng.randf_range(-0.05, 0.05)
			if x % 16 == 0 or y % 16 == 0:
				f *= 0.7
			img.set_pixel(x, y, _shade(base, f))
	var t := _tex(img)
	_cache["paving"] = t
	return t


## آسمان شب ستاره‌دار (پانورامای equirectangular)
static func star_panorama() -> ImageTexture:
	if _cache.has("stars"):
		return _cache["stars"]
	var w := 1024
	var h := 512
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	var img := _img(w, h, Color.BLACK)
	var top := Color("0a0420")
	var mid := Color("3b1257")
	var hor := Color("b83a86")
	var bottom := Color("22073a")
	for y in h:
		var t := float(y) / float(h)
		var c: Color
		if t < 0.5:
			c = top.lerp(mid, pow(t / 0.5, 1.6)).lerp(hor, pow(maxf(0.0, (t - 0.38) / 0.12), 2.0))
		else:
			c = hor.lerp(bottom, clampf((t - 0.5) / 0.1, 0.0, 1.0))
		for x in w:
			img.set_pixel(x, y, c)
	for i in 700:
		var x := rng.randi_range(0, w - 1)
		var y := rng.randi_range(0, int(h * 0.42))
		var b := rng.randf_range(0.35, 1.0)
		var sc := Color(b, b, minf(1.0, b + 0.1), 1.0)
		if rng.randf() < 0.15:
			sc = Color(1.0, 0.8, 0.9, 1.0) * b
		img.set_pixel(x, y, sc)
		if b > 0.85:
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var q: Vector2i = Vector2i(x, y) + d
				if q.x >= 0 and q.x < w and q.y >= 0 and q.y < h:
					img.set_pixel(q.x, q.y, sc * 0.55)
	var t2 := _tex(img, false)
	_cache["stars"] = t2
	return t2


# ===================== متریال =====================
static func mat(color: Color, emission: float = 0.0, texture: Texture2D = null, rough: float = 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	if texture != null:
		m.albedo_texture = texture
		m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	m.roughness = rough
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	return m


static func glow_mat(color: Color) -> StandardMaterial3D:
	var key := "glowmat_" + color.to_html()
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.albedo_texture = glow_tex()
	m.albedo_color = color
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.billboard_keep_scale = true
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	_cache[key] = m
	return m


# ===================== ساخت مش =====================
static func _box_mesh(size: Vector3) -> BoxMesh:
	if not _mesh_cache.has(size):
		var b := BoxMesh.new()
		b.size = size
		_mesh_cache[size] = b
	return _mesh_cache[size]


static func box(parent: Node3D, size: Vector3, pos: Vector3, m: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = _box_mesh(size)
	mi.material_override = m
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


static func cyl(parent: Node3D, r_top: float, r_bottom: float, height: float, pos: Vector3, m: Material, rot_deg: Vector3 = Vector3.ZERO, segments: int = 12) -> MeshInstance3D:
	var key := "cyl_%.3f_%.3f_%.3f_%d" % [r_top, r_bottom, height, segments]
	var c: CylinderMesh
	if _mesh_cache.has(key):
		c = _mesh_cache[key]
	else:
		c = CylinderMesh.new()
		c.top_radius = r_top
		c.bottom_radius = r_bottom
		c.height = height
		c.radial_segments = segments
		c.rings = 1
		_mesh_cache[key] = c
	var mi := MeshInstance3D.new()
	mi.mesh = c
	mi.material_override = m
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


static func sphere(parent: Node3D, radius: float, pos: Vector3, m: Material, segments: int = 10) -> MeshInstance3D:
	var key := "sph_%.3f_%d" % [radius, segments]
	var sm: SphereMesh
	if _mesh_cache.has(key):
		sm = _mesh_cache[key]
	else:
		sm = SphereMesh.new()
		sm.radius = radius
		sm.height = radius * 2.0
		sm.radial_segments = segments
		sm.rings = maxi(4, segments / 2)
		_mesh_cache[key] = sm
	var mi := MeshInstance3D.new()
	mi.mesh = sm
	mi.material_override = m
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


## هاله‌ی نورانی که همیشه رو به دوربین است
static func glow(parent: Node3D, pos: Vector3, size: float, color: Color) -> MeshInstance3D:
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = glow_mat(color)
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


## لکه‌ی نور روی زمین (افقی)
static func pool(parent: Node3D, pos: Vector3, size: Vector2, color: Color) -> MeshInstance3D:
	var key := "poolmat_" + color.to_html()
	var m: StandardMaterial3D
	if _cache.has(key):
		m = _cache[key]
	else:
		m = StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		m.albedo_texture = glow_tex()
		m.albedo_color = color
		m.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
		_cache[key] = m
	var p := PlaneMesh.new()
	p.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = p
	mi.material_override = m
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


## سایه‌ی نرم زیر اشیا
static func shadow(parent: Node3D, size: Vector2, alpha: float = 0.5, y: float = 0.02) -> MeshInstance3D:
	var key := "shadowmat_%.2f" % alpha
	var m: StandardMaterial3D
	if _cache.has(key):
		m = _cache[key]
	else:
		m = StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.albedo_texture = glow_tex()
		m.albedo_color = Color(0, 0, 0, alpha)
		m.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
		_cache[key] = m
	var p := PlaneMesh.new()
	p.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = p
	mi.material_override = m
	mi.position = Vector3(0.0, y, 0.0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


static func label(parent: Node3D, text: String, pos: Vector3, size_px: int, color: Color, pixel_size: float = 0.01, rot_deg: Vector3 = Vector3.ZERO) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font_size = size_px
	l.pixel_size = pixel_size
	l.outline_size = 10
	l.outline_modulate = color.darkened(0.6)
	l.modulate = color
	l.shaded = false
	l.double_sided = false
	l.position = pos
	l.rotation_degrees = rot_deg
	parent.add_child(l)
	return l
