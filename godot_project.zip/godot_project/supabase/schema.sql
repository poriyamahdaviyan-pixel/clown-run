-- =====================================================================
--  فرار از دلقک — دیتابیس آنلاین (Supabase / PostgreSQL)
--  اجرا: Supabase ← SQL Editor ← این فایل را کامل Paste کن ← Run
--  امن‌سازی: همه‌ی نوشتن‌ها فقط از راه توابع (RPC) انجام می‌شود؛ قفل و خرید سمت سرور است.
-- =====================================================================

-- ------------------------- جدول‌ها -------------------------
create table if not exists public.profiles (
  id             uuid primary key references auth.users(id) on delete cascade,
  username       text not null unique check (char_length(username) between 3 and 20),
  coins          integer not null default 0 check (coins >= 0),
  best_score     integer not null default 0,
  best_distance  integer not null default 0,
  is_admin       boolean not null default false,
  banned         boolean not null default false,
  local_claimed  boolean not null default false,
  daily_streak   integer not null default 0,
  last_daily     date,
  last_run_at    timestamptz,
  created_at     timestamptz not null default now()
);

create table if not exists public.scores (
  id          bigint generated always as identity primary key,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  score       integer not null,
  distance    integer not null,
  coins       integer not null default 0,
  created_at  timestamptz not null default now()
);
create index if not exists scores_user_idx on public.scores(user_id);
create index if not exists scores_time_idx on public.scores(created_at desc);

create table if not exists public.items (
  id               uuid primary key default gen_random_uuid(),
  kind             text not null check (kind ~ '^[a-z][a-z0-9_]{1,23}$'),   -- نوع باز: skin, glb, coin, voice, anim, police, ...
  name             text not null,
  description      text not null default '',
  price            integer not null default 0 check (price >= 0),
  rarity           text not null default 'common' check (rarity in ('common', 'rare', 'epic', 'legendary')),
  preview_path     text,            -- در باکت public «previews»
  file_path        text,            -- در باکت خصوصی «item-files» (فقط خریداران)
  glb_yaw          integer not null default 0,
  payload          jsonb not null default '{}'::jsonb,   -- تنظیم اضافه‌ی نوع (مثلاً برای صدا: {"event":"jump","replace":true})
  stock            integer check (stock is null or stock >= 0),   -- null = نامحدود (نسخه‌ی محدود)
  discount_percent integer not null default 0 check (discount_percent between 0 and 90),
  ends_at          timestamptz,     -- فروش ویژه‌ی زمان‌دار
  featured         boolean not null default false,
  status           text not null default 'approved' check (status in ('approved', 'hidden')),
  sales            integer not null default 0,
  sort             integer not null default 0,
  created_at       timestamptz not null default now()
);

create table if not exists public.purchases (
  user_id    uuid not null references public.profiles(id) on delete cascade,
  item_id    uuid not null references public.items(id) on delete cascade,
  price_paid integer not null,
  created_at timestamptz not null default now(),
  primary key (user_id, item_id)
);

create table if not exists public.config (
  key         text primary key,
  value       jsonb not null,
  description text not null default '',
  updated_at  timestamptz not null default now()
);

-- ------------------------- کمکی‌ها -------------------------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false);
$$;

-- ساخت خودکار پروفایل بعد از ثبت‌نام
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  uname text := coalesce(nullif(trim(new.raw_user_meta_data ->> 'username'), ''), 'player' || substr(new.id::text, 1, 6));
begin
  if char_length(uname) < 3 then uname := uname || '___'; end if;
  uname := left(uname, 20);
  if exists (select 1 from public.profiles where lower(username) = lower(uname)) then
    uname := left(uname, 14) || substr(new.id::text, 1, 5);
  end if;
  insert into public.profiles (id, username) values (new.id, uname);
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ------------------------- امنیت سطح ردیف (RLS) -------------------------
alter table public.profiles  enable row level security;
alter table public.scores    enable row level security;
-- ارتقا از نسخه‌ی قبل (نوع باز + payload)؛ بی‌خطر برای اجرای دوباره
alter table public.items drop constraint if exists items_kind_check;
alter table public.items add constraint items_kind_check check (kind ~ '^[a-z][a-z0-9_]{1,23}$');
alter table public.items add column if not exists payload jsonb not null default '{}'::jsonb;
alter table public.items     enable row level security;
alter table public.purchases enable row level security;
alter table public.config    enable row level security;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select using (id = auth.uid() or public.is_admin());
drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles for update using (public.is_admin()) with check (public.is_admin());

drop policy if exists scores_admin on public.scores;
create policy scores_admin on public.scores for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists items_select on public.items;
create policy items_select on public.items for select using (status = 'approved' or public.is_admin());
drop policy if exists items_admin_write on public.items;
create policy items_admin_write on public.items for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists purchases_select on public.purchases;
create policy purchases_select on public.purchases for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists purchases_admin on public.purchases;
create policy purchases_admin on public.purchases for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists config_select on public.config;
create policy config_select on public.config for select using (true);
drop policy if exists config_admin_write on public.config;
create policy config_admin_write on public.config for all using (public.is_admin()) with check (public.is_admin());

-- دسترسی پایه‌ی جدول‌ها (سطح دسترسی واقعی را RLS بالا تعیین می‌کند)
grant usage on schema public to anon, authenticated;
grant select on public.items, public.config to anon, authenticated;
grant select on public.profiles, public.purchases, public.scores to authenticated;
grant insert, update, delete on public.items, public.config to authenticated;      -- RLS: فقط ادمین
grant insert, update, delete on public.purchases, public.scores to authenticated;  -- RLS: فقط ادمین

-- کاربر عادی هیچ ستونی از پروفایل را مستقیم تغییر نمی‌دهد (فقط RPC)
revoke insert, update, delete on public.profiles from anon, authenticated;
grant update on public.profiles to authenticated;     -- با RLS فقط ادمین می‌تواند

-- ------------------------- توابع بازی (RPC) -------------------------
-- پایان یک دور بازی: امتیاز و سکه‌ها را با بررسی منطقی‌بودن ثبت می‌کند
create or replace function public.submit_run(p_score int, p_distance int, p_coins int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  rank_now int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if p_score < 0 or p_distance < 0 or p_coins < 0
     or p_distance > 30000
     or p_coins > p_distance + 60
     or p_score > 6 * p_distance + 10 * p_coins + 500 then
    return jsonb_build_object('ok', false, 'error', 'implausible');
  end if;
  if me.last_run_at is not null and now() - me.last_run_at < interval '8 seconds' then
    return jsonb_build_object('ok', false, 'error', 'too_fast');
  end if;
  insert into public.scores (user_id, score, distance, coins) values (me.id, p_score, p_distance, p_coins);
  update public.profiles set
    coins = coins + p_coins,
    best_score = greatest(best_score, p_score),
    best_distance = greatest(best_distance, p_distance),
    last_run_at = now()
  where id = me.id;
  select count(*) + 1 into rank_now from public.profiles
    where not banned and best_score > greatest(me.best_score, p_score);
  return jsonb_build_object('ok', true, 'coins', me.coins + p_coins, 'rank', rank_now);
end $$;

-- جدول امتیازها: period = 'all' | 'week' | 'day'
create or replace function public.get_leaderboard(p_period text default 'all', p_limit int default 50)
returns table (rank bigint, username text, score int, distance int)
language sql stable security definer set search_path = public as $$
  with best as (
    select s.user_id, max(s.score) as score, max(s.distance) as distance
    from public.scores s
    where case p_period
            when 'day'  then s.created_at > now() - interval '1 day'
            when 'week' then s.created_at > now() - interval '7 days'
            else true end
    group by s.user_id
  )
  select row_number() over (order by b.score desc, b.distance desc) as rank,
         p.username, b.score, b.distance
  from best b join public.profiles p on p.id = b.user_id
  where not p.banned
  order by b.score desc, b.distance desc
  limit least(greatest(p_limit, 1), 100);
$$;

-- ------------------------- چالش روزانه و اتاق‌های دوئل -------------------------
-- room = کد اتاق. چالش روزانه: عدد تاریخ UTC مثل 20261107 (همه یک مسیر مشترک می‌دوند)؛
-- اتاق دوستانه: هر عدد ۴ تا ۹ رقمی که دوستان با هم قرار می‌گذارند.
create table if not exists public.challenge_scores (
  room int not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  score int not null,
  distance int not null,
  updated_at timestamptz not null default now(),
  primary key (room, user_id)
);
alter table public.challenge_scores enable row level security;
revoke all on public.challenge_scores from anon, authenticated;

create or replace function public.submit_challenge(p_room int, p_score int, p_distance int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  today int := to_char(now() at time zone 'utc', 'YYYYMMDD')::int;
  existed boolean;
  reward int := 0;
  rank_now int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if p_room < 1000 or p_room > 999999999 then return jsonb_build_object('ok', false, 'error', 'bad_room'); end if;
  if p_room >= 20200101 and p_room <> today then return jsonb_build_object('ok', false, 'error', 'room_expired'); end if;
  if p_score < 0 or p_distance < 0 or p_distance > 30000 or p_score > 6 * p_distance + 10 * (p_distance + 60) + 500 then
    return jsonb_build_object('ok', false, 'error', 'implausible');
  end if;
  existed := exists (select 1 from public.challenge_scores c where c.room = p_room and c.user_id = me.id);
  insert into public.challenge_scores (room, user_id, score, distance) values (p_room, me.id, p_score, p_distance)
  on conflict (room, user_id) do update set
    score = greatest(public.challenge_scores.score, excluded.score),
    distance = greatest(public.challenge_scores.distance, excluded.distance),
    updated_at = now();
  -- پاداش اولین شرکت در چالش روزانه (یک بار در روز)
  if p_room = today and not existed then
    reward := 40;
    update public.profiles set coins = coins + reward where id = me.id;
  end if;
  select count(*) + 1 into rank_now from public.challenge_scores c
    where c.room = p_room and c.score > (select score from public.challenge_scores where room = p_room and user_id = me.id);
  return jsonb_build_object('ok', true, 'rank', rank_now, 'reward', reward, 'coins', me.coins + reward);
end $$;

create or replace function public.get_challenge_board(p_room int, p_limit int default 30)
returns table (rank bigint, username text, score int, distance int)
language sql stable security definer set search_path = public as $$
  select row_number() over (order by c.score desc, c.distance desc) as rank, p.username, c.score, c.distance
  from public.challenge_scores c join public.profiles p on p.id = c.user_id
  where c.room = p_room and not p.banned
  order by c.score desc, c.distance desc
  limit least(greatest(p_limit, 1), 100);
$$;

-- انتقال یک‌باره‌ی سکه‌های آفلاین به حساب آنلاین
create or replace function public.claim_local_coins(p_coins int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  cap int := coalesce((select (value #>> '{}')::int from public.config where key = 'migrate_cap'), 3000);
  amount int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null or me.banned then return jsonb_build_object('ok', false); end if;
  if me.local_claimed then return jsonb_build_object('ok', false, 'error', 'already'); end if;
  amount := least(greatest(p_coins, 0), cap);
  update public.profiles set coins = coins + amount, local_claimed = true where id = me.id;
  return jsonb_build_object('ok', true, 'coins', me.coins + amount, 'added', amount);
end $$;

-- جایزه‌ی روزانه با زنجیره‌ی روزهای پشت‌سرهم
create or replace function public.claim_daily() returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  streak int;
  reward int;
  base int := coalesce((select (value #>> '{}')::int from public.config where key = 'daily_base'), 20);
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null or me.banned then return jsonb_build_object('ok', false); end if;
  if me.last_daily = current_date then
    return jsonb_build_object('ok', false, 'error', 'already', 'streak', me.daily_streak);
  end if;
  streak := case when me.last_daily = current_date - 1 then least(me.daily_streak + 1, 7) else 1 end;
  reward := base * streak;
  update public.profiles set coins = coins + reward, daily_streak = streak, last_daily = current_date where id = me.id;
  return jsonb_build_object('ok', true, 'reward', reward, 'streak', streak, 'coins', me.coins + reward);
end $$;

-- خرید آیتم با سکه‌ی حساب (قیمت، تخفیف، موجودی و زمان همه سمت سرور بررسی می‌شود)
create or replace function public.buy_item(p_item uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  it public.items;
  cost int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  select * into it from public.items where id = p_item and status = 'approved' for update;
  if it.id is null then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if exists (select 1 from public.purchases where user_id = me.id and item_id = it.id) then
    return jsonb_build_object('ok', false, 'error', 'owned');
  end if;
  if it.ends_at is not null and it.ends_at < now() then
    return jsonb_build_object('ok', false, 'error', 'expired');
  end if;
  if it.stock is not null and it.stock <= 0 then
    return jsonb_build_object('ok', false, 'error', 'sold_out');
  end if;
  cost := (it.price * (100 - it.discount_percent)) / 100;
  if me.coins < cost then
    return jsonb_build_object('ok', false, 'error', 'no_coins', 'need', cost - me.coins);
  end if;
  update public.profiles set coins = coins - cost where id = me.id;
  insert into public.purchases (user_id, item_id, price_paid) values (me.id, it.id, cost);
  update public.items set sales = sales + 1, stock = case when stock is null then null else stock - 1 end where id = it.id;
  return jsonb_build_object('ok', true, 'coins', me.coins - cost, 'paid', cost);
end $$;

-- ------------------------- توابع مدیریت (فقط ادمین) -------------------------
create or replace function public.admin_set_ban(p_user uuid, p_banned boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  update public.profiles set banned = p_banned where id = p_user;
end $$;

create or replace function public.admin_grant_coins(p_user uuid, p_amount int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  update public.profiles set coins = greatest(coins + p_amount, 0) where id = p_user;
end $$;

create or replace function public.admin_reset_leaderboard() returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  delete from public.scores where true;
  update public.profiles set best_score = 0, best_distance = 0 where true;
end $$;

grant execute on function public.submit_run(int, int, int)        to authenticated;
grant execute on function public.get_leaderboard(text, int)       to anon, authenticated;
grant execute on function public.submit_challenge(int, int, int)  to authenticated;
grant execute on function public.get_challenge_board(int, int)    to anon, authenticated;
grant execute on function public.claim_local_coins(int)           to authenticated;
grant execute on function public.claim_daily()                    to authenticated;
grant execute on function public.buy_item(uuid)                   to authenticated;
grant execute on function public.admin_set_ban(uuid, boolean)     to authenticated;
grant execute on function public.admin_grant_coins(uuid, int)     to authenticated;
grant execute on function public.admin_reset_leaderboard()        to authenticated;
grant execute on function public.is_admin()                       to anon, authenticated;

-- ------------------------- ذخیره‌سازی فایل (Storage) -------------------------
insert into storage.buckets (id, name, public) values ('previews', 'previews', true)
  on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('item-files', 'item-files', false)
  on conflict (id) do nothing;

drop policy if exists previews_read on storage.objects;
create policy previews_read on storage.objects for select using (bucket_id = 'previews');
drop policy if exists previews_admin on storage.objects;
create policy previews_admin on storage.objects for all
  using (bucket_id = 'previews' and public.is_admin()) with check (bucket_id = 'previews' and public.is_admin());

drop policy if exists files_admin on storage.objects;
create policy files_admin on storage.objects for all
  using (bucket_id = 'item-files' and public.is_admin()) with check (bucket_id = 'item-files' and public.is_admin());
-- فایل اصلی فقط برای خریدار آن آیتم قابل دانلود است (قفل واقعی)
drop policy if exists files_owner_read on storage.objects;
create policy files_owner_read on storage.objects for select using (
  bucket_id = 'item-files' and exists (
    select 1 from public.purchases p join public.items i on i.id = p.item_id
    where p.user_id = auth.uid() and i.file_path = storage.objects.name
  )
);

-- ------------------------- تنظیمات پیش‌فرض بازی (از پنل مدیریت عوض می‌شود) -------------------------
insert into public.config (key, value, description) values
 ('game', '{"START_SPEED":11,"MAX_SPEED":25,"SPEED_PER_SECOND":0.07,"COIN_SCORE":5,"ZONE_LENGTH":450,"STUMBLE_TIME":5,"STUMBLE_SLOW":0.72,"JET_GRACE":1.6,"SLOW_MULT":0.7,"NEAR_BONUS":15,"REVIVE_PRICE":30,"UPGRADE_BASE_PRICE":40,"HEAT_TIME":12,"POWER_BASE":[8,10,10,6,10,8],"POWER_STEP":[2,2,2.5,1,2.5,2]}', 'ثابت‌های گیم‌پلی (سرعت، زمان قدرت‌ها، قیمت زنده‌شدن، پلیس ...)'),
 ('announcement', '""', 'پیام اعلان در منوی اصلی (خالی = بدون اعلان)'),
 ('maintenance', 'false', 'اگر true شود بخش آنلاین بسته می‌شود'),
 ('min_version', '1', 'کمترین نسخه‌ی مجاز بازی (عدد)'),
 ('migrate_cap', '3000', 'سقف انتقال سکه‌های آفلاین به حساب آنلاین'),
 ('daily_base', '20', 'جایزه‌ی روز اول؛ روز n برابر n×این مقدار (تا ۷ روز)')
on conflict (key) do nothing;


-- =====================================================================
--  حالت کاملاً آنلاین: سکه، ارتقاها، ماموریت‌ها و پیشرفت روی سرور
--  (اجرای دوباره بی‌خطر است)
-- =====================================================================
alter table public.profiles add column if not exists levels int[] not null default '{0,0,0,0,0,0}';
alter table public.profiles add column if not exists save jsonb not null default '{}'::jsonb;
alter table public.profiles add column if not exists last_mission_at timestamptz;

-- ارتقای قدرت‌ها (قیمت = پایه × (سطح+1)؛ پایه از config.game.UPGRADE_BASE_PRICE، پیش‌فرض ۴۰؛ حداکثر سطح ۵)
create or replace function public.buy_upgrade(p_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  lvl int;
  base int := coalesce((select (value ->> 'UPGRADE_BASE_PRICE')::int from public.config where key = 'game'), 40);
  cost int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if p_id < 0 or p_id > 5 then return jsonb_build_object('ok', false, 'error', 'bad_id'); end if;
  lvl := coalesce(me.levels[p_id + 1], 0);
  if lvl >= 5 then return jsonb_build_object('ok', false, 'error', 'max_level'); end if;
  cost := base * (lvl + 1);
  if me.coins < cost then return jsonb_build_object('ok', false, 'error', 'no_coins', 'need', cost - me.coins); end if;
  update public.profiles set coins = coins - cost, levels[p_id + 1] = lvl + 1 where id = me.id;
  return jsonb_build_object('ok', true, 'coins', me.coins - cost, 'level', lvl + 1, 'paid', cost);
end $$;

-- ادامه‌ی بازی با سکه (قیمت از config.game.REVIVE_PRICE، پیش‌فرض ۳۰)
create or replace function public.spend_revive() returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  price int := coalesce((select (value ->> 'REVIVE_PRICE')::int from public.config where key = 'game'), 30);
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if me.coins < price then return jsonb_build_object('ok', false, 'error', 'no_coins', 'need', price - me.coins); end if;
  update public.profiles set coins = coins - price, last_run_at = null where id = me.id;
  return jsonb_build_object('ok', true, 'coins', me.coins - price, 'paid', price);
end $$;

-- جایزه‌ی ماموریت (سقف ۱۰۰ سکه در هر بار، فاصله‌ی حداقل ۲ ثانیه)
create or replace function public.mission_reward(p_amount int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null or me.banned then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if p_amount < 1 or p_amount > 100 then return jsonb_build_object('ok', false, 'error', 'implausible'); end if;
  if me.last_mission_at is not null and now() - me.last_mission_at < interval '2 seconds' then
    return jsonb_build_object('ok', false, 'error', 'too_fast');
  end if;
  update public.profiles set coins = coins + p_amount, last_mission_at = now() where id = me.id;
  return jsonb_build_object('ok', true, 'coins', me.coins + p_amount);
end $$;

-- ذخیره‌ی پیشرفت کلاینت (فعلاً: ماموریت‌ها). حداکثر ۲۰ کیلوبایت
create or replace function public.save_progress(p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if pg_column_size(p_data) > 20000 then return jsonb_build_object('ok', false, 'error', 'too_big'); end if;
  update public.profiles set save = p_data where id = auth.uid() and not banned;
  return jsonb_build_object('ok', true);
end $$;

grant execute on function public.buy_upgrade(int)      to authenticated;
grant execute on function public.spend_revive()        to authenticated;
grant execute on function public.mission_reward(int)   to authenticated;
grant execute on function public.save_progress(jsonb)  to authenticated;

-- ===== به‌روزرسانی ۳ و ۴ (فایل‌های بزرگ، نسخه‌ها، رقابت) =====
-- =====================================================================
--  به‌روزرسانی ۳ (اجرای دوباره بی‌خطر است): فایل‌های بزرگ، نسخه‌ها و بروزرسانی، و بخش رقابتی
--  در Supabase ← SQL Editor ← New query ← کل این فایل را بچسبان ← Run
-- =====================================================================

-- ------------------------- ۱) فایل‌های بالای ۵۰ مگابایت (تکه‌تکه) -------------------------
-- فایل بزرگ به تکه‌های «نام.part0001 …» شکسته می‌شود؛ خریدار باید به همه‌ی تکه‌ها دسترسی داشته باشد
drop policy if exists files_owner_read on storage.objects;
create policy files_owner_read on storage.objects for select using (
  bucket_id = 'item-files' and exists (
    select 1 from public.purchases p join public.items i on i.id = p.item_id
    where p.user_id = auth.uid() and (
      i.file_path = storage.objects.name
      or (length(storage.objects.name) = length(i.file_path) + 9
          and left(storage.objects.name, length(i.file_path) + 5) = i.file_path || '.part')
    )
  )
);

-- ------------------------- ۲) نسخه‌ها: لینک دانلود APK و وصله‌ی بروزرسانی -------------------------
insert into storage.buckets (id, name, public) values ('releases', 'releases', true)
  on conflict (id) do nothing;
drop policy if exists releases_read on storage.objects;
create policy releases_read on storage.objects for select using (bucket_id = 'releases');
drop policy if exists releases_admin on storage.objects;
create policy releases_admin on storage.objects for all
  using (bucket_id = 'releases' and public.is_admin()) with check (bucket_id = 'releases' and public.is_admin());

create table if not exists public.app_releases (
  id           uuid primary key default gen_random_uuid(),
  kind         text not null check (kind in ('apk', 'patch')),
  version_name text not null default '',
  version_code int  not null default 1,
  base_code    int  not null default 0,      -- فقط برای وصله: روی کدام شماره‌ی ساخت APK کار می‌کند
  edition      text not null default 'all' check (edition in ('all', 'public', 'owner')),
  file_path    text not null default '',     -- مسیر در باکت releases
  url          text not null default '',     -- لینک بیرونی (مثلاً GitHub Releases) برای APKهای بزرگ
  size         bigint not null default 0,
  sha256       text not null default '',
  sig          text not null default '',     -- امضای RSA وصله
  notes        text not null default '',
  mandatory    boolean not null default false,
  published    boolean not null default true,
  created_at   timestamptz not null default now()
);
alter table public.app_releases enable row level security;
drop policy if exists releases_select on public.app_releases;
create policy releases_select on public.app_releases for select using (published or public.is_admin());
drop policy if exists releases_write on public.app_releases;
create policy releases_write on public.app_releases for all using (public.is_admin()) with check (public.is_admin());
grant select on public.app_releases to anon, authenticated;
grant insert, update, delete on public.app_releases to authenticated;
-- =====================================================================
--  به‌روزرسانی ۴: بخش رقابتی و چندنفره (لیگ و جام، فصل، رویداد، اتاق باز، پنل مدیر)
--  اجرای دوباره بی‌خطر است. Supabase ← SQL Editor ← New query ← همه‌ی این فایل ← Run
--  (اگر نصب تازه می‌کنی این بخش آخر schema.sql هم هست؛ لازم نیست جدا اجرا کنی.)
-- =====================================================================

alter table public.profiles
  add column if not exists trophies       int not null default 0,
  add column if not exists best_trophies  int not null default 0,
  add column if not exists season         int not null default -1,
  add column if not exists comp_banned    boolean not null default false,
  add column if not exists comp_streak    int not null default 0,
  add column if not exists comp_last_day  int not null default 0,
  add column if not exists comp_wins      int not null default 0,
  add column if not exists comp_games     int not null default 0;

alter table public.challenge_scores add column if not exists tries int not null default 1;

-- رویدادهای مدیر و اتاق‌های باز بازیکنان
create table if not exists public.comp_events (
  id             int generated always as identity (start with 10000000) primary key,
  kind           text not null default 'event' check (kind in ('event', 'duel')),
  title          text not null default '',
  modifier       text not null default '',
  starts_at      timestamptz not null default now(),
  ends_at        timestamptz not null,
  entry_fee      int not null default 0,
  prizes         jsonb not null default '[]',          -- جایزه‌ی سکه به‌ترتیب رتبه
  trophy_rewards jsonb not null default '[]',          -- جام به‌ترتیب رتبه
  max_tries      int not null default 0,               -- 0 = نامحدود
  is_public      boolean not null default true,
  creator        uuid references public.profiles(id) on delete set null,
  pool           int not null default 0,               -- جمع ورودی‌ها (برای دوئل‌ها)
  settled        boolean not null default false,
  created_at     timestamptz not null default now()
);
alter table public.comp_events enable row level security;
revoke all on public.comp_events from anon, authenticated;

create table if not exists public.comp_claims (
  user_id uuid not null references public.profiles(id) on delete cascade,
  room    int not null,
  primary key (user_id, room)
);
alter table public.comp_claims enable row level security;
revoke all on public.comp_claims from anon, authenticated;

-- ------------------------- تنظیمات (مدیر در بازی عوض می‌کند: config.key = 'competitive') -------------------------
create or replace function public.comp_cfg() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'enabled', true, 'daily_enabled', true, 'events_enabled', true, 'player_rooms', true,
    'daily_reward', 40, 'streak_bonus', 5, 'daily_tries', 0,
    'participation_trophies', 5,
    'rank_rewards', jsonb_build_array(150, 100, 60, 40, 30, 20, 20, 10, 10, 10),
    'rank_trophies', jsonb_build_array(40, 30, 20, 15, 10, 10, 5, 5, 5, 5),
    'duel_win_trophies', 25, 'duel_lose_trophies', 10, 'duel_rake_percent', 10,
    'create_room_fee', 20, 'entry_fee_max', 500, 'max_room_hours', 72, 'max_open_rooms', 20,
    'season_days', 30, 'season_keep_percent', 50, 'season_coins_per_100', 10, 'season_offset', 0,
    'max_score_mult', 3
  ) || coalesce((select value from public.config where key = 'competitive'), '{}'::jsonb);
$$;

create or replace function public._today() returns int language sql stable as $$
  select to_char(now() at time zone 'utc', 'YYYYMMDD')::int
$$;

create or replace function public._season_id() returns int language sql stable security definer set search_path = public as $$
  select (floor(extract(epoch from now()) / 86400 / greatest((public.comp_cfg()->>'season_days')::int, 1)))::int
         + (public.comp_cfg()->>'season_offset')::int
$$;

-- شروع فصل تازه برای همین کاربر (جام‌ها کم می‌شود و جایزه‌ی پایان فصل می‌گیرد)
create or replace function public._season_roll(uid uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare me public.profiles; sid int := public._season_id(); cfg jsonb := public.comp_cfg(); reward int := 0; old int;
begin
  select * into me from public.profiles where id = uid for update;
  if me.season = sid then return jsonb_build_object('rolled', false); end if;
  old := me.trophies;
  if me.season >= 0 then
    reward := (old / 100) * (cfg->>'season_coins_per_100')::int;
    update public.profiles set trophies = (old * (cfg->>'season_keep_percent')::int) / 100, season = sid, coins = coins + reward where id = uid;
  else
    update public.profiles set season = sid where id = uid;
  end if;
  return jsonb_build_object('rolled', me.season >= 0, 'old_trophies', old, 'reward', reward);
end $$;

-- ------------------------- ثبت نتیجه -------------------------
drop function if exists public.comp_submit(int, int, int);
create or replace function public.comp_submit(p_room int, p_score int, p_distance int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles; cfg jsonb := public.comp_cfg(); today int := public._today();
  ev public.comp_events; existed boolean; tries_now int := 0; max_t int := 0;
  reward int := 0; troph int := 0; fee int := 0; rank_now int; streak int; bonus int := 0;
  is_daily boolean := (p_room = public._today()); is_event boolean := (p_room >= 10000000 and p_room < 20200101);
  best_cap numeric;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned or me.comp_banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if not (cfg->>'enabled')::boolean then return jsonb_build_object('ok', false, 'error', 'comp_off'); end if;
  perform public._season_roll(me.id);
  if p_room < 1000 or p_room > 2147483000 then return jsonb_build_object('ok', false, 'error', 'bad_room'); end if;
  if p_room >= 20200101 and p_room <> today then return jsonb_build_object('ok', false, 'error', 'room_expired'); end if;
  best_cap := (cfg->>'max_score_mult')::numeric * (6 * p_distance + 10 * (p_distance + 60) + 500);
  if p_score < 0 or p_distance < 0 or p_distance > 30000 or p_score > best_cap then
    return jsonb_build_object('ok', false, 'error', 'implausible');
  end if;
  if is_daily then
    if not (cfg->>'daily_enabled')::boolean then return jsonb_build_object('ok', false, 'error', 'comp_off'); end if;
    max_t := (cfg->>'daily_tries')::int;
  elsif is_event then
    select * into ev from public.comp_events where id = p_room;
    if ev.id is null then return jsonb_build_object('ok', false, 'error', 'no_room'); end if;
    if ev.kind = 'event' and not (cfg->>'events_enabled')::boolean then return jsonb_build_object('ok', false, 'error', 'comp_off'); end if;
    if now() < ev.starts_at then return jsonb_build_object('ok', false, 'error', 'not_started'); end if;
    if now() >= ev.ends_at or ev.settled then return jsonb_build_object('ok', false, 'error', 'room_ended'); end if;
    max_t := ev.max_tries;
  end if;
  select tries into tries_now from public.challenge_scores where room = p_room and user_id = me.id;
  existed := found;
  tries_now := coalesce(tries_now, 0);
  if max_t > 0 and tries_now >= max_t then return jsonb_build_object('ok', false, 'error', 'no_tries'); end if;
  -- ورودی اتاق‌های دارای هزینه (فقط بار اول)
  if is_event and not existed and ev.entry_fee > 0 and ev.creator is distinct from me.id then
    fee := ev.entry_fee;
    if me.coins < fee then return jsonb_build_object('ok', false, 'error', 'no_coins', 'need', fee - me.coins); end if;
    update public.profiles set coins = coins - fee where id = me.id;
    update public.comp_events set pool = pool + fee where id = ev.id;
  end if;
  insert into public.challenge_scores (room, user_id, score, distance, tries) values (p_room, me.id, p_score, p_distance, 1)
  on conflict (room, user_id) do update set
    score = greatest(public.challenge_scores.score, excluded.score),
    distance = greatest(public.challenge_scores.distance, excluded.distance),
    tries = public.challenge_scores.tries + 1, updated_at = now();
  update public.profiles set comp_games = comp_games + 1 where id = me.id;
  streak := me.comp_streak;
  if is_daily and not existed then
    if me.comp_last_day = to_char((now() at time zone 'utc')::date - 1, 'YYYYMMDD')::int then streak := me.comp_streak + 1;
    elsif me.comp_last_day = today then streak := me.comp_streak; else streak := 1; end if;
    bonus := least(streak, 7) * (cfg->>'streak_bonus')::int;
    reward := (cfg->>'daily_reward')::int + bonus;
    troph := (cfg->>'participation_trophies')::int;
    update public.profiles set coins = coins + reward, trophies = trophies + troph, best_trophies = greatest(best_trophies, trophies + troph),
      comp_streak = streak, comp_last_day = today where id = me.id;
  end if;
  select count(*) + 1 into rank_now from public.challenge_scores c
    where c.room = p_room and c.score > (select score from public.challenge_scores where room = p_room and user_id = me.id);
  select coins, trophies into me.coins, me.trophies from public.profiles where id = me.id;
  return jsonb_build_object('ok', true, 'rank', rank_now, 'reward', reward, 'coins', me.coins, 'trophies', me.trophies,
    'trophies_gained', troph, 'streak', streak, 'streak_bonus', bonus, 'fee', fee,
    'tries_left', case when max_t > 0 then greatest(max_t - tries_now - 1, 0) else -1 end);
end $$;

drop function if exists public.comp_board(int, int);
create or replace function public.comp_board(p_room int, p_limit int default 30)
returns table (rank bigint, username text, score int, distance int, tries int, trophies int)
language sql stable security definer set search_path = public as $$
  select row_number() over (order by c.score desc, c.distance desc, c.updated_at asc) as rank, p.username, c.score, c.distance, c.tries, p.trophies
  from public.challenge_scores c join public.profiles p on p.id = c.user_id
  where c.room = p_room and not p.banned and not p.comp_banned
  order by c.score desc, c.distance desc, c.updated_at asc
  limit least(greatest(p_limit, 1), 100);
$$;

-- ------------------------- وضعیت من، فصل، جایزه‌ی دیروز -------------------------
create or replace function public.comp_state() returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles; cfg jsonb := public.comp_cfg(); roll jsonb; yday int; yrank int; ycount int; idx int;
  claim jsonb := null; srank int; tries_used int := 0; sid int := public._season_id(); days_left numeric;
begin
  select * into me from public.profiles where id = auth.uid();
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  roll := public._season_roll(me.id);
  perform public.comp_settle();
  select * into me from public.profiles where id = me.id;
  yday := to_char((now() at time zone 'utc')::date - 1, 'YYYYMMDD')::int;
  select count(*) into ycount from public.challenge_scores where room = yday;
  if exists (select 1 from public.challenge_scores where room = yday and user_id = me.id)
     and not exists (select 1 from public.comp_claims where user_id = me.id and room = yday) then
    select count(*) + 1 into yrank from public.challenge_scores c
      where c.room = yday and c.score > (select score from public.challenge_scores where room = yday and user_id = me.id);
    idx := yrank - 1;
    claim := jsonb_build_object('rank', yrank, 'count', ycount,
      'coins', coalesce((cfg->'rank_rewards'->>idx)::int, 0), 'trophies', coalesce((cfg->'rank_trophies'->>idx)::int, 2));
  end if;
  select count(*) + 1 into srank from public.profiles p where p.trophies > me.trophies and not p.banned and not p.comp_banned;
  select coalesce(tries, 0) into tries_used from public.challenge_scores where room = public._today() and user_id = me.id;
  days_left := ((sid + 1 - (cfg->>'season_offset')::int) * (cfg->>'season_days')::int) - extract(epoch from now()) / 86400;
  return jsonb_build_object('ok', true, 'trophies', me.trophies, 'best_trophies', me.best_trophies, 'streak', me.comp_streak,
    'wins', me.comp_wins, 'games', me.comp_games, 'season', sid, 'season_rank', srank,
    'season_days_left', greatest(ceil(days_left), 0), 'season_roll', roll, 'claim', claim,
    'tries_used', coalesce(tries_used, 0), 'banned', me.comp_banned, 'cfg', cfg, 'coins', me.coins);
end $$;

create or replace function public.comp_claim_yesterday() returns jsonb
language plpgsql security definer set search_path = public as $$
declare me public.profiles; cfg jsonb := public.comp_cfg(); yday int; yrank int; idx int; c int; t int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned or me.comp_banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  yday := to_char((now() at time zone 'utc')::date - 1, 'YYYYMMDD')::int;
  if not exists (select 1 from public.challenge_scores where room = yday and user_id = me.id) then
    return jsonb_build_object('ok', false, 'error', 'nothing');
  end if;
  begin
    insert into public.comp_claims (user_id, room) values (me.id, yday);
  exception when unique_violation then return jsonb_build_object('ok', false, 'error', 'already');
  end;
  select count(*) + 1 into yrank from public.challenge_scores s
    where s.room = yday and s.score > (select score from public.challenge_scores where room = yday and user_id = me.id);
  idx := yrank - 1;
  c := coalesce((cfg->'rank_rewards'->>idx)::int, 0);
  t := coalesce((cfg->'rank_trophies'->>idx)::int, 2);
  update public.profiles set coins = coins + c, trophies = trophies + t, best_trophies = greatest(best_trophies, trophies + t),
    comp_wins = comp_wins + case when yrank = 1 then 1 else 0 end where id = me.id;
  return jsonb_build_object('ok', true, 'rank', yrank, 'coins_gained', c, 'trophies_gained', t, 'coins', me.coins + c, 'trophies', me.trophies + t);
end $$;

-- ------------------------- رویدادها و اتاق‌های باز -------------------------
create or replace function public.comp_events_list() returns jsonb
language plpgsql security definer set search_path = public as $$
declare rows jsonb;
begin
  perform public.comp_settle();
  select coalesce(jsonb_agg(x order by x.ends_at), '[]'::jsonb) into rows from (
    select e.id, e.kind, e.title, e.modifier, e.starts_at, e.ends_at, e.entry_fee, e.prizes, e.trophy_rewards, e.max_tries, e.pool,
      (select p.username from public.profiles p where p.id = e.creator) as creator,
      (select count(*) from public.challenge_scores c where c.room = e.id) as players,
      (select c.score from public.challenge_scores c where c.room = e.id and c.user_id = auth.uid()) as my_score,
      (select c.tries from public.challenge_scores c where c.room = e.id and c.user_id = auth.uid()) as my_tries
    from public.comp_events e
    where not e.settled and e.ends_at > now() and (e.is_public or e.creator = auth.uid() or public.is_admin())
  ) x;
  return rows;
end $$;

create or replace function public.comp_create_room(p_title text, p_modifier text, p_hours int, p_entry_fee int, p_public boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
declare me public.profiles; cfg jsonb := public.comp_cfg(); fee int := (cfg->>'create_room_fee')::int; new_id int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned or me.comp_banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if not (cfg->>'enabled')::boolean or not (cfg->>'player_rooms')::boolean then return jsonb_build_object('ok', false, 'error', 'comp_off'); end if;
  if (select count(*) from public.comp_events where kind = 'duel' and creator = me.id and not settled and ends_at > now()) >= 3 then
    return jsonb_build_object('ok', false, 'error', 'too_many_rooms');
  end if;
  if (select count(*) from public.comp_events where not settled and ends_at > now()) >= (cfg->>'max_open_rooms')::int then
    return jsonb_build_object('ok', false, 'error', 'rooms_full');
  end if;
  if me.coins < fee then return jsonb_build_object('ok', false, 'error', 'no_coins', 'need', fee - me.coins); end if;
  update public.profiles set coins = coins - fee where id = me.id;
  insert into public.comp_events (kind, title, modifier, ends_at, entry_fee, creator, is_public, max_tries)
  values ('duel', left(coalesce(nullif(trim(p_title), ''), 'دوئل ' || me.username), 40), left(coalesce(p_modifier, ''), 40),
    now() + make_interval(hours => least(greatest(p_hours, 1), (cfg->>'max_room_hours')::int)),
    least(greatest(p_entry_fee, 0), (cfg->>'entry_fee_max')::int), me.id, p_public, 0) returning id into new_id;
  return jsonb_build_object('ok', true, 'room', new_id, 'coins', me.coins - fee);
end $$;

-- پایان‌دادن و پرداخت جایزه‌ی همه‌ی رویدادهای تمام‌شده (چند بار صدا زدنش بی‌خطر است)
create or replace function public.comp_settle() returns int
language plpgsql security definer set search_path = public as $$
declare ev public.comp_events; cfg jsonb := public.comp_cfg(); n int := 0; r record; idx int; coins_g int; troph_g int; payout int; players int;
begin
  for ev in select * from public.comp_events where not settled and ends_at <= now() for update skip locked loop
    select count(*) into players from public.challenge_scores where room = ev.id;
    idx := 0;
    for r in select c.user_id from public.challenge_scores c join public.profiles p on p.id = c.user_id
             where c.room = ev.id and not p.banned and not p.comp_banned order by c.score desc, c.distance desc, c.updated_at asc loop
      if ev.kind = 'event' then
        coins_g := coalesce((ev.prizes->>idx)::int, 0);
        troph_g := coalesce((ev.trophy_rewards->>idx)::int, 0);
      else
        coins_g := 0;
        if idx = 0 and players >= 2 then
          payout := (ev.pool * (100 - (cfg->>'duel_rake_percent')::int)) / 100;
          coins_g := payout; troph_g := (cfg->>'duel_win_trophies')::int;
        elsif players >= 2 then troph_g := -(cfg->>'duel_lose_trophies')::int;
        else troph_g := 0; end if;
        if players < 2 and idx = 0 and ev.pool > 0 then coins_g := ev.pool; end if;  -- تنها بازیکن: ورودی‌اش برمی‌گردد
      end if;
      update public.profiles set coins = coins + coins_g, trophies = greatest(trophies + troph_g, 0),
        best_trophies = greatest(best_trophies, trophies + troph_g), comp_wins = comp_wins + case when idx = 0 and (ev.kind = 'event' or players >= 2) then 1 else 0 end
        where id = r.user_id;
      idx := idx + 1;
    end loop;
    update public.comp_events set settled = true where id = ev.id;
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.comp_season_board(p_limit int default 50)
returns table (rank bigint, username text, trophies int, wins int)
language sql stable security definer set search_path = public as $$
  select row_number() over (order by p.trophies desc, p.comp_wins desc, p.username) as rank, p.username, p.trophies, p.comp_wins
  from public.profiles p where not p.banned and not p.comp_banned and (p.trophies > 0 or p.comp_games > 0)
  order by p.trophies desc, p.comp_wins desc, p.username
  limit least(greatest(p_limit, 1), 100);
$$;

-- ------------------------- ابزار مدیر (همه‌ی کارها در یک تابع؛ فقط ادمین) -------------------------
create or replace function public.comp_admin(p_action text, p_args jsonb default '{}') returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; v_room int; amt int; new_id int; n int;
begin
  if not public.is_admin() then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  v_room := (p_args->>'room')::int;
  if p_args ? 'username' then
    select id into uid from public.profiles where lower(username) = lower(p_args->>'username');
    if uid is null and p_action in ('remove_score', 'reduce_score', 'trophies', 'coins', 'ban') then
      return jsonb_build_object('ok', false, 'error', 'no_user');
    end if;
  end if;
  case p_action
    when 'create_event' then
      insert into public.comp_events (kind, title, modifier, starts_at, ends_at, entry_fee, prizes, trophy_rewards, max_tries, is_public, creator)
      values ('event', left(coalesce(p_args->>'title', 'رویداد'), 60), left(coalesce(p_args->>'modifier', ''), 40),
        coalesce((p_args->>'starts_at')::timestamptz, now()),
        coalesce((p_args->>'ends_at')::timestamptz, now() + interval '24 hours'),
        greatest(coalesce((p_args->>'entry_fee')::int, 0), 0),
        coalesce(p_args->'prizes', '[]'), coalesce(p_args->'trophy_rewards', '[]'),
        greatest(coalesce((p_args->>'max_tries')::int, 0), 0), coalesce((p_args->>'is_public')::boolean, true), null)
      returning id into new_id;
      return jsonb_build_object('ok', true, 'room', new_id);
    when 'end_room' then
      update public.comp_events set ends_at = now() where id = v_room;
      perform public.comp_settle();
      return jsonb_build_object('ok', true);
    when 'delete_room' then
      delete from public.challenge_scores where room = (p_args->>'room')::int;
      delete from public.comp_events where id = v_room;
      return jsonb_build_object('ok', true);
    when 'reset_board' then
      delete from public.challenge_scores where room = (p_args->>'room')::int;
      return jsonb_build_object('ok', true);
    when 'remove_score' then
      delete from public.challenge_scores where room = (p_args->>'room')::int and user_id = uid;
      return jsonb_build_object('ok', true);
    when 'reduce_score' then
      amt := greatest(coalesce((p_args->>'amount')::int, 0), 0);
      update public.challenge_scores set score = greatest(score - amt, 0) where room = (p_args->>'room')::int and user_id = uid;
      get diagnostics n = row_count;
      return jsonb_build_object('ok', n > 0, 'error', case when n = 0 then 'no_score' else '' end);
    when 'trophies' then
      amt := coalesce((p_args->>'delta')::int, 0);
      update public.profiles set trophies = greatest(trophies + amt, 0), best_trophies = greatest(best_trophies, trophies + amt) where id = uid;
      return jsonb_build_object('ok', true);
    when 'coins' then
      amt := coalesce((p_args->>'delta')::int, 0);
      update public.profiles set coins = greatest(coins + amt, 0) where id = uid;
      return jsonb_build_object('ok', true);
    when 'ban' then
      update public.profiles set comp_banned = coalesce((p_args->>'banned')::boolean, true) where id = uid;
      return jsonb_build_object('ok', true);
    when 'new_season' then
      insert into public.config (key, value) values ('competitive', jsonb_build_object('season_offset', (public.comp_cfg()->>'season_offset')::int + 1))
      on conflict (key) do update set value = public.config.value || jsonb_build_object('season_offset', (public.comp_cfg()->>'season_offset')::int + 1);
      return jsonb_build_object('ok', true);
    else
      return jsonb_build_object('ok', false, 'error', 'unknown_action');
  end case;
end $$;

grant execute on function public.comp_submit(int, int, int)           to authenticated;
grant execute on function public.comp_board(int, int)                  to anon, authenticated;
grant execute on function public.comp_state()                          to authenticated;
grant execute on function public.comp_claim_yesterday()                to authenticated;
grant execute on function public.comp_events_list()                    to authenticated;
grant execute on function public.comp_create_room(text, text, int, int, boolean) to authenticated;
grant execute on function public.comp_settle()                         to authenticated;
grant execute on function public.comp_season_board(int)                to anon, authenticated;
grant execute on function public.comp_admin(text, jsonb)               to authenticated;
revoke execute on function public._season_roll(uuid) from public, anon, authenticated;

-- ===== به‌روزرسانی ۵: ابزارهای مصرفی (موشک، سپر، شبح، آهنربا، زمان‌منجمد، بلیت زندگی…) =====
-- اجرای دوباره بی‌خطر است. موجودی هر بازیکن در ستون boosts (jsonb: شناسه ← تعداد) نگه‌داری می‌شود.
alter table public.profiles add column if not exists boosts jsonb not null default '{}'::jsonb;

-- خرید: قیمت هر ابزار = config.game.BOOSTS.<id>.price (مالک از تنظیمات عوض می‌کند) وگرنه قیمت پیش‌فرض
create or replace function public.buy_boost(p_id text, p_qty int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  cfg jsonb := coalesce((select value -> 'BOOSTS' from public.config where key = 'game'), '{}'::jsonb);
  defaults jsonb := '{"rocket":60,"coin2":40,"shield":45,"ghost":70,"magnet":35,"freeze":50,"life":80}'::jsonb;
  unit int;
  cost int;
  have int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if not (defaults ? p_id) then return jsonb_build_object('ok', false, 'error', 'bad_id'); end if;
  if p_qty < 1 or p_qty > 20 then return jsonb_build_object('ok', false, 'error', 'bad_qty'); end if;
  if coalesce((cfg -> p_id ->> 'on')::boolean, true) = false then return jsonb_build_object('ok', false, 'error', 'unavailable'); end if;
  unit := coalesce((cfg -> p_id ->> 'price')::int, (defaults ->> p_id)::int);
  unit := least(greatest(unit, 0), 5000);
  have := coalesce((me.boosts ->> p_id)::int, 0);
  if have + p_qty > 99 then return jsonb_build_object('ok', false, 'error', 'too_many'); end if;
  cost := unit * p_qty;
  if me.coins < cost then return jsonb_build_object('ok', false, 'error', 'no_coins', 'need', cost - me.coins); end if;
  update public.profiles
     set coins = coins - cost,
         boosts = jsonb_set(coalesce(boosts, '{}'::jsonb), array[p_id], to_jsonb(have + p_qty))
   where id = me.id;
  return jsonb_build_object('ok', true, 'coins', me.coins - cost, 'paid', cost,
    'boosts', jsonb_set(coalesce(me.boosts, '{}'::jsonb), array[p_id], to_jsonb(have + p_qty)));
end $$;

-- مصرف: فقط کم می‌کند و هیچ‌وقت منفی نمی‌شود (تقلب با افزایش موجودی ممکن نیست)
create or replace function public.use_boosts(p_used jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  k text;
  n int;
  cur jsonb;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  cur := coalesce(me.boosts, '{}'::jsonb);
  for k in select jsonb_object_keys(coalesce(p_used, '{}'::jsonb)) loop
    n := least(greatest(coalesce((p_used ->> k)::int, 0), 0), 50);
    if n > 0 and cur ? k then
      cur := jsonb_set(cur, array[k], to_jsonb(greatest(coalesce((cur ->> k)::int, 0) - n, 0)));
    end if;
  end loop;
  update public.profiles set boosts = cur where id = me.id;
  return jsonb_build_object('ok', true, 'boosts', cur);
end $$;

revoke execute on function public.buy_boost(text, int) from public, anon;
revoke execute on function public.use_boosts(jsonb)    from public, anon;
grant execute on function public.buy_boost(text, int) to authenticated;
grant execute on function public.use_boosts(jsonb)    to authenticated;
