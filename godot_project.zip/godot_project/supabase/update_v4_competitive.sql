-- =====================================================================
--  به‌روزرسانی ۴: بخش رقابتی و چندنفره (لیگ و جام، فصل، رویداد، اتاق باز، پنل مدیر)
--  اجرای دوباره بی‌خطر است. Supabase ← SQL Editor ← New query ← همه‌ی این فایل ← Run
--  (اگر نصب تازه می‌کنی این بخش آخر schema.sql هم هست؛ لازم نیست جدا اجرا کنی.)
-- =====================================================================

alter table public.profiles
  add column if not exists trophies       int not null default 0,
  add column if not exists best_trophies  int not null default 0,
  add column if not exists season         int not null default -1,
  add column if not exists comp_banned    boolean not null default false,
  add column if not exists comp_streak    int not null default 0,
  add column if not exists comp_last_day  int not null default 0,
  add column if not exists comp_wins      int not null default 0,
  add column if not exists comp_games     int not null default 0;

alter table public.challenge_scores add column if not exists tries int not null default 1;

-- رویدادهای مدیر و اتاق‌های باز بازیکنان
create table if not exists public.comp_events (
  id             int generated always as identity (start with 10000000) primary key,
  kind           text not null default 'event' check (kind in ('event', 'duel')),
  title          text not null default '',
  modifier       text not null default '',
  starts_at      timestamptz not null default now(),
  ends_at        timestamptz not null,
  entry_fee      int not null default 0,
  prizes         jsonb not null default '[]',          -- جایزه‌ی سکه به‌ترتیب رتبه
  trophy_rewards jsonb not null default '[]',          -- جام به‌ترتیب رتبه
  max_tries      int not null default 0,               -- 0 = نامحدود
  is_public      boolean not null default true,
  creator        uuid references public.profiles(id) on delete set null,
  pool           int not null default 0,               -- جمع ورودی‌ها (برای دوئل‌ها)
  settled        boolean not null default false,
  created_at     timestamptz not null default now()
);
alter table public.comp_events enable row level security;
revoke all on public.comp_events from anon, authenticated;

create table if not exists public.comp_claims (
  user_id uuid not null references public.profiles(id) on delete cascade,
  room    int not null,
  primary key (user_id, room)
);
alter table public.comp_claims enable row level security;
revoke all on public.comp_claims from anon, authenticated;

-- ------------------------- تنظیمات (مدیر در بازی عوض می‌کند: config.key = 'competitive') -------------------------
create or replace function public.comp_cfg() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'enabled', true, 'daily_enabled', true, 'events_enabled', true, 'player_rooms', true,
    'daily_reward', 40, 'streak_bonus', 5, 'daily_tries', 0,
    'participation_trophies', 5,
    'rank_rewards', jsonb_build_array(150, 100, 60, 40, 30, 20, 20, 10, 10, 10),
    'rank_trophies', jsonb_build_array(40, 30, 20, 15, 10, 10, 5, 5, 5, 5),
    'duel_win_trophies', 25, 'duel_lose_trophies', 10, 'duel_rake_percent', 10,
    'create_room_fee', 20, 'entry_fee_max', 500, 'max_room_hours', 72, 'max_open_rooms', 20,
    'season_days', 30, 'season_keep_percent', 50, 'season_coins_per_100', 10, 'season_offset', 0,
    'max_score_mult', 3
  ) || coalesce((select value from public.config where key = 'competitive'), '{}'::jsonb);
$$;

create or replace function public._today() returns int language sql stable as $$
  select to_char(now() at time zone 'utc', 'YYYYMMDD')::int
$$;

create or replace function public._season_id() returns int language sql stable security definer set search_path = public as $$
  select (floor(extract(epoch from now()) / 86400 / greatest((public.comp_cfg()->>'season_days')::int, 1)))::int
         + (public.comp_cfg()->>'season_offset')::int
$$;

-- شروع فصل تازه برای همین کاربر (جام‌ها کم می‌شود و جایزه‌ی پایان فصل می‌گیرد)
create or replace function public._season_roll(uid uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare me public.profiles; sid int := public._season_id(); cfg jsonb := public.comp_cfg(); reward int := 0; old int;
begin
  select * into me from public.profiles where id = uid for update;
  if me.season = sid then return jsonb_build_object('rolled', false); end if;
  old := me.trophies;
  if me.season >= 0 then
    reward := (old / 100) * (cfg->>'season_coins_per_100')::int;
    update public.profiles set trophies = (old * (cfg->>'season_keep_percent')::int) / 100, season = sid, coins = coins + reward where id = uid;
  else
    update public.profiles set season = sid where id = uid;
  end if;
  return jsonb_build_object('rolled', me.season >= 0, 'old_trophies', old, 'reward', reward);
end $$;

-- ------------------------- ثبت نتیجه -------------------------
drop function if exists public.comp_submit(int, int, int);
create or replace function public.comp_submit(p_room int, p_score int, p_distance int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles; cfg jsonb := public.comp_cfg(); today int := public._today();
  ev public.comp_events; existed boolean; tries_now int := 0; max_t int := 0;
  reward int := 0; troph int := 0; fee int := 0; rank_now int; streak int; bonus int := 0;
  is_daily boolean := (p_room = public._today()); is_event boolean := (p_room >= 10000000 and p_room < 20200101);
  best_cap numeric;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned or me.comp_banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if not (cfg->>'enabled')::boolean then return jsonb_build_object('ok', false, 'error', 'comp_off'); end if;
  perform public._season_roll(me.id);
  if p_room < 1000 or p_room > 2147483000 then return jsonb_build_object('ok', false, 'error', 'bad_room'); end if;
  if p_room >= 20200101 and p_room <> today then return jsonb_build_object('ok', false, 'error', 'room_expired'); end if;
  best_cap := (cfg->>'max_score_mult')::numeric * (6 * p_distance + 10 * (p_distance + 60) + 500);
  if p_score < 0 or p_distance < 0 or p_distance > 30000 or p_score > best_cap then
    return jsonb_build_object('ok', false, 'error', 'implausible');
  end if;
  if is_daily then
    if not (cfg->>'daily_enabled')::boolean then return jsonb_build_object('ok', false, 'error', 'comp_off'); end if;
    max_t := (cfg->>'daily_tries')::int;
  elsif is_event then
    select * into ev from public.comp_events where id = p_room;
    if ev.id is null then return jsonb_build_object('ok', false, 'error', 'no_room'); end if;
    if ev.kind = 'event' and not (cfg->>'events_enabled')::boolean then return jsonb_build_object('ok', false, 'error', 'comp_off'); end if;
    if now() < ev.starts_at then return jsonb_build_object('ok', false, 'error', 'not_started'); end if;
    if now() >= ev.ends_at or ev.settled then return jsonb_build_object('ok', false, 'error', 'room_ended'); end if;
    max_t := ev.max_tries;
  end if;
  select tries into tries_now from public.challenge_scores where room = p_room and user_id = me.id;
  existed := found;
  tries_now := coalesce(tries_now, 0);
  if max_t > 0 and tries_now >= max_t then return jsonb_build_object('ok', false, 'error', 'no_tries'); end if;
  -- ورودی اتاق‌های دارای هزینه (فقط بار اول)
  if is_event and not existed and ev.entry_fee > 0 and ev.creator is distinct from me.id then
    fee := ev.entry_fee;
    if me.coins < fee then return jsonb_build_object('ok', false, 'error', 'no_coins', 'need', fee - me.coins); end if;
    update public.profiles set coins = coins - fee where id = me.id;
    update public.comp_events set pool = pool + fee where id = ev.id;
  end if;
  insert into public.challenge_scores (room, user_id, score, distance, tries) values (p_room, me.id, p_score, p_distance, 1)
  on conflict (room, user_id) do update set
    score = greatest(public.challenge_scores.score, excluded.score),
    distance = greatest(public.challenge_scores.distance, excluded.distance),
    tries = public.challenge_scores.tries + 1, updated_at = now();
  update public.profiles set comp_games = comp_games + 1 where id = me.id;
  streak := me.comp_streak;
  if is_daily and not existed then
    if me.comp_last_day = to_char((now() at time zone 'utc')::date - 1, 'YYYYMMDD')::int then streak := me.comp_streak + 1;
    elsif me.comp_last_day = today then streak := me.comp_streak; else streak := 1; end if;
    bonus := least(streak, 7) * (cfg->>'streak_bonus')::int;
    reward := (cfg->>'daily_reward')::int + bonus;
    troph := (cfg->>'participation_trophies')::int;
    update public.profiles set coins = coins + reward, trophies = trophies + troph, best_trophies = greatest(best_trophies, trophies + troph),
      comp_streak = streak, comp_last_day = today where id = me.id;
  end if;
  select count(*) + 1 into rank_now from public.challenge_scores c
    where c.room = p_room and c.score > (select score from public.challenge_scores where room = p_room and user_id = me.id);
  select coins, trophies into me.coins, me.trophies from public.profiles where id = me.id;
  return jsonb_build_object('ok', true, 'rank', rank_now, 'reward', reward, 'coins', me.coins, 'trophies', me.trophies,
    'trophies_gained', troph, 'streak', streak, 'streak_bonus', bonus, 'fee', fee,
    'tries_left', case when max_t > 0 then greatest(max_t - tries_now - 1, 0) else -1 end);
end $$;

drop function if exists public.comp_board(int, int);
create or replace function public.comp_board(p_room int, p_limit int default 30)
returns table (rank bigint, username text, score int, distance int, tries int, trophies int)
language sql stable security definer set search_path = public as $$
  select row_number() over (order by c.score desc, c.distance desc, c.updated_at asc) as rank, p.username, c.score, c.distance, c.tries, p.trophies
  from public.challenge_scores c join public.profiles p on p.id = c.user_id
  where c.room = p_room and not p.banned and not p.comp_banned
  order by c.score desc, c.distance desc, c.updated_at asc
  limit least(greatest(p_limit, 1), 100);
$$;

-- ------------------------- وضعیت من، فصل، جایزه‌ی دیروز -------------------------
create or replace function public.comp_state() returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles; cfg jsonb := public.comp_cfg(); roll jsonb; yday int; yrank int; ycount int; idx int;
  claim jsonb := null; srank int; tries_used int := 0; sid int := public._season_id(); days_left numeric;
begin
  select * into me from public.profiles where id = auth.uid();
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  roll := public._season_roll(me.id);
  perform public.comp_settle();
  select * into me from public.profiles where id = me.id;
  yday := to_char((now() at time zone 'utc')::date - 1, 'YYYYMMDD')::int;
  select count(*) into ycount from public.challenge_scores where room = yday;
  if exists (select 1 from public.challenge_scores where room = yday and user_id = me.id)
     and not exists (select 1 from public.comp_claims where user_id = me.id and room = yday) then
    select count(*) + 1 into yrank from public.challenge_scores c
      where c.room = yday and c.score > (select score from public.challenge_scores where room = yday and user_id = me.id);
    idx := yrank - 1;
    claim := jsonb_build_object('rank', yrank, 'count', ycount,
      'coins', coalesce((cfg->'rank_rewards'->>idx)::int, 0), 'trophies', coalesce((cfg->'rank_trophies'->>idx)::int, 2));
  end if;
  select count(*) + 1 into srank from public.profiles p where p.trophies > me.trophies and not p.banned and not p.comp_banned;
  select coalesce(tries, 0) into tries_used from public.challenge_scores where room = public._today() and user_id = me.id;
  days_left := ((sid + 1 - (cfg->>'season_offset')::int) * (cfg->>'season_days')::int) - extract(epoch from now()) / 86400;
  return jsonb_build_object('ok', true, 'trophies', me.trophies, 'best_trophies', me.best_trophies, 'streak', me.comp_streak,
    'wins', me.comp_wins, 'games', me.comp_games, 'season', sid, 'season_rank', srank,
    'season_days_left', greatest(ceil(days_left), 0), 'season_roll', roll, 'claim', claim,
    'tries_used', coalesce(tries_used, 0), 'banned', me.comp_banned, 'cfg', cfg, 'coins', me.coins);
end $$;

create or replace function public.comp_claim_yesterday() returns jsonb
language plpgsql security definer set search_path = public as $$
declare me public.profiles; cfg jsonb := public.comp_cfg(); yday int; yrank int; idx int; c int; t int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned or me.comp_banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  yday := to_char((now() at time zone 'utc')::date - 1, 'YYYYMMDD')::int;
  if not exists (select 1 from public.challenge_scores where room = yday and user_id = me.id) then
    return jsonb_build_object('ok', false, 'error', 'nothing');
  end if;
  begin
    insert into public.comp_claims (user_id, room) values (me.id, yday);
  exception when unique_violation then return jsonb_build_object('ok', false, 'error', 'already');
  end;
  select count(*) + 1 into yrank from public.challenge_scores s
    where s.room = yday and s.score > (select score from public.challenge_scores where room = yday and user_id = me.id);
  idx := yrank - 1;
  c := coalesce((cfg->'rank_rewards'->>idx)::int, 0);
  t := coalesce((cfg->'rank_trophies'->>idx)::int, 2);
  update public.profiles set coins = coins + c, trophies = trophies + t, best_trophies = greatest(best_trophies, trophies + t),
    comp_wins = comp_wins + case when yrank = 1 then 1 else 0 end where id = me.id;
  return jsonb_build_object('ok', true, 'rank', yrank, 'coins_gained', c, 'trophies_gained', t, 'coins', me.coins + c, 'trophies', me.trophies + t);
end $$;

-- ------------------------- رویدادها و اتاق‌های باز -------------------------
create or replace function public.comp_events_list() returns jsonb
language plpgsql security definer set search_path = public as $$
declare rows jsonb;
begin
  perform public.comp_settle();
  select coalesce(jsonb_agg(x order by x.ends_at), '[]'::jsonb) into rows from (
    select e.id, e.kind, e.title, e.modifier, e.starts_at, e.ends_at, e.entry_fee, e.prizes, e.trophy_rewards, e.max_tries, e.pool,
      (select p.username from public.profiles p where p.id = e.creator) as creator,
      (select count(*) from public.challenge_scores c where c.room = e.id) as players,
      (select c.score from public.challenge_scores c where c.room = e.id and c.user_id = auth.uid()) as my_score,
      (select c.tries from public.challenge_scores c where c.room = e.id and c.user_id = auth.uid()) as my_tries
    from public.comp_events e
    where not e.settled and e.ends_at > now() and (e.is_public or e.creator = auth.uid() or public.is_admin())
  ) x;
  return rows;
end $$;

create or replace function public.comp_create_room(p_title text, p_modifier text, p_hours int, p_entry_fee int, p_public boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
declare me public.profiles; cfg jsonb := public.comp_cfg(); fee int := (cfg->>'create_room_fee')::int; new_id int;
begin
  select * into me from public.profiles where id = auth.uid() for update;
  if me.id is null then return jsonb_build_object('ok', false, 'error', 'not_logged_in'); end if;
  if me.banned or me.comp_banned then return jsonb_build_object('ok', false, 'error', 'banned'); end if;
  if not (cfg->>'enabled')::boolean or not (cfg->>'player_rooms')::boolean then return jsonb_build_object('ok', false, 'error', 'comp_off'); end if;
  if (select count(*) from public.comp_events where kind = 'duel' and creator = me.id and not settled and ends_at > now()) >= 3 then
    return jsonb_build_object('ok', false, 'error', 'too_many_rooms');
  end if;
  if (select count(*) from public.comp_events where not settled and ends_at > now()) >= (cfg->>'max_open_rooms')::int then
    return jsonb_build_object('ok', false, 'error', 'rooms_full');
  end if;
  if me.coins < fee then return jsonb_build_object('ok', false, 'error', 'no_coins', 'need', fee - me.coins); end if;
  update public.profiles set coins = coins - fee where id = me.id;
  insert into public.comp_events (kind, title, modifier, ends_at, entry_fee, creator, is_public, max_tries)
  values ('duel', left(coalesce(nullif(trim(p_title), ''), 'دوئل ' || me.username), 40), left(coalesce(p_modifier, ''), 40),
    now() + make_interval(hours => least(greatest(p_hours, 1), (cfg->>'max_room_hours')::int)),
    least(greatest(p_entry_fee, 0), (cfg->>'entry_fee_max')::int), me.id, p_public, 0) returning id into new_id;
  return jsonb_build_object('ok', true, 'room', new_id, 'coins', me.coins - fee);
end $$;

-- پایان‌دادن و پرداخت جایزه‌ی همه‌ی رویدادهای تمام‌شده (چند بار صدا زدنش بی‌خطر است)
create or replace function public.comp_settle() returns int
language plpgsql security definer set search_path = public as $$
declare ev public.comp_events; cfg jsonb := public.comp_cfg(); n int := 0; r record; idx int; coins_g int; troph_g int; payout int; players int;
begin
  for ev in select * from public.comp_events where not settled and ends_at <= now() for update skip locked loop
    select count(*) into players from public.challenge_scores where room = ev.id;
    idx := 0;
    for r in select c.user_id from public.challenge_scores c join public.profiles p on p.id = c.user_id
             where c.room = ev.id and not p.banned and not p.comp_banned order by c.score desc, c.distance desc, c.updated_at asc loop
      if ev.kind = 'event' then
        coins_g := coalesce((ev.prizes->>idx)::int, 0);
        troph_g := coalesce((ev.trophy_rewards->>idx)::int, 0);
      else
        coins_g := 0;
        if idx = 0 and players >= 2 then
          payout := (ev.pool * (100 - (cfg->>'duel_rake_percent')::int)) / 100;
          coins_g := payout; troph_g := (cfg->>'duel_win_trophies')::int;
        elsif players >= 2 then troph_g := -(cfg->>'duel_lose_trophies')::int;
        else troph_g := 0; end if;
        if players < 2 and idx = 0 and ev.pool > 0 then coins_g := ev.pool; end if;  -- تنها بازیکن: ورودی‌اش برمی‌گردد
      end if;
      update public.profiles set coins = coins + coins_g, trophies = greatest(trophies + troph_g, 0),
        best_trophies = greatest(best_trophies, trophies + troph_g), comp_wins = comp_wins + case when idx = 0 and (ev.kind = 'event' or players >= 2) then 1 else 0 end
        where id = r.user_id;
      idx := idx + 1;
    end loop;
    update public.comp_events set settled = true where id = ev.id;
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.comp_season_board(p_limit int default 50)
returns table (rank bigint, username text, trophies int, wins int)
language sql stable security definer set search_path = public as $$
  select row_number() over (order by p.trophies desc, p.comp_wins desc, p.username) as rank, p.username, p.trophies, p.comp_wins
  from public.profiles p where not p.banned and not p.comp_banned and (p.trophies > 0 or p.comp_games > 0)
  order by p.trophies desc, p.comp_wins desc, p.username
  limit least(greatest(p_limit, 1), 100);
$$;

-- ------------------------- ابزار مدیر (همه‌ی کارها در یک تابع؛ فقط ادمین) -------------------------
create or replace function public.comp_admin(p_action text, p_args jsonb default '{}') returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; v_room int; amt int; new_id int; n int;
begin
  if not public.is_admin() then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  v_room := (p_args->>'room')::int;
  if p_args ? 'username' then
    select id into uid from public.profiles where lower(username) = lower(p_args->>'username');
    if uid is null and p_action in ('remove_score', 'reduce_score', 'trophies', 'coins', 'ban') then
      return jsonb_build_object('ok', false, 'error', 'no_user');
    end if;
  end if;
  case p_action
    when 'create_event' then
      insert into public.comp_events (kind, title, modifier, starts_at, ends_at, entry_fee, prizes, trophy_rewards, max_tries, is_public, creator)
      values ('event', left(coalesce(p_args->>'title', 'رویداد'), 60), left(coalesce(p_args->>'modifier', ''), 40),
        coalesce((p_args->>'starts_at')::timestamptz, now()),
        coalesce((p_args->>'ends_at')::timestamptz, now() + interval '24 hours'),
        greatest(coalesce((p_args->>'entry_fee')::int, 0), 0),
        coalesce(p_args->'prizes', '[]'), coalesce(p_args->'trophy_rewards', '[]'),
        greatest(coalesce((p_args->>'max_tries')::int, 0), 0), coalesce((p_args->>'is_public')::boolean, true), null)
      returning id into new_id;
      return jsonb_build_object('ok', true, 'room', new_id);
    when 'end_room' then
      update public.comp_events set ends_at = now() where id = v_room;
      perform public.comp_settle();
      return jsonb_build_object('ok', true);
    when 'delete_room' then
      delete from public.challenge_scores where room = (p_args->>'room')::int;
      delete from public.comp_events where id = v_room;
      return jsonb_build_object('ok', true);
    when 'reset_board' then
      delete from public.challenge_scores where room = (p_args->>'room')::int;
      return jsonb_build_object('ok', true);
    when 'remove_score' then
      delete from public.challenge_scores where room = (p_args->>'room')::int and user_id = uid;
      return jsonb_build_object('ok', true);
    when 'reduce_score' then
      amt := greatest(coalesce((p_args->>'amount')::int, 0), 0);
      update public.challenge_scores set score = greatest(score - amt, 0) where room = (p_args->>'room')::int and user_id = uid;
      get diagnostics n = row_count;
      return jsonb_build_object('ok', n > 0, 'error', case when n = 0 then 'no_score' else '' end);
    when 'trophies' then
      amt := coalesce((p_args->>'delta')::int, 0);
      update public.profiles set trophies = greatest(trophies + amt, 0), best_trophies = greatest(best_trophies, trophies + amt) where id = uid;
      return jsonb_build_object('ok', true);
    when 'coins' then
      amt := coalesce((p_args->>'delta')::int, 0);
      update public.profiles set coins = greatest(coins + amt, 0) where id = uid;
      return jsonb_build_object('ok', true);
    when 'ban' then
      update public.profiles set comp_banned = coalesce((p_args->>'banned')::boolean, true) where id = uid;
      return jsonb_build_object('ok', true);
    when 'new_season' then
      insert into public.config (key, value) values ('competitive', jsonb_build_object('season_offset', (public.comp_cfg()->>'season_offset')::int + 1))
      on conflict (key) do update set value = public.config.value || jsonb_build_object('season_offset', (public.comp_cfg()->>'season_offset')::int + 1);
      return jsonb_build_object('ok', true);
    else
      return jsonb_build_object('ok', false, 'error', 'unknown_action');
  end case;
end $$;

grant execute on function public.comp_submit(int, int, int)           to authenticated;
grant execute on function public.comp_board(int, int)                  to anon, authenticated;
grant execute on function public.comp_state()                          to authenticated;
grant execute on function public.comp_claim_yesterday()                to authenticated;
grant execute on function public.comp_events_list()                    to authenticated;
grant execute on function public.comp_create_room(text, text, int, int, boolean) to authenticated;
grant execute on function public.comp_settle()                         to authenticated;
grant execute on function public.comp_season_board(int)                to anon, authenticated;
grant execute on function public.comp_admin(text, jsonb)               to authenticated;
revoke execute on function public._season_roll(uuid) from public, anon, authenticated;
