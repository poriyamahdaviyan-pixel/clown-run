-- =====================================================================
--  به‌روزرسانی ۳ (اجرای دوباره بی‌خطر است): فایل‌های بزرگ، نسخه‌ها و بروزرسانی، و بخش رقابتی
--  در Supabase ← SQL Editor ← New query ← کل این فایل را بچسبان ← Run
-- =====================================================================

-- ------------------------- ۱) فایل‌های بالای ۵۰ مگابایت (تکه‌تکه) -------------------------
-- فایل بزرگ به تکه‌های «نام.part0001 …» شکسته می‌شود؛ خریدار باید به همه‌ی تکه‌ها دسترسی داشته باشد
drop policy if exists files_owner_read on storage.objects;
create policy files_owner_read on storage.objects for select using (
  bucket_id = 'item-files' and exists (
    select 1 from public.purchases p join public.items i on i.id = p.item_id
    where p.user_id = auth.uid() and (
      i.file_path = storage.objects.name
      or (length(storage.objects.name) = length(i.file_path) + 9
          and left(storage.objects.name, length(i.file_path) + 5) = i.file_path || '.part')
    )
  )
);

-- ------------------------- ۲) نسخه‌ها: لینک دانلود APK و وصله‌ی بروزرسانی -------------------------
insert into storage.buckets (id, name, public) values ('releases', 'releases', true)
  on conflict (id) do nothing;
drop policy if exists releases_read on storage.objects;
create policy releases_read on storage.objects for select using (bucket_id = 'releases');
drop policy if exists releases_admin on storage.objects;
create policy releases_admin on storage.objects for all
  using (bucket_id = 'releases' and public.is_admin()) with check (bucket_id = 'releases' and public.is_admin());

create table if not exists public.app_releases (
  id           uuid primary key default gen_random_uuid(),
  kind         text not null check (kind in ('apk', 'patch')),
  version_name text not null default '',
  version_code int  not null default 1,
  base_code    int  not null default 0,      -- فقط برای وصله: روی کدام شماره‌ی ساخت APK کار می‌کند
  edition      text not null default 'all' check (edition in ('all', 'public', 'owner')),
  file_path    text not null default '',     -- مسیر در باکت releases
  url          text not null default '',     -- لینک بیرونی (مثلاً GitHub Releases) برای APKهای بزرگ
  size         bigint not null default 0,
  sha256       text not null default '',
  sig          text not null default '',     -- امضای RSA وصله
  notes        text not null default '',
  mandatory    boolean not null default false,
  published    boolean not null default true,
  created_at   timestamptz not null default now()
);
alter table public.app_releases enable row level security;
drop policy if exists releases_select on public.app_releases;
create policy releases_select on public.app_releases for select using (published or public.is_admin());
drop policy if exists releases_write on public.app_releases;
create policy releases_write on public.app_releases for all using (public.is_admin()) with check (public.is_admin());
grant select on public.app_releases to anon, authenticated;
grant insert, update, delete on public.app_releases to authenticated;
