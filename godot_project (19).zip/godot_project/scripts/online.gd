extends Node
## بخش آنلاین (Supabase): ورود، جدول امتیاز، فروشگاه آیتم‌ها، کیف پول، تنظیمات از راه دور.
## همه‌ی منطق حساس (قیمت، قفل، سکه) سمت سرور است؛ این فایل فقط درخواست می‌فرستد.

signal auth_changed
signal profile_changed
signal items_changed
signal busy_changed(busy: bool)
signal connection_changed(online: bool)

const CFG_PATH := "res://online.cfg"
const SESSION_PATH := "user://online_session.cfg"
const REMOTE_CACHE := "user://remote_config.json"
const ITEM_DIR := "user://online_items/"
const CACHE_DIR := "user://online_cache/"
const EMAIL_DOMAIN := "players.coinrunner.app"
var APP_VERSION: int:
	get: return Updater.BUILD
const MAX_DOWNLOAD := 2 * 1024 * 1024 * 1024
var SINGLE_MAX := 45 * 1024 * 1024         # سقف هر آبجکت در Supabase (طرح رایگان ۵۰MB) — بزرگ‌تر از این تکه‌تکه می‌شود
var CHUNK := 40 * 1024 * 1024
const PARTS_MAGIC := "clownparts"
signal transfer(text: String)            # پیشرفت آپلود/دانلود (برای نمایش در رابط)

var url := ""
var anon_key := ""
var token := ""
var refresh_token := ""
var user_id := ""
var username := ""
var coins := 0
var is_admin := false
var daily_ready := true
var items: Array = []
var levels: Array = [0, 0, 0, 0, 0, 0]
var save_data: Dictionary = {}
var profile_loaded := false
var restoring := false
var offline := false
var _sent_coins := 0
var pending: Array = []          # کارهای انجام‌شده بدون اینترنت که بعداً به سرور می‌روند
var _flushing := false
const PENDING_PATH := "user://online_pending.json"
var _save_timer: Timer
var _beat: Timer
var owned := {}            # item_id → true
var announcement := ""
var maintenance := false
var last_error := ""
var busy := 0
var _tex_cache := {}
var _refreshing := false


func _ready() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(CFG_PATH) == OK:
		url = String(cfg.get_value("server", "url", "")).strip_edges().trim_suffix("/")
		anon_key = String(cfg.get_value("server", "anon_key", "")).strip_edges()
	_save_timer = Timer.new()
	_save_timer.one_shot = true
	_save_timer.wait_time = 4.0
	_save_timer.timeout.connect(_flush_save)
	add_child(_save_timer)
	_beat = Timer.new()
	_beat.wait_time = 10.0
	_beat.timeout.connect(_heartbeat)
	add_child(_beat)
	if OS.get_environment("CR_NOGATE") != "1":
		_beat.start()
	Game.game_started.connect(func(): _sent_coins = 0)
	DirAccess.make_dir_recursive_absolute(ITEM_DIR)
	DirAccess.make_dir_recursive_absolute(CACHE_DIR)
	_load_cached_remote()
	if enabled():
		_restore_session()
		fetch_config()
	Game.game_over.connect(_on_game_over)


func enabled() -> bool:
	return url != "" and anon_key != ""


func logged_in() -> bool:
	return token != "" and user_id != ""


# ------------------------- درخواست پایه -------------------------
## نتیجه: {ok, code, data, error}
func _req(method: int, path: String, body = null, auth: bool = true, raw: bool = false, extra: PackedStringArray = PackedStringArray()) -> Dictionary:
	if not enabled():
		return {"ok": false, "code": 0, "data": null, "error": "سرور آنلاین تنظیم نشده است"}
	var h := HTTPRequest.new()
	h.timeout = 25.0
	h.accept_gzip = true
	add_child(h)
	var headers := PackedStringArray(["apikey: " + anon_key, "Content-Type: application/json"])
	# کلید جدید «sb_publishable_…» JWT نیست و نباید در Authorization برود؛ کلید قدیمی anon (JWT) می‌رود.
	if auth and token != "":
		headers.append("Authorization: Bearer " + token)
	elif not anon_key.begins_with("sb_"):
		headers.append("Authorization: Bearer " + anon_key)
	headers.append_array(extra)
	var payload := ""
	if body != null:
		payload = JSON.stringify(body)
	_set_busy(1)
	var err := h.request(url + path, headers, method, payload)
	if err != OK:
		h.queue_free()
		_set_busy(-1)
		_set_offline(true)
		return {"ok": false, "code": 0, "data": null, "error": "اتصال برقرار نشد"}
	var res: Array = await h.request_completed
	h.queue_free()
	_set_busy(-1)
	var code: int = res[1]
	var bytes: PackedByteArray = res[3]
	if res[0] != HTTPRequest.RESULT_SUCCESS:
		_set_offline(true)
		return {"ok": false, "code": 0, "data": null, "error": "اینترنت در دسترس نیست"}
	_set_offline(false)
	if raw:
		return {"ok": code >= 200 and code < 300, "code": code, "data": bytes, "error": "" if code < 300 else "خطا %d" % code}
	var data = null
	var txt := bytes.get_string_from_utf8()
	if txt != "":
		data = JSON.parse_string(txt)
	if code == 401 and auth and refresh_token != "" and not _refreshing:
		if await _refresh():
			return await _req(method, path, body, auth, raw, extra)
	var ok := code >= 200 and code < 300
	var emsg := ""
	if not ok:
		emsg = _error_text(data, code)
		last_error = emsg
	return {"ok": ok, "code": code, "data": data, "error": emsg}


func _set_offline(v: bool) -> void:
	if offline != v:
		offline = v
		connection_changed.emit(not v)


## باز بودن بازی: سرور تنظیم شده، وارد شده و پروفایل از سرور آمده
func gate_open() -> bool:
	if OS.get_environment("CR_NOGATE") == "1":      # فقط برای تست‌های خودکار
		return true
	return enabled() and logged_in() and profile_loaded


func _save_pending() -> void:
	var f := FileAccess.open(PENDING_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify({"uid": user_id, "ops": pending}))


func _load_pending() -> void:
	pending = []
	if not FileAccess.file_exists(PENDING_PATH):
		return
	var d = JSON.parse_string(FileAccess.get_file_as_string(PENDING_PATH))
	if d is Dictionary and String(d.get("uid", "")) == user_id and d.get("ops") is Array:
		pending = d.ops


## تغییر سکه‌ای که هنوز به سرور نرسیده (دورها و جایزه‌ها منهای ادامه‌های بدون اینترنت)
func pending_coins() -> int:
	var t := 0
	for op in pending:
		match String(op.get("t", "")):
			"run": t += int(op.get("coins", 0))
			"mission": t += int(op.get("amount", 0))
			"revive": t -= Game.REVIVE_PRICE
	return t


func display_coins() -> int:
	return maxi(0, coins + pending_coins())


func queue_op(op: Dictionary) -> void:
	pending.append(op)
	_save_pending()
	_sync_game()
	profile_changed.emit()


func _rpc(fn: String, body: Dictionary) -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/" + fn, body)
	if r.ok and r.data is Dictionary:
		return {"ok": bool(r.data.get("ok", false)), "net": false, "data": r.data, "error": String(r.data.get("error", ""))}
	return {"ok": false, "net": r.code == 0, "data": {}, "error": String(r.error)}


## ارسال کارهای صف‌شده به ترتیب؛ با قطع اینترنت متوقف می‌شود و بعداً ادامه می‌دهد
func flush_pending() -> void:
	if _flushing or not logged_in() or pending.is_empty() or token == "offline":
		return
	_flushing = true
	while not pending.is_empty():
		var op: Dictionary = pending[0]
		var r: Dictionary
		match String(op.get("t", "")):
			"run":
				r = await _rpc("submit_run", {"p_score": int(op.score), "p_distance": int(op.distance), "p_coins": int(op.coins)})
			"mission":
				r = await _rpc("mission_reward", {"p_amount": int(op.amount)})
			"revive":
				r = await _rpc("spend_revive", {})
			"challenge":
				r = await _rpc("comp_submit", {"p_room": int(op.room), "p_score": int(op.score), "p_distance": int(op.distance)})
			_:
				r = {"ok": true, "net": false, "data": {}, "error": ""}
		if r.net:
			break
		if r.error == "too_fast":
			await get_tree().create_timer(9.0).timeout
			continue
		pending.pop_front()
		_save_pending()
		if r.ok and r.data.has("coins"):
			coins = int(r.data.coins)
		elif not r.ok:
			Game.toast.emit("یک مورد ثبت نشد: " + error_text(r.error))
	_flushing = false
	if pending.is_empty():
		await refresh_profile()
	else:
		_sync_game()
		profile_changed.emit()


func _heartbeat() -> void:
	if not enabled():
		return
	var was := offline
	await _req(HTTPClient.METHOD_GET, "/rest/v1/config?select=key&limit=1", null, false)
	if was and not offline:
		if token == "offline":
			await _refresh()
		if logged_in() and token != "offline":
			await flush_pending()
			refresh_profile()
		fetch_config()


## بررسی فوری اتصال (دکمه‌ی «تلاش دوباره»)
func check_connection() -> void:
	await _heartbeat()


func _error_text(data, code: int) -> String:
	if data is Dictionary:
		var m := s(data.get("msg", data.get("message", data.get("error_description", data.get("error", "")))))
		if m.contains("Invalid login"):
			return "نام کاربری یا رمز اشتباه است"
		if m.contains("already registered") or m.contains("already been registered"):
			return "این نام کاربری قبلاً گرفته شده"
		if m.contains("Password should be"):
			return "رمز باید حداقل ۶ کاراکتر باشد"
		if m.contains("rate limit"):
			return "تعداد تلاش زیاد است؛ کمی بعد دوباره امتحان کن"
		if m != "":
			return m
	return "خطا (%d)" % code


func _set_busy(d: int) -> void:
	var before := busy > 0
	busy = maxi(0, busy + d)
	if before != (busy > 0):
		busy_changed.emit(busy > 0)


func _email(user: String) -> String:
	return "%s@%s" % [user.to_lower(), EMAIL_DOMAIN]


static func s(v) -> String:
	return "" if v == null else str(v)


static func valid_username(u: String) -> bool:
	if u.length() < 3 or u.length() > 20:
		return false
	for i in u.length():
		var c := u.unicode_at(i)
		if not ((c >= 48 and c <= 57) or (c >= 65 and c <= 90) or (c >= 97 and c <= 122) or c == 95):
			return false
	return true


# ------------------------- ورود / ثبت‌نام -------------------------
func sign_up(user: String, pw: String) -> Dictionary:
	if not valid_username(user):
		return {"ok": false, "error": "نام کاربری: ۳ تا ۲۰ حرف انگلیسی، عدد یا _"}
	if pw.length() < 6:
		return {"ok": false, "error": "رمز باید حداقل ۶ کاراکتر باشد"}
	var r := await _req(HTTPClient.METHOD_POST, "/auth/v1/signup", {"email": _email(user), "password": pw, "data": {"username": user}}, false)
	if not r.ok:
		return r
	var d: Dictionary = r.data if r.data is Dictionary else {}
	if not d.has("access_token"):
		return {"ok": false, "error": "ثبت‌نام انجام شد ولی ورود خودکار نشد؛ (در Supabase گزینه‌ی Confirm email را خاموش کن) سپس وارد شو"}
	await _accept_session(d)
	return {"ok": true, "error": ""}


func sign_in(user: String, pw: String) -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/auth/v1/token?grant_type=password", {"email": _email(user), "password": pw}, false)
	if not r.ok:
		return r
	await _accept_session(r.data as Dictionary)
	return {"ok": true, "error": ""}


func sign_out() -> void:
	token = ""
	refresh_token = ""
	user_id = ""
	username = ""
	coins = 0
	is_admin = false
	profile_loaded = false
	pending = []
	_save_pending()
	levels = [0, 0, 0, 0, 0, 0]
	save_data = {}
	owned.clear()
	Game.coins = 0
	Game.coins_changed.emit(0)
	var cfg := ConfigFile.new()
	cfg.save(SESSION_PATH)
	auth_changed.emit()


func _accept_session(d: Dictionary) -> void:
	token = s(d.get("access_token", ""))
	refresh_token = s(d.get("refresh_token", refresh_token))
	var u = d.get("user", {})
	if u is Dictionary:
		user_id = s(u.get("id", user_id))
	var cfg := ConfigFile.new()
	cfg.set_value("s", "refresh", refresh_token)
	cfg.save(SESSION_PATH)
	await refresh_profile()
	_load_pending()
	flush_pending()
	auth_changed.emit()


func _save_cache(p: Dictionary) -> void:
	var cfg := ConfigFile.new()
	cfg.load(SESSION_PATH)
	cfg.set_value("s", "refresh", refresh_token)
	cfg.set_value("s", "cache", {"uid": user_id, "username": username, "coins": coins, "levels": levels,
		"save": save_data, "is_admin": is_admin, "best_score": int(p.get("best_score", 0)), "best_distance": int(p.get("best_distance", 0))})
	cfg.save(SESSION_PATH)


## بدون اینترنت و با حساب قبلی: با آخرین اطلاعات ذخیره‌شده وارد می‌شود (تا اتصال برگردد)
func _apply_cache(c) -> void:
	if not (c is Dictionary) or String(c.get("uid", "")) == "":
		return
	user_id = String(c.uid)
	username = String(c.get("username", ""))
	coins = int(c.get("coins", 0))
	is_admin = bool(c.get("is_admin", false))
	levels = []
	for x in c.get("levels", [0, 0, 0, 0, 0, 0]):
		levels.append(int(x))
	if levels.size() != 6:
		levels = [0, 0, 0, 0, 0, 0]
	save_data = c.get("save", {})
	token = "offline"
	profile_loaded = true
	_load_pending()
	_sync_game(c)
	profile_changed.emit()


func _restore_session() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SESSION_PATH) != OK:
		return
	refresh_token = String(cfg.get_value("s", "refresh", ""))
	if refresh_token != "":
		restoring = true
		auth_changed.emit()
		if await _refresh():
			await refresh_profile()
			_load_pending()
			flush_pending()
		elif offline:
			_apply_cache(cfg.get_value("s", "cache", {}))
		restoring = false
		auth_changed.emit()


func _refresh() -> bool:
	if refresh_token == "":
		return false
	_refreshing = true
	var r := await _req(HTTPClient.METHOD_POST, "/auth/v1/token?grant_type=refresh_token", {"refresh_token": refresh_token}, false)
	_refreshing = false
	if not r.ok or not (r.data is Dictionary):
		if r.code == 400 or r.code == 401:
			refresh_token = ""
		return false
	var d: Dictionary = r.data
	token = s(d.get("access_token", ""))
	refresh_token = s(d.get("refresh_token", refresh_token))
	var u = d.get("user", {})
	if u is Dictionary:
		user_id = s(u.get("id", user_id))
	var cfg := ConfigFile.new()
	cfg.set_value("s", "refresh", refresh_token)
	cfg.save(SESSION_PATH)
	return token != ""


func refresh_profile() -> void:
	if not logged_in():
		return
	var r := await _req(HTTPClient.METHOD_GET, "/rest/v1/profiles?id=eq.%s&select=*" % user_id)
	if r.ok and r.data is Array and (r.data as Array).size() > 0:
		var p: Dictionary = r.data[0]
		username = s(p.get("username", ""))
		coins = int(p.get("coins", 0))
		is_admin = bool(p.get("is_admin", false))
		var lv = p.get("levels", [])
		if lv is Array and (lv as Array).size() == 6:
			levels = []
			for x in lv:
				levels.append(int(x))
		var sv = p.get("save", {})
		save_data = sv if sv is Dictionary else {}
		profile_loaded = true
		_save_cache(p)
		_sync_game(p)
		daily_ready = s(p.get("last_daily", "")) != Time.get_date_string_from_system(true)
		if bool(p.get("banned", false)):
			last_error = "این حساب مسدود شده است"
		profile_changed.emit()
		var pr := await _req(HTTPClient.METHOD_GET, "/rest/v1/purchases?select=item_id")
		if pr.ok and pr.data is Array:
			owned.clear()
			for row in pr.data:
				owned[String(row.item_id)] = true


## سرور مرجع است: سکه، ارتقاها، رکورد و ماموریت‌ها از حساب می‌آیند (وسط دور بازی سکه‌ی دور جاری دست نمی‌خورد)
func _sync_game(p: Dictionary = {}) -> void:
	if not Game.is_active or Game.over:
		Game.coins = display_coins()
		Game.coins_changed.emit(Game.coins)
	for i in 6:
		Game.levels[i] = clampi(int(levels[i]), 0, Game.MAX_LEVEL)
	if not p.is_empty():
		Game.high_score = int(p.get("best_score", Game.high_score))
		Game.best_distance = int(p.get("best_distance", Game.best_distance))
	var ms = save_data.get("missions", null)
	if ms is Array and not (ms as Array).is_empty():
		Game.set_missions_from_server(ms)
	elif profile_loaded:
		queue_save()


func queue_save() -> void:
	if logged_in() and profile_loaded and _save_timer != null:
		_save_timer.start()


func _flush_save() -> void:
	if not logged_in():
		return
	save_data["missions"] = Game.missions
	await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/save_progress", {"p_data": save_data})


func buy_upgrade(id: int) -> Dictionary:
	if not pending.is_empty():
		await flush_pending()
	if not pending.is_empty() or offline:
		return {"ok": false, "error": "برای ارتقا باید اینترنت وصل باشد"}
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/buy_upgrade", {"p_id": id})
	if r.ok and r.data is Dictionary:
		if r.data.get("ok", false):
			coins = int(r.data.coins)
			levels[id] = int(r.data.level)
			profile_changed.emit()
		return r.data
	return {"ok": false, "error": r.error}


func pay_revive() -> Dictionary:
	if pending.is_empty() and not offline:
		var r := await _rpc("spend_revive", {})
		if r.ok:
			coins = int(r.data.coins)
			return {"ok": true, "coins": display_coins()}
		if not r.net:
			return {"ok": false, "error": r.error, "need": int(r.data.get("need", 0))}
	# بدون اینترنت: بازی قطع نمی‌شود؛ هزینه بعداً از حساب کم می‌شود
	if display_coins() < Game.REVIVE_PRICE:
		return {"ok": false, "error": "no_coins", "need": Game.REVIVE_PRICE - display_coins()}
	queue_op({"t": "revive"})
	return {"ok": true, "coins": display_coins()}


func mission_reward(amount: int) -> void:
	if not pending.is_empty() or offline:
		queue_op({"t": "mission", "amount": amount})
		flush_pending()
		return
	var r := await _rpc("mission_reward", {"p_amount": amount})
	if r.ok:
		coins = int(r.data.coins)
		profile_changed.emit()
	elif r.net:
		queue_op({"t": "mission", "amount": amount})


## (مدیر) سکه برای خودش
func admin_grant_self(amount: int) -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/admin_grant_coins", {"p_user": user_id, "p_amount": amount})
	if r.ok:
		await refresh_profile()
	return {"ok": r.ok, "error": r.error}


# ------------------------- تنظیمات از راه دور -------------------------
func _load_cached_remote() -> void:
	if not FileAccess.file_exists(REMOTE_CACHE):
		return
	var d = JSON.parse_string(FileAccess.get_file_as_string(REMOTE_CACHE))
	if d is Dictionary:
		_apply_remote(d)


var comp_cfg: Dictionary = {}          # تنظیمات رقابت (از config.competitive)
var comp_state_cache: Dictionary = {}  # آخرین وضعیت من در رقابت


func _apply_remote(d: Dictionary) -> void:
	comp_cfg = d.get("competitive", {}) if d.get("competitive") is Dictionary else {}
	if d.get("game") is Dictionary:
		Game.apply_remote_config(d.game)
	if d.has("police"):
		PoliceCfg.apply_remote(d.police)
	if d.has("content"):
		Content.apply_remote(d.content)
	announcement = s(d.get("announcement", ""))
	maintenance = bool(d.get("maintenance", false))
	if int(d.get("min_version", 1)) > APP_VERSION:
		announcement = "نسخه‌ی جدید بازی منتشر شده؛ لطفاً به‌روزرسانی کن."


func fetch_config() -> void:
	var r := await _req(HTTPClient.METHOD_GET, "/rest/v1/config?select=key,value", false)
	if not r.ok or not (r.data is Array):
		return
	var d := {}
	for row in r.data:
		d[String(row.key)] = row.value
	var f := FileAccess.open(REMOTE_CACHE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))
		f.close()
	_apply_remote(d)


## (فقط ادمین؛ سرور خودش RLS را اجرا می‌کند) تنظیمات گیم‌پلی را برای همه‌ی بازیکنان ذخیره می‌کند
func push_game_config(d: Dictionary) -> Dictionary:
	if not is_admin:
		return {"ok": false, "error": "فقط مدیر می‌تواند"}
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/config?on_conflict=key", {"key": "game", "value": d}, true, false, PackedStringArray(["Prefer: resolution=merge-duplicates,return=minimal"]))
	return {"ok": r.ok, "error": r.error}


## (فقط ادمین) تنظیمات بدن/حرکتِ تعقیب‌کننده را برای همه ذخیره می‌کند
## متن‌ها، منو و قابلیت‌های نسخه‌ی عمومی (فقط مدیر)
func push_content(d: Dictionary) -> Dictionary:
	if not is_admin:
		return {"ok": false, "error": "فقط مدیر می‌تواند"}
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/config?on_conflict=key", {"key": "content", "value": d}, true, false, PackedStringArray(["Prefer: resolution=merge-duplicates,return=minimal"]))
	return {"ok": r.ok, "error": r.error}


func push_chaser_config(d: Dictionary) -> Dictionary:
	if not is_admin:
		return {"ok": false, "error": "فقط مدیر می‌تواند"}
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/config?on_conflict=key", {"key": "police", "value": d}, true, false, PackedStringArray(["Prefer: resolution=merge-duplicates,return=minimal"]))
	return {"ok": r.ok, "error": r.error}


# ------------------------- امتیاز و کیف پول -------------------------
func _on_game_over(summary: Dictionary) -> void:
	if not logged_in() or maintenance:
		return
	var sc := int(summary.get("score", 0))
	var dist := int(summary.get("distance", 0))
	if Game.challenge_room > 0:
		var room := Game.challenge_room
		var cr := await submit_challenge(room, sc, dist)
		if cr.ok:
			var bits: Array = ["رتبه‌ی تو: %d" % int(cr.rank)]
			if int(cr.reward) > 0:
				bits.append("+%d سکه" % int(cr.reward))
			if int(cr.get("trophies_gained", 0)) > 0:
				bits.append("+%d جام" % int(cr.trophies_gained))
			if int(cr.get("fee", 0)) > 0:
				bits.append("ورودی %d سکه" % int(cr.fee))
			if int(cr.get("streak", 0)) > 1 and int(cr.reward) > 0:
				bits.append("%d روز پشت‌سرهم" % int(cr.streak))
			Game.toast.emit("  •  ".join(bits))
		elif offline:
			queue_op({"t": "challenge", "room": room, "score": sc, "distance": dist})
		else:
			Game.toast.emit("ثبت رقابت ناموفق: " + error_text(String(cr.error)))
	var rc := int(summary.get("coins", 0))
	var delta := maxi(0, rc - _sent_coins)
	_sent_coins = rc
	queue_op({"t": "run", "score": sc, "distance": dist, "coins": delta})
	await flush_pending()
	_flush_save()


func submit_run(score: int, distance: int, run_coins: int) -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/submit_run", {"p_score": score, "p_distance": distance, "p_coins": run_coins})
	if r.ok and r.data is Dictionary and r.data.get("ok", false):
		coins = int(r.data.get("coins", coins))
		_sync_game()
		profile_changed.emit()
		return {"ok": true, "rank": int(r.data.get("rank", 0))}
	var e := ""
	if r.data is Dictionary:
		e = String(r.data.get("error", ""))
	return {"ok": false, "error": e if e != "" else r.error}


func leaderboard(period: String = "all") -> Array:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/get_leaderboard", {"p_period": period, "p_limit": 50}, false)
	return r.data if (r.ok and r.data is Array) else []


## کد چالش روزانه (تاریخ UTC): همه‌ی بازیکنان امروز یک عدد مشترک دارند
static func daily_room() -> int:
	var d := Time.get_datetime_dict_from_system(true)
	return int(d.year) * 10000 + int(d.month) * 100 + int(d.day)


func submit_challenge(room: int, score: int, distance: int) -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/comp_submit", {"p_room": room, "p_score": score, "p_distance": distance})
	if r.ok and r.data is Dictionary and r.data.get("ok", false):
		coins = int(r.data.get("coins", coins))
		profile_changed.emit()
		var out: Dictionary = (r.data as Dictionary).duplicate()
		out["ok"] = true
		out["rank"] = int(r.data.get("rank", 0))
		out["reward"] = int(r.data.get("reward", 0))
		return out
	var e := ""
	var need := 0
	if r.data is Dictionary:
		e = String(r.data.get("error", ""))
		need = int(r.data.get("need", 0))
	return {"ok": false, "error": e if e != "" else r.error, "need": need}


func challenge_board(room: int, limit: int = 30) -> Array:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/comp_board", {"p_room": room, "p_limit": limit}, false)
	return r.data if (r.ok and r.data is Array) else []


## وضعیت من در رقابت: جام، لیگ، فصل، جایزه‌ی دیروز…
func comp_state() -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/comp_state", {})
	if r.ok and r.data is Dictionary and r.data.get("ok", false):
		comp_state_cache = r.data
		coins = int(r.data.get("coins", coins))
		profile_changed.emit()
		return r.data
	return {}


func comp_events_list() -> Array:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/comp_events_list", {})
	return r.data if (r.ok and r.data is Array) else []


func comp_season_board(limit: int = 50) -> Array:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/comp_season_board", {"p_limit": limit}, false)
	return r.data if (r.ok and r.data is Array) else []


func comp_create_room(title: String, modifier: String, hours: int, fee: int, is_public: bool) -> Dictionary:
	var r := await _rpc("comp_create_room", {"p_title": title, "p_modifier": modifier, "p_hours": hours, "p_entry_fee": fee, "p_public": is_public})
	if r.ok:
		coins = int(r.data.get("coins", coins))
		profile_changed.emit()
		return {"ok": true, "room": int(r.data.get("room", 0)), "error": ""}
	return {"ok": false, "error": r.error, "need": int(r.data.get("need", 0))}


func comp_claim_yesterday() -> Dictionary:
	var r := await _rpc("comp_claim_yesterday", {})
	if r.ok:
		coins = int(r.data.get("coins", coins))
		profile_changed.emit()
	return {"ok": r.ok, "data": r.data, "error": r.error}


## ابزار مدیر؛ action: create_event, end_room, delete_room, reset_board, remove_score, reduce_score, trophies, coins, ban, new_season
func comp_admin(action: String, args: Dictionary = {}) -> Dictionary:
	if not is_admin:
		return {"ok": false, "error": "forbidden"}
	var r := await _rpc("comp_admin", {"p_action": action, "p_args": args})
	return {"ok": r.ok, "data": r.data, "error": r.error}


## تنظیمات رقابت را برای همه ذخیره می‌کند (فقط مدیر)
func push_comp_config(d: Dictionary) -> Dictionary:
	if not is_admin:
		return {"ok": false, "error": "فقط مدیر می‌تواند"}
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/config?on_conflict=key", {"key": "competitive", "value": d}, true, false, PackedStringArray(["Prefer: resolution=merge-duplicates,return=minimal"]))
	if r.ok:
		comp_cfg = d
	return {"ok": r.ok, "error": r.error}


func claim_daily() -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/claim_daily", {})
	if r.ok and r.data is Dictionary:
		if r.data.get("ok", false):
			coins = int(r.data.coins)
			daily_ready = false
			profile_changed.emit()
		return r.data
	return {"ok": false, "error": r.error}


func claim_local_coins() -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/claim_local_coins", {"p_coins": Game.coins})
	if r.ok and r.data is Dictionary and r.data.get("ok", false):
		coins = int(r.data.coins)
		profile_changed.emit()
		return r.data
	return {"ok": false, "error": r.error if r.data == null else String((r.data as Dictionary).get("error", r.error))}


# ------------------------- فروشگاه -------------------------
func load_items() -> void:
	var r := await _req(HTTPClient.METHOD_GET, "/rest/v1/items?select=*&status=eq.approved&order=featured.desc,sort.asc,created_at.desc", null, logged_in())
	if r.ok and r.data is Array:
		items = r.data
		items_changed.emit()


## آیتم‌های مخصوص یک کاراکتر (انیمیشن/صدا): payload.char == key
func is_char_item(it: Dictionary) -> bool:
	var p = it.get("payload", {})
	return p is Dictionary and String(p.get("char", "")) != ""


func items_of_char(key: String, kind: String, source: Array = []) -> Array:
	var out: Array = []
	for it: Dictionary in (items if source.is_empty() else source):
		var p = it.get("payload", {})
		if p is Dictionary and String(p.get("char", "")) == key and String(it.kind) == kind:
			out.append(it)
	return out


# ------------------------- مدیریت آیتم (فقط مدیر) -------------------------
## همه‌ی آیتم‌های یک کاراکتر، حتی پنهان‌ها (مدیر)
func admin_load_char_items(key: String) -> Array:
	if not is_admin:
		return []
	var r := await _req(HTTPClient.METHOD_GET, "/rest/v1/items?select=*&payload-%3E%3Echar=eq." + key.uri_encode())
	var out: Array = []
	if r.ok and r.data is Array:
		for it in r.data:
			var p = it.get("payload", {})
			if p is Dictionary and String(p.get("char", "")) == key:
				out.append(it)
	return out


func admin_save_item(d: Dictionary) -> Dictionary:
	if not is_admin:
		return {"ok": false, "error": "فقط مدیر"}
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/items", d, true, false, PackedStringArray(["Prefer: return=representation"]))
	if r.ok and r.data is Array and not (r.data as Array).is_empty():
		return {"ok": true, "item": r.data[0], "error": ""}
	return {"ok": false, "error": r.error if r.error != "" else "ثبت نشد"}


func admin_patch_item(id: String, patch: Dictionary) -> Dictionary:
	if not is_admin:
		return {"ok": false, "error": "فقط مدیر"}
	var r := await _req(HTTPClient.METHOD_PATCH, "/rest/v1/items?id=eq." + id, patch, true, false, PackedStringArray(["Prefer: return=minimal"]))
	return {"ok": r.ok, "error": r.error}


func admin_upload(path: String, bytes: PackedByteArray, ctype: String, bucket: String = "item-files") -> Dictionary:
	if not is_admin or not enabled():
		return {"ok": false, "error": "فقط مدیر"}
	if bytes.size() <= SINGLE_MAX:
		return await _put_object(bucket, path, bytes, ctype)
	# فایل بزرگ: تکه‌تکه (path.part0001 …) + یک فایل فهرست در خود path؛ هنگام دانلود خودکار سرهم می‌شود
	var n := int(ceil(float(bytes.size()) / float(CHUNK)))
	for i in n:
		var part := bytes.slice(i * CHUNK, mini((i + 1) * CHUNK, bytes.size()))
		transfer.emit("آپلود بخش %d از %d…" % [i + 1, n])
		var r := {}
		for attempt in 3:
			r = await _put_object(bucket, "%s.part%04d" % [path, i + 1], part, "application/octet-stream")
			if r.ok:
				break
		if not r.ok:
			transfer.emit("")
			return {"ok": false, "error": "بخش %d از %d آپلود نشد؛ دوباره امتحان کن (%s)" % [i + 1, n, r.error]}
	var man := {"clownparts": 1, "n": n, "size": bytes.size(), "sha": _sha_hex(bytes)}
	var mr := await _put_object(bucket, path, JSON.stringify(man).to_utf8_buffer(), "application/json")
	transfer.emit("")
	mr["parts"] = n
	return mr


static func _sha_hex(bytes: PackedByteArray) -> String:
	var ctx := HashingContext.new()
	ctx.start(HashingContext.HASH_SHA256)
	var off := 0
	while off < bytes.size():
		ctx.update(bytes.slice(off, mini(off + 4 * 1024 * 1024, bytes.size())))
		off += 4 * 1024 * 1024
	return ctx.finish().hex_encode()


func _put_object(bucket: String, path: String, bytes: PackedByteArray, ctype: String) -> Dictionary:
	var r := await _put_object_once(bucket, path, bytes, ctype)
	# توکن ورود منقضی شده باشد، Storage به‌جای ۴۰۱ گاهی ۴۰۰ می‌دهد؛ یک‌بار تازه می‌کنیم و دوباره می‌فرستیم
	if not r.ok and int(r.get("code", 0)) in [400, 401] and refresh_token != "" and not _refreshing:
		if await _refresh():
			r = await _put_object_once(bucket, path, bytes, ctype)
	return r


func _put_object_once(bucket: String, path: String, bytes: PackedByteArray, ctype: String) -> Dictionary:
	var h := HTTPRequest.new()
	add_child(h)
	var headers := PackedStringArray(["apikey: " + anon_key, "Authorization: Bearer " + token, "Content-Type: " + ctype, "x-upsert: true"])
	var err := h.request_raw(url + "/storage/v1/object/" + bucket + "/" + path.uri_encode().replace("%2F", "/"), headers, HTTPClient.METHOD_POST, bytes)
	if err != OK:
		h.queue_free()
		return {"ok": false, "error": "اتصال برقرار نشد"}
	var res: Array = await h.request_completed
	h.queue_free()
	var ok: bool = res[0] == HTTPRequest.RESULT_SUCCESS and int(res[1]) >= 200 and int(res[1]) < 300
	var why := ""
	if not ok:
		why = "آپلود ناموفق (%d)" % int(res[1])
		if int(res[1]) == 413:
			why = "فایل از سقف سرور بزرگ‌تر است (413)"
		# متن خطای خود سرور (مثلاً «Bucket not found» یا «violates row-level security»)
		var body: PackedByteArray = res[3] if res.size() > 3 else PackedByteArray()
		if body.size() > 0:
			var jj = JSON.parse_string(body.get_string_from_utf8())
			var sm := ""
			if jj is Dictionary:
				sm = String((jj as Dictionary).get("message", (jj as Dictionary).get("error", "")))
			else:
				sm = body.get_string_from_utf8().left(120)
			if sm != "":
				why += " — " + sm.left(160)
	return {"ok": ok, "error": why, "code": int(res[1])}


## یک آبجکت Storage را به فایل محلی می‌ریزد؛ اگر «فهرست تکه‌ها» باشد همه‌ی تکه‌ها را می‌گیرد و پشت هم می‌چسباند.
## public=true: بدون ورود (باکت عمومی). خروجی: {ok, error, size}
func fetch_object_to_file(bucket: String, path: String, local: String, public: bool = false) -> Dictionary:
	var first := await _get_object(bucket, path, public)
	if not first.ok:
		return first
	var data: PackedByteArray = first.data
	var man: Dictionary = {}
	if data.size() < 600 and data.size() > 0 and data[0] == 0x7b and data.get_string_from_utf8().begins_with("{\"clownparts\""):
		var j = JSON.parse_string(data.get_string_from_utf8())
		if j is Dictionary and int(j.get("n", 0)) > 0:
			man = j
	var f := FileAccess.open(local + ".tmp", FileAccess.WRITE)
	if f == null:
		return {"ok": false, "error": "ذخیره‌ی فایل ممکن نشد"}
	var total := 0
	if man.is_empty():
		f.store_buffer(data)
		total = data.size()
	else:
		var n := int(man.n)
		if int(man.get("size", 0)) > MAX_DOWNLOAD:
			f.close()
			return {"ok": false, "error": "فایل خیلی بزرگ است"}
		for i in n:
			transfer.emit("دانلود بخش %d از %d…" % [i + 1, n])
			var r := await _get_object(bucket, "%s.part%04d" % [path, i + 1], public)
			if not r.ok:
				f.close()
				DirAccess.remove_absolute(local + ".tmp")
				transfer.emit("")
				return {"ok": false, "error": "بخش %d از %d دانلود نشد (%s)" % [i + 1, n, r.error]}
			f.store_buffer(r.data)
			total += (r.data as PackedByteArray).size()
		transfer.emit("")
	f.close()
	if not man.is_empty():
		if total != int(man.get("size", total)):
			DirAccess.remove_absolute(local + ".tmp")
			return {"ok": false, "error": "فایل سرهم‌شده ناقص است؛ دوباره امتحان کن"}
		var want := String(man.get("sha", ""))
		if want != "" and _sha_file(local + ".tmp") != want:
			DirAccess.remove_absolute(local + ".tmp")
			return {"ok": false, "error": "فایل سرهم‌شده خراب است؛ دوباره امتحان کن"}
	if FileAccess.file_exists(local):
		DirAccess.remove_absolute(local)
	DirAccess.rename_absolute(local + ".tmp", local)
	return {"ok": true, "error": "", "size": total}


static func _sha_file(path: String) -> String:
	return FileAccess.get_sha256(path)


func _get_object(bucket: String, path: String, public: bool) -> Dictionary:
	var enc := path.uri_encode().replace("%2F", "/")
	var last := {}
	for attempt in 3:
		var h := HTTPRequest.new()
		h.timeout = 300.0
		h.accept_gzip = false
		add_child(h)
		var headers := PackedStringArray(["apikey: " + anon_key])
		var mode := "public" if public else "authenticated"
		if not public and token != "":
			headers.append("Authorization: Bearer " + token)
		elif not anon_key.begins_with("sb_"):
			headers.append("Authorization: Bearer " + anon_key)
		_set_busy(1)
		var err := h.request(url + "/storage/v1/object/%s/%s/%s" % [mode, bucket, enc], headers)
		if err != OK:
			h.queue_free()
			_set_busy(-1)
			last = {"ok": false, "error": "اتصال برقرار نشد"}
			continue
		var res: Array = await h.request_completed
		h.queue_free()
		_set_busy(-1)
		if res[0] != HTTPRequest.RESULT_SUCCESS:
			last = {"ok": false, "error": "اینترنت در دسترس نیست"}
			continue
		if int(res[1]) >= 200 and int(res[1]) < 300:
			return {"ok": true, "error": "", "data": res[3]}
		last = {"ok": false, "error": "خطا %d" % int(res[1])}
		if int(res[1]) in [400, 401, 403, 404]:
			break
	return last


func price_of(it: Dictionary) -> int:
	return (int(it.get("price", 0)) * (100 - int(it.get("discount_percent", 0)))) / 100


func is_owned(it: Dictionary) -> bool:
	return owned.has(String(it.id))


func item_state(it: Dictionary) -> String:
	## owned | expired | sold_out | locked
	if is_owned(it):
		return "owned"
	var ends := s(it.get("ends_at", ""))
	if ends != "" and Time.get_unix_time_from_datetime_string(ends.left(19)) < Time.get_unix_time_from_system():
		return "expired"
	if it.get("stock") != null and int(it.stock) <= 0:
		return "sold_out"
	return "locked"


func buy(it: Dictionary) -> Dictionary:
	var r := await _req(HTTPClient.METHOD_POST, "/rest/v1/rpc/buy_item", {"p_item": String(it.id)})
	if r.ok and r.data is Dictionary:
		if r.data.get("ok", false):
			coins = int(r.data.coins)
			owned[String(it.id)] = true
			profile_changed.emit()
			items_changed.emit()
		return r.data
	return {"ok": false, "error": r.error}


func error_text(code: String, need: int = 0) -> String:
	match code:
		"no_coins": return "سکه‌ات کافی نیست (%d سکه‌ی دیگر لازم است)" % need
		"owned": return "این آیتم را قبلاً خریده‌ای"
		"sold_out": return "موجودی تمام شد"
		"expired": return "زمان فروش این آیتم تمام شده"
		"not_logged_in": return "اول وارد حساب شو"
		"banned": return "حساب شما مسدود است"
		"implausible": return "نتیجه‌ی بازی معتبر نبود"
		"max_level": return "به آخرین سطح رسیده‌ای!"
		"too_fast": return "خیلی سریع؛ کمی صبر کن"
		"bad_room": return "کد اتاق باید یک عدد ۴ تا ۹ رقمی باشد"
		"room_expired": return "این چالش روزانه تمام شده است"
		"no_tries": return "تعداد دفعات مجاز این رقابت تمام شد"
		"no_room": return "این اتاق وجود ندارد"
		"not_started": return "این رویداد هنوز شروع نشده"
		"room_ended": return "این رویداد تمام شده است"
		"comp_off": return "بخش رقابت فعلاً غیرفعال است"
		"too_many_rooms": return "حداکثر ۳ اتاق باز هم‌زمان می‌توانی داشته باشی"
		"rooms_full": return "ظرفیت اتاق‌های باز پر است؛ کمی بعد"
		"no_user": return "بازیکنی با این نام نیست"
		"forbidden": return "فقط مدیر"
		"no_score": return "این بازیکن در این اتاق امتیازی ندارد"
		"nothing": return "جایزه‌ای برای دریافت نیست"
		"already": return "قبلاً دریافت کرده‌ای"
		_: return code if " " in code else "خطا: " + code


## تصویر پیش‌نمایش (عمومی)؛ در حافظه و روی دیسک ذخیره می‌شود
func preview(it: Dictionary) -> Texture2D:
	var path := s(it.get("preview_path", ""))
	if path == "":
		return null
	if _tex_cache.has(path):
		return _tex_cache[path]
	var local := CACHE_DIR + path.replace("/", "_")
	var img := Image.new()
	var ok := false
	if FileAccess.file_exists(local):
		ok = img.load(local) == OK
	if not ok:
		var r := await _req(HTTPClient.METHOD_GET, "/storage/v1/object/public/previews/" + path, null, false, true)
		if r.ok:
			var bytes: PackedByteArray = r.data
			var f := FileAccess.open(local, FileAccess.WRITE)
			if f:
				f.store_buffer(bytes)
				f.close()
			ok = img.load(local) == OK
	if not ok:
		return null
	var t := ImageTexture.create_from_image(img)
	_tex_cache[path] = t
	return t


## پیش‌نمایشِ قفل‌شده: نسخه‌ی عمومیِ فایل آیتم (payload.pv در باکت previews) را می‌گیرد و مسیر محلی را برمی‌گرداند.
## اگر آیتم را داری و فایل اصلی دانلود شده باشد همان استفاده می‌شود. اگر نسخه‌ای برای پیش‌نمایش نباشد "".
func preview_file(it: Dictionary) -> String:
	if it.has("_local"):
		return String(it["_local"])          # پیش‌نمایش پیش از انتشار (ابزار مالک)
	var pl = it.get("payload", {})
	var pv: String = String(pl.get("pv", "")) if pl is Dictionary else ""
	var fp := s(it.get("file_path", ""))
	if fp != "":
		var own := ITEM_DIR + String(it.id) + "." + fp.get_extension()
		if FileAccess.file_exists(own):
			return own
	if pv == "":
		return ""
	var dir := "user://prev_cache/"
	DirAccess.make_dir_recursive_absolute(dir)
	var local := dir + pv.replace("/", "_")
	if FileAccess.file_exists(local):
		return local
	var r := await fetch_object_to_file("previews", pv, local, true)
	return local if r.ok else ""


## فایل اصلیِ یک آیتم خریداری‌شده را می‌گیرد و در بازی نصب می‌کند
func install(it: Dictionary) -> Dictionary:
	if not is_owned(it):
		return {"ok": false, "error": "اول باید بخری"}
	var pl0 = it.get("payload", {})
	var is_pack: bool = pl0 is Dictionary and bool(pl0.get("pack", false))
	if String(it.kind) == "anim_clip" and not is_pack:       # بدون فایل: کلیپ از خودِ مدل کاراکتر است
		return apply_item_file(it, "")
	var path := s(it.get("file_path", ""))
	var local := ITEM_DIR + String(it.id) + "." + path.get_extension()
	if not FileAccess.file_exists(local):
		var r := await fetch_object_to_file("item-files", path, local, false)
		if not r.ok:
			return {"ok": false, "error": "دانلود نشد (%s)" % r.error}
	return apply_item_file(it, local)


## فایلِ دانلودشده‌ی یک آیتم را بر اساس «نوع» در بازی اعمال می‌کند (برای آزمایش بدون شبکه هم قابل‌فراخوانی است)
func apply_item_file(it: Dictionary, local: String) -> Dictionary:
	var nm := s(it.get("name", "آیتم"))
	var payload = it.get("payload", {})
	if not payload is Dictionary:
		payload = {}
	match String(it.kind):
		"skin":
			var img := Image.load_from_file(local)
			if img == null:
				return {"ok": false, "error": "تصویر خراب است"}
			var serr := Skins.add_image(img, nm)
			if serr != "":
				return {"ok": false, "error": serr}
			return {"ok": true, "message": "اسکین «%s» اضافه و انتخاب شد" % nm}
		"anim_clip":
			var pl: Dictionary = payload
			var cname := String(pl.get("clip", nm))
			if bool(pl.get("pack", false)):          # انیمیشن گرفته‌شده از فایل کاراکترِ دیگر
				var pk := AnimPack.parse(FileAccess.get_file_as_string(local))
				if pk.is_empty():
					return {"ok": false, "error": "بسته‌ی انیمیشن معتبر نیست"}
				AnimPack.save(String(it.id), pk)
				cname = "pack:" + String(it.id)
			Rules.library_add({"id": String(it.id), "kind": "anim", "name": nm, "char": String(pl.get("char", "")), "clip": cname})
			return {"ok": true, "message": "انیمیشن «%s» اضافه شد؛ در «صدا و انیمیشن‌ها» برای حرکتی که می‌خواهی انتخابش کن" % nm}
		"glb":
			var gerr := Skins.add_glb(local, nm)
			if gerr != "":
				return {"ok": false, "error": gerr}
			Skins.set_origin(Skins.current_id, String(it.id))
			for i in int(it.get("glb_yaw", 0)):
				Skins.cycle_glb_yaw()
			return {"ok": true, "message": "مدل «%s» اضافه و انتخاب شد" % nm}
		"coin":
			var cimg := Image.load_from_file(local)
			if cimg == null:
				return {"ok": false, "error": "تصویر خراب است"}
			var cerr := CoinSkin.set_image(cimg)
			if cerr != "":
				return {"ok": false, "error": cerr}
			CoinSkin.select_design(CoinSkin.PHOTO)
			CoinSkin.save_draft()
			return {"ok": true, "message": "طرح سکه «%s» روی همه‌ی سکه‌های بازی اعمال شد" % nm}
		"police":
			var perr := PoliceCfg.set_bought_model(local, int(it.get("glb_yaw", 0)))
			if perr != "":
				return {"ok": false, "error": perr}
			return {"ok": true, "message": "ظاهر «%s» برای تعقیب‌کننده اعمال شد" % nm}
		"voice", "chaser_voice":
			var vn := Rules.import_voice(local, String(it.id))
			if vn == "":
				return {"ok": false, "error": "فایل صوتی معتبر نیست"}
			Rules.library_add({"id": String(it.id), "kind": "voice", "name": nm, "arg": vn, "hint": String(payload.get("event", "")), "char": String(payload.get("char", "")), "for": "chaser" if String(it.kind) == "chaser_voice" else ""})
			return {"ok": true, "message": "صدای «%s» به کتابخانه‌ات اضافه شد؛ در «صدا و انیمیشن‌ها» انتخابش کن" % nm}
		"music":
			var mm := Music.import_track(local)
			if mm != "":
				return {"ok": false, "error": mm}
			var mchar := String(payload.get("char", ""))
			if mchar != "" and Music.last_import != "":
				Music.set_char_choice(mchar, Music.last_import)
				return {"ok": true, "message": "آهنگ «%s» برای «%s» انتخاب شد؛ هنگام بازی با او پخش می‌شود" % [nm, String(payload.get("char_name", "کاراکتر"))]}
			return {"ok": true, "message": "آهنگ «%s» به لیست موسیقی‌ات اضافه شد؛ در تنظیمات (موسیقی) انتخابش کن" % nm}
		"anim", "chaser_anim":
			var pack := Rules.parse_pack(FileAccess.get_file_as_string(local))
			if pack.is_empty():
				return {"ok": false, "error": "بسته‌ی انیمیشن معتبر نیست"}
			Rules.library_add({"id": String(it.id), "kind": "anim", "name": nm, "rules": pack, "for": "chaser" if String(it.kind) == "chaser_anim" else ""})
			return {"ok": true, "message": "انیمیشن «%s» به کتابخانه‌ات اضافه شد؛ در «صدا و انیمیشن‌ها» انتخابش کن" % nm}
	# نوع تازه (هنوز کدی برایش نیست): فایل فقط ذخیره می‌شود
	return {"ok": true, "message": "«%s» ذخیره شد (این نوع هنوز عملکردی ندارد)" % nm}
